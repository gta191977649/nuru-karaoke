import{f as sn,r as g,j as t,R as Pe,g as X,h as A,o as D,q as xs,t as Ln,B as Fr,u as Rr,v as Zn,x as at,T as Br,y as Cn,z as ai,G as Bs,U as Ar,H as Pr,I as Er,J as _s,N as Mt,O as $t,P as tr,Q as nr,V as Lr,W as Ir,X as Dr}from"./vendor-Ukah3R8y.js";import{P as sr,T as bs,a as ir,b as Hr,A as rr,G as _t,C as As,B as Or,c as Gr,S as zr,_ as qr}from"./pixi-DxEaCaAv.js";import{p as Kr,W as Vr,S as Wr}from"./spessasynth-BZZ1ZHIs.js";import{P as $r,a as rs}from"./audio-DrEsh_Xl.js";import{l as Ur,t as Xr,a as Yr,m as Qr,s as Jr,n as Zr,d as ea,b as ar,c as ta,e as na,r as sa,f as ia,g as ra}from"./tfjs-8lzJC7f7.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const a of r)if(a.type==="childList")for(const o of a.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function n(r){const a={};return r.integrity&&(a.integrity=r.integrity),r.referrerPolicy&&(a.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?a.credentials="include":r.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function i(r){if(r.ep)return;r.ep=!0;const a=n(r);fetch(r.href,a)}})();const aa="https://raku-sound.okamei.net",Ps=aa,Es=Ps.endsWith("/")?Ps.slice(0,-1):Ps;function Nt(s){return Es?s.startsWith("/")?`${Es}${s}`:`${Es}/${s}`:s}async function Xn(s={}){const e=new URLSearchParams;s.q&&e.set("q",s.q),s.artist&&e.set("artist",s.artist),s.artistQ&&e.set("artist_q",s.artistQ),s.titleQ&&e.set("title_q",s.titleQ),s.tag&&e.set("tag",s.tag),s.language&&e.set("language",s.language),s.page&&e.set("page",String(s.page)),s.pageSize&&e.set("page_size",String(s.pageSize));const n=e.toString(),i=n?`/api/songs/?${n}`:"/api/songs/",r=await fetch(Nt(i),{method:"GET",signal:s.signal});if(!r.ok)throw new Error(`Failed to load songs (${r.status})`);if(!(r.headers.get("content-type")||"").includes("application/json")){const l=await r.text();throw new Error(`Unexpected response for songs API. ${l.slice(0,120)}`)}const o=await r.json();return Array.isArray(o)?{items:o,count:o.length,next:null,previous:null}:Array.isArray(o?.results)?{items:o.results,count:o.count??o.results.length,next:o.next,previous:o.previous}:{items:[],count:0,next:null,previous:null}}async function oa(s,e={}){if(!s)throw new Error("Song code required");const n=await fetch(Nt(`/api/songs/${encodeURIComponent(s)}/`),{method:"GET",signal:e.signal});if(!n.ok)throw new Error(`Failed to load song (${n.status})`);if(!(n.headers.get("content-type")||"").includes("application/json"))throw new Error("Unexpected response for song API");return n.json()}async function ca(s={}){const e=await fetch(Nt("/api/tags"),{method:"GET",signal:s.signal});if(!e.ok)throw new Error(`Failed to load tags (${e.status})`);if(!(e.headers.get("content-type")||"").includes("application/json")){const r=await e.text();throw new Error(`Unexpected response for tags API. ${r.slice(0,120)}`)}const i=await e.json();return Array.isArray(i)?i:Array.isArray(i?.results)?i.results:[]}const V={home:"home",findSongs:"findSongs",myRoom:"myRoom",moreModes:"moreModes",mySongs:"mySongs",settings:"settings",comfirmSongs:"confirmSongs",karaoke:"karaoke",queue:"queue",findSongKeywords:"findSongKeywords",leaderboard:"leaderboard",auth:"auth",artist:"artist"},xt=sn(s=>({screen:V.home,selectedArtist:"",songSearchMode:"title",artistReturnScreen:V.home,songDetailReturnScreen:V.findSongs,karaokeActive:!0,karaokeMini:!0,setScreen:e=>s({screen:e}),openSongSearch:(e="title")=>s(n=>({screen:V.findSongs,songSearchMode:e,karaokeMini:n.karaokeActive?!0:n.karaokeMini})),setSongDetailReturnScreen:e=>s({songDetailReturnScreen:e}),openArtist:e=>s(n=>({screen:V.artist,selectedArtist:String(e||"").trim(),artistReturnScreen:n.screen===V.artist?n.artistReturnScreen:n.screen,karaokeMini:n.karaokeActive?!0:n.karaokeMini})),closeArtist:()=>s(e=>({screen:e.artistReturnScreen||V.home,karaokeMini:e.artistReturnScreen===V.karaoke?!1:e.karaokeMini})),setKaraokeActive:e=>s({karaokeActive:e}),setKaraokeMini:e=>s({karaokeMini:e}),openKaraoke:()=>s({screen:V.karaoke,karaokeActive:!0,karaokeMini:!1})})),la=[["1","2","3","4","5","6","7","8","9","0"],["Q","W","E","R","T","Y","U","I","O","P"],["A","S","D","F","G","H","J","K","L"],["Z","X","C","V","B","N","M"]];function Ls(s){return String(s??"").trim().toLowerCase()}function ua({initialMode:s="title",onBack:e,onSelectSong:n}){const i=xt(S=>S.openArtist),[r,a]=g.useState(s==="artist"?"":"Pretender"),[o,l]=g.useState(!1),[d,m]=g.useState(s),[u,h]=g.useState([]),[c,f]=g.useState(!1),[b,p]=g.useState("");g.useEffect(()=>{const S=r.trim();if(!S){const _=window.setTimeout(()=>{h([]),f(!1),p("")},0);return()=>window.clearTimeout(_)}const N=new AbortController;let w=!1;const v=window.setTimeout(()=>{f(!0),p(""),Xn({signal:N.signal,pageSize:50,artistQ:d==="artist"?S:void 0,titleQ:d==="title"?S:void 0}).then(_=>{w||h(Array.isArray(_?.items)?_.items:[])}).catch(_=>{w||p(_?.message||"Failed to load songs.")}).finally(()=>{w||f(!1)})},180);return()=>{w=!0,window.clearTimeout(v),N.abort()}},[d,r]);const x=g.useMemo(()=>{const S=Ls(r);if(!S)return[];const N=u.filter(w=>{const v=d==="artist"?w.artist:w.title;return Ls(v).includes(S)});return d==="artist"?[...new Map(N.map(w=>[Ls(w.artist),w])).values()].slice(0,3):N.slice(0,3)},[d,u,r]);return t.jsxs("div",{className:"wiiFind",children:[t.jsxs("div",{className:"wiiFind__header",children:[t.jsx("div",{className:"wiiFind__hint",children:"Enter a search term to find an original artist or song."}),c?t.jsx("div",{className:"wiiFind__hint text-muted",children:"Loading songs…"}):null,b?t.jsx("div",{className:"wiiFind__hint text-danger",children:b}):null]}),t.jsxs(Pe,{className:"g-3",children:[t.jsxs(X,{xs:12,lg:9,children:[t.jsxs("div",{className:"wiiFind__inputRow",children:[t.jsx(A.Control,{className:"wiiFind__input",value:r,onChange:S=>{if(o){a(S.target.value);return}a(S.target.value.toUpperCase())},onCompositionStart:()=>l(!0),onCompositionEnd:S=>{l(!1),a(S.target.value)},autoComplete:"off",spellCheck:!1}),t.jsxs(D,{className:"wiiFind__delete",type:"button",onClick:()=>a(S=>S.length?S.slice(0,-1):S),"aria-label":"Delete",children:[t.jsx("span",{className:"wiiFind__deleteX","aria-hidden":"true",children:"×"}),"Delete"]})]}),t.jsx("div",{className:"wiiKeyboard",role:"group","aria-label":"On-screen keyboard",children:t.jsxs(xs,{gap:2,children:[la.map((S,N)=>t.jsx("div",{className:"wiiKeyboard__row",children:S.map(w=>t.jsx(D,{className:"wiiKey",type:"button",onClick:()=>a(v=>`${v}${w}`),children:w},w))},N)),t.jsx(D,{className:"wiiKey wiiKey--space",type:"button",onClick:()=>a(S=>`${S} `),children:"Space"})]})}),t.jsxs(Pe,{className:"g-3 mt-2",children:[t.jsx(X,{xs:12,md:6,children:t.jsxs(D,{className:"wiiSearchBtn wiiSearchBtn--artist w-100",type:"button",onClick:()=>m("artist"),children:[t.jsx("span",{className:"wiiSearchBtn__icon","aria-hidden":"true"}),t.jsx("span",{className:"wiiSearchBtn__label",children:"Search Artist"})]})}),t.jsx(X,{xs:12,md:6,children:t.jsxs(D,{className:"wiiSearchBtn wiiSearchBtn--title w-100",type:"button",onClick:()=>m("title"),children:[t.jsx("span",{className:"wiiSearchBtn__icon wiiSearchBtn__icon--note","aria-hidden":"true"}),t.jsx("span",{className:"wiiSearchBtn__label",children:"Search Title"})]})})]})]}),t.jsx(X,{xs:12,lg:3,children:t.jsxs("div",{className:"wiiSuggest",children:[t.jsx("div",{className:"wiiSuggest__title",children:"もしかして..."}),t.jsx(xs,{gap:2,children:x.length?x.map(S=>t.jsxs(D,{className:"wiiSuggest__item",type:"button",onClick:()=>{if(d==="artist"){i(S.artist);return}n?n(S):a((d==="artist"?S.artist:S.title).toUpperCase())},title:d==="artist"?S.artist:S.title,children:[t.jsx("span",{className:"wiiSuggest__note","aria-hidden":"true",children:"♪"}),t.jsx("span",{className:"wiiSuggest__text",children:d==="artist"?S.artist:S.title})]},`${S.artist}-${S.title}`)):t.jsx("div",{className:"wiiSuggest__empty",children:"Type to see suggestions"})})]})})]}),t.jsx("div",{className:"wiiFind__bottom",children:t.jsxs("div",{className:"wiiFind__bottomLeft",children:[t.jsx(D,{className:"wiiBottomMini wiiBottomMini--dark",type:"button",onClick:e,children:"Back"}),t.jsx(D,{className:"wiiBottomMini wiiBottomMini--dark",type:"button",onClick:e,children:"Main Menu"})]})})]})}const da={ready:!1,status:"Initializing…",engineLoadStage:"starting",engineLoadError:"",soundFontName:"GM",midiUrl:"",midiName:"",isPlaying:!1,currentTime:0,duration:0,reverbGain:1.5,chorusGain:1.2,enableMIDIStandardMapping:!0,transposition:0,queue:[],queueIndex:-1,playbackSessionId:0,history:[],enabledChannels:Array.from({length:16},()=>!0),channelInstrumentNames:Array.from({length:16},(s,e)=>e===9?"Drums":"—"),midiChannels:Array.from({length:16},(s,e)=>({channel:e,isDrum:e===9,program:0,bankMSB:0,bankLSB:0,name:e===9?"Drums":"—"})),channelActivityVelocity:Array.from({length:16},()=>0),channelActivityTime:Array.from({length:16},()=>-1),polyphonyCount:0,xgDrumMapEnabled:!0,xgPreferGsPlayback:!0,smfKnifeConfigName:"",smfKnifeSource:"",smfKnifeDestination:"",xgDrumMapState:{globalMode:"unknown",detectedBy:null,xgBankSelectPairs:0,drumChannels:Array.from({length:16},()=>!1),brushChannels:Array.from({length:16},()=>!1),bankMSB:Array.from({length:16},()=>-1),bankLSB:Array.from({length:16},()=>-1)}},ha={pendingSong:null,lrcName:"",lrcEntries:[],lyricOffsetMs:0,activeLyricIndex:-1,karaokeProgress:0,lastIntroMidiUrl:"",karaokeView:"message"},Be=sn(s=>({...da,...ha,setPendingSong:e=>s({pendingSong:e||null}),clearPendingSong:()=>s({pendingSong:null}),setLyrics:e=>s({lrcName:e?.lrcName||"",lrcEntries:Array.isArray(e?.lrcEntries)?e.lrcEntries:[]}),setLyricOffsetMs:e=>s({lyricOffsetMs:Number(e)||0}),setKaraokeState:e=>s({activeLyricIndex:Number.isFinite(e?.activeLyricIndex)?e.activeLyricIndex:-1,karaokeProgress:Number.isFinite(e?.karaokeProgress)?e.karaokeProgress:0}),setLastIntroMidiUrl:e=>s({lastIntroMidiUrl:e||""}),setKaraokeView:e=>s({karaokeView:e==="results"?"results":e==="message"?"message":"singing"}),resetLyrics:()=>s({lrcName:"",lrcEntries:[],lyricOffsetMs:0,activeLyricIndex:-1,karaokeProgress:0})})),qe=()=>Be.getState(),cn=s=>Be.setState(s);function or(s){const e=s.match(/^\[(\d{1,3}):(\d{2})(?:\.(\d{1,3}))?\]$/);if(!e)return null;const n=Number(e[1]),i=Number(e[2]),r=e[3]??"0",a=r.length===3?Number(r):r.length===2?Number(r)*10:Number(r)*100;return!Number.isFinite(n)||!Number.isFinite(i)||!Number.isFinite(a)?null:n*60+i+a/1e3}function $n(s,e){if(!e?.text)return;const n=s[s.length-1];if(n&&!n.ruby&&!e.ruby&&n.falsetto===e.falsetto){n.text+=e.text;return}s.push(e)}const ma=[["予よ","予","よ"],["想そう","想","そう"],["通どお","通","どお"],["僕ぼく","僕","ぼく"],["何なに","何","なに"],["綺き","綺","き"],["麗れい","麗","れい"],["否いな","否","いな"],["難がた","難","がた"],["痛いた","痛","いた"],["甘あま","甘","あま"]];function wn(s,e,n){if(!e)return;let i=0,r="";for(;i<e.length;){const a=ma.find(([o])=>e.startsWith(o,i));if(!a){r+=e[i],i+=1;continue}r&&($n(s,{text:r,ruby:"",falsetto:n}),r=""),$n(s,{text:a[1],ruby:a[2],falsetto:n}),i+=a[0].length}r&&$n(s,{text:r,ruby:"",falsetto:n})}function fa(s,e,n,i){if(!e)return;const r=e.match(/[A-Za-z][A-Za-z0-9'-]*$/);if(r){const l=r[0],d=e.slice(0,e.length-l.length);d&&wn(s,d,i),$n(s,{text:l,ruby:n,falsetto:i});return}const a=e.slice(0,-1),o=e.slice(-1);a&&wn(s,a,i),o&&$n(s,{text:o,ruby:n,falsetto:i})}function Ss(s){const e=String(s??""),n=[];let i=0,r=!1;for(;i<e.length;){const a=e.indexOf("<",i),o=e.indexOf("{",i),l=a>=0,d=o>=0,m=l&&d?Math.min(a,o):l?a:d?o:-1;if(m===-1){wn(n,e.slice(i),r);break}if(m===a){const h=e.indexOf(">",a+1);if(h===-1){wn(n,e.slice(i),r);break}const c=e.slice(i,a),f=e.slice(a+1,h);fa(n,c,f,r),i=h+1;continue}const u=e.slice(i,o);if(u&&wn(n,u,r),e.startsWith("{f}",o)){r=!0,i=o+3;continue}if(e.startsWith("{/f}",o)){r=!1,i=o+4;continue}wn(n,"{",r),i=o+1}return{segments:n,plainText:n.map(a=>a.text).join(""),hasRuby:n.some(a=>!!a.ruby)}}function ga(s,e,n){if(!e.length)return null;const i=[];let r=null,a=null,o=0;const l=s.slice(0,e[0].index),d=[];for(let h=0;h<e.length;h+=1){const c=e[h],f=or(c[0]);if(f==null)continue;const b=c.index+c[0].length,p=e[h+1]?.index??s.length;let x=s.slice(b,p);h===0&&l&&(x=`${l}${x}`);const S=h===e.length-1;if(!x&&S){a=Math.max(0,f+n);continue}if(!x.trim()&&S&&(a=Math.max(0,f+n),!x))continue;const N=Math.max(0,f+n);r==null&&(r=N),d.push(x);const v=Ss(x).plainText,_=/\S/u.test(v)?1:0;i.push({time:N,text:v,weight:_,weightStart:o}),o+=_}if(!i.length||r==null)return null;const m=d.join(""),u=Ss(m);return{time:r,text:m,plainText:u.plainText,segments:u.segments,hasRuby:u.hasRuby,tokens:i,tokenTotalWeight:o,endTime:a}}function ys(s){const e=String(s??"").replace(/\r\n/g,`
`).split(`
`),n=[];let i=0;for(const a of e){const o=a.trimEnd();if(!o)continue;const l=o.match(/^\[offset:([+-]?\d+)\]$/i);if(l){const f=Number(l[1]);Number.isFinite(f)&&(i=f/1e3);continue}if(/^\[[a-z]{2,}:[^\]]*\]$/i.test(o)&&!/^\[\d/.test(o))continue;const d=[...o.matchAll(/\[\d{1,3}:\d{2}(?:\.\d{1,3})?\]/g)];if(!d.length)continue;let m=!1,u=0;for(const f of d){const b=o.slice(u,f.index);if(/\S/.test(b)){m=!0;break}u=f.index+f[0].length}if(m){const f=ga(o,d,i);f&&n.push(f);continue}const h=o.replace(/\[\d{1,3}:\d{2}(?:\.\d{1,3})?\]/g,"").trim(),c=Ss(h);for(const f of d){const b=or(f[0]);b!=null&&n.push({time:Math.max(0,b+i),text:h,plainText:c.plainText,segments:c.segments,hasRuby:c.hasRuby})}}n.sort((a,o)=>a.time-o.time);const r=[];for(const a of n){const o=r[r.length-1];o&&o.time===a.time?r[r.length-1]=a:r.push(a)}return r}function pa(s,e){if(!s?.length||!Number.isFinite(e))return-1;let n=0,i=s.length-1;if(e<s[0].time)return-1;for(;n<=i;){const r=n+i>>1,a=s[r].time;if(a===e)return r;a<e?n=r+1:i=r-1}return Math.max(0,n-1)}const Ot=sn(s=>({alert:null,visible:!1,showAlert:({message:e,variant:n="primary",timeoutMs:i=0})=>s({alert:{message:e,variant:n,timeoutMs:i},visible:!0}),hideAlert:()=>s({visible:!1}),clearAlert:()=>s({alert:null,visible:!1})}));function cr({show:s,title:e,message:n,children:i,showActions:r=!0,confirmLabel:a="確認",cancelLabel:o="取消",onConfirm:l,onCancel:d,onClose:m}){return t.jsxs(Ln,{show:s,centered:!0,backdrop:"static",keyboard:!1,onHide:m,children:[t.jsx(Ln.Header,{children:t.jsx(Ln.Title,{className:"w-100 text-center",children:e})}),t.jsx(Ln.Body,{className:"text-center",children:i||t.jsx("div",{className:"fw-semibold",children:n})}),r?t.jsxs(Ln.Footer,{className:"w-100 justify-content-between",children:[t.jsx(D,{variant:"secondary",className:"px-4",type:"button",onClick:d,children:o}),t.jsx(D,{variant:"warning",className:"px-4",type:"button",onClick:l,children:a})]}):null]})}const xa="/assets/sc55-zAX-Epjw.sf2",Ie={XG:"XG",GS:"GS",GM:"GM",GM2:"GM2",SMF:"SMF"},ba=[67,null,76,0,0,126,0],Sa=[126,127,9,3],ya=[126,127,9,1],Na=[65,null,66,18,64,0,127,0];function wa(s){return s?.length>=8&&s[0]===65&&s[2]===66&&s[3]===18}function as(s,e){if(!s||s.length<e.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!==null&&s[n]!==e[n])return!1;return!0}function ln(s,e){s.includes(e)||s.push(e)}function lr(s){if(!s||s.length===0)return s;let e=s;return e[0]===240&&(e=e.slice(1)),e[e.length-1]===247&&(e=e.slice(0,-1)),e}function va(s,e){if(s!==64&&s!==80||(e&240)!==16)return-1;let n=-1;return e===16?n=9:e>=17&&e<=25?n=e-17:e>=26&&e<=31&&(n=e-26+10),n<0?-1:(s===80&&(n+=16),n)}function Ni(s){return!s||!s.length?"":Array.from(s,e=>e.toString(16).padStart(2,"0").toUpperCase()).join(" ")}function _a(s){const e=new DataView(s);let n=0;if(e.getUint32(n)!==1297377380)return null;n+=4;const i=e.getUint32(n);n+=4;const r=e.getUint16(n);n+=2;const a=e.getUint16(n);n+=2;const o=e.getUint16(n);n+=2,n+=Math.max(0,i-6);const l={format:r,division:o,xg:!1,gs:!1,gm2:!1,gm:!1,gs_sc88ish:!1,noteActivity:0,drumActivity:0,lastCC0ByChan:new Uint8Array(16),sawMapSelectLike:!1,mapSelectValues:new Set,sawRolandDT1:!1,sawAddr50:!1,sawEFXBlock:!1,sawLarge29:!1,total29:0,reasons:[]},d=()=>{let m=0,u;do{if(n>=s.byteLength)return 0;u=e.getUint8(n++),m=m<<7|u&127}while(u&128);return m>>>0};for(let m=0;m<a&&!(n+8>s.byteLength||e.getUint32(n)!==1297379947);m++){n+=4;const u=e.getUint32(n);n+=4;const h=Math.min(s.byteLength,n+u);let c=0;for(;n<h&&(d(),!(n>=h));){let f=e.getUint8(n);f&128?(n++,c=f):f=c;const b=f&240,p=f&15;if(f===255){if(n>=h)break;n++;const x=d();n=Math.min(h,n+x);continue}if(f===240||f===247){const x=d(),S=new Uint8Array(s,n,Math.min(x,h-n)),N=lr(S);if(as(N,ba)?(l.xg=!0,ln(l.reasons,"XG: System On SysEx")):as(N,Sa)?(l.gm2=!0,ln(l.reasons,"GM2: Reset SysEx")):as(N,ya)?(l.gm=!0,ln(l.reasons,"GM: Reset SysEx")):as(N,Na)&&(l.gs=!0,ln(l.reasons,"GS: Reset SysEx")),wa(N)){l.sawRolandDT1=!0,l.gs=!0;const w=N[4]??0,v=N[5]??0;if(w===80&&(l.sawAddr50=!0),w===64&&v===3&&(l.sawEFXBlock=!0),w===41){const _=N.length-8;l.total29+=_,_>=64&&(l.sawLarge29=!0)}}n+=x;continue}switch(b){case 128:n+=2;break;case 144:{if(n+2>h){n=h;break}e.getUint8(n),n++;const x=e.getUint8(n);n++,x>0&&(l.noteActivity++,p===9&&l.drumActivity++);break}case 160:n+=2;break;case 176:{if(n+2>h){n=h;break}const x=e.getUint8(n);n++;const S=e.getUint8(n);n++,x===0?l.lastCC0ByChan[p]=S:x===32&&l.lastCC0ByChan[p]===0&&(S===2||S===3||S===4)&&(l.sawMapSelectLike=!0,l.mapSelectValues.add(S));break}case 192:case 208:n+=1;break;case 224:n+=2;break}}n=h}return l.gs&&(l.sawAddr50&&(l.gs_sc88ish=!0,ln(l.reasons,"GS: DT1 writes to 0x50 bank (2nd module / extra parts) => SC-88ST/Pro-ish")),l.sawEFXBlock&&(l.gs_sc88ish=!0,ln(l.reasons,"GS: DT1 writes to 40 03 ** (EFX/FX block) => SC-88-ish")),(l.sawLarge29||l.total29>=256)&&(l.gs_sc88ish=!0,ln(l.reasons,"GS: Large Bulk Table writes (Addr 0x29) => SC-88-ish"))),l}function ka(s){const e=new Uint8Array(16);if(e[9]=1,!s)return e;try{const n=new DataView(s);let i=0;if(n.getUint32(i)!==1297377380)return e;i+=4;const r=n.getUint32(i);i+=4;const a=n.getUint16(i+2);i+=6,i+=Math.max(0,r-6);const o=new Uint8Array(16),l=()=>{let d=0,m;do{if(i>=s.byteLength)return 0;m=n.getUint8(i++),d=d<<7|m&127}while(m&128);return d>>>0};for(let d=0;d<a&&!(i+8>s.byteLength||n.getUint32(i)!==1297379947);d++){i+=4;const m=n.getUint32(i);i+=4;const u=Math.min(s.byteLength,i+m);let h=0;for(;i<u&&(l(),!(i>=u));){let c=n.getUint8(i);c&128?(i++,h=c):c=h;const f=c&240,b=c&15;if(c===255){if(i>=u)break;i++;const p=l();i=Math.min(u,i+p);continue}if(c===240||c===247){const p=l(),x=new Uint8Array(s,i,Math.min(p,u-i)),S=lr(x);if(S?.length>=7&&S[0]===67&&S[1]===16&&S[2]===76&&S[3]===8&&S[5]===7){const N=S[4],w=S[6];if(N>=0&&N<=15){const v=N,_=w!==0;e[v]=_?1:0,_&&v!==9&&console.log("[XG Drum]",{channel:v+1,mode:w,sysex:Ni(x)})}}if(S?.length>=8&&S[0]===65&&S[2]===66&&S[3]===18){const N=S[4],w=S[5],v=S[6],_=S[7];if((N===64||N===80)&&v===21){const R=va(N,w);if(R>=0&&R<=15){const k=_!==0;e[R]=k?1:0,k&&R!==9&&console.log("[GS Drum2]",{channel:R+1,sysex:Ni(x)})}}}i+=p;continue}if(f===176){if(i+2>u){i=u;break}const p=n.getUint8(i);i++;const x=n.getUint8(i);i++,p===0&&(o[b]=x,(x===120||x===126||x===127)&&(e[b]=1));continue}if(f===128||f===144||f===160||f===224){i+=2;continue}if(f===192||f===208){i+=1;continue}}}}catch{return e}return e}function Ma(s){if(!s)return{standard:Ie.SMF,gsVariant:null,reasons:["No buffer"]};try{const e=_a(s);if(!e)return{standard:Ie.SMF,gsVariant:null,reasons:["Parse failed"]};let n=Ie.SMF,i=null,r=null;return e.xg?n=Ie.XG:e.gs?(n=Ie.GS,i=e.gs_sc88ish?"SC-88-ish":"Plain GS"):e.gm2?n=Ie.GM2:e.gm?n=Ie.GM:(n=Ie.SMF,e.reasons.push("No SysEx detected")),n===Ie.GS&&(e.mapSelectValues.has(3)?r="88PRO":e.mapSelectValues.has(2)||e.gs_sc88ish?r="88":r="55"),{standard:n,gsVariant:i,gsModule:r,convertSC88:n===Ie.GS&&(r==="88"||r==="88PRO"),reasons:e.reasons,debug:{format:e.format,division:e.division,sawRolandDT1:e.sawRolandDT1,sawAddr50:e.sawAddr50,sawEFXBlock:e.sawEFXBlock,sawLarge29:e.sawLarge29,total29:e.total29,sawMapSelectLike:e.sawMapSelectLike,mapSelectValues:Array.from(e.mapSelectValues)}}}catch(e){return console.warn("MIDI Detection failed",e),{standard:Ie.SMF,gsVariant:null,reasons:["Error: "+e.message]}}}function lt(s){return Number.isFinite(s)?Math.max(0,Math.min(127,Math.round(s))):0}function Ca(){const s=Array.from({length:8},()=>new Uint8Array(128));for(let e=0;e<=127;e++){const n=e/127;s[0][e]=e,s[1][e]=Math.round(127*Math.pow(n,.8)),s[2][e]=Math.round(127*Math.pow(n,.6)),s[3][e]=Math.round(127*Math.pow(n,1.2)),s[4][e]=Math.round(127*Math.pow(n,1.6));const i=n<.5?2*n*n:1-2*(1-n)*(1-n),r=n<.5?4*n*n*n:1-4*(1-n)*(1-n)*(1-n);s[5][e]=Math.round(127*i),s[6][e]=Math.round(127*r),s[7][e]=127-e}return s}const ja=Ca();function Ta(s,e){const n=Math.max(0,Math.min(7,Number(e)||0));return ja[n][lt(s)]}function Kn(s,e){if(!e)return lt(s);const i=Ta(s,e.curve)*(e.value1??100)/100+(e.value2??0);return lt(i)}function Ut(s,e=10){if(!s)return null;const n=s.trim();return n?e===16||/^0x/i.test(n)||/[a-f]/i.test(n)?Number.parseInt(n,16):Number.parseInt(n,10):null}function Yn(s){const e=s.indexOf(",");if(e===-1)return{name:s.trim(),fields:[]};const n=s.slice(0,e).trim(),r=s.slice(e+1).split(",").flatMap(a=>a.trim().split(/\s+/)).filter(Boolean);return{name:n,fields:r}}function wi(s){const{name:e,fields:n}=Yn(s),i=Ut(n[0],10),r=Ut(n[1],10);return{name:e.replace(/^\(/,"").trim(),makerId:Number.isFinite(i)?i:null,deviceId:Number.isFinite(r)?r:null}}function en(s){const{name:e,fields:n}=Yn(s),i=n.map(r=>Ut(r,10)).filter(r=>r!==null&&Number.isFinite(r));return{name:e,values:i}}function Fa(s){const e=s.replace(/^\(/,"").trim(),{name:n,fields:i}=Yn(e),r=i.map(a=>Ut(a,16)).filter(a=>a!==null&&Number.isFinite(a));return{name:n.trim(),tokens:r}}function vi(s){const e=new Map,n=new Map,i=new Map;for(const r of s){const a=`${r.srcMSB},${r.srcLSB},${r.srcProgram}`;e.has(a)||e.set(a,r);const o=`${r.srcLSB},${r.srcProgram}`;n.has(o)||n.set(o,r);const l=`${r.srcMSB},${r.srcProgram}`;i.has(l)||i.set(l,r)}return{exact:e,byLsbPc:n,byMsbPc:i}}function ur(s,e={}){const n={name:e.name||null,title:null,source:null,destination:null,tempoChange:null,velocity:null,ccChanges:{},nrpnChanges:[],rpnChanges:[],adjust:[],drums:[],exclusive:[],excValue:{}},i=String(s||"").replace(/\r\n/g,`
`).split(`
`);let r=null,a=null,o=null;for(const d of i){const m=d.split(";")[0];if(!m.trim())continue;const u=m.trim();if(u){if(u.startsWith("[")){r=u.replace(/[\[\]]/g,"").trim().toUpperCase(),a=null,o=null;continue}if(r){if(r==="SOURCE"){n.source=wi(u);continue}if(r==="DESTINATION"){n.destination=wi(u);continue}if(r==="TITLE"){const{fields:h}=Yn(u);n.title=h.join(" ").trim()||null;continue}if(r==="TEMPO CHANGE"){const{values:h}=en(u);h.length>=2&&(n.tempoChange={value1:h[0],value2:h[1]});continue}if(r==="VELOCITY"){const{values:h}=en(u);h.length>=2&&(n.velocity={value1:h[0],value2:h[1],curve:h[2]??0});continue}if(r==="CC CHANGE"){const{name:h,values:c}=en(u);if(c.length>=3){let f=null;const b=h.match(/CC#?\s*(\d+)/i);b&&(f=Ut(b[1],10)),Number.isFinite(f)||(f=c[0]);const p=c[1],x=c[2],S=c[3]??0;Number.isFinite(f)&&(n.ccChanges[f]={value1:p,value2:x,curve:S})}continue}if(r==="NRPN CHANGE"){const{values:h}=en(u);h.length>=5&&n.nrpnChanges.push({msb:h[0],lsb:h[1],value1:h[2],value2:h[3],curve:h[4]??0});continue}if(r==="RPN CHANGE"){const{values:h}=en(u);h.length>=5&&n.rpnChanges.push({msb:h[0],lsb:h[1],value1:h[2],value2:h[3],curve:h[4]??0});continue}if(r==="EXC VALUE"){const{fields:h}=Yn(u);if(h.length>=4){const c=Ut(h[0],16),f=Ut(h[1],10),b=Ut(h[2],10),p=Ut(h[3],10);Number.isFinite(c)&&(n.excValue[c]={value1:Number.isFinite(f)?f:100,value2:Number.isFinite(b)?b:0,curve:Number.isFinite(p)?p:0})}continue}if(r==="EXCLUSIVE"){if(!u.startsWith("("))continue;const h=Fa(u);o?(n.exclusive.push({name:o.name||h.name,source:o.tokens,destination:h.tokens}),o=null):o=h;continue}if(r==="ADJUST"){const{name:h,values:c}=en(u);if(c.length>=7){const f={name:h,srcMSB:c[0],srcLSB:c[1],srcProgram:c[2],volume:c[3],destMSB:c[4],destLSB:c[5],destProgram:c[6],pitch:c[7]??0,pan:c[8]??0,cc91:c[9]??0,cc93:c[10]??0,cc72:c[11]??0,cc73:c[12]??0,cc74:c[13]??0};n.adjust.push(f)}continue}if(r==="DRUMS"){if(u.startsWith("(")){const{name:f,values:b}=en(u);if(b.length>=7){const p={name:f,srcMSB:b[0],srcLSB:b[1],srcProgram:b[2],volume:b[3],destMSB:b[4],destLSB:b[5],destProgram:b[6],pitch:b[7]??0,pan:b[8]??0,cc91:b[9]??0,cc93:b[10]??0,cc72:b[11]??0,cc73:b[12]??0,cc74:b[13]??0,noteMap:new Map};n.drums.push(p),a=p}continue}if(!a)continue;const{name:h,values:c}=en(u);if(c.length>=3){const f={name:h,srcNote:c[0],velocity:c[1],destNote:c[2],destMSB:c[3]??null,destLSB:c[4]??null,destProgram:c[5]??null};a.noteMap.set(f.srcNote,f)}continue}}}}n._adjustIndex=vi(n.adjust),n._drumIndex=vi(n.drums);const l=n.source?.name?.toLowerCase?.()||"";return n.source?.makerId===43||/xg|yamaha|mu\b/.test(l)?n.sourceHint=Ie.XG:n.source?.makerId===41||/roland|gs|sc-?55|sound canvas/.test(l)?n.sourceHint=Ie.GS:n.sourceHint=null,n}function Ra(s,e,n,i){const r=s._adjustIndex.exact.get(`${e},${n},${i}`);if(r)return r;if(s.sourceHint==="XG"){const o=s._adjustIndex.byLsbPc.get(`${n},${i}`);return o||s._adjustIndex.byMsbPc.get(`${e},${i}`)}const a=s._adjustIndex.byMsbPc.get(`${e},${i}`);return a||s._adjustIndex.byLsbPc.get(`${n},${i}`)}function Ba(s,e,n,i){const r=s._drumIndex.exact.get(`${e},${n},${i}`);if(r)return r;if(s.sourceHint==="XG"){const o=s._drumIndex.byLsbPc.get(`${n},${i}`);return o||s._drumIndex.byMsbPc.get(`${e},${i}`)}const a=s._drumIndex.byMsbPc.get(`${e},${i}`);return a||s._drumIndex.byLsbPc.get(`${n},${i}`)}function _i(s,e,n){for(const i of s){const r=i.msb===-1||i.msb===e,a=i.lsb===-1||i.lsb===n;if(r&&a)return i}return null}function un(s,e,n){return{type:"cc",channel:s,controller:e,value:lt(n),status:0,data:null,raw:null,note:0,velocity:0}}function Aa(s,e){return{type:"program",channel:s,value:lt(e),status:0,data:null,raw:null,note:0,velocity:0,controller:0}}function Pa(s){return{type:"sysex",channel:0,data:s,raw:s,status:0,note:0,velocity:0,controller:0,value:0}}function Ea(s,e){if(!s||e<=0)return 0;let n=0;s[0]===240&&s[1]===65&&s[3]===66&&s[4]===18?n=5:s[0]===240&&(n=1);let i=0;for(let r=n;r<e;r++)i+=s[r];return 128-i%128&127}function La(s,e,n){if(!s||!e||s.length!==e.length)return null;const i=new Map;for(let a=0;a<s.length;a++){const o=s[a],l=e[a];if(o!==271){if(o<=255){if(o!==l)return null;continue}if(o>=256&&o<=270)if(i.has(o)){if(i.get(o)!==l)return null}else i.set(o,l)}}const r=new Map;for(const[a,o]of i.entries()){const l=n?.[a];r.set(a,Kn(o,l))}return{vars:r}}function Ia(s,e){const n=new Uint8Array(s.length),i=[];for(let r=0;r<s.length;r++){const a=s[r];if(a===271){n[r]=0,i.push(r);continue}if(a<=255){n[r]=a&255;continue}if(a>=256&&a<=270){n[r]=lt(e?.get?.(a)??0);continue}n[r]=0}for(const r of i)n[r]=Ea(n,r);return n}function Da(s,e){if(s!==64&&s!==80||(e&240)!==16)return-1;let n=-1;return e===16?n=9:e>=17&&e<=25?n=e-17:e>=26&&e<=31&&(n=e-26+10),n<0?-1:(s===80&&(n+=16),n)}function ki(s){return!s||!s.length?"":Array.from(s,e=>e.toString(16).padStart(2,"0").toUpperCase()).join(" ")}function Ha(s,e={}){if(!s)throw new Error("SMF Knife config required");const n=e.enableDrumBankRemap===!0,i=e.ignoreEq===!0||e.ignoreEqForXg===!0&&s.sourceHint==="XG",r=e.ignoreFx===!0||e.ignoreFxForXg===!0&&s.sourceHint==="XG",a=e.initialDrumChannels?.length===16?Uint8Array.from(e.initialDrumChannels,d=>d?1:0):null,o={enabled:!0,globalMode:"smfknife",bankMSB:new Int16Array(16).fill(0),bankLSB:new Int16Array(16).fill(0),program:new Int16Array(16).fill(0),drumChannels:new Uint8Array(16).fill(0),transpose:new Int16Array(16).fill(0),ccValues:Array.from({length:16},()=>new Int16Array(128).fill(0)),activeDrumKits:Array.from({length:16},()=>null),noteMapCache:Array.from({length:16},()=>new Int16Array(128).fill(-1)),nrpnMSB:new Int16Array(16).fill(-1),nrpnLSB:new Int16Array(16).fill(-1),rpnMSB:new Int16Array(16).fill(-1),rpnLSB:new Int16Array(16).fill(-1),paramMode:new Int8Array(16).fill(0)};o.drumChannels[9]=1,a&&(o.drumChannels.set(a),o.drumChannels[9]=1);const l=d=>{if(!o.enabled)return[d];if(!d)return[];if(d.type==="sysex"&&d.data){if(d.data.length>=9&&d.data[0]===240&&d.data[1]===67&&d.data[2]===16&&d.data[3]===76&&d.data[4]===8&&d.data[6]===7){const m=d.data[5],u=d.data[7];if(m>=0&&m<=15){const h=m,c=u!==0;o.drumChannels[h]=c?1:0,c||(o.activeDrumKits[h]=null,o.noteMapCache[h].fill(-1)),c&&h!==9&&console.log("[XG Drum]",{channel:h+1,mode:u,sysex:ki(d.data)}),l.onStateChange&&l.onStateChange(l.getState())}}if(d.data.length>=10&&d.data[0]===240&&d.data[1]===65&&d.data[3]===66&&d.data[4]===18){const m=d.data[5],u=d.data[6],h=d.data[7],c=d.data[8];if((m===64||m===80)&&h===21){const f=Da(m,u);if(f>=0&&f<=15){const b=c!==0;o.drumChannels[f]=b?1:0,b||(o.activeDrumKits[f]=null,o.noteMapCache[f].fill(-1)),b&&f!==9&&console.log("[GS Drum2]",{channel:f+1,sysex:ki(d.data)}),l.onStateChange&&l.onStateChange(l.getState())}}}for(const m of s.exclusive){if(r&&/reverb|chorus/i.test(m.name||""))continue;const u=La(m.source,d.data,s.excValue);if(u){const h=Ia(m.destination,u.vars);return[Pa(h)]}}return[d]}if(d.type==="cc"){const m=d.channel,u=d.controller;if(u===99?(o.nrpnMSB[m]=d.value,o.paramMode[m]=1):u===98?(o.nrpnLSB[m]=d.value,o.paramMode[m]=1):u===101?(o.rpnMSB[m]=d.value,o.paramMode[m]=2):u===100&&(o.rpnLSB[m]=d.value,o.paramMode[m]=2),u===6){if(o.paramMode[m]===1){const c=_i(s.nrpnChanges,o.nrpnMSB[m],o.nrpnLSB[m]);if(c){if(i)return[];d.value=Kn(d.value,c)}}else if(o.paramMode[m]===2){const c=_i(s.rpnChanges,o.rpnMSB[m],o.rpnLSB[m]);if(c){if(i)return[];d.value=Kn(d.value,c)}}}if(i&&(u===71||u===72||u===73||u===74))return[];if(r&&(u===91||u===93))return[d];const h=s.ccChanges[u];if(h){if(r&&(u===91||u===93))return[d];d.value=Kn(d.value,h)}if(u===0){o.bankMSB[m]=d.value;const c=o.bankMSB[m]===120||o.bankMSB[m]===126||o.bankMSB[m]===127||m===9;o.drumChannels[m]!==(c?1:0)&&(o.drumChannels[m]=c?1:0,c||(o.activeDrumKits[m]=null,o.noteMapCache[m].fill(-1)),l.onStateChange&&l.onStateChange(l.getState()))}return u===32&&(o.bankLSB[m]=d.value),u>=0&&u<=127&&(o.ccValues[m][u]=d.value),[d]}if(d.type==="program"){const m=d.channel,u=d.value;o.program[m]=u;const h=o.bankMSB[m]===120||o.bankMSB[m]===126||o.bankMSB[m]===127||m===9;if(o.drumChannels[m]!==(h?1:0)&&(o.drumChannels[m]=h?1:0,l.onStateChange&&l.onStateChange(l.getState())),o.drumChannels[m]||(o.activeDrumKits[m]=null,o.noteMapCache[m].fill(-1)),o.drumChannels[m]){const x=Ba(s,o.bankMSB[m],o.bankLSB[m],u);if(o.noteMapCache[m].fill(-1),x){o.activeDrumKits[m]=x;const S=[];n&&(Number.isFinite(x.destMSB)&&S.push(un(m,0,x.destMSB)),Number.isFinite(x.destLSB)&&S.push(un(m,32,x.destLSB)));const N=Number.isFinite(x.destProgram)?x.destProgram:u;d.value=lt(N),S.push(d);const w=Mi(o,m,x,{ignoreEq:i,ignoreFx:r});return w.length&&S.push(...w),S}return o.activeDrumKits[m]=null,[d]}const c=Ra(s,o.bankMSB[m],o.bankLSB[m],u);if(!c)return o.transpose[m]=0,[d];const f=[];Number.isFinite(c.destMSB)&&f.push(un(m,0,c.destMSB)),Number.isFinite(c.destLSB)&&f.push(un(m,32,c.destLSB));const b=Number.isFinite(c.destProgram)?c.destProgram:u;d.value=lt(b),f.push(d);const p=Mi(o,m,c,{ignoreEq:i,ignoreFx:r});return p.length&&f.push(...p),f}if(d.type==="note_on"||d.type==="note_off"){const m=d.channel,u=d.type==="note_off"||d.type==="note_on"&&d.velocity===0,h=o.drumChannels[m]===1;let c=d.note,f=d.velocity;if(h){const b=o.activeDrumKits[m];if(b?.noteMap){const p=b.noteMap.get(c);if(p){const x=Number.isFinite(p.destNote)?p.destNote:c;if(!u)f=lt(f+(p.velocity??0)),o.noteMapCache[m][c]=x;else{const S=c,N=o.noteMapCache[m][S];N>=0?(c=N,o.noteMapCache[m][S]=-1):c=x}if(!u&&(Number.isFinite(p.destMSB)||Number.isFinite(p.destLSB)||Number.isFinite(p.destProgram))){const S=[];return n&&(Number.isFinite(p.destMSB)&&S.push(un(m,0,p.destMSB)),Number.isFinite(p.destLSB)&&S.push(un(m,32,p.destLSB))),Number.isFinite(p.destProgram)&&S.push(Aa(m,p.destProgram)),d.note=lt(x),d.velocity=lt(f),S.push(d),S}c=x}}}else{const b=o.transpose[m]||0;b&&(c=lt(c+b))}return!u&&s.velocity&&(f=Kn(f,s.velocity)),d.note=lt(c),d.velocity=lt(f),[d]}return[d]};return l.reset=()=>{o.bankMSB.fill(0),o.bankLSB.fill(0),o.program.fill(0),o.drumChannels.fill(0),o.drumChannels[9]=1,a&&(o.drumChannels.set(a),o.drumChannels[9]=1),o.transpose.fill(0),o.ccValues.forEach(d=>d.fill(0)),o.activeDrumKits.fill(null),o.noteMapCache.forEach(d=>d.fill(-1)),o.nrpnMSB.fill(-1),o.nrpnLSB.fill(-1),o.rpnMSB.fill(-1),o.rpnLSB.fill(-1),o.paramMode.fill(0)},l.setEnabled=d=>{o.enabled=!!d},l.getState=()=>({globalMode:o.globalMode,configName:s.name||s.title||"SMF Knife",mappingSource:s.source?.name||"",mappingDestination:s.destination?.name||"",drumChannels:o.drumChannels}),l}function Mi(s,e,n,i={}){const r=[];if(!n)return r;const a=i.ignoreEq===!0,o=i.ignoreFx===!0,l=(d,m)=>{if(m==null)return;const u=m>=1e3||m<=-1e3,h=s.ccValues[e][d]??0,c=u?m-(m>=1e3?1e3:-1e3):h+m,f=lt(c);s.ccValues[e][d]=f,r.push(un(e,d,f))};if(Number.isFinite(n.volume)&&l(7,n.volume),Number.isFinite(n.pan)&&l(10,n.pan),o||(Number.isFinite(n.cc91)&&l(91,n.cc91),Number.isFinite(n.cc93)&&l(93,n.cc93)),a||(Number.isFinite(n.cc72)&&l(72,n.cc72),Number.isFinite(n.cc73)&&l(73,n.cc73),Number.isFinite(n.cc74)&&l(74,n.cc74)),Number.isFinite(n.pitch)){const d=n.pitch>=1e3||n.pitch<=-1e3;s.transpose[e]=d?n.pitch-(n.pitch>=1e3?1e3:-1e3):n.pitch}return r}const Oa=`; ---------------------------------------------------------------------------\r
;【デ ー タ 名 】ＳＭＦナイフ用 CFGFILE     MU100 -> SC-88 v2.60\r
;【作   成   者】須釜俊一 (VEN10211@nifty.com)\r
;【対 応 音 源 】SC-88(VL/ST/Pro)/M-GS64\r
;【ＳＭＦナイフ】要v1.21以降/推奨V2.09以降\r
; ---------------------------------------------------------------------------\r
;\r
[SOURCE]\r
YAMAHA MU100,43,0\r
[DESTINATION]\r
Roland SC-88,41,1\r
;\r
[EXCLUSIVE]\r
;\r
(XG_MASTERVOL , F0,43,10,4C,00,00,04,10E,F7\r
 GS_MASTERVOL , F0,41,10,42,12,40,00,04,10E,10F,F7\r
;\r
(XG_REVERB ROOM1 , F0,43,10,4C,02,01,00,02, 00    ,F7\r
 GS_REVERB ROOM1 , F0,41,10,42,12,40,01,30, 00,10F,F7\r
;\r
(XG_REVERB ROOM2 , F0,43,10,4C,02,01,00,02, 01    ,F7\r
 GS_REVERB ROOM2 , F0,41,10,42,12,40,01,30, 01,10F,F7\r
;\r
(XG_REVERB ROOM3 , F0,43,10,4C,02,01,00,02, 02    ,F7\r
 GS_REVERB ROOM3 , F0,41,10,42,12,40,01,30, 02,10F,F7\r
;\r
(XG_REVERB HALL1 , F0,43,10,4C,02,01,00,01, 00    ,F7\r
 GS_REVERB HALL1 , F0,41,10,42,12,40,01,30, 03,10F,F7\r
;\r
(XG_REVERB HALL2 , F0,43,10,4C,02,01,00,01, 01    ,F7\r
 GS_REVERB HALL2 , F0,41,10,42,12,40,01,30, 04,10F,F7\r
;\r
(XG_REVERB PLATE , F0,43,10,4C,02,01,00,04, 00    ,F7\r
 GS_REVERB PLATE , F0,41,10,42,12,40,01,30, 05,10F,F7\r
;\r
(XG_CHORUS CHO1  , F0,43,10,4C,02,01,20,41, 00    ,F7\r
 GS_CHORUS CHO1  , F0,41,10,42,12,40,01,38, 00,10F,F7\r
; \r
(XG_CHORUS CHO2  , F0,43,10,4C,02,01,20,41, 01    ,F7\r
 GS_CHORUS CHO2  , F0,41,10,42,12,40,01,38, 01,10F,F7\r
;\r
(XG_CHORUS CHO3  , F0,43,10,4C,02,01,20,41, 02    ,F7\r
 GS_CHORUS CHO3  , F0,41,10,42,12,40,01,38, 02,10F,F7\r
;\r
(XG_CHORUS CHO4  , F0,43,10,4C,02,01,20,41, 08    ,F7\r
 GS_CHORUS CHO4  , F0,41,10,42,12,40,01,38, 03,10F,F7\r
;\r
(XG_CHORUS FLG1  , F0,43,10,4C,02,01,20,43, 00    ,F7\r
 GS_CHORUS FLG   , F0,41,10,42,12,40,01,38, 05,10F,F7\r
;\r
(XG_CHORUS FLG2  , F0,43,10,4C,02,01,20,43, 01    ,F7\r
 GS_CHORUS FLG   , F0,41,10,42,12,40,01,38, 05,10F,F7\r
;\r
(XG_REVERB TIME  , F0,43,10,4C,02,01,02,100,F7\r
 GS_REVERB TIME  , F0,41,10,42,12,40,01,34,100,10F,F7\r
;\r
[EXC VALUE]\r
TIME,50,3,0\r
;\r
[CC CHANGE]\r
;\r
CC#1  MODURATION , 1, 120 ,0 ,1\r
CC#7  VOLUME     , 7,  90 ,0 ,0\r
CC#32 BANK L     ,32,   0 ,2 ,0\r
CC#91 REVERB     ,91, 100 ,4 ,0\r
CC#93 CHORUS     ,93, 100 ,4 ,0\r
CC#94 VARIATION  ,94,   0 ,0 ,0\r
CC#71 RESONANCE  ,71,  25, 48,0\r
CC#72 RELEASE    ,72,  50, 32,0\r
CC#73 ATTACK     ,73,  50, 32,0\r
CC#74 CUTOFF     ,74,  50, 28,0\r
;\r
[VELOCITY]\r
Velocity,100,0,0\r
;\r
[NRPN CHANGE]\r
;\r
CUT OFF  ,1, 32, 50,28 ,0\r
RESONANCE,1, 33, 25,48 ,0\r
ATTACK   ,1, 99 ,50,32 ,0\r
RELEASE  ,1,101, 50,32 ,0\r
DECAY    ,1,100, 50,32 ,0\r
;\r
[ADJUST]\r
;\r
; ピアノ\r
;\r
GrandP #  , 0, 0,  0, -0,  0, 2,0  ,0\r
GrandPnoK , 0, 1,  0,  0,  0, 2,0  ,0\r
MelloGrP  , 0,18,  0,  0, 16, 2,0  ,0\r
PianoStr  , 0,40,  0,  0,  0, 2,0  ,0\r
Dream     , 0,41,  0,  0,  0, 2,0  ,0\r
ConGrnd   , 0,64,  0,  0,  0, 1,0  ,0\r
ConGrndK  , 0,65,  0,  0,  0, 1,0  ,0\r
DblConGr  , 0,66,  0,  0,  8, 1,0  ,0\r
MIDIGrd1  , 0,67,  0,  0,  0, 2,0  ,0\r
MIDIGrd2  , 0,68,  0,  0,  0, 2,0  ,0\r
;\r
BriteP #  , 0, 0,  1,  0,  8, 2,1  ,0\r
BritePnoK , 0, 1,  1,  0,  0, 2,1  ,0\r
StBrtPno  , 0, 3,  1,  0,  8, 2,1  ,0\r
ResoBrtP  , 0,20,  1,  0,  0, 2,1  ,0\r
DtndBrtP  , 0,32,  1,  0,  8, 2,1  ,0\r
SyPadPno  , 0,40,  1,  0,  8, 2,1  ,0\r
BrConGrd  , 0,64,  1,  0,  8, 2,1  ,0\r
BrConGrK  , 0,65,  1,  0,  0, 2,1  ,0\r
MIDIGrd3  , 0,66,  0,  0,  0, 2,0  ,0\r
MIDIGrd4  , 0,67,  0,  0,  0, 2,0  ,0\r
OldPiano  , 0,68,  0,  0,  0, 2,0  ,0\r
;\r
E.Grand   , 0, 0,  2,  3,  0, 2,2  ,0\r
E.GrandK  , 0, 1,  2,  3,  8, 2,2  ,0\r
Det.CP80  , 0,32,  2,  2,  8, 2,2  ,0\r
Synth CP  , 0,35,  2,  2,  8, 2,2  ,0\r
LayerCP1  , 0,40,  2,  2,  1, 2,2  ,0\r
LayerCP2  , 0,41,  2,  2,  2, 2,2  ,0\r
;\r
HnkyTnk   , 0, 0,  3,  0,  8, 2,3  ,0\r
HnkyTnkK  , 0, 1,  3,  0,  0, 2,3  ,0\r
;\r
E.Piano1# , 0, 0,  4,  0,  0, 2,4  ,0\r
E.Pno1K   , 0, 1,  4,  0, 26, 2,4  ,0\r
MelloEP1  , 0,18,  4,  0,  0, 2,4  ,0\r
Chor.EP1  , 0,32,  4,  0,  8, 2,4  ,0\r
HardEl.P  , 0,40,  4,  0, 25, 2,4  ,0\r
VX El.P1  , 0,45,  4,  0,  0, 2,4  ,0\r
60'sEl.P1 , 0,64,  4,  0, 24, 2,4  ,0\r
Old EP    , 0,65,  0,  0, 24, 2,4  ,0\r
Tribecca  , 0,66,  0,  0, 24, 2,4  ,0\r
Diploid1  , 0,67,  0,  0,  0, 2,4  ,0\r
Flops     , 0,68,  0,  0,  0, 2,4  ,0\r
Soho      , 0,69,  0,  0,  0, 2,4  ,0\r
FlopsDtd  , 0,70,  0,  0,  0, 2,4  ,0\r
Diploid2  , 0,71,  0,  0,  0, 2,4  ,0\r
Brooklyn  , 0,72,  0,  0,  0, 2,4  ,0\r
Diploid3  , 0,73,  0,  0,  0, 2,4  ,0\r
PhunkyDX  , 0,74,  0,  0,  0, 2,4  ,0\r
Nasal DX  , 0,75,  0,  0,  0, 2,4  ,0\r
NaslDXDt  , 0,76,  0,  0,  0, 2,4  ,0\r
Din       , 0,77,  0,  0,  0, 2,4  ,0\r
;\r
E.Piano2# , 0, 0,  5,  0, 24, 2,5  ,0\r
El.Pno2K  , 0, 1,  5,  0, 24, 2,5  ,0\r
ChoEPDcy  , 0,12,  5,  0,  8, 2,5  ,0\r
Chor.EP2  , 0,32,  5,  0,  8, 2,5  ,0\r
DX.Hard   , 0,33,  5,  0, 16, 2,5  ,0\r
DXLegend  , 0,34,  5,  0,  0, 2,5  ,0\r
DX Phase  , 0,40,  5,  0,  0, 2,5  ,0\r
DX+Analog , 0,41,  5,  0, 16, 2,4  ,0\r
DXKotoEP  , 0,42,  5,  0,  0, 2,5  ,0\r
VX El.P2  , 0,45,  5,  0,  8, 2,5  ,0\r
ChoEP K   , 0,48,  5,  0,  8, 2,5  ,0\r
DXMallet  , 0,52,  5,  0,  8, 2,5  ,0\r
Shrakawa  , 0,64,  5,  0,  8, 2,5  ,0\r
OldEP Tn  , 0,65,  5,  0,  8, 2,5  ,0\r
Flips     , 0,66,  5,  0,  0, 2,5  ,0\r
FlipsDtd  , 0,67,  5,  0,  8, 2,5  ,0\r
Flicks    , 0,68,  5,  0,  8, 2,5  ,0\r
FliksDtd  , 0,69,  5,  0,  8, 2,5  ,0\r
BrightDX  , 0,70,  5,  0,  0, 2,5  ,0\r
BrtDXDtd  , 0,71,  5,  0,  8, 2,5  ,0\r
Kitayama  , 0,72,  5,  0,  8, 2,5  ,0\r
Turnpikl  , 0,73,  5,  0,  8, 2,5  ,0\r
Turnpik2  , 0,74,  5,  0,  8, 2,5  ,0\r
Cerritos  , 0,75,  5,  0,  8, 2,5  ,0\r
Sunset    , 0,76,  5,  0,  0, 2,5  ,0\r
Soft DX   , 0,77,  5,  0,  8, 2,5  ,0\r
Reso DX   , 0,78,  5,  0,  8, 2,5  ,0\r
PiercnDX  , 0,79,  5,  0,  8, 2,5  ,0\r
ShvrngDX  , 0,80,  5,  0,  8, 2,5  ,0\r
ShvrnDX   , 0,81,  5,  0,  8, 2,5  ,0\r
RattlnDX  , 0,82,  5,  0,  8, 2,5  ,0\r
RatlnDX+  , 0,83,  5,  0,  8, 2,5  ,0\r
TinkerDX  , 0,84,  5,  0,  8, 2,5  ,0\r
TinkrDX+  , 0,85,  5,  0,  8, 2,5  ,0\r
;\r
Harpsi    , 0, 0,  6,  0,  8, 2,6  ,0\r
Harpsi.K  , 0, 1,  6,  0,  0, 2,6  ,0\r
Harpsi.2  , 0,25,  6,  0, 16, 2,6  ,0\r
Harpsi.3  , 0 35,  6,  0,  8, 2,6  ,0\r
ElHarpsi  , 0 40,  6,  0,  8, 2,6  ,0\r
SynHarpsi   0 64,  6,  0,  8, 2,6  ,0\r
;\r
Clavi.    , 0, 0,  7,  0,  0, 2,7  ,0\r
Clavi.K   , 0, 1,  7,  0,  0, 2,7  ,0\r
Clavi.Wah , 0,27,  7,  0,  0, 2,7  ,0\r
CsmcClav  , 0,40,  7,  0,  0, 2,7  ,0\r
PulseClv  , 0,64,  7,  0,  0, 2,87 ,0\r
PierceCl  , 0,65,  7,  0,  0, 2,7  ,0\r
ClrClavi  , 0,66,  7,  0,  0, 2,7  ,0\r
SwpClavi  , 0,67,  7,  0,  0, 2,7  ,0\r
SynClavi  , 0,68,  7,  0,  0, 2,7  ,0\r
SprClavi  , 0,69,  7,  0,  0, 2,7  ,0\r
GtrClavi  , 0,70,  7,  0,  0, 2,7  ,0\r
HardyPlk  , 0,71,  7,  0,  0, 2,7  ,0\r
HrdyPlk+  , 0,72,  7,  0,  0, 2,7  ,0\r
FMClavDb  , 0,73,  7,  0,  0, 2,7  ,0\r
;\r
; クロマチックパーカッション\r
;\r
Celesta   , 0, 0,  8,  0,  0, 2,8  ,0\r
FMCelsta  , 0,64,  8,  0,  0, 2,8  ,0\r
Glocken   , 0, 0,  9,-10,  0, 2,9  ,0\r
MusicBox  , 0, 0, 10,  2,  0, 1,10 ,0\r
Orgel     , 0,64, 10,  0,  0, 2,10 ,0\r
SmalOrgl  , 0,65, 10,  0,  0, 2,10 ,0\r
Vibes     , 0, 0, 11, -7,  0, 2,11 ,0\r
Vibes K   , 0, 1, 11, -7,  8, 2,11 ,0\r
Hard Vibe , 0,45, 11,  0,  1, 2,11 ,0\r
Marimba   , 0, 0, 12,  0,  0, 2,12 ,0\r
Marimba K , 0, 1, 12,  0,  8, 2,12 ,0\r
SineMrmb  , 0,64, 12,  0,  8, 2,12 ,0\r
Barafon   , 0,96, 12,  0, 16, 2,12 ,0\r
Barafon 2 , 0,97, 12,  0, 17, 2,12 ,0\r
Log drum  , 0,98, 12,  0, 24, 2,12 ,0\r
Xylophon  , 0, 0, 13,  0,  0, 2,13 ,0\r
Tubulbel  , 0, 0, 14, -7,  0, 2,14 ,0\r
ChrchBell , 0,96, 14, -6,  8, 2,14 ,0\r
Carilon   , 0,97, 14,  0,  9, 2,14 ,0\r
Dulcimer  , 0, 0, 15,  0,  0, 2,15 ,0\r
Dulcimr2  , 0,35, 15,  0,  0, 2,15 ,0\r
Cimbalom  , 0,96, 15,  0,  8, 2,15 ,0\r
Santur    , 0,97, 15,  0,  0, 2,15 ,0\r
;\r
; オルガン\r
;\r
DrawOrgan , 0, 0, 16, 8,  0,2 ,16  ,0\r
StDrawOr  , 0, 3, 16, 8,  0,2 ,16  ,0\r
DetDrwOrg , 0,32, 16, 8,  8,2 ,16  ,0\r
60sDrOr1  , 0,33, 16, 4, 16,2 ,16  ,0\r
60sDrOr2  , 0,34, 16, 4, 17,2 ,16  ,0\r
70sDrOr1  , 0,35, 16, 3,  1,2 ,16  ,0\r
DrawOrg2  , 0,36, 16, 4,  9,2 ,16  ,0\r
60sDrOr3  , 0,37, 16, 6, 18,2 ,16  ,0\r
Even Bar  , 0,38, 16, 3, 33,2 ,16  ,0\r
16+2"2/3  , 0,40, 16, 2,  9,2 ,16  ,0\r
Organ Ba  , 0,64, 16, 1, 40,2 ,16  ,0\r
70sDrOr2  , 0,65, 16, 1, 32,2 ,16  ,0\r
CheesOrg  , 0,66, 16, 0, 24,2 ,16  ,0\r
DrawOrg3  , 0,67, 16, 0, 32,2 ,16  ,0\r
StdiumOr  , 0,68, 16, 0, 32,2 ,16  ,0\r
StdiumO2  , 0,69, 16, 0, 32,2 ,16  ,0\r
GospelOr  , 0,70, 16, 0, 32,2 ,16  ,0\r
ClkGsplO  , 0,71, 16, 0, 32,2 ,16  ,0\r
ChapelOr  , 0,72, 16, 0, 32,2 ,16  ,0\r
DimChors  , 0,73, 16, 0, 32,2 ,16  ,0\r
Dawn      , 0,74, 16, 0, 32,2 ,16  ,0\r
Mellorgn  , 0,75, 16, 0, 32,2 ,16  ,0\r
Fuzzorgn  , 0,76, 16, 0, 32,2 ,16  ,0\r
FMO       , 0,77, 16, 0, 32,2 ,16  ,0\r
;\r
PercOrgn  , 0, 0, 17, 2,  0,2 ,17  ,0\r
70sPcOr1  , 0,24, 17, 2,  1,1 ,17  ,0\r
DetPrcOr  , 0,32, 17, 2,  8,1 ,17  ,0\r
Lite Org  , 0,33, 17, 0, 32,2 ,17  ,0\r
PercOrg2  , 0,37, 17, 0, 32,2 ,17  ,0\r
JazOrgan  , 0,64, 17, 0, 32,2 ,17  ,0\r
WarmJzOr  , 0,65, 17, 0, 32,2 ,17  ,0\r
ClikOrgn  , 0,66, 17, 0, 32,2 ,17  ,0\r
Grace     , 0,67, 17, 0, 32,2 ,17  ,0\r
CrnGrace  , 0,68, 17, 0, 32,2 ,17  ,0\r
DimClick  , 0,69, 17, 0, 32,2 ,17  ,0\r
Dusk      , 0,70, 17, 0, 32,2 ,17  ,0\r
FM Click  , 0,71, 17, 0, 32,2 ,17  ,0\r
Spoony    , 0,72, 17, 0, 32,2 ,17  ,0\r
SpyRotary , 0,73, 17, 0, 32,2 ,17  ,0\r
LoFiOrgn  , 0,74, 17, 0, 32,2 ,17  ,0\r
BeepOrgn  , 0,75, 17, 0, 32,2 ,17  ,0\r
Belief    , 0,76, 17, 0, 32,2 ,17  ,0\r
SnapOrgn  , 0,77, 17, 0, 32,2 ,17  ,0\r
;\r
RockOrgn  , 0, 0, 18, 0,  0,2 ,18  ,0\r
RotaryOr  , 0,64, 18, 0,  8,2 ,18  ,0\r
SloRotar  , 0,65, 18, 0, 16,2 ,18  ,0\r
FstRotar  , 0,66, 18, 0, 24,2 ,18  ,0\r
GlaclRtr  , 0,67, 18, 0, 24,2 ,18  ,0\r
;\r
ChrchOrg  , 0, 0, 19, 0,  0,2 ,19  ,0\r
ChurOrg3  , 0,32, 19, 0, 16,2 ,19  ,0\r
ChurOrg2  , 0,35, 19, 0,  8,2 ,19  ,0\r
Notredum  , 0,40, 19, 0,  0,2 ,19  ,0\r
OrgFlute  , 0,64, 19, 0, 24,2 ,19  ,0\r
TrmOrgFl  , 0 65, 19, 0, 32,2 ,19  ,0\r
;\r
ReedOrgn  , 0, 0, 20, 0,  0,2 ,20  ,0\r
ReedOrDt  , 0,32, 20, 0,  0,2 ,20  ,0\r
Puff Org  , 0,40, 20, 0,  0,2 ,20  ,0\r
SyReedDk  , 0,64, 20, 0,  0,2 ,20  ,0\r
Acordion  , 0, 0, 21, 0,  0,2, 21  ,0\r
AccordIt  , 0,32, 21, 0,  8,2, 21  ,0\r
Harmnica  , 0, 0, 22, 0,  0,2, 22  ,0\r
Harmo2    , 0,32, 22, 0,  1,2, 22  ,0\r
TangoAc#  , 0, 0, 23, 14, 0,2 ,23  ,0\r
TangoAcd2 , 0,64, 23, 14, 0,1 ,23  ,0\r
TightAcd  , 0,65, 23, 14, 0,1 ,23  ,0\r
TghtAcdD  , 0,66, 23, 14, 0,1 ,23  ,0\r
;\r
; ギター\r
;\r
Nylon Gt# , 0, 0, 24,  2, 0, 2,24  ,0\r
Nylon Gt2 , 0,16, 24,  3,32, 2,24  ,0\r
Nylon Gt3 , 0,25, 24,  0,40, 2,24  ,0\r
VelGtrHrm , 0,43, 24,  0,24, 2,24  ,0\r
Ukulele   , 0,96, 24,  0, 8, 2,24  ,0\r
Steel Gt  , 0, 0, 25,-12, 0, 2,25  ,0\r
Steel Gt2 , 0,16, 25,-12,32, 2,25  ,0\r
Nyln&Stl  , 0,35, 25,-10, 9, 2,25  ,0\r
12StrGtr  , 0,40, 25,-10, 8, 2,25  ,0\r
Stl&Body  , 0,41, 25,-10, 0, 2,25  ,0\r
Mandolin  , 0,96, 25,-10,16, 2,25  ,0\r
Jazz Gt.  , 0, 0, 26,  6, 0, 2,26  ,0\r
MellowGt  , 0,18, 26,  8, 1, 2,26  ,0\r
JazzAmp   , 0,32, 15,  9, 0, 2,26  ,0\r
PdlSteel  , 0,96, 26,  0, 8, 2,26  ,0\r
Clean Gt  , 0, 0, 27,  6, 0, 1,27  ,0\r
ChorusGt  , 0,32, 27,  5, 8, 1,27  ,0\r
CleanGt2  , 0,64, 27,  0, 0, 2,27  ,0\r
Mute Gtr  , 0, 0, 28,  0, 0, 2,28  ,0\r
FunkGtr1  , 0,40, 28,  0, 8, 2,28  ,0\r
MuteStlGt , 0,41, 28,  0, 0, 2,28  ,0\r
FunkGtr2  , 0,43, 28,  0,16, 2,28  ,0\r
Jazz Man  , 0,45, 28,  0,16, 2,28  ,0\r
Mu.DstGt  , 0,96, 28,-14, 0, 2,30  ,0\r
OvrDrive  , 0, 0, 29, -2, 0, 2,29  ,0\r
Gt.Pinch  , 0,43, 29,  0, 0, 2,29  ,0\r
Dist.Gtr  , 0, 0, 30, -8, 0, 2,30  ,0\r
DstRthmG  , 0,12, 30, -9,24, 2,30  ,0\r
DistGtr2  , 0,24, 30, -9, 1, 2,30  ,0\r
DistGtr3  , 0,35, 30, -9, 2, 2,30  ,0\r
PowerGt2  , 0,36, 30,-11,16, 2,30  ,0\r
PowerGt1  , 0,37, 30,-11,17, 2,30  ,0\r
Dst5ths   , 0,38, 30, -9,18, 2,30  ,0\r
FeedbkGt  , 0,40, 30, -9, 8, 2,30  ,0\r
FeedbGt2  , 0,41, 30, -9, 9, 2,30  ,0\r
RkRythm2  , 0,43, 30, -9,24, 2,30  ,0\r
RockRthm  , 0,45, 30, -9,25, 2,30  ,0\r
Gt.Harmo  , 0, 0, 31,  0, 0, 2,31  ,0\r
Aco.Harmo , 0,64, 31,  0,16, 2,31  ,0\r
Gt.Harom2 , 0,65, 31,  0, 8, 2,31  ,0\r
;\r
; ベース\r
;\r
Aco.Bass  , 0, 0, 32,  0, 0, 2,32  ,0\r
JazzRthm  , 0,40, 32,  0, 0, 2,32  ,0\r
VxUprght  , 0,45, 32,  0, 0, 2,32  ,0\r
FngrBass  , 0, 0, 33,  4, 0, 2,33  ,0\r
FingrDrk  , 0,18, 33,  3, 1, 2,33  ,0\r
FlangeBa  , 0,27, 33,  0, 0, 2,33  ,0\r
Ba&DstEG  , 0,40, 33,  0, 0, 2,33  ,0\r
FngrSlap  , 0,43, 33,  0, 0, 2,33  ,0\r
FngBass2  , 0,45, 33,  0, 1, 2,33  ,0\r
JazzBass  , 0,64, 33,  0, 2, 2,33  ,0\r
ModAlem   , 0,65, 33,  0, 0, 2,33  ,0\r
PickBass  , 0, 0, 34,  0, 0, 2,34  ,0\r
MutePkBs  , 0,28, 34,  0, 8, 2,34  ,0\r
Fretless  , 0, 0, 35,  0, 0, 2,35  ,0\r
Fretles2  , 0,32, 35,  0, 1, 2,35  ,0\r
Fretles3  , 0,33, 35,  0, 2, 2,35  ,0\r
Fretles4  , 0,34, 35,  0, 3, 2,35  ,0\r
SynFret1  , 0,96, 35,  0, 4, 2,35  ,0\r
Smooth    , 0,97, 35,  0, 5, 2,35  ,0\r
SlapBas1  , 0, 0, 36,  0, 0, 2,36  ,0\r
ResoSlap  , 0,27, 36,  0, 8, 2,36  ,0\r
SlapBas2  , 0, 0, 37,  0, 0, 2,37  ,0\r
VeloSLAP  , 0,43, 37,  0, 0, 2,37  ,0\r
SynBass1  , 0, 0, 38,  6, 0, 2,38  ,0\r
SynBa1Dk  , 0,18, 38,  5, 1, 2,38  ,0\r
AcidBass  , 0,24, 38,  3, 8, 2,38  ,0\r
FastResB  , 0,20, 38,  3, 9, 2,38  ,0\r
TeknoBas  , 0,40, 38,  3,10, 2,38  ,0\r
ClavBass  , 0,35, 38,  6,16, 2,38  ,0\r
Oscar     , 0,64, 38,  6,16, 2,38  ,0\r
Sqr Bass  , 0,65, 38,  6,16, 2,38  ,0\r
RubberBa  , 0,66, 38,  0,16, 2,39  ,0\r
Hammer    , 0,96, 38,  6,16, 2,38  ,0\r
SynBass2  , 0, 0, 39,  0, 0, 2,39  ,0\r
MelloSB1  , 0, 6, 39,  0,18, 2,39  ,0\r
Seq Bass  , 0,12, 39,  0, 3, 2,39  ,0\r
ClkSynBa  , 0,18, 39,  0, 1, 2,39  ,0\r
SynBa2Dk  , 0,19, 39,  0,17, 2,39  ,0\r
Zealot    , 0,22, 39,  0,17, 2,39  ,0\r
SmthBs2   , 0,32, 39,  0,19, 2,39  ,0\r
ModulrBa  , 0,40, 39,  0, 2, 2,39  ,0\r
DX Bass   , 0,41, 39,  0, 8, 2,39  ,0\r
DXBa Brt  , 0,42, 39,  0, 8, 2,39  ,0\r
X WireBa  , 0,64, 39,  0, 9, 2,39  ,0\r
AtkPulse  , 0,65, 39,  0, 9, 2,39  ,0\r
CS Light  , 0,66, 39,  0, 9, 2,39  ,0\r
MetlBass  , 0,67, 39,  0, 9, 2,39  ,0\r
FrcOscBa  , 0,68, 39,  0, 9, 2,39  ,0\r
Cubit     , 0,69, 39,  0, 9, 2,39  ,0\r
Cubit +   , 0,70, 39,  0, 9, 2,39  ,0\r
Keel      , 0,71, 39,  0, 9, 2,39  ,0\r
KeelPwrd  , 0,72, 39,  0, 9, 2,39  ,0\r
PlnPluse  , 0,73, 39,  0, 9, 2,39  ,0\r
PwrdPuls  , 0,74, 39,  0, 9, 2,39  ,0\r
PwrPulsB  , 0,75, 39,  0, 9, 2,39  ,0\r
Pwrd Saw  , 0,76, 39,  0, 9, 2,39  ,0\r
;\r
; ストリングス/オーケストラ\r
;\r
Violin #  , 0, 0, 40, -9, 0, 1,40  ,0\r
SlowVln   , 0, 8, 40, -9, 8, 2,40  ,0\r
Unison    , 0,40, 40, -9, 8, 2,40  ,0\r
Cadenza   , 0,64, 40, -9, 8, 2,40  ,0\r
CadenzDk  , 0,65, 40, -9, 8, 2,40  ,0\r
Viola     , 0, 0, 41, -7, 0, 1,41  ,0\r
VlaDoubl  , 0,40, 41, -7, 0, 1,41  ,0\r
Sonata    , 0,64, 41, -7, 0, 1,41  ,0\r
Cello     , 0, 0, 42, -6, 0, 1,42  ,0\r
Cntrabas  , 0, 0, 43,  0, 0, 1,43  ,0\r
TremStr#  , 0, 0, 44,  0, 0, 2,44  ,0\r
SlwTrStr  , 0, 8, 44,  0, 0, 2,44  ,0\r
SlwTrStr  , 0, 8, 44,  0, 0, 2,44  ,0\r
Susp Str  , 0,40, 44,  0, 9, 2,44  ,0\r
Fear      , 0,64, 44,  0, 9, 2,44  ,0\r
Fear Dtd  , 0,65, 44,  0, 9, 2,44  ,0\r
Apoclyps  , 0,66, 44,  0, 9, 2,44  ,0\r
Pizz.Str  , 0, 0, 45,  0, 0, 1,45  ,0\r
Pizz Oct  , 0,35, 45,  0, 0, 1,45  ,0\r
Sleep     , 0,40, 45,  0, 0, 1,45  ,0\r
Harp      , 0, 0, 46,  0, 0, 2,46  ,0\r
YangChin  , 0,40, 46,  0, 0, 2,46  ,0\r
Vln Harp  , 0,96, 46,  0, 0, 2,46  ,0\r
VlnHrpDt  , 0,97, 46,  0, 0, 2,46  ,0\r
Timpani   , 0, 0, 47,  0, 0, 2,47  ,0\r
Roll&Hit  , 0,43, 47,  0, 0, 2,47  ,0\r
;\r
; アンサンブル\r
;\r
Strings1# , 0, 0, 48, -3, 0, 1,48  ,0\r
S.Strngs  , 0, 3, 48, -2,16, 2,48  ,0\r
SlowStr   , 0, 8, 48, -1, 0, 2,49  ,0\r
SfzStrgs  , 0,14, 48, -1, 0, 2,49  ,0\r
ArcoStr   , 0,24, 48,  0, 0, 2,48  ,0\r
60sStrng  , 0,35, 48,  0, 0, 2,48  ,0\r
Orchestr  , 0,40, 48,  0, 8, 2,48  ,0\r
Orchstr2  , 0,41, 48,  0, 9, 2,48  ,0\r
TrmoOrch  , 0,42, 48,  0,10, 2,48  ,0\r
VeloStr   , 0,45, 48,  0,24, 2,48  ,0\r
Lento     , 0,50, 48,  0,24, 2,48  ,0\r
SprStrng  , 0,64, 48,  0,24, 2,48  ,0\r
SprStrSt  , 0,65, 48,  0,24, 2,48  ,0\r
Triste    , 0,66, 48,  0,24, 2,48  ,0\r
Basso     , 0,67, 48,  0,24, 2,48  ,0\r
Strings2# , 0, 0, 49,  0, 0, 1,49  ,0\r
S.SlwStr  , 0, 3, 49,  0,10, 2,49  ,0\r
LegatoSt  , 0, 8, 49,  0, 8, 2,49  ,0\r
Warm Str  , 0,40, 49,  0, 9, 2,49  ,0\r
Kingdom   , 0,41, 49,  0, 1, 2,49  ,0\r
70sStr    , 0,64, 49,  0, 1, 2,49  ,0\r
Str Ens3  , 0,65, 49,  0, 0, 2,49  ,0\r
Syn.Str1  , 0, 0, 50,  0, 0, 1,50  ,0\r
Memory    , 0, 8, 50,  0, 0, 1,50  ,0\r
Zephyr    , 0,18, 50,  0, 0, 1,50  ,0\r
ResoStr   , 0,27, 50,  0, 1, 2,50  ,0\r
Syn.Str3  , 0,35, 50,  0, 8, 2,50  ,0\r
Monarchy  , 0,39, 50,  0, 8, 2,50  ,0\r
GrandPad  , 0,40, 50,  0, 8, 2,50  ,0\r
SweepStr  , 0,41, 50,  0, 8, 2,50  ,0\r
SwpStOct  , 0,42, 50,  0, 8, 2,50  ,0\r
Syn.Str4  , 0,64, 50,  0, 8, 2,50  ,0\r
Syn Str5  , 0,65, 50,  0, 0, 2,50  ,0\r
Solitude  , 0,66, 50,  0, 0, 2,50  ,0\r
Fate      , 0,67, 50,  0, 0, 2,50  ,0\r
Thulium   , 0,68, 50,  0, 0, 2,50  ,0\r
Brook     , 0,69, 50,  0, 0, 2,50  ,0\r
Brook St  , 0,70, 50,  0, 0, 2,50  ,0\r
Syn.Str2  , 0, 0, 51,  0, 0, 2,51  ,0\r
TradeWnd  , 0,21, 51,  0, 0, 2,51  ,0\r
WormHole  , 0,39, 51,  0, 0, 2,51  ,0\r
Hope      , 0,64, 51,  0, 0, 2,51  ,0\r
Virgo     , 0,65, 51,  0, 0, 2,51  ,0\r
Platinum  , 0,66, 51,  0, 0, 2,51  ,0\r
OctavPWM  , 0,67, 51,  0, 0, 2,51  ,0\r
Taurus    , 0,68, 51,  0, 0, 2,51  ,0\r
Frost     , 0,69, 51,  0, 0, 2,51  ,0\r
Leo       , 0,70, 51,  0, 0, 2,51  ,0\r
SolPlexs  , 0,71, 51,  0, 0, 2,51  ,0\r
ChoirAah  , 0, 0, 52,  3, 0, 2,52  ,0\r
S.Choir   , 0 ,3, 52,  4, 8, 2,52  ,0\r
Ch Aahs2  , 0,16, 52,  3,32, 2,52  ,0\r
MelChoir  , 0,32, 52,  5, 9, 2,52  ,0\r
Gasp      , 0,39, 52,  5, 9, 2,52  ,0\r
ChoirStr  , 0,40, 52,  4,11, 2,48  ,0\r
Dead Sea  , 0,41, 52,  4,11, 2,48  ,0\r
StrngAah  , 0,64, 52,  0,11, 2,48  ,0\r
Male Aah  , 0,65, 52,  0, 0, 2,52  ,0\r
Scroll    , 0,66, 52,  0, 0, 2,52  ,0\r
Scroll +  , 0,67, 52,  0, 0, 2,52  ,0\r
VoiceOoh  , 0, 0, 53, 11, 0, 2,53  ,0\r
VoiceDoo  , 0,64, 53, 11, 0, 2,53  ,0\r
Hmn       , 0,65, 53, 11, 0, 2,53  ,0\r
WrlChoir  , 0,66, 53, 11, 0, 2,53  ,0\r
VoiceHmn  , 0,96, 53, 11, 0, 2,53  ,0\r
SynVoice  , 0, 0, 54, 17, 0, 2,54  ,0\r
Syn.Vox2  , 0,40, 54, 17, 8, 2,54  ,0\r
Choral    , 0,41, 54, 12, 0, 2,54  ,0\r
AnaVoice  , 0,64, 54, 12, 0, 2,54  ,0\r
Aspirate  , 0,65, 54, 12, 0, 2,54  ,0\r
AsprateD  , 0,66, 54, 12, 0, 2,54  ,0\r
Facula    , 0,67, 54, 12, 0, 2,54  ,0\r
Orch.Hit  , 0, 0, 55,  0, 0, 2,55  ,0\r
LoFi HIt  , 0,12, 55,  0, 0, 2,55  ,0\r
OrchHit2  , 0,35, 55,  0, 0, 2,55  ,0\r
Throne    , 0,40, 55,  0, 0, 2,55  ,0\r
Impact    , 0,64, 55,  0, 8, 2,55  ,0\r
BrssStab  , 0,65, 55,  0,10, 2,55  ,0\r
DoublHit  , 0,66, 55,  0, 9, 2,55  ,0\r
BrStab80  , 0,67, 55,  0,16, 2,55  ,0\r
Bass Hit  , 0,68, 55,  0,16, 2,55  ,0\r
BassHit+  , 0,69, 55,  0,16, 2,55  ,0\r
6th Hit   , 0,70, 55,  0,16, 2,55  ,0\r
6th Hit+  , 0,71, 55,  0,16, 2,55  ,0\r
Euro Hit  , 0,72, 55,  0,16, 2,55  ,0\r
EuroHit+  , 0,73, 55,  0,16, 2,55  ,0\r
Blowout   , 0,74, 55,  0,16, 2,55  ,0\r
;\r
; ブラス\r
;\r
Trumpet#  , 0, 0, 56, -2, 0,1,56   ,0\r
Trumpet2  , 0,16, 56,  0, 1,2,56   ,0\r
BriteTrp  , 0,17, 56,  0,24,2,56   ,0\r
WarmTrp   , 0,32, 56,  0,25,2,56   ,0\r
DarkTrp   , 0,64, 56,  0,25,2,56   ,0\r
DrkTpSft  , 0,65, 56,  0,25,2,56   ,0\r
Soft Trp  , 0,66, 56,  0,25,2,56   ,0\r
Blow      , 0,67, 56,  0,25,2,56   ,0\r
Blow Dbl  , 0,68, 56,  0,25,2,56   ,0\r
FluglHrn  , 0,96, 56,  0, 8,2,56   ,0\r
Cornet    , 0,97, 56,  0, 8,2,56   ,0\r
Trmbone#  , 0, 0, 57,  0, 0,1,57   ,0\r
Trmbone2  , 0,18, 57,  0, 1,2,57   ,0\r
BrghtTrb  , 0,64, 57,  0, 1,2,57   ,0\r
MellowTb  , 0,65, 57,  0, 1,2,57   ,0\r
JJJ       , 0,66, 57,  0, 1,2,57   ,0\r
Tuba      , 0, 0, 58,  0, 0,1,58   ,0\r
Tuba2     , 0,16, 58,  0, 1,2,58   ,0\r
MuteTrp#  , 0, 0, 59, -8, 0,1,59   ,0\r
BackYard  , 0,40, 59,  0, 0,2,59   ,0\r
MuteTrp2  , 0,64, 59,  0, 0,2,59   ,0\r
Bkstairs  , 0,65, 59, -6, 0,2,59   ,0\r
Fr.Horn   , 0, 0, 60, -4, 0,1,60   ,0\r
Fr.HrnSl  , 0, 6, 60, -4, 8,2,60   ,0\r
Fr.Horn2  , 0,32, 60, -4, 1,2,60   ,0\r
HornOrch  , 0,37, 60, -4,16,2,60   ,0\r
Syn Horn  , 0,64, 60, -4,16,2,60   ,0\r
BrssSec#  , 0, 0, 61, -4, 0,2,61   ,0\r
StBrsSec  , 0, 3, 61, -4, 0,2,61   ,0\r
SfrzndBr  , 0,14, 61, -2, 0,2,61   ,0\r
MildBrss  , 0,18, 61, -2, 0,2,61   ,0\r
Tp&TbSec  , 0,35, 61,  0, 0,2,61   ,0\r
Tp&TbSc2  , 0,36, 61,  0, 0,2,61   ,0\r
BrssFall  , 0,39, 61, -2,16,2,61   ,0\r
Brass 2   , 0,40, 61, -2, 8,2,61   ,0\r
Hi Brass  , 0,41, 61,  0, 8,2,61   ,0\r
MelloBrs  , 0,42, 61,  0, 8,2,61   ,0\r
Bund      , 0,52, 61,  0, 8,2,61   ,0\r
FakeHorn  , 0,53, 61,  0, 8,2,61   ,0\r
FkHrnOCt  , 0,54, 61,  0, 8,2,61   ,0\r
SprBrass  , 0,64, 61,  0, 8,2,61   ,0\r
SprBrCut  , 0,65, 61,  0, 8,2,61   ,0\r
SprBrBrw  , 0,66, 61,  0, 8,2,61   ,0\r
Pwrd Sfz  , 0,67, 61,  0, 8,2,61   ,0\r
PwrSfzBr  , 0,68, 61,  0, 8,2,61   ,0\r
Alto&Trp  , 0,69, 61,  0, 8,2,61   ,0\r
Tnr&Trp   , 0,70, 61,  0, 8,2,61   ,0\r
BrssBros  , 0,71, 61,  0, 8,2,61   ,0\r
VagueBro  , 0,72, 61,  0, 8,2,61   ,0\r
SynBras1  , 0, 0, 62, -2, 0,2,62   ,0\r
QuarkBrs  , 0,12, 62, -2, 9,2,62   ,0\r
RezSynBr  , 0,20, 62,  0, 0,2,62   ,0\r
PolyBras  , 0,24, 62, -1, 1,2,62   ,0\r
SynBras3  , 0,27, 62,  0, 8,2,62   ,0\r
AnalgSfz  , 0,29, 62,  0, 8,2,62   ,0\r
JumpBras  , 0,32, 62,  0,16,2,62   ,0\r
SyBrsSub  , 0,40, 62,  0,16,2,62   ,0\r
AnaVelBr  , 0,45, 62,  0, 0,2,62   ,0\r
AnaBrss1  , 0,64, 62,  0, 0,2,62   ,0\r
SynthThn  , 0,65, 62,  0, 0,2,62   ,0\r
SyncBrss  , 0,66, 62,  0, 0,2,62   ,0\r
SyncBrSt  , 0,67, 62,  0, 0,2,62   ,0\r
AnaHorn1  , 0,68, 62,  0, 0,2,62   ,0\r
AnaHorn1  , 0,69, 62,  0, 0,2,62   ,0\r
AnHrnOct  , 0,70, 62,  0, 0,2,62   ,0\r
SawBrPwr  , 0,71, 62,  0, 0,2,62   ,0\r
SynBras2  , 0, 0, 63,  0, 0,2,63   ,0\r
Soft Brs  , 0,18, 63,  0, 1,2,63   ,0\r
SynBras4  , 0,40, 63,  0, 8,2,63   ,0\r
ChoirBrs  , 0,41, 63,  0, 0,2,63   ,0\r
AnHrnRch  , 0,42, 63,  0, 0,2,63   ,0\r
VelBras2  , 0,45, 63,  0,16,2,63   ,0\r
AnaBrss 2 , 0,64, 63,  0,17,2,63   ,0\r
Soft Cut  , 0,65, 63,  0,17,2,63   ,0\r
AnaHornS  , 0,66, 63,  0,17,2,63   ,0\r
;\r
; リード\r
;\r
SprnoSax  , 0, 0, 64, 12, 0,2,64   ,0\r
VgSprnSx  , 0, 8, 64,  2, 0,2,64   ,0\r
Mdtation  , 0,64, 64,  2, 0,2,64   ,0\r
MdtatnRs  , 0,65, 64,  2, 0,2,64   ,0\r
AltoSax#  , 0, 0, 65,  9, 0,1,65   ,0\r
ASax Lgt  , 0,18, 65,  9, 0,1,65   ,0\r
Sax Sect  , 0,40, 65,  7, 0,2,65   ,0\r
HyprAlto  , 0,43, 65,  6, 8,2,65   ,0\r
ASaxPwrd  , 0,64, 65,  6, 8,2,65   ,0\r
FakeAlto  , 0,65, 65,  6, 8,2,65   ,0\r
FakeAlt+  , 0,66, 65,  6, 8,2,65   ,0\r
FakeAltD  , 0,67, 65,  6, 8,2,65   ,0\r
TenorSax  , 0, 0, 66,  4, 0,1,66   ,0\r
BrthTnSx  , 0,40, 66,  3, 8,2,66   ,0\r
Soft Tnr  , 0,41, 66,  4, 0,2,66   ,0\r
TnrSax 2  , 0,64, 66,  2, 0,1,66   ,0\r
SprTenor  , 0,65, 66,  2, 0,1,66   ,0\r
SprTnr +  , 0,66, 66,  2, 0,1,66   ,0\r
SprTnrSt  , 0,67, 66,  2, 0,1,66   ,0\r
Tnr&Alto  , 0,68, 66,  2, 0,1,66   ,0\r
Bari.Sax  , 0, 0, 67,  2, 0,1,67   ,0\r
Oboe    # , 0, 0, 68,  8, 0,2,68   ,0\r
Heinz     , 0,64, 68,  8, 0,2,68   ,0\r
HeinzUni  , 0,65, 68,  8, 0,2,68   ,0\r
Eng.Horn  , 0, 0, 69,  0, 0,1,69   ,0\r
Basson    , 0, 0, 70,  0, 0,1,70   ,0\r
Clarinet  , 0, 0, 71,  1, 0,1,71   ,0\r
Syn&clr   , 0,40, 71,  1, 0,1,71   ,0\r
BassClar  , 0,96, 71,  0, 8,2,71   ,0\r
;\r
;パイプ\r
;\r
Piccolo   , 0, 0, 72, -4, 0,1,72   ,0\r
Flute    #, 0, 0, 73,  3, 0,1,73   ,0\r
NeatBrth  , 0,40, 73,  3, 0,1,73   ,0\r
Boehm     , 0,64, 73,  3, 0,1,73   ,0\r
Boehm Br  , 0,65, 73,  3, 0,1,73   ,0\r
Pastoral  , 0,66, 73,  3, 0,1,73   ,0\r
Shepherd  , 0,67, 73,  3, 0,1,73   ,0\r
Recorder  , 0, 0, 74,  6, 0,1,74   ,0\r
Piplith   , 0,64, 74,  6, 0,1,74   ,0\r
Home      , 0,65, 74,  6, 0,1,74   ,0\r
PanFlute #, 0, 0, 75,-10, 0,2,75   ,0\r
PanFlut2  , 0,64, 75,-10, 0,2,75   ,0\r
Meadow    , 0,65, 75,-10, 0,2,75   ,0\r
Kawala    , 0,96, 75, -2, 8,2,75   ,0\r
Bottle    , 0, 0, 76,  0, 0,2,76   ,0\r
BottlLgt  , 0,64, 76,  0, 0,2,76   ,0\r
Shakhchi  , 0, 0, 77,  7, 0,2,77   ,0\r
Whistle   , 0, 0, 78,  0, 0,2,78   ,0\r
Reverie   , 0,64, 78,  0, 0,2,78   ,0\r
Ocarina   , 0, 0, 79,  2, 0,2,79   ,0\r
Oparina   , 0,64, 79,  2, 0,2,79   ,0\r
;\r
; シンセ・リード\r
;\r
SquareLd  , 0, 0, 80, 1,  0,2,80   ,0\r
Square 2  , 0, 6, 80, 2,  1,2,80   ,0\r
LM Squar  , 0, 8, 80, 0,  6,2,80   ,0\r
Hollow    , 0,18, 80, 0,  2,2,80   ,0\r
Shmoog    , 0,19, 80, 0,  5,2,80   ,0\r
2 Osc     , 0,35, 80, 0,  5,2,80   ,0\r
Mellow    , 0,64, 80, 0,  3,2,80   ,0\r
SoloSine  , 0,65, 80, 0,  8,2,80   ,0\r
SineLead  , 0,66, 80, 0,  8,2,80   ,0\r
Pluse Ld  , 0,67, 80, 0,  8,2,80   ,0\r
SyncLead  , 0,68, 80, 0,  8,2,80   ,0\r
ForcdOsc  , 0,69, 80, 0,  8,2,80   ,0\r
Accent    , 0,70, 80, 0,  8,2,80   ,0\r
Brick     , 0,71, 80, 0,  8,2,80   ,0\r
Alum      , 0,72, 80, 0,  8,2,80   ,0\r
Query     , 0,73, 80, 0,  8,2,80   ,0\r
FMSlwSwp  , 0,74, 80, 0,  8,2,80   ,0\r
DynvLdDb  , 0,75, 80, 0,  8,2,80   ,0\r
Curse     , 0,76, 80, 0,  8,2,80   ,0\r
OctvBeep  , 0,77, 80, 0,  8,2,80   ,0\r
;\r
Saw.Lead  , 0, 0, 81, 0,  0,2,81   ,0\r
Saw 2     , 0, 6, 81, 0,  1,2,81   ,0\r
ThickSaw  , 0, 8, 81, 0,  6,2,81   ,0\r
Dyna Saw  , 0,18, 81, 0,  3,2,81   ,0\r
Digi Saw  , 0,19, 81, 0,  7,2,81   ,0\r
Big Lead  , 0,20, 81, 0,  4,2,81   ,0\r
Heavy Syn , 0,24, 81, 0,  4,2,81   ,0\r
Waspy Syn , 0,25, 81, 0, 16,2,81   ,0\r
Mondo     , 0,26, 81, 0, 16,2,81   ,0\r
RezzySaw  , 0,27, 81, 0, 16,2,81   ,0\r
DoublSaw  , 0,32, 81, 0, 16,2,81   ,0\r
Toy Lead  , 0,35, 81, 0, 16,2,81   ,0\r
Dim Saw   , 0,36, 81, 0, 16,2,81   ,0\r
Pulse Saw , 0,40, 81, 0,  2,2,81   ,0\r
Dr.Lead   , 0,41, 81, 0,  8,2,81   ,0\r
VeloLead  , 0,45, 81, 0,  5,2,81   ,0\r
Digger    , 0,64, 81, 0,  5,2,81   ,0\r
Dunce     , 0,65, 81, 0,  5,2,81   ,0\r
BrassSaw  , 0,66, 81, 0,  5,2,81   ,0\r
SawRiver  , 0,67, 81, 0,  5,2,81   ,0\r
BrPulsDb  , 0,68, 81, 0,  5,2,81   ,0\r
Saw Trp   , 0,69, 81, 0,  5,2,81   ,0\r
Hue       , 0,70, 81, 0,  5,2,81   ,0\r
StrghtSw  , 0,71, 81, 0,  1,2,81   ,0\r
StrtPlse  , 0,72, 81, 0,  2,2,81   ,0\r
PWMania   , 0,73, 81, 0,  2,2,81   ,0\r
Mod Saw   , 0,74, 81, 0,  2,2,81   ,0\r
Toad      , 0,75, 81, 0,  2,2,81   ,0\r
FatOctav  , 0,76, 81, 0,  2,2,81   ,0\r
Overdose  , 0,77, 81, 0,  2,2,81   ,0\r
PWMDecay  , 0,78, 81, 0,  2,2,81   ,0\r
SawDecay  , 0,79, 81, 0,  2,2,81   ,0\r
Seq Ana   , 0,96, 81, 0,  0,2,81   ,0\r
;\r
CaliopLd  , 0, 0, 82, 0,  0,2,82   ,0\r
Novice    , 0,40, 82, 0,  0,2,82   ,0\r
Vent Syn  , 0,64, 82, 0,  1,2,82   ,0\r
Pure Pan  , 0,65, 82, 1,  2,2,82   ,0\r
ElPrimtv  , 0,66, 82, 1,  2,2,82   ,0\r
Chiff Ld  , 0, 0, 83, 0,  0,2,83   ,0\r
SaltLead  , 0,40, 83, 0,  0,2,83   ,0\r
Rubby     , 0,64, 83, 0,  0,2,83   ,0\r
HardSync  , 0,65, 83, 0,  0,2,83   ,0\r
ChargLd   , 0, 0, 84, 0,  0,2,84   ,0\r
DistLead  , 0,64, 84, 0,  8,2,84   ,0\r
WireLead  , 0,65, 84, 0,  8,2,84   ,0\r
SynPluck  , 0,66, 84, 0,  8,2,84   ,0\r
Voice Ld  , 0, 0, 85, 0,  0,2,85   ,0\r
SynthAah  , 0,24, 85, 0,  0,2,85   ,0\r
Voc Lead  , 0,64, 85, 0,  0,2,85   ,0\r
Br.Layer  , 0,65, 85, 0,  0,2,85   ,0\r
Cypher 1  , 0,66, 85, 0,  0,2,85   ,0\r
Cypher 2  , 0,67, 85, 0,  0,2,85   ,0\r
Cypher 3  , 0,68, 85, 0,  0,2,85   ,0\r
SynCyphr  , 0,69, 85, 0,  0,2,85   ,0\r
Fifth Ld  , 0, 0, 86, 0,  0,2,86   ,0\r
FifthLdS  , 0, 8, 86, 0,  0,2,86   ,0\r
Big Five  , 0,35, 86, 0,  1,2,86   ,0\r
Bass& Ld  , 0, 0, 87, 9,  0,2,87   ,0\r
Big& Raw  , 0,16, 87 ,6,  1,2,87   ,0\r
Fat&Prky  , 0,64, 87, 8,  2,2,87   ,0\r
Soft Wrl  , 0,65, 87, 8,  2,2,87   ,0\r
Cant      , 0,66, 87, 8,  2,2,87   ,0\r
Mogul     , 0,67, 87, 8,  2,2,87   ,0\r
Distance  , 0,68, 87, 8,  2,2,87   ,0\r
Sync B&L  , 0,69, 87, 8,  2,2,87   ,0\r
;\r
; シンセ・パッドなど\r
;\r
NewAgePd  , 0, 0, 88, 0,  0,2,88   ,0\r
Fantasy 2 , 0,64, 88, 0,  1,2,88   ,0\r
Libra     , 0,65, 88, 0,  1,2,88   ,0\r
Warm Pad  , 0, 0, 89,10,  0,2,89   ,0\r
Thick Pad , 0,16, 89, 0,  1,2,89   ,0\r
Soft Pad  , 0,17, 89, 0,  4,2,89   ,0\r
Sine Pad  , 0,18, 89, 0,  2,2,89   ,0\r
Vishnu    , 0,40, 89, 0,  2,2,89   ,0\r
Horn Pad  , 0,64, 89, 0,  2,2,89   ,0\r
RotarStr  , 0,65, 89, 0,  3,2,89   ,0\r
PolysynPd , 0, 0, 90, 0,  0,2,90   ,0\r
PolyPd 80 , 0,64, 90, 0,  1,2,90   ,0\r
ClickPad  , 0,65, 90, 0,  0,2,90   ,0\r
Ana Pad   , 0,66, 90, 0,  0,2,90   ,0\r
Square Pd , 0,67, 90, 0,  0,2,90   ,0\r
Snow   Pd , 0,68, 90, 0,  0,2,90   ,0\r
Pixie     , 0,69, 90, 0,  0,2,90   ,0\r
Pisces    , 0,70, 90, 0,  0,2,90   ,0\r
Spiral    , 0,69, 90, 0,  0,2,90   ,0\r
Choir Pad , 0, 0, 91, 0,  0,2,91   ,0\r
Heaven    , 0,64, 91, 0,  1,2,91   ,0\r
Lite Pad  , 0,65, 91, 0,  0,2,91   ,0\r
Itopia    , 0,66, 91, 0,  0,2,91   ,0\r
CC Pad    , 0,67, 91, 0,  0,2,91   ,0\r
Cosmic Pad, 0,68, 91, 0,  0,2,91   ,0\r
Bowed Pad , 0, 0, 92, 0,  0,2,92   ,0\r
Gracier   , 0,64, 92, 0,  0,2,92   ,0\r
Grass Pad , 0,65, 92, 0,  0,2,92   ,0\r
SqrTwang  , 0,66, 92, 0,, 0,2,92   ,0\r
Metal Pad , 0, 0, 93, 0,  0,2,93   ,0\r
Tine Pad  , 0,64, 93, 0,  0,2,93   ,0\r
Pan Pad   , 0,65, 93,-12, 0,2,93   ,0\r
Queever   , 0,66, 93, 0,  0,2,93   ,0\r
Halo Pad  , 0, 0, 94, 0,  0,2,94   ,0\r
Tiu       , 0,40, 94, 0,  0,2,94   ,0\r
Aries     , 0,64, 94, 0,  0,2,94   ,0\r
Sweep Pad , 0, 0, 95, 0,  0,2,95   ,0\r
Shwimmer  , 0,20, 95, 0,  9,2,95   ,0\r
Converge  , 0,27, 95, 0,  8,2,95   ,0\r
Polar Pad , 0,64, 95, 0,  1,2,95   ,0\r
Sweepy    , 0,65, 95, 0,  0,2,95   ,0\r
Celestial , 0,66, 95, 0, 10,2,95   ,0\r
Monsoon   , 0,67, 95, 0, 10,2,95   ,0\r
IO        , 0,68, 95, 0, 10,2,95   ,0\r
;\r
; シンセＳＦＸ\r
;\r
Rain      , 0, 0, 96, 0,  0,2,96   ,0\r
ClaviPad  , 0,45, 96, 0,  8,2,96   ,0\r
HrmoRain  , 0,64, 96, 0,  1,2,96   ,0\r
Afrcnwod  , 0,65, 96, 0,  2,2,96   ,0\r
Caribean  , 0,66, 96, 0,  0,2,96   ,0\r
SoundTrk  , 0, 0, 97, 0,  0,2,97   ,0\r
Prologue  , 0,27, 97, 0,  2,2,97   ,0\r
Ancestrl  , 0,64 ,97 ,0,  1,2,97   ,0\r
Rave      , 0,65, 97, 0,  8,2,97   ,0\r
Fairy     , 0,66, 97, 0,  8,2,97   ,0\r
Hermit    , 0,67, 97, 0,  8,2,97   ,0\r
Crystal   , 0, 0, 98,-20, 0,2,98   ,0\r
SynDrCmp  , 0,12, 98,-15, 0,2,98   ,0\r
PopCorn   , 0,14, 98,-15, 0,2,98   ,0\r
TinyBell  , 0,18, 98,-15, 0,2,98   ,0\r
RndGlock  , 0,35, 98,-5,  3,2,98   ,0\r
GlockChi  , 0,40, 98,-5,  5,2,98   ,0\r
ClearBel  , 0,41, 98,-5,  6,2,98   ,0\r
ChorBell  , 0,42, 98,-5, 16,2,98   ,0\r
SynMalet  , 0,64, 98,-5,  1,2,98   ,0\r
SftCryst  , 0,65, 98,-5,  2,2,98   ,0\r
LoudGlok  , 0,66, 98,-5,  4,2,98   ,0\r
XmasBell  , 0,67, 98,-5,  7,2,98   ,0\r
VibeBell  , 0,68, 98,-5,  8,2,98   ,0\r
DigiBell  , 0,69, 98,-5,  9,2,98   ,0\r
AirBells  , 0,70, 98,-5, 17,2,98   ,0\r
BellHarp  , 0,71, 98,-5, 18,2,98   ,0\r
Gamelmba  , 0,72, 98, 0, 19,2,98   ,0\r
Bounce    , 0,73, 98, 0, 19,2,98   ,0\r
Atmosphr  , 0, 0, 99, 0,  0,2,99   ,0\r
WarmAtms  , 0,18, 99, 0,  1,2,99   ,0\r
HollwRls  , 0,19, 99, 0,  4,2,99   ,0\r
Nylon EP  , 0,40, 99, 0,  5,2,99   ,0\r
NylnHarp  , 0,64, 99, 0,  2,2,99   ,0\r
Harp vox  , 0,65, 99, 0,  3,2,99   ,0\r
AtomsPad  , 0,66, 99, 0,  6,2,99   ,0\r
Planet    , 0,67, 99, 0,  6,2,99   ,0\r
Lyra      , 0,68, 99, 0,  6,2,99   ,0\r
Akasaka   , 0,69, 99, 0,  6,2,99   ,0\r
DgBermda  , 0,70, 99, 0,  6,2,99   ,0\r
Bright    , 0, 0,100,-6,  0,2,100  ,0\r
FantaBel  , 0,64,100, 0,  0,2,100  ,0\r
Smokey    , 0,96,100, 0,  0,2,100  ,0\r
Goblins   , 0, 0,101, 0,  0,2,101  ,0\r
Gobnsyn   , 0,64,101, 0,  1,2,101  ,0\r
Creeper   , 0,65,101, 0,  2,2,101  ,0\r
Ring Pad  , 0,66,101, 0,  0,2,101  ,0\r
Ritual    , 0,67,101, 0,  0,2,101  ,0\r
ToHeaven  , 0,68,101, 0,  0,2,101  ,0\r
MlkeyWay  , 0,69,101, 0,  0,2,101  ,0\r
Night     , 0,70,101, 0,  0,2,101  ,0\r
Glisten   , 0,71,101, 0,  0,2,101  ,0\r
Puffy     , 0,72,101, 0,  0,2,101  ,0\r
Mimicry   , 0,73,101, 0,  0,2,101  ,0\r
Parasite  , 0,74,101, 0,  0,2,101  ,0\r
Cicada    , 0,75,101, 0,  0,2,101  ,0\r
Beacon    , 0,76,101, 0,  0,2,101  ,0\r
BelChoir  , 0,96,101, 0,  0,2,101  ,0\r
Dharama   , 0,97,101, 0,  0,2,101  ,0\r
Echoes    , 0, 0,102, 0,  0,2,102  ,0\r
Echoes 2  , 0, 8,102, 0,  2,2,102  ,0\r
Echo Pan  , 0,14,102, 0,  3,2,102  ,0\r
EchoBell  , 0,64,102, 0,  1,2,102  ,0\r
Big Pan   , 0,65,102, 0,  4,2,102  ,0\r
SynPiano  , 0,66,102, 0,  6,2,102  ,0\r
Creation  , 0,67,102, 0,  6,2,102  ,0\r
Stardust  , 0,68,102, 0,  6,2,102  ,0\r
Reso&Pan  , 0,69,102, 0,  5,2,102  ,0\r
Sci-Fi    , 0, 0,103, 0,  0,2,103  ,0\r
Starz     , 0,64,103, 0,  1,2,103  ,0\r
Odyssey   , 0,65,103, 0,  1,2,103  ,0\r
;\r
; エスニックなど\r
;\r
Sitar     , 0, 0,104, 9,  0,2,104  ,0\r
DetSitar  , 0,32,104,12,  2,2,104  ,0\r
Sitar 2   , 0,35,104,10,  1,2,104  ,0\r
Bhuj      , 0,40,104,10,  1,2,104  ,0\r
Raga Syn  , 0,64,104,10,  1,2,104  ,0\r
Tambra    , 0,96,104, 0,  8,2,104  ,0\r
Tamboura  , 0,97,104, 0, 16,2,104  ,0\r
Bnajo     , 0, 0,105, 0,  0,2,105  ,0\r
Mt.Banjo  , 0,28,105, 0,  1,2,105  ,0\r
El Banjo  , 0,64,105, 0,  1,2,105  ,0\r
Rabab     , 0,96,105, 0,  8,2,105  ,0\r
Gopichnt  , 0,97,105, 0, 16,2,105  ,0\r
Oud       , 0 98,105, 0, 24,2,105  ,0\r
Shamisen  , 0, 0,106, 0,  0,2,106  ,0\r
Tsugaru   , 0,96,106, 0,  1,2,106  ,0\r
Koto      , 0, 0,107, 0,  0,2,107  ,0\r
FM Koto   , 0,64,107, 0,  0,2,107  ,0\r
Taisho-k  , 0,96,107, 0,  8,2,107  ,0\r
Kanoon    , 0,97,107, 0, 16,2,107  ,0\r
Kalimba   , 0, 0,108, 0,  0,2,108  ,0\r
Big Klim  , 0,64,108, 0,  0,2,108  ,0\r
Bagpipe   , 0, 0,109, 0,  0,2,109  ,0\r
Thistle   , 0,64,109, 0,  0,2,109  ,0\r
Fiddle    , 0, 0,110, 0,  0,2,110  ,0\r
Shanai    , 0, 0,111, 0,  0,2,111  ,0\r
Shanai 2  , 0,64,111, 0,  1,2,111  ,0\r
Pungi     , 0,96,111, 0,  8,2,111  ,0\r
Hichriki  , 0,97,111, 0, 16,2,111  ,0\r
;\r
; パーカッシブ\r
;\r
TnklBell  , 0, 0,112, 0,  0,2,112  ,0\r
TcklBell  , 0,64,112, 0,  0,2,112  ,0\r
Bonang    , 0,96,112, 0,  8,2,112  ,0\r
Gender    , 0,97,112, 0,  9,2,112  ,0\r
Gamelan   , 0,98,112, 0, 10,2,112  ,0\r
S.Gamlan  , 0,99,112, 0, 11,2,112  ,0\r
Rama Cym  , 0,100,112,0, 16,2,112  ,0\r
AsianBel  , 0,101,112,0, 16,2,112  ,0\r
Agogo     , 0, 0,113, 0,  0,2,113  ,0\r
Atrigane  , 0,96,113, 0,  8,2,113  ,0\r
SteelDrm  , 0, 0,114, 0,  0,2,114  ,0\r
Tablas    , 0,96,114, 0,  0,2,114  ,0\r
Glas Perc , 0,97,114, 0,  0,2,114  ,0\r
Thai Bell , 0,98,114, 0,  0,2,114  ,0\r
Woodblck  , 0, 0,115, 0,  0,2,115  ,0\r
Castanet  , 0,96,115, 0,  8,2,115  ,0\r
Taiko     , 0, 0,116, 0,  0,2,116  ,0\r
Gr.Cassa  , 0,96,116, 0,  8,2,116  ,0\r
Melo.Tom1 , 0, 0,117, 0,  0,2,117  ,0\r
Melo.Tom2 , 0,64,117, 0,  8,2,117  ,0\r
Real Tom  , 0,65,117, 0,  1,2,117  ,0\r
Rock Tom  , 0,66,117, 0,  9,2,117  ,0\r
SynthTom  , 0, 0,118, 0,  0,2,118  ,0\r
808 Tom   , 0,64,118, 0,  8,2,118  ,0\r
ElecPerc  , 0,65,118, 0,  9,2,118  ,0\r
Rev Cym   , 0, 0,119, 0,  0,2,119  ,0\r
Rev Cym2  , 0,64,119, 0,  1,2,119  ,0\r
RevSnar1  , 0,96,119, 0,  8,2,119  ,0\r
RevSnar2  , 0,97,119, 0,  9,2,119  ,0\r
RevKick1  , 0,98,119, 0, 16,2,119  ,0\r
RevConBD  , 0,99,119, 0, 17,2,119  ,0\r
Rev Tom1  , 0,100,119, 0,24,2,119  ,0\r
Rev Tom2  , 0,101,119, 0,25,2,119  ,0\r
;\r
GtFtNoiz  , 0, 0,120, 0,  0,2,120  ,0\r
GtCtNoiz  ,64, 0,  0, 0,  1,2,120  ,0\r
Str Slap  ,64, 0,  3, 0,  2,2,120  ,0\r
GtCtNoz2  ,64, 0,  1, 0,  3,2,120  ,0\r
DsCtNoiz  ,64, 0,  2, 0,  4,2,120  ,0\r
BassSlde  ,64, 0,  4, 0,  5,2,120  ,0\r
PickScrp  ,64, 0,  5, 0,  6,2,120  ,0\r
BrthNoiz  , 0, 0,121, 0,  0,2,121  ,0\r
FlKyClck  ,64, 0, 16, 0,  1,2,121  ,0\r
Seashore  , 0, 0,122, 0,  0,2,122  ,0\r
Rain      ,64, 0, 32, 0,  1,2,122  ,0\r
Thunder   ,64, 0, 33, 0,  2,2,122  ,0\r
Wind      ,64, 0, 34, 0,  3,2,122  ,0\r
Stream    ,64, 0, 35, 0,  4,2,122  ,0\r
Bubble    ,64, 0, 36, 0,  5,2,122  ,0\r
Feed      ,64, 0, 37, 0,  5,2,122  ,0\r
Bird      , 0, 0,123, 0,  0,2,123  ,0\r
Dog       ,64, 0, 48, 0,  1,2,123  ,0\r
Horse     ,64, 0, 49, 0,  2,2,123  ,0\r
Bird 2    ,64, 0, 50, 0,  3,2,123  ,0\r
Kitty     ,64, 0, 51, 0,  4,2,123  ,0\r
Growl     ,64, 0, 52, 0,  5,2,123  ,0\r
Haunted   ,64, 0, 53, 0,  5,2,123  ,0\r
Ghost     ,64, 0, 54, 0,  5,2,123  ,0\r
Maou      ,64, 0, 55, 0,  5,2,123  ,0\r
Tele 1    , 0, 0,124, 0,  0,2,124  ,0\r
Tel.Dial  ,64, 0, 64, 0,  1,2,124  ,0\r
Creaking  ,64, 0, 65, 0,  2,2,124  ,0\r
Door      ,64, 0, 66, 0,  3,2,124  ,0\r
Scratch   ,64, 0, 67, 0,  4,2,124  ,0\r
Scratch2  ,64, 0, 68, 0,  7,2,124  ,0\r
WindChim  ,64, 0, 69, 0,  5,2,124  ,0\r
Tele 2    ,64, 0, 70, 0,  1,2,124  ,0\r
Helcpter  , 0, 0,125, 0,  0,2,125  ,0\r
CarEngne  ,64, 0, 80, 0,  1,2,125  ,0\r
Car-Stop  ,64, 0, 81, 0,  2,2,125  ,0\r
Car-Pass  ,64, 0, 82, 0,  3,2,125  ,0\r
CarCrash  ,64, 0, 83, 0,  4,2,125  ,0\r
Siren     ,64, 0, 84, 0,  5,2,125  ,0\r
Train     ,64, 0, 85, 0,  6,2,125  ,0\r
Jetplane  ,64, 0, 86, 0,  7,2,125  ,0\r
Starship  ,64, 0, 87, 0,  8,2,125  ,0\r
BrstNoiz  ,64, 0, 88, 0,  9,2,125  ,0\r
Coaster   ,64, 0, 89, 0,  0,2,125  ,0\r
SbMarine  ,64  0, 90, 0,  5,2,125  ,0\r
Applause  , 0, 0,126, 0,  0,2,126  ,0\r
Laughing  ,64, 0, 96, 0,  1,2,126  ,0\r
Screamng  ,64, 0, 97, 0,  2,2,126  ,0\r
Punch     ,64, 0, 98, 0,  3,2,126  ,0\r
Heart     ,64, 0, 99, 0,  4,2,126  ,0\r
Footstep  ,64, 0,100, 0 , 5,2,126  ,0\r
Aplause2  ,64, 0,101, 0,  6,2,126  ,0\r
Gun Shot  , 0, 0,127, 0,  0,2,127  ,0\r
MchinGun  ,64, 0,112, 0,  1,2,127  ,0\r
Lasergun  ,64, 0,113, 0,  2,2,127  ,0\r
Explsion  ,64, 0,114, 0,  3,2,127  ,0\r
FireWork  ,64, 0,115, 0,  0,2,127  ,0\r
;\r
[DRUMS]\r
;\r
(Standard Kit-> Standard Set, 127, 0,0 , 10,  0,2,0   ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Rock Kit  -> Power Set   , 127, 0,16, 10,  0,2,16  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Rock Kit  -> Power Set   , 127, 0,17, 10,  0,2,16  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Analog Kit -> TR808 Set,  127, 0,25, 10,  0,1,25  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Analog Kit 2 -> TR808909 Set, 127, 0,26, 10,  0,2,25  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Dance  Kit   -> Dance    Set, 127, 0,27, 10,  0,2,27  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(HipHop Kit   -> TR909    Set, 127, 0,28, 10,  0,2,25  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Jungle Kit   -> TR909    Set, 127, 0,29, 10,  0,2,25  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Apogee Kit   -> TR909    Set, 127, 0,30, 10,  0,2,25  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Pergee Kit   -> TR909    Set, 127, 0,31, 10,  0,2,25  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  2,35\r
Kick 1     ,36,  2,36\r
909        ,40,-12,40\r
Open HH    ,46,-12,46\r
;\r
(Room Kit   -> Room Set    , 127, 0, 8, 10,  0,2,8   ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Brush Kit  -> Brush Set   , 127, 0,40, 10,  0,1,40  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Brush Kit 2-> Brush Set   , 127, 0,41, 10,  0,2,40  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(SFX  Set   -> SFX  Set    , 126, 0, 0, 10,  0,2,56  ,0\r
(SFX2 Set   -> R SFX Set   , 126, 0, 1, 10,  0,2,57  ,0\r
;\r
(Elec Kit   -> Elec  Set   , 127, 0,24, 10,  0,2,24  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Class Kit  -> Orch    Set , 127, 0,48, 10,  0,2,48  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
;\r
(Standard 2 -> Standard2Set, 127, 0, 1, 10,  0,2, 1  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Jazz Kit 2 -> Jazz Set    , 127, 0,33, 10,  0,2,32  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Jazz Kit   -> Jazz Set(55), 127, 0,32, 10,  0,1,32  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35,  7,35\r
Kick 1     ,36,  7,36\r
Open HH    ,46,-12,46\r
Tom        ,41, -7,41\r
Tom        ,43, -7,43\r
Tom        ,45, -7,45\r
Tom        ,47, -7,47\r
Tom        ,50, -7,50\r
;\r
(Tramp Kit  -> TR909 Set   , 127, 0,64, 10,  0,2,25  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Amber Kit  -> TR909 Set   , 127, 0,65, 10,  0,2,25  ,0\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Coffin Kit -> TR909 Set   , 127, 0,66, 10,  0,2,25  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Dry   Kit  -> Standard 55 , 127, 0, 2, 10,  0,1, 0  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Brite Kit  -> Standard 2  , 127, 0, 3, 10,  0,2, 1  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Skim  Kit  -> Standard    , 127, 0, 5, 10,  0,2, 0  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Slim  Kit  -> Standard 55 , 127, 0, 5, 10,  0,1, 0  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Rogue Kit  -> Standard    , 127, 0, 6, 10,  0,2, 0  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(Hob   Kit  -> Elect       , 127, 0, 7, 10,  0,2,24  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
(DarkR Kit  -> Room        , 127, 0, 9, 10,  0,2, 8  ,0\r
;\r
SrudoMute  ,13,  0,86\r
SrudoOpen  ,14,  0,87\r
HiQ        ,15,  0,27\r
WhipSlap   ,16,  0,28\r
ScratchPush,17,  0,29\r
ScratchPull,18,  0,30\r
FingerSnap ,19,  0,26\r
ClickNoise ,20,  0,32\r
MetroClick ,21,  0,33\r
MetroBell  ,22,  0,34\r
SeqClickL  ,23,  0,32\r
SeqClickH  ,24,  0,32\r
BrushTap   ,25,-20,40\r
BrushSwirlL,26,-20,40\r
BrushSlap  ,27,-20,40\r
BrushSwirlH,28,-20,40\r
SnareRoll  ,29,  0,25\r
Castanet   ,30,  0,85\r
Snare L    ,31,  0,38\r
Sticks     ,32,  0,31\r
BassDrumL  ,33,  0,36\r
OpenRim    ,34,  0,37\r
Kick 2     ,35, 12,35\r
Kick 1     ,36, 12,36\r
Open HH    ,46,-12,46\r
;\r
;\r
;(C) 1996-2001 Toshikazu Sugama\r
;\r
`,Is={[Ie.XG]:{type:"smfknife",name:"10088.CFG",text:Oa}},Ds=new Map;function Ci(s,e){const n=s===Ie.GS?e==="88PRO"?Is.GS_88PRO:e==="88"?Is.GS_88:null:Is[s];if(!n||n.type!=="smfknife")return null;const i=n.name;if(Ds.has(i))return Ds.get(i);try{const r=ur(n.text,{name:n.name});return Ds.set(i,r),r}catch(r){return console.warn("[MidiMapper] Failed to parse default SMF Knife config",r),null}}function Xs(s,e={}){let n=null,i=Ie.SMF,r=[],a=null,o=!1,l=null,d=e.smfKnifeConfig||null,m=e.ignoreEqForXg??!1,u=e.ignoreFxForXg??!1,h=i,c=e.initialDrumChannels||null;if(s){const p=Ma(s);i=p.standard,r=p.reasons,a=p.gsVariant,o=p.convertSC88,l=p.gsModule||null,console.log(`[MidiMapper] Detected: ${i} (${a||"Std"})`,r,{convertSC88:o}),c||(c=ka(s))}if(h=i,!e.ignoreEqForXg&&i===Ie.XG&&(m=!0),!e.ignoreFxForXg&&i===Ie.XG&&(u=!0),!d&&e.smfKnifeConfigText)try{d=ur(e.smfKnifeConfigText,{name:e.smfKnifeConfigName})}catch(p){console.warn("[MidiMapper] Failed to parse SMF Knife config",p)}if(d||(d=Ci(h,l)),d){const p=d.sourceHint,x=p&&(p===h||h===Ie.GS&&p===Ie.GS);(e.forceSmfKnife||x)&&(h===Ie.GS&&!(l==="88"||l==="88PRO")?n=null:n={type:"smfknife",config:d})}if(!n&&h===Ie.XG){const p=Ci(h,l);p&&(n={type:"smfknife",config:p})}if(!n){const p=x=>[x];return p.setEnabled=()=>{},p.setPreferGsPlayback=()=>{},p.getState=()=>({globalMode:i,detectedStandard:i,detectedBy:"auto-detect",configName:"None (Identity)",drumChannels:c||new Uint8Array(16),detectedModule:l}),p.reset=()=>{},p}let f=null;if(n.type==="factory")f=n.factory(e);else if(n.type==="smfknife")f=Ha(n.config,{...e,ignoreEq:!0,ignoreFx:!0,ignoreEqForXg:m,ignoreFxForXg:u,initialDrumChannels:c});else return console.error("Unknown mapping type",n),Xs(null);const b=f.getState;return f.getState=()=>({...b(),detectedStandard:i,detectedVariant:a,detectedModule:l}),f}const Ne={sampleRate:44100,windowSize:2048,hopSize:256,rmsGate:.01,clarityGate:.8,enableDoubleExponentialSmoothing:!1,smoothAlpha:.5,smoothBeta:.1,stepResetThresholdCents:80,stepResetClusterCents:45,stepResetConfirmFrames:2,f0MinHz:80,f0MaxHz:1e3,pitchToleranceSemis:1.5,f0TimeToleranceSec:.12,breakToleranceMs:0,medianWindowSize:3,maxJumpSemitones:6,holdFrames:0,enablePitchSnap:!1,snapToleranceSemis:.35,hpfCutoffHz:80,enableDcRemoval:!0,enableHpf:!0,enableRmsGate:!0,enableF0Validate:!0,enableTemporalSmooth:!1,micConstraints:{echoCancellation:!1,noiseSuppression:!1,autoGainControl:!1},debugPipeline:!1,debugPipelineStride:4,pitchAlgoId:"aubio",aubioTolerance:.5,yinConfidenceGate:.2};let Un=null,dr=Ne.sampleRate;function hr(){return Un||(Un=new AudioContext({sampleRate:dr}),console.log("Engine: created audio context")),Un}async function Ga(){const s=hr();return s.state!=="running"&&await s.resume(),s}function za(){return Un}function qa(s){if(Un)return;const e=Number(s);Number.isFinite(e)&&e>0&&(dr=e)}let Hs=null;function Qn(){return Hs||(Hs={getAudioContext:za,ensureAudioContext:hr,resumeAudio:Ga,setSampleRate:qa}),Hs}let Os=null;function In(s){const e=Number(s);return Number.isFinite(e)?Math.max(0,Math.min(1,e)):1}function Ka(){const s={sfxVolume:.7,bgmVolume:.9};let e=null,n=null,i=null,r=0;function a(){return e||(e=new Audio,e.preload="auto",e.volume=s.sfxVolume),e}function o(){return n||(n=new Audio,n.preload="auto",n.volume=s.bgmVolume,n.loop=!1),n}function l(p){s.sfxVolume=In(p),e&&(e.volume=s.sfxVolume)}function d(p){s.bgmVolume=In(p),n&&(n.volume=s.bgmVolume)}function m(){return{...s}}async function u(p,x={}){if(!p)return;const S=a(),N=x.volume==null?s.sfxVolume:In(x.volume);try{S.pause(),S.src=p,S.currentTime=0,S.volume=N,await S.play()}catch(w){console.warn("[ui-audio] SFX play failed",w)}finally{S.volume=s.sfxVolume}}function h(){return i&&(cancelAnimationFrame(i),i=null),r+=1,r}function c(p,x){const S=n;if(!S)return;const N=h(),w=performance.now(),v=Number.isFinite(S.volume)?S.volume:s.bgmVolume,_=In(p),R=Math.max(0,Number(x)||0),k=E=>{if(N!==r)return;const se=R>0?Math.min(1,(E-w)/R):1;S.volume=v+(_-v)*se,se<1?i=requestAnimationFrame(k):i=null};i=requestAnimationFrame(k)}async function f(p,x={}){if(!p)return;const S=o();h();const N=x.loop!==!1,w=x.restart!==!1,v=x.volume==null?s.bgmVolume:In(x.volume);try{S.src!==p&&(S.src=p),w&&(S.currentTime=0),S.loop=!!N,S.volume=v,await S.play()}catch(_){console.warn("[ui-audio] BGM play failed",_)}}function b(p={}){const x=n;if(!x)return;const S=Math.max(0,Number(p.fadeMs)||0),N=p.reset!==!1;if(x.loop=!1,S<=0){h();try{x.pause(),N&&(x.currentTime=0),x.volume=s.bgmVolume}catch{}return}const w=h(),v=performance.now(),_=Number.isFinite(x.volume)?x.volume:s.bgmVolume,R=k=>{if(w!==r)return;const E=Math.min(1,(k-v)/S),se=Math.max(0,_*(1-E));if(x.volume=se,E<1){i=requestAnimationFrame(R);return}i=null;try{x.pause(),N&&(x.currentTime=0),x.volume=s.bgmVolume}catch{}};i=requestAnimationFrame(R)}return{getVolumes:m,setSfxVolume:l,setBgmVolume:d,playSfx:u,playBgm:f,stopBgm:b,fadeBgmTo:c}}function Ns(){return Os||(Os=Ka()),Os}const Va={stopFadeMs:3e3},Ys={karaokeTransitionMs:1e3},Kt={enableMIDIStandardMapping:!0,reverb:1.35,chorus:1.2},pt={NOTE_OFF:128,NOTE_ON:144,POLY_PRESSURE:160,CC:176,PROGRAM:192,CHANNEL_PRESSURE:208,PITCH:224},Wa=()=>({type:"unknown",channel:0,note:0,velocity:0,controller:0,value:0,status:0,data:null,raw:null}),$a=(s,e)=>{const n=Number(s?.[0]??0);if(e.status=n,e.raw=s,e.data=null,e.note=0,e.velocity=0,e.controller=0,e.value=0,e.channel=n&15,e.type="unknown",n>=128&&n<240){switch(n&240){case pt.NOTE_OFF:e.type="note_off",e.note=Number(s?.[1]??0),e.velocity=Number(s?.[2]??0);break;case pt.NOTE_ON:e.type="note_on",e.note=Number(s?.[1]??0),e.velocity=Number(s?.[2]??0);break;case pt.POLY_PRESSURE:e.type="poly_pressure",e.note=Number(s?.[1]??0),e.value=Number(s?.[2]??0);break;case pt.CC:e.type="cc",e.controller=Number(s?.[1]??0),e.value=Number(s?.[2]??0);break;case pt.PROGRAM:e.type="program",e.value=Number(s?.[1]??0);break;case pt.CHANNEL_PRESSURE:e.type="channel_pressure",e.value=Number(s?.[1]??0);break;case pt.PITCH:{e.type="pitch";const r=Number(s?.[1]??0)&127,a=Number(s?.[2]??0)&127;e.value=a<<7|r;break}default:e.type="channel";break}return e}return n===240||n===247?(e.type="sysex",e.data=s,e):(e.type="system",e.data=s,e)},Ua=(s,e,n)=>{switch(s.type){case"note_on":return e[0]=pt.NOTE_ON|s.channel&15,e[1]=s.note&127,e[2]=s.velocity&127,e;case"note_off":return e[0]=pt.NOTE_OFF|s.channel&15,e[1]=s.note&127,e[2]=s.velocity&127,e;case"cc":return e[0]=pt.CC|s.channel&15,e[1]=s.controller&127,e[2]=s.value&127,e;case"program":return n[0]=pt.PROGRAM|s.channel&15,n[1]=s.value&127,n;case"channel_pressure":return n[0]=pt.CHANNEL_PRESSURE|s.channel&15,n[1]=s.value&127,n;case"poly_pressure":return e[0]=pt.POLY_PRESSURE|s.channel&15,e[1]=s.note&127,e[2]=s.value&127,e;case"pitch":{const i=Number(s.value)||0;return e[0]=pt.PITCH|s.channel&15,e[1]=i&127,e[2]=i>>7&127,e}case"sysex":case"system":return s.data||s.raw;default:return s.raw}};function Xa(s,e=null){if(!s?.tracks?.length)return Array.from({length:16},()=>null);const n=Array.from({length:16},()=>0),i=Array.from({length:16},()=>0),r=Array.from({length:16},()=>null),a=Array.from({length:16},()=>null),o=Array.from({length:16},()=>0),l=Array.from({length:16},()=>0),d=Array.from({length:16},()=>!1),m=Array.from({length:16},()=>!1),u=[];let h=0;for(const c of s.tracks)if(c?.events?.length)for(const f of c.events){if(!f)continue;const b=Number(f.statusByte);if(!Number.isFinite(b)||b<128)continue;const p=Number(f.ticks)||0,x=b&240,S=b&15,N=f.data?.[0],w=f.data?.[1];let v=9;x===176&&(N===0||N===32)?v=0:x===192?v=1:x===144&&(w??0)>0?v=2:x===176&&(v=8),u.push({ticks:p,status:b,data:f.data,order:v,ordinal:h++}),S>=0&&S<=15&&(m[S]=!0)}u.sort((c,f)=>c.ticks-f.ticks||c.order-f.order||c.ordinal-f.ordinal);for(const c of u){const f=c.status&240,b=c.status&15;if(!(b<0||b>15)){if(f===176){const p=c.data?.[0],x=c.data?.[1];p===0&&(n[b]=x??0,o[b]=n[b]),p===32&&(i[b]=x??0,l[b]=i[b]);continue}if(f===192){const p=c.data?.[0]??0;a[b]=p,o[b]=n[b],l[b]=i[b];continue}if(f===144&&(c.data?.[1]??0)>0){if(d[b])continue;d[b]=!0;const p=a[b]??0,x=b===9||!!e?.[b];r[b]={program:p,bankMSB:o[b],bankLSB:l[b],isGMGSDrum:x}}}}for(let c=0;c<16;c++){if(r[c]||a[c]==null)continue;const f=c===9||!!e?.[c];r[c]={program:a[c],bankMSB:o[c],bankLSB:l[c],isGMGSDrum:f}}for(let c=0;c<16;c++){if(r[c]||!m[c])continue;const f=c===9||!!e?.[c];r[c]={program:0,bankMSB:n[c],bankLSB:i[c],isGMGSDrum:f}}return r}function Gs(s,e,n){if(!e)return n===9?"Drums (0)":"—";const i=(e.program||0)+1;if(e.isGMGSDrum||n===9)return`Drums (${i})`;const r=s?.find(l=>l.program===e.program&&l.bankMSB===e.bankMSB&&l.bankLSB===e.bankLSB);if(r?.name)return`${r.name} (${i})`;const a=s?.find(l=>l.program===e.program&&l.bankMSB===e.bankMSB);if(a?.name)return`${a.name} (${i})`;const o=s?.find(l=>l.program===e.program);return o?.name?`${o.name} (${i})`:`Program ${i}`}class Ya{constructor(){this._initialized=!1,this._initializing=null,this._context=null,this._synth=null,this._seq=null,this._smfKnifeConfigText="",this._smfKnifeConfigName="",this._smfKnifeForce=!1,this._lastMidiBuffer=null,this._referenceMidiData=null,this._midiMapper=Xs(null),this._midiEvent=Wa(),this._midiMessage3=new Uint8Array(3),this._midiMessage2=new Uint8Array(2),this._channelActivityVelocity=Array.from({length:16},()=>0),this._channelActivityTime=Array.from({length:16},()=>-1),this._activeNoteCounts=Array.from({length:16},()=>Array.from({length:128},()=>0)),this._polyphonyCount=0,this._activityDirty=!1,this._polyphonyDirty=!1,this._channelInstrumentNames=Array.from({length:16},()=>"—"),this._channelPrograms=Array.from({length:16},()=>({program:0,bankMSB:0,bankLSB:0})),this._drumChannelsApplied=new Uint8Array(16),this._midiChannelState=Array.from({length:16},(e,n)=>({channel:n,isDrum:n===9,program:0,bankMSB:0,bankLSB:0,name:n===9?"Drums":"—"})),this._instrumentDirty=!1,this._raf=0,this._prevFinished=!1,this._isAdvancing=!1,this._isStopping=!1,this._sequencerEventsBound=!1,this._autoPlayOnNextSong=!1,this._midiMapper.setEnabled(Kt.enableMIDIStandardMapping),this._midiMapper.onStateChange=e=>{this._setState({midiMapState:e}),this._bgSyncDrums(e.drumChannels)},this._setState({enableMIDIStandardMapping:Kt.enableMIDIStandardMapping,midiMapState:this._midiMapper.getState(),reverbGain:Kt.reverb,chorusGain:Kt.chorus,smfKnifeConfigName:"",smfKnifeSource:"",smfKnifeDestination:"",midiChannels:this._cloneMidiChannelState()})}_setState(e){cn(e)}_cloneMidiChannelState(){return this._midiChannelState.map(e=>({...e}))}_syncMidiChannelState(e){if(!Number.isInteger(e)||e<0||e>15)return;const n=this._midiChannelState[e],i=this._channelPrograms[e],r=this._channelInstrumentNames[e]||"—";this._midiChannelState[e]={...n,program:i.program,bankMSB:i.bankMSB,bankLSB:i.bankLSB,name:r},this._setState({midiChannels:this._cloneMidiChannelState()})}async ensureInitialized(){if(!this._initialized){if(this._initializing)return this._initializing;this._initializing=(async()=>{this._setState({ready:!1,status:"シンセエンジンを起動しています…",engineLoadStage:"audio",engineLoadError:""});try{const n=Qn().ensureAudioContext();await n.audioWorklet.addModule(Kr);const i=new Vr(n,{initializeChorusProcessor:!0,initializeReverbProcessor:!0});i.connect(n.destination),this._setState({status:"音色ライブラリをダウンロードしています…",engineLoadStage:"soundfont-download"});const r=await fetch(xa);if(!r.ok)throw new Error(`SoundFont HTTP ${r.status}`);const a=await r.arrayBuffer();this._setState({status:"音色ライブラリを読み込んでいます…",engineLoadStage:"soundfont-load"}),await i.soundBankManager.addSoundBank(a,"main"),this._setState({status:"プレーヤーを準備しています…",engineLoadStage:"player"});const o=new Wr(i);o.loopCount=-1,this._context=n,this._synth=i,this._seq=o,this._bindSequencerEvents(),this._setupMidiMapper(),this._applyDefaultEffects();const{enabledChannels:l}=qe();l.forEach((d,m)=>i.muteChannel(m,!d)),this._initialized=!0,this._setState({ready:!0,status:"準備完了",engineLoadStage:"ready",engineLoadError:""})}catch(e){throw this._initialized=!1,this._setState({ready:!1,status:"シンセエンジンの読み込みに失敗しました",engineLoadStage:"error",engineLoadError:String(e?.message||e)}),e}})();try{await this._initializing}finally{this._initializing=null}}}_applyDefaultEffects(){if(this._synth)try{Number.isFinite(Kt.reverb)&&this._synth.setMasterParameter("reverbGain",Kt.reverb),Number.isFinite(Kt.chorus)&&this._synth.setMasterParameter("chorusGain",Kt.chorus),this._setState({reverbGain:Number(this._synth.getMasterParameter("reverbGain"))||0,chorusGain:Number(this._synth.getMasterParameter("chorusGain"))||0,transposition:Number(this._synth.getMasterParameter("transposition"))||0})}catch(e){console.warn("Failed to apply default effects",e)}}_startClock(){if(this._raf)return;const e=()=>{const n=this._seq;if(n){const i=n.currentHighResolutionTime??n.currentTime??0,r=n.duration||0,a=qe(),o=i-(a.lyricOffsetMs||0)/1e3,l=pa(a.lrcEntries||[],o);let d=0;if(l>=0){const h=a.lrcEntries[l],c=a.lrcEntries[l+1]?.time;if(h?.tokens?.length){const f=h.time,b=c??Math.max(f+1,r||f+1),p=Number.isFinite(h.endTime)?Math.min(h.endTime,b):b;if(o<=f)d=0;else if(o>=p)d=1;else{const x=h.tokens,S=x.length;let N=0,w=x.length-1,v=0;if(o<x[0].time)v=0;else for(;N<=w;){const L=N+w>>1,Y=x[L].time;if(Y===o){v=L;break}Y<o?(v=L,N=L+1):w=L-1}const _=x[v],R=x[v+1]?.time??p,k=Math.max(.001,R-_.time),E=Math.min(1,Math.max(0,(o-_.time)/k)),se=Number.isFinite(h.tokenTotalWeight)?h.tokenTotalWeight:S,F=Number.isFinite(_?.weightStart)?_.weightStart:v,z=Number.isFinite(_?.weight)?_.weight:1,j=Math.min(se,Math.max(0,F+E*z));d=Math.min(1,Math.max(0,j/Math.max(1,se)))}}else{const f=h.time,b=c??Math.max(f+1,r||f+1),p=Math.max(.001,b-f);d=Math.min(1,Math.max(0,(o-f)/p))}}else r>0&&(d=Math.min(1,Math.max(0,i/r)));const m=!n.paused&&!n.isFinished,u={currentTime:i,duration:r,isPlaying:m};this._activityDirty&&(u.channelActivityVelocity=this._channelActivityVelocity.slice(),u.channelActivityTime=this._channelActivityTime.slice(),this._activityDirty=!1),this._polyphonyDirty&&(u.polyphonyCount=this._polyphonyCount,this._polyphonyDirty=!1),this._instrumentDirty&&(u.channelInstrumentNames=this._channelInstrumentNames.slice(),this._instrumentDirty=!1),u.activeLyricIndex=l,u.karaokeProgress=d,this._setState(u),n.isFinished&&!this._prevFinished&&(this._prevFinished=!0),n.isFinished||(this._prevFinished=!1)}n&&!n.paused&&!n.isFinished?this._raf=window.requestAnimationFrame(e):this._raf=0};this._raf=window.requestAnimationFrame(e)}_stopClock(){this._raf&&(window.cancelAnimationFrame(this._raf),this._raf=0)}_bgSyncDrums(e){if(!(!this._synth||!e)&&typeof this._synth.setDrums=="function")try{e.forEach((n,i)=>{const r=n?1:0;if(this._drumChannelsApplied[i]===r)return;this._drumChannelsApplied[i]=r;const a=this._midiChannelState[i];a&&(a.isDrum=!!n,a.isDrum&&!a.name&&(a.name="Drums")),this._synth.setDrums(i,!!n);const o=this._channelPrograms?.[i]?.program??0;typeof this._synth.programChange=="function"&&this._synth.programChange(i,o)}),this._setState({midiChannels:this._cloneMidiChannelState()})}catch(n){console.warn("Failed to sync drums",n)}}_setupMidiMapper(){!this._seq||!this._synth||!this._midiMapper||(this._bgSyncDrums(this._midiMapper.getState().drumChannels),this._seq.connectMIDIOutput({send:e=>{this._handleMidiOutputMessage(e)}}))}_bindSequencerEvents(){!this._seq||this._sequencerEventsBound||(this._sequencerEventsBound=!0,this._seq.eventHandler.addEvent("songChange","sync-playback-state",()=>{const e=this._seq?.duration||0;this._setState({currentTime:0,duration:e}),this._autoPlayOnNextSong&&(this._autoPlayOnNextSong=!1,this.play())}))}_rebuildMidiMapper(e){e&&(this._lastMidiBuffer=e);const n=qe().enableMIDIStandardMapping??Kt.enableMIDIStandardMapping;this._midiMapper=Xs(e,{smfKnifeConfigText:this._smfKnifeConfigText,smfKnifeConfigName:this._smfKnifeConfigName,forceSmfKnife:!!this._smfKnifeForce}),this._midiMapper.setEnabled(n),typeof this._midiMapper.reset=="function"&&this._midiMapper.reset(),this._midiMapper.onStateChange=r=>{this._setState({midiMapState:r}),console.log(r),this._bgSyncDrums(r.drumChannels)};const i=this._midiMapper.getState();this._setState({midiMapState:i,smfKnifeConfigName:i?.globalMode==="smfknife"?i.configName:"",smfKnifeSource:i?.mappingSource||"",smfKnifeDestination:i?.mappingDestination||""}),this._bgSyncDrums(i.drumChannels)}_handleMidiOutputMessage(e){if(!this._synth)return;const n=$a(e,this._midiEvent),i=this._midiMapper?this._midiMapper(n):[n];for(const r of i){if(!r)continue;const a=Ua(r,this._midiMessage3,this._midiMessage2);a&&(this._synth.sendMessage(a),this._trackChannelActivity(r),this._trackPolyphony(r),this._trackProgramChange(r))}}_trackProgramChange(e){if(!e)return;const n=Number(e.channel);if(!Number.isInteger(n)||n<0||n>15)return;let i=!1;const r=this._channelPrograms[n];if(e.type==="program"){const a=Number(e.value)||0;r.program!==a&&(r.program=a,i=!0)}else if(e.type==="cc"){if(e.controller===0){const a=Number(e.value)||0;r.bankMSB!==a&&(r.bankMSB=a,i=!0)}else if(e.controller===32){const a=Number(e.value)||0;r.bankLSB!==a&&(r.bankLSB=a,i=!0)}}if(i){const a={program:r.program,bankMSB:r.bankMSB,bankLSB:r.bankLSB,isGMGSDrum:n===9||this._midiMapper?.getState()?.drumChannels?.[n]},o=Gs(this._synth.presetList,a,n);this._channelInstrumentNames[n]!==o&&(this._channelInstrumentNames[n]=o,this._instrumentDirty=!0),this._syncMidiChannelState(n)}}_resetMidiMapperState(){this._midiMapper&&this._midiMapper.reset()}_resetChannelActivity(){this._channelActivityVelocity.fill(0),this._channelActivityTime.fill(-1),this._activityDirty=!1,this._drumChannelsApplied.fill(0),this._channelInstrumentNames.fill("—"),this._channelPrograms.forEach(e=>{e.program=0,e.bankMSB=0,e.bankLSB=0}),this._instrumentDirty=!0,this._midiChannelState=Array.from({length:16},(e,n)=>({channel:n,isDrum:n===9,program:0,bankMSB:0,bankLSB:0,name:n===9?"Drums":"—"})),this._setState({channelActivityVelocity:this._channelActivityVelocity.slice(),channelActivityTime:this._channelActivityTime.slice(),channelInstrumentNames:this._channelInstrumentNames.slice(),midiChannels:this._cloneMidiChannelState()})}_resetPolyphony(){this._activeNoteCounts.forEach(e=>e.fill(0)),this._polyphonyCount=0,this._polyphonyDirty=!1,this._setState({polyphonyCount:0})}_reportPolyphony(){this._setState({polyphonyCount:this._polyphonyCount}),this._polyphonyDirty=!1}_trackChannelActivity(e){if(e?.type!=="note_on")return;const n=Number(e.velocity);if(!(n>0))return;const i=Number(e.channel);if(!Number.isInteger(i)||i<0||i>15)return;const r=this._seq?.currentHighResolutionTime??this._seq?.currentTime??0,a=Math.max(0,Math.min(1,n/127)),o=this._channelActivityVelocity[i]||0;this._channelActivityVelocity[i]=Math.max(o*.6,a),this._channelActivityTime[i]=r,this._activityDirty=!0}_trackPolyphony(e){if(!e)return;const n=Number(e.channel);if(!Number.isInteger(n)||n<0||n>15)return;const i=Number(e.note);if(!Number.isInteger(i)||i<0||i>127)return;const r=e.type==="note_on"&&Number(e.velocity)>0,a=e.type==="note_off"||e.type==="note_on"&&Number(e.velocity)===0;if(!r&&!a)return;const o=this._activeNoteCounts[n];r?(o[i]+=1,this._polyphonyCount+=1):o[i]>0&&(o[i]-=1,this._polyphonyCount=Math.max(0,this._polyphonyCount-1)),this._polyphonyDirty=!0}panic(){if(!this._synth)return;const e=this._synth,n=typeof e.controllerChange=="function"?(r,a,o)=>e.controllerChange(r,a,o):typeof e.controller=="function"?(r,a,o)=>e.controller(r,a,o):typeof e.sendMessage=="function"?(r,a,o)=>e.sendMessage(new Uint8Array([176+r,a,o])):null,i=typeof e.programChange=="function"?(r,a)=>e.programChange(r,a):typeof e.sendMessage=="function"?(r,a)=>e.sendMessage(new Uint8Array([192+r,a])):null;if(typeof e.resetControllers=="function")try{e.resetControllers()}catch{}if(n)for(let r=0;r<16;r++)n(r,121,0),n(r,120,0),n(r,123,0),n(r,91,0),n(r,93,0),n(r,0,0),n(r,32,0),i&&i(r,0);if(typeof e.setDrums=="function"){for(let r=0;r<16;r++){const a=r===9;e.setDrums(r,a);const o=this._midiChannelState?.[r];o&&(o.isDrum=a,o.name=a?"Drums":this._channelInstrumentNames?.[r]||"—"),this._drumChannelsApplied[r]=a?1:0}this._setState({midiChannels:this._cloneMidiChannelState()})}if(typeof e.stopAll=="function")try{e.stopAll(!0)}catch{}if(typeof e.muteChannel=="function"){const r=qe().enabledChannels||[];for(let a=0;a<16;a++)e.muteChannel(a,!r[a])}this._channelPrograms.forEach((r,a)=>{r.program=0,r.bankMSB=0,r.bankLSB=0;const o={program:r.program,bankMSB:r.bankMSB,bankLSB:r.bankLSB,isGMGSDrum:a===9||this._midiMapper?.getState()?.drumChannels?.[a]},l=Gs(this._synth.presetList,o,a);this._channelInstrumentNames[a]=l}),this._instrumentDirty=!0,this._channelActivityVelocity.fill(0),this._channelActivityTime.fill(-1),this._activityDirty=!0,this._activeNoteCounts.forEach(r=>r.fill(0)),this._polyphonyCount=0,this._polyphonyDirty=!0,this._reportPolyphony()}async resumeAudio(){await this.ensureInitialized(),await Qn().resumeAudio()}getAudioContext(){return this._context}async getMidiData(){return this._referenceMidiData}async loadMIDI({buffer:e,midiName:n,midiUrl:i=""}){await this.ensureInitialized(),this.panic(),this._autoPlayOnNextSong=!0,this._referenceMidiData=null;try{const a=e instanceof ArrayBuffer?e.slice(0):e?.buffer?.slice(Number(e.byteOffset)||0,(Number(e.byteOffset)||0)+Number(e.byteLength));a instanceof ArrayBuffer&&(this._referenceMidiData=Fr.fromArrayBuffer(a,n))}catch(a){console.warn("[SynthEngine] Failed to cache reference MIDI data",a)}this._rebuildMidiMapper(e),this._setupMidiMapper(),this._resetChannelActivity(),this._resetPolyphony(),this._setState({isPlaying:!1,currentTime:0,duration:0}),this._seq.pause(),this._synth.stopAll(!0),this._seq.loadNewSongList([{binary:e,fileName:n}]),this._seq.currentTime=0;const r=this._seq?.duration||0;return this._setState({midiUrl:i,midiName:n,status:`MIDI loaded: ${n}`,duration:r,currentTime:0}),requestAnimationFrame(()=>{if(!this._seq)return;const a=this._seq.duration||0;a!==r&&this._setState({duration:a,currentTime:0})}),this._updateChannelInstrumentNames().catch(()=>{}),this._applyDefaultEffects(),this._startClock(),e}async loadMidiFromUrl(e){this._setState({status:`Loading MIDI: ${e}`});const n=await fetch(e);if(!n.ok)throw new Error(`MIDI HTTP ${n.status}`);const i=await n.arrayBuffer(),r=e.split("/").pop()||e;return this.loadMIDI({buffer:i,midiName:r,midiUrl:e})}async loadMidiFromFile(e){const n=await e.arrayBuffer(),i=e.name;return this.loadMIDI({buffer:n,midiName:i,midiUrl:""})}setPendingSong(e){cn({pendingSong:e||null})}clearPendingSong(){cn({pendingSong:null})}enqueueSong(e){if(!e)return;const n=qe().queue.slice();n.push(e),this._setState({queue:n})}enqueuePendingSong(){const e=qe().pendingSong;e&&(this.enqueueSong(e),this.clearPendingSong())}clearQueue(){this._setState({queue:[],queueIndex:-1})}removeFromQueue(e){const n=Number(e);if(!Number.isInteger(n))return;const i=qe().queue.slice();if(n<0||n>=i.length)return;i.splice(n,1);let r=qe().queueIndex;r>=i.length&&(r=i.length-1),this._setState({queue:i,queueIndex:r})}bumpQueueNext(e){const n=Number(e);if(!Number.isInteger(n))return;const i=qe().queue.slice();if(n<0||n>=i.length)return;const r=qe().queueIndex,a=r>=0?r+1:0;if(n===a)return;const[o]=i.splice(n,1),l=Math.min(a,i.length);i.splice(l,0,o);let d=r;r>=0&&(n<r&&(d=r-1),l<=d&&(d+=1)),this._setState({queue:i,queueIndex:d})}async playQueueFrom(e=0){await this.ensureInitialized();const n=Number(e),i=qe().queue;if(!Number.isInteger(n)||n<0||n>=i.length)return;const r=i[n];if(!r?.url)return;await this.resumeAudio(),this.setTransposition(0),cn({lrcName:"",lrcEntries:[],lyricOffsetMs:0,activeLyricIndex:-1});const a=(Number(qe().playbackSessionId)||0)+1;if(this._setState({queueIndex:n,playbackSessionId:a}),await this.loadMidiFromUrl(r.url,{autoPlay:!1}),typeof this._synth?.muteChannel=="function"){const o=qe().enabledChannels?.[0]!==!1,l=r.guideMelodyEnabled!==!1;this._synth.muteChannel(0,!(o&&l))}if(r.lrc)try{const o=await fetch(r.lrc);if(o.ok){const l=await o.text();cn({lrcName:r.lrcName||r.lrc.split("/").pop()||"lyrics.lrc",lrcEntries:ys(l)})}}catch{}Number.isFinite(r.lrc_offset)&&this.setLyricOffsetMs(r.lrc_offset),this.seek(0),this.play()}async playQueueIfIdle(){await this.ensureInitialized();const{queue:e,queueIndex:n}=qe();e.length&&(n>=0||await this.playQueueFrom(0))}async _advanceQueueIfNeeded(){await this._advanceQueue({autoPlayNext:!0})}play(){this._seq&&(this._seq.play(),this._setState({isPlaying:!0}),this._startClock())}pause(){this._seq&&(this._seq.pause(),this._setState({isPlaying:!1}),this._stopClock())}stop(){!this._seq||!this._synth||(this._seq.pause(),this._seq.currentTime=0,this._synth.stopAll(!0),this._resetChannelActivity(),this._resetPolyphony(),this._setState({isPlaying:!1,currentTime:0}),this._stopClock())}async stopAndAdvance(e={}){if(await this.ensureInitialized(),!this._synth||!this._seq||this._isStopping)return;this._isStopping=!0;const n=Math.max(0,Number(e.fadeMs??Va.stopFadeMs)),i=Number(this._synth.getMasterParameter("masterGain"))||1;try{if(n>0){const a=performance.now();await new Promise(o=>{const l=d=>{const m=Math.min(1,(d-a)/n),u=i*(1-m);this._synth.setMasterParameter("masterGain",u),m>=1?o():requestAnimationFrame(l)};requestAnimationFrame(l)})}else this._synth.setMasterParameter("masterGain",0);this.stop(),this._synth.setMasterParameter("masterGain",i),await new Promise(a=>setTimeout(a,n)),await this._advanceQueue({autoPlayNext:!0});const{queueIndex:r}=qe();r>=0&&this._seq?.paused&&await this.playQueueFrom(r)}finally{this._isStopping=!1}}async _advanceQueue({autoPlayNext:e}){if(!this._isAdvancing&&!(qe().queueIndex<0)){this._isAdvancing=!0;try{const{queue:n,history:i,queueIndex:r}=qe(),a=n.slice(),o=i.slice(),l=a[r];l&&o.unshift(l),r>=0&&r<a.length&&a.splice(r,1);const d=a.length?Math.min(r,a.length-1):-1;this._setState({queue:a,history:o,queueIndex:d}),e&&d>=0&&await this.playQueueFrom(d)}finally{this._isAdvancing=!1}}}seek(e){this._seq&&(this._seq.currentTime=Math.max(0,Number(e)||0))}setReverbGain(e){if(!this._synth)return;const n=Math.max(0,Number(e)||0);this._synth.setMasterParameter("reverbGain",n),this._setState({reverbGain:n})}setChorusGain(e){if(!this._synth)return;const n=Math.max(0,Number(e)||0);this._synth.setMasterParameter("chorusGain",n),this._setState({chorusGain:n})}setSmfKnifeMapping(e,n=""){const i=String(e||"");i.trim()&&(this._smfKnifeConfigText=i,this._smfKnifeConfigName=n||"SMF Knife",this._smfKnifeForce=!1,this._setState({smfKnifeConfigName:this._smfKnifeConfigName,smfKnifeSource:"",smfKnifeDestination:""}),this._rebuildMidiMapper(this._lastMidiBuffer||null))}clearSmfKnifeMapping(){this._smfKnifeConfigText="",this._smfKnifeConfigName="",this._smfKnifeForce=!1,this._setState({smfKnifeConfigName:"",smfKnifeSource:"",smfKnifeDestination:""}),this._rebuildMidiMapper(this._lastMidiBuffer||null)}setTransposition(e){if(!this._synth)return;const n=Number(e)||0;this._synth.setMasterParameter("transposition",n),this._setState({transposition:n})}setEnableMIDIStandardMapping(e){const n=!!e;this._midiMapper?.setEnabled(n),this._setState({enableMIDIStandardMapping:n})}shiftTransposition(e){const n=(Number(qe().transposition)||0)+(Number(e)||0);this.setTransposition(n)}setChannelEnabled(e,n){if(!this._synth)return;const i=Number(e);if(!Number.isInteger(i)||i<0||i>15)return;const r=qe().enabledChannels.slice();r[i]=!!n,this._synth.muteChannel(i,!r[i]),this._setState({enabledChannels:r})}async loadLrcFromFile(e){const n=await e.text(),i=ys(n);cn({lrcName:e.name,lrcEntries:i})}setLyricOffsetMs(e){const n=Math.max(-3e4,Math.min(3e4,Number(e)||0));cn({lyricOffsetMs:n})}async _updateChannelInstrumentNames(e=1500){if(!this._seq||!this._synth)return;const n=new Promise((l,d)=>{setTimeout(()=>d(new Error("getMIDI timeout")),e)}),i=await Promise.race([this._seq.getMIDI(),n]),r=this._midiMapper?.getState?.()?.drumChannels,a=Xa(i,r);a.forEach((l,d)=>{l&&(this._channelPrograms[d]={...l})});const o=a.map((l,d)=>Gs(this._synth.presetList,l,d));this._channelInstrumentNames=o,this._setState({channelInstrumentNames:o})}}const ee=new Ya,vn=sn(Rr(s=>({guideMelodyEnabled:!0,microphoneDeviceId:"",setGuideMelodyEnabled:e=>s({guideMelodyEnabled:!!e}),setMicrophoneDeviceId:e=>s({microphoneDeviceId:String(e||"")})}),{name:"nuru-karaoke-settings",partialize:s=>({guideMelodyEnabled:s.guideMelodyEnabled,microphoneDeviceId:s.microphoneDeviceId})})),mr=()=>vn.getState();async function ks(s){if(!s)return;const e=s.guideMelodyEnabled==null?{...s,guideMelodyEnabled:mr().guideMelodyEnabled}:s;await ee.resumeAudio(),ee.enqueueSong(e),ee.clearPendingSong(),await ee.playQueueIfIdle()}function Qa(){ee.clearQueue()}function Ja(s){ee.removeFromQueue(s)}function Za(s){ee.bumpQueueNext(s)}function zs(s){ee.setPendingSong(s)}const eo="/assets/success-51BZlxIa.mp3",to="/assets/fail-CXtc_xkS.mp3",no="/assets/select-CRwIxpKg.mp3",Qs={SUCCESS:eo,FAIL:to,SELECT:no},so=Object.freeze(Object.defineProperty({__proto__:null,SFX:Qs},Symbol.toStringTag,{value:"Module"}));function Ms({isOpen:s,onClose:e,status:n="success",message:i}){if(g.useEffect(()=>{if(!s)return;const a=Ns();n==="success"?a.playSfx(Qs.SUCCESS).catch(()=>{}):n==="error"&&a.playSfx(Qs.FAIL).catch(()=>{})},[s,n]),!s)return null;const r=i||(n==="loading"?"通信中...":n==="error"?"通信に失敗しました。":"インターネットに接続成功しました。");return t.jsx("div",{className:"wiiAlertOverlay",onClick:e,children:t.jsxs("div",{className:"wiiAlertBox",onClick:a=>a.stopPropagation(),children:[t.jsx("div",{className:"wiiAlertHeader",children:"インターネット通信"}),t.jsxs("div",{className:"wiiAlertBody",children:[t.jsx("div",{children:r}),t.jsx("div",{className:"wiiAlertIcon",children:n==="loading"?"…":n==="error"?"!":"♪"})]})]})})}async function oi(s,e){const n=await s.text();if(!n)return e;try{const i=JSON.parse(n);return i?.detail||Object.values(i).flat().join(" / ")||e}catch{return n}}async function io(s,e={}){if(!s)throw new Error("Authentication required");const n=await fetch(Nt("/api/user/favorites"),{method:"GET",headers:{Authorization:`Bearer ${s}`},signal:e.signal});if(!n.ok)throw new Error(await oi(n,"Failed to load favorites"));const i=await n.json();return Array.isArray(i)?i:[]}async function ro(s,e){if(!s)throw new Error("Song code required");if(!e)throw new Error("Authentication required");const n=await fetch(Nt("/api/user/favorites"),{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`},body:JSON.stringify({song:s})});if(!n.ok)throw new Error(await oi(n,"Failed to add favorite"));return n.json()}async function ao(s,e){if(!s)throw new Error("Song code required");if(!e)throw new Error("Authentication required");const n=await fetch(Nt(`/api/user/favorites/${encodeURIComponent(s)}`),{method:"DELETE",headers:{Authorization:`Bearer ${e}`}});if(!n.ok)throw new Error(await oi(n,"Failed to remove favorite"));return n.json()}let os=0;const yt=sn((s,e)=>({items:[],status:"idle",error:"",reset:()=>{os+=1,s({items:[],status:"idle",error:""})},load:async n=>{if(!n)return e().reset(),[];const i=++os;s({status:"loading",error:""});try{const r=await io(n);return i===os&&s({items:r,status:"ready",error:""}),r}catch(r){throw i===os&&s({status:"error",error:r?.message||"Failed to load favorites"}),r}},add:async(n,i)=>{const r=n?.song_code||n?.id;if(!r)throw new Error("Song code required");return e().items.some(a=>a.song_code===r)?!1:(await ro(r,i),s(a=>({items:[{song_code:r,title:n?.title||r,artist:n?.artist||"",created_at:new Date().toISOString()},...a.items.filter(o=>o.song_code!==r)],status:"ready",error:""})),!0)},remove:async(n,i)=>{await ao(n,i),s(r=>({items:r.items.filter(a=>a.song_code!==n),error:""}))}}));async function oo(s,e){const n=await fetch(Nt("/api/auth/login"),{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({username_or_email:s,password:e})});if(!n.ok){const i=await n.text();throw new Error(i||"Login failed")}return n.json()}async function co(s,e,n){const i=await fetch(Nt("/api/auth/register"),{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({username:s,email:e,password:n})});if(!i.ok){const r=await i.text();throw new Error(r||"Register failed")}return i.json()}async function lo(){const s=await fetch(Nt("/api/auth/refresh"),{method:"POST",credentials:"include"});if(!s.ok){const e=await s.text();throw new Error(e||"Refresh failed")}return s.json()}async function uo(){await fetch(Nt("/api/auth/logout"),{method:"POST",credentials:"include"})}async function qs(s){const e=await fetch(Nt("/api/user/me"),{method:"GET",headers:{Authorization:`Bearer ${s}`}});if(!e.ok){const n=await e.text();throw new Error(n||"Failed to load user")}return e.json()}const Re=sn((s,e)=>({status:"idle",user:null,accessToken:"",error:"",isGuest:!1,setGuest:()=>s({status:"guest",user:null,accessToken:"",error:"",isGuest:!0}),clearError:()=>s({error:""}),login:async(n,i)=>{s({status:"loading",error:""});try{const a=(await oo(n,i))?.access||"";let o=null;a&&(o=await qs(a)),s({status:"authenticated",user:o,accessToken:a,error:"",isGuest:!1})}catch(r){throw s({status:"error",error:r?.message||"Login failed"}),r}},register:async(n,i,r)=>{s({status:"loading",error:""});try{const o=(await co(n,i,r))?.access||"";let l=null;o&&(l=await qs(o)),s({status:"authenticated",user:l,accessToken:o,error:"",isGuest:!1})}catch(a){throw s({status:"error",error:a?.message||"Register failed"}),a}},refresh:async()=>{try{const i=(await lo())?.access||"";if(!i){s({status:"idle",user:null,accessToken:"",isGuest:!1});return}const r=await qs(i);s({status:"authenticated",user:r,accessToken:i,error:"",isGuest:!1})}catch(n){s({status:"idle",user:null,accessToken:"",isGuest:!1,error:n?.message||""})}},logout:async()=>{await uo(),s({status:"idle",user:null,accessToken:"",isGuest:!1})},getAuthHeader:()=>{const n=e().accessToken;return n?{Authorization:`Bearer ${n}`}:{}}})),kn="pitch-v11-log-duration-tolerance",ho=.5,ji=.75,$e=Object.freeze({pitchToleranceSemitones:2,durationToleranceMinLog:Math.log(1.15),durationToleranceMaxLog:Math.log(1.5),durationTolerancePivotSec:.5,durationTolerancePower:1.5,centerToleranceMinRatio:.08,centerToleranceMaxRatio:.28,centerTolerancePivotSec:.5,centerTolerancePower:1,centerToleranceMinSec:.04,centerToleranceMaxSec:.18,fragmentJoinMinSec:.05,fragmentJoinMaxSec:.14,fragmentJoinPivotSec:.5,fragmentJoinPower:1,fragmentJoinMaxNoteRatio:.4,sampleGridSec:.02,sampleLookupToleranceSec:.03,shortNoteMaxSec:.22,visualConfirmationMinSec:.08,visualConfirmationMaxSec:.16,visualConfirmationNoteRatio:.35,shortNoteSettleDelaySec:.04,visualFillRate:1.5});function Ti(s){return Number.isFinite(s)?Math.max(0,Math.min(1,s)):0}function Js(s,e,n){return Math.max(e,Math.min(n,s))}function Fi(s){const e=s%12;return e<0?e+12:e}function fr(s,e=$e){const n=Math.max(0,Number(s?.t1Sec)-Number(s?.t0Sec)),i=Number.isFinite(e?.fragmentJoinMinSec)?Math.max(0,Number(e.fragmentJoinMinSec)):$e.fragmentJoinMinSec,r=Number.isFinite(e?.fragmentJoinMaxSec)?Math.max(i,Number(e.fragmentJoinMaxSec)):$e.fragmentJoinMaxSec,a=Number.isFinite(e?.fragmentJoinPivotSec)?Math.max(1e-4,Number(e.fragmentJoinPivotSec)):$e.fragmentJoinPivotSec,o=Number.isFinite(e?.fragmentJoinPower)?Math.max(.1,Number(e.fragmentJoinPower)):$e.fragmentJoinPower,l=Number.isFinite(e?.fragmentJoinMaxNoteRatio)?Math.max(0,Number(e.fragmentJoinMaxNoteRatio)):$e.fragmentJoinMaxNoteRatio,d=i+(r-i)/(1+(n/a)**o);return Math.min(d,n*l)}function mo(s,e){const n=Number(s),i=Number(e);return!Number.isFinite(n)||!Number.isFinite(i)||n<=0||i<=0?1/0:Math.abs(Math.log(i/n))}function Ri(s,e=$e){const n=Math.max(0,Number(s)||0),i=Number.isFinite(e?.durationToleranceMinLog)?Math.max(0,Number(e.durationToleranceMinLog)):$e.durationToleranceMinLog,r=Number.isFinite(e?.durationToleranceMaxLog)?Math.max(i,Number(e.durationToleranceMaxLog)):$e.durationToleranceMaxLog,a=Number.isFinite(e?.durationTolerancePivotSec)?Math.max(1e-4,Number(e.durationTolerancePivotSec)):$e.durationTolerancePivotSec,o=Number.isFinite(e?.durationTolerancePower)?Math.max(.1,Number(e.durationTolerancePower)):$e.durationTolerancePower;return i+(r-i)/(1+(n/a)**o)}function Cs(s,e){const n=Number.isFinite(s)?Number(s):null,i=Number.isFinite(e)?Number(e):null;if(n===null||i===null)return{normalizedMidi:null,octaveFoldSemitones:null,centsError:null,absCentsError:null};const r=Math.round((n-i)/12)*12,a=n-r,o=(a-i)*100;return{normalizedMidi:a,octaveFoldSemitones:r,centsError:o,absCentsError:Math.abs(o)}}function fo(s,e){if(!Number.isFinite(s)||!Number.isFinite(e))return null;const n=Math.round(Number(s)),i=Math.round(Number(e));return(Fi(n)-Fi(i)+18)%12-6}function Bi(s,e,n={}){const i=Cs(s,e),r=fo(s,e);if(!Number.isFinite(r))return{...i,distance:null,credit:0,classification:"unvoiced"};const a=Number.isFinite(n.pitchToleranceSemitones)?Math.max(0,Math.round(Number(n.pitchToleranceSemitones))):$e.pitchToleranceSemitones,o=Math.abs(r)<=a;return{...i,distance:r,credit:o?1:0,classification:o?"accurate":"miss"}}function go(s,e){const n=Cs(s,e);if(!Number.isFinite(e)||!Number.isFinite(n.normalizedMidi))return null;const i=Number(e),r=(n.normalizedMidi-i)*ho,a=Js(r,-ji,ji);return i+a}class po{constructor(){this.reset([])}reset(e=[],n={}){this.referenceNotes=Array.isArray(e)?e.slice().sort((i,r)=>Number(i.t0Sec)-Number(r.t0Sec)):[],this.reference=n.reference||null,this.noteWeights=n.noteWeights||{normal:1,default:1},this.rmsGate=Number.isFinite(n.rmsGate)?Number(n.rmsGate):.01,this.config={...$e,...n.scoringConfig||{}},this.totalWeightedBeats=this._computeTotalWeightedBeats(),this.correctWeightedBeats=0,this.finalizedWeightedBeats=0,this._samples=[],this._nextNoteIndex=0,this._noteResults=[],this._lastSampleTime=null,this._visualTimeSec=0,this._lastFinalizeCount=0,this._lastFinalizeScore=0,this._liveResult=null,this._currentFrame=null,this._metrics={totalSamples:0,voicedSamples:0,rejectedRms:0,rejectedClarity:0,smoothingResetCount:0},this._lastDebug={timeSec:null,targetMidi:null,userMidi:null,normalizedUserMidi:null,octaveFoldSemitones:null,distance:null,credit:0,centsError:null}}getMaxGapSec(e){return fr(e,this.config)}getEdgeToleranceSec(e){const n=Math.max(0,Number(e?.t1Sec)-Number(e?.t0Sec)),i=Number.isFinite(this.config.centerToleranceMinRatio)?Math.max(0,Number(this.config.centerToleranceMinRatio)):$e.centerToleranceMinRatio,r=Number.isFinite(this.config.centerToleranceMaxRatio)?Math.max(i,Number(this.config.centerToleranceMaxRatio)):$e.centerToleranceMaxRatio,a=Number.isFinite(this.config.centerTolerancePivotSec)?Math.max(1e-4,Number(this.config.centerTolerancePivotSec)):$e.centerTolerancePivotSec,o=Number.isFinite(this.config.centerTolerancePower)?Math.max(.1,Number(this.config.centerTolerancePower)):$e.centerTolerancePower,l=Number.isFinite(this.config.centerToleranceMinSec)?Math.max(0,Number(this.config.centerToleranceMinSec)):$e.centerToleranceMinSec,d=Number.isFinite(this.config.centerToleranceMaxSec)?Math.max(l,Number(this.config.centerToleranceMaxSec)):$e.centerToleranceMaxSec,m=i+(r-i)/(1+(n/a)**o);return Js(n*m,l,d)}_getNoteWeight(e){const n=e?.type||"normal",i=this.noteWeights[n];return Number.isFinite(i)?i:Number.isFinite(this.noteWeights.default)?this.noteWeights.default:1}_noteBeatLength(e){if(!e)return 0;if(Number.isFinite(e.t0Beat)&&Number.isFinite(e.t1Beat))return Math.max(0,e.t1Beat-e.t0Beat);if(this.reference?.getBeatAtTime&&Number.isFinite(e.t0Sec)&&Number.isFinite(e.t1Sec)){const n=this.reference.getBeatAtTime(e.t0Sec),i=this.reference.getBeatAtTime(e.t1Sec);if(Number.isFinite(n)&&Number.isFinite(i))return Math.max(0,i-n)}return Math.max(0,Number(e.t1Sec)-Number(e.t0Sec))}_computeTotalWeightedBeats(){if(!this.referenceNotes.length)return 1;const e=this.referenceNotes.reduce((n,i)=>n+this._noteBeatLength(i)*this._getNoteWeight(i),0);return e>0?e:1}_beatAtTime(e){if(this.reference?.getBeatAtTime){const n=this.reference.getBeatAtTime(e);if(Number.isFinite(n))return n}return Number(e)||0}_findReferenceNoteAtTime(e){let n=0,i=this.referenceNotes.length-1;for(;n<=i;){const r=n+i>>1,a=this.referenceNotes[r];if(e<a.t0Sec)i=r-1;else if(e>=a.t1Sec)n=r+1;else return a}return null}_samplesBetween(e,n){const i=r=>{let a=0,o=this._samples.length;for(;a<o;){const l=a+o>>1;this._samples[l].timeSec<r?a=l+1:o=l}return a};return this._samples.slice(i(e),i(n))}_decisionWindowSec(e){const n=Math.max(0,Number(e?.t1Sec)-Number(e?.t0Sec));return n<=this.config.shortNoteMaxSec+1e-7?this.config.visualConfirmationMinSec:Js(n*this.config.visualConfirmationNoteRatio,this.config.visualConfirmationMinSec,this.config.visualConfirmationMaxSec)}_visualDelaySec(e){return this._decisionWindowSec(e)}_emptyNoteResult(e){const n=Math.max(0,Number(e?.t1Sec)-Number(e?.t0Sec)),i=n<=this.config.shortNoteMaxSec+1e-7?"short-native":"standard-grid";return{note:e,noteId:e?`${e.t0Sec}:${e.t1Sec}:${e.midi}`:null,creditBeats:0,rawCreditBeats:0,totalBeats:this._noteBeatLength(e),voicedBeats:0,stableBeats:0,hitBeats:0,meanCredit:0,meanRawCredit:0,meanAbsCents:null,meanStabilityFactor:0,stableCoverage:0,voicedCoverage:0,hitCoverage:0,stableSegments:[],currentFrame:null,stabilityMode:i,pendingConfirmation:!1,decisionWindowSec:this._decisionWindowSec(e),visualDelaySec:this._visualDelaySec(e),rawFrameCoverage:0,validRawFrames:0,stableIslandSec:0,filledWholeNote:!1,durationLogError:null,durationToleranceLog:Ri(n,this.config),centerErrorSec:null,centerToleranceSec:this.getEdgeToleranceSec(e),rejectionReason:"unvoiced",smoothingResetCount:0,smoothingResetMaxCents:0,stability:{stable:!1,stableState:"unvoiced",stabilityFactor:0,rejectionReason:"unvoiced"}}}_evaluateNote(e,n=e?.t1Sec,i=!0){const r=Number(e?.t0Sec),a=Number(e?.t1Sec),o=a-r;if(!Number.isFinite(o)||o<=0||!Number.isFinite(e?.midi))return this._emptyNoteResult(e);const l=Math.max(r,Math.min(a,Number(n)||a)),d=l>=a-1e-7,m=o<=this.config.shortNoteMaxSec+1e-7,u=!d||!i,h=this._samplesBetween(r-1e-7,l-1e-7),c=this.getMaxGapSec(e),f=this.getEdgeToleranceSec(e),b=[],p=[];let x=null,S=null,N=0,w=0;const v=()=>{if(!x||!Number.isFinite(S)){x=null,S=null;return}x.t1Sec=S,x.t1Sec>x.t0Sec+1e-9&&b.push(x),x=null,S=null};for(const q of h){const Q=Number(e.midi)+(Number(q.transposition)||0),be=Bi(q.midi,Q,this.config),He=Number.isFinite(q.midi),Me=be.credit===1;if(He&&(w+=1,Number.isFinite(be.absCentsError)&&(N+=be.absCentsError)),Me){const Ce=Number.isFinite(S)?q.timeSec-S:1/0;(!x||Ce>c+1e-9)&&(v(),x={t0Sec:q.timeSec,t1Sec:q.timeSec,midi:Number(e.midi)}),x.t1Sec=q.timeSec,S=q.timeSec}else x&&Number.isFinite(S)&&q.timeSec-S>c+1e-9&&v();const Ae=Me&&!u;p.push({timeSec:q.timeSec,endTimeSec:q.timeSec,midi:be.normalizedMidi,rawMidi:q.midi,octaveFoldSemitones:be.octaveFoldSemitones,targetMidi:Q,distance:be.distance,rawCredit:be.credit,gatedCredit:Ae?be.credit:0,stabilityFactor:Ae?be.credit:0,centsError:be.centsError,absCentsError:be.absCentsError,stable:Ae,isHit:Ae,stableState:Ae?"stable":He?"voiced":"unvoiced"})}v();let _=!1,R=1/0;const k=Ri(o,this.config);let E=1/0;if(d&&b.length===1){const q=b[0],Q=Math.max(0,q.t1Sec-q.t0Sec);R=mo(o,Q);const be=(r+a)*.5,He=(q.t0Sec+q.t1Sec)*.5;E=Math.abs(He-be),R<=k+1e-9&&E<=f+1e-9&&(q.t0Sec=r,q.t1Sec=a,_=!0)}const se=b,F=u?[]:b,z=se.reduce((q,Q)=>q+Math.max(0,this._beatAtTime(Q.t1Sec)-this._beatAtTime(Q.t0Sec)),0),j=Math.max(0,this._beatAtTime(l)-this._beatAtTime(r)),L=this._noteBeatLength(e),Y=d?L:j,pe=F.reduce((q,Q)=>q+Math.max(0,Q.t1Sec-Q.t0Sec),0),ie=p[p.length-1]||null,me=Y>0?z/Y:0,de=h.length>0?w/h.length:0,I=z>0?null:w>0?"out-of-tolerance":"unvoiced";return{note:e,noteId:`${e.t0Sec}:${e.t1Sec}:${e.midi}`,creditBeats:z,rawCreditBeats:z,totalBeats:Y,voicedBeats:Y*de,stableBeats:z,hitBeats:z,meanCredit:me,meanRawCredit:me,meanAbsCents:w>0?N/w:null,meanStabilityFactor:me,stableCoverage:me,voicedCoverage:de,hitCoverage:me,stableSegments:F,currentFrame:ie,stabilityMode:m?"short-native":"standard-grid",pendingConfirmation:u,decisionWindowSec:this._decisionWindowSec(e),visualDelaySec:this._visualDelaySec(e),rawFrameCoverage:de,validRawFrames:w,stableIslandSec:pe,filledWholeNote:_,durationLogError:Number.isFinite(R)?R:null,durationToleranceLog:k,centerErrorSec:Number.isFinite(E)?E:null,centerToleranceSec:f,rejectionReason:I,smoothingResetCount:h.filter(q=>q.smoothingReset).length,smoothingResetMaxCents:h.length?Math.max(...h.map(q=>Math.abs(q.smoothingResetCents||0))):0,stability:{stable:!!ie?.stable,stableState:ie?.stableState||"unvoiced",stabilityFactor:ie?.stabilityFactor||0,rejectionReason:I}}}_finalizeReadyNotes(e,n=!1){for(this._lastFinalizeCount=0;this._nextNoteIndex<this.referenceNotes.length;){const i=this.referenceNotes[this._nextNoteIndex],r=Number(i.t1Sec)+this._visualDelaySec(i);if(!n&&e<r)break;const a=this._evaluateNote(i);a.finalizedAtSec=e;const o=this._getNoteWeight(i);this.correctWeightedBeats+=a.creditBeats*o,this.finalizedWeightedBeats+=a.totalBeats*o,this._noteResults.push(a),this._noteResults.length>40&&this._noteResults.shift(),this._nextNoteIndex+=1,this._lastFinalizeCount+=1}this._lastFinalizeCount>0&&(this._lastFinalizeScore=this.getLiveScore())}process({userPitch:e,transposition:n=0,timeSec:i}){const r=Number(i);if(!Number.isFinite(r))return;if(Number.isFinite(this._lastSampleTime)&&r<this._lastSampleTime-.05){const f=this.referenceNotes,b={reference:this.reference,noteWeights:this.noteWeights,rmsGate:this.rmsGate,scoringConfig:this.config};this.reset(f,b)}if(Number.isFinite(this._lastSampleTime)&&r<=this._lastSampleTime+.001)return;this._lastSampleTime=r,this._visualTimeSec=r;const a=Number.isFinite(e?.rms),o=!a||Number(e.rms)>=this.rmsGate,l=Number.isFinite(e?.rawMidi)?Number(e.rawMidi):Number.isFinite(e?.midi)?Number(e.midi):null,d=o?l:null;this._metrics.totalSamples+=1,Number.isFinite(d)?this._metrics.voicedSamples+=1:a&&!o&&(this._metrics.rejectedRms+=1),e?.smoothingReset===!0&&(this._metrics.smoothingResetCount+=1);const m={timeSec:r,midi:d,rawMidi:d,rms:a?Number(e.rms):null,confidence:Number.isFinite(e?.confidence)?Number(e.confidence):0,rawConfidence:Number.isFinite(e?.rawConfidence)?Number(e.rawConfidence):0,smoothingReset:e?.smoothingReset===!0,smoothingResetCount:Number.isFinite(e?.smoothingResetCount)?Number(e.smoothingResetCount):0,smoothingResetCents:Number.isFinite(e?.smoothingResetCents)?Number(e.smoothingResetCents):null,transposition:Number.isFinite(Number(n))?Number(n):0};this._samples.push(m),this._finalizeReadyNotes(r);const u=this._findReferenceNoteAtTime(r),h=u?Number(u.midi)+m.transposition:null,c=Bi(d,h,this.config);return this._liveResult=u?this._evaluateNote(u,Math.min(r+this.config.sampleGridSec,u.t1Sec),!1):null,this._currentFrame=this._liveResult?.currentFrame||{timeSec:r,endTimeSec:r,midi:c.normalizedMidi,rawMidi:d,octaveFoldSemitones:c.octaveFoldSemitones,targetMidi:h,distance:c.distance,rawCredit:c.credit,gatedCredit:0,centsError:c.centsError,stable:!1,isHit:!1,stabilityFactor:0,stableState:Number.isFinite(d)?"voiced":"unvoiced"},this._lastDebug={timeSec:r,targetMidi:h,userMidi:d,normalizedUserMidi:c.normalizedMidi,octaveFoldSemitones:c.octaveFoldSemitones,distance:c.distance,credit:c.credit,centsError:c.centsError},{noteId:this._liveResult?.noteId||null,stableState:this._currentFrame.stableState,rawCredit:this._currentFrame.rawCredit,gatedCredit:this._currentFrame.gatedCredit,stabilityFactor:this._currentFrame.stabilityFactor,centsError:this._currentFrame.centsError,stable:this._currentFrame.stable,isHit:this._currentFrame.isHit}}finalize(e=this._lastSampleTime){const n=Number.isFinite(Number(e))?Number(e):this._lastSampleTime||0;return this._visualTimeSec=n,this._finalizeReadyNotes(n,!0),this.getScore()}getScore(){return!Number.isFinite(this.totalWeightedBeats)||this.totalWeightedBeats<=0?0:Ti(this.correctWeightedBeats/this.totalWeightedBeats)*100}getLiveScore(){return!Number.isFinite(this.finalizedWeightedBeats)||this.finalizedWeightedBeats<=0?0:Ti(this.correctWeightedBeats/this.finalizedWeightedBeats)*100}getLiveScoreInfo(e=3){const n=this._nextNoteIndex,i=Math.max(1,Number(e)||1),r=Math.min(i,Math.max(1,this.referenceNotes.length));return{score:this.getLiveScore(),ready:n>=r,finalizedNotes:n,finalizedWeightedBeats:this.finalizedWeightedBeats}}getDebugInfo(){const e=this._metrics.totalSamples,n=this._noteResults.reduce((i,r)=>{const a=r.rejectionReason||r.stability?.rejectionReason;return a&&(i[a]=(i[a]||0)+1),i},{});return{algorithmVersion:kn,score:this.getScore(),liveScore:this.getLiveScore(),correctWeightedBeats:this.correctWeightedBeats,totalWeightedBeats:this.totalWeightedBeats,finalizedWeightedBeats:this.finalizedWeightedBeats,finalizedNotes:this._nextNoteIndex,pendingNotes:Math.max(0,this.referenceNotes.length-this._nextNoteIndex),octaveShift:0,octavePolicy:"pitch-class",calibrationStatus:"disabled",calibrationSamples:0,voicedCoverage:e>0?this._metrics.voicedSamples/e:0,rejectedRms:this._metrics.rejectedRms,rejectedClarity:this._metrics.rejectedClarity,smoothingResetCount:this._metrics.smoothingResetCount,stabilityRejections:n,recentNotes:this._noteResults.slice(),liveNote:this._liveResult,last:{...this._lastDebug}}}_confirmedThroughForResult(e){if(!e)return null;const n=e.note,i=Number(n?.t0Sec),r=Number(n?.t1Sec);return!Number.isFinite(i)||!Number.isFinite(r)?null:Number.isFinite(e.finalizedAtSec)&&!e.pendingConfirmation?r:i}_confirmedSegmentsForResult(e){if(!e||!Array.isArray(e.stableSegments))return[];const n=this._confirmedThroughForResult(e);return Number.isFinite(n)?e.stableSegments.flatMap(i=>{const r=Number(i.t0Sec),a=Math.min(Number(i.t1Sec),n);return!Number.isFinite(r)||!Number.isFinite(a)||a<=r?[]:[{...i,t1Sec:a,noteId:e.noteId,decisionWindowSec:e.decisionWindowSec,visualDelaySec:e.visualDelaySec,confirmedAtSec:e.finalizedAtSec}]}):[]}getVisualState(){const e=Number.isFinite(this._visualTimeSec)?this._visualTimeSec:0,i=(this._liveResult?[...this._noteResults.filter(l=>l.noteId!==this._liveResult.noteId),this._liveResult]:this._noteResults.slice()).flatMap(l=>this._confirmedSegmentsForResult(l)).sort((l,d)=>l.t0Sec-d.t0Sec),r=this._liveResult||this._noteResults[this._noteResults.length-1]||null,a=this._confirmedThroughForResult(r),o=r?Math.max(0,Math.ceil((Math.min(Number(r.note?.t1Sec)||e,e)-(Number.isFinite(a)?a:Number(r.note?.t0Sec)||e))/this.config.sampleGridSec)):0;return{algorithmVersion:kn,octaveShift:0,octavePolicy:"pitch-class",calibrationStatus:"disabled",currentFrame:this._currentFrame,liveNote:this._liveResult,recentNotes:this._noteResults.slice(),confirmedSegments:i,pendingDecisionCount:o,decisionWindowSec:r?.decisionWindowSec??null,confirmedThroughSec:a}}getFinalizeInfo(){return{count:this._lastFinalizeCount,score:this._lastFinalizeScore}}}async function gr(s,e={}){if(!s)return{song:null,limit:0,results:[]};const n=new URLSearchParams({song:s}),i=e.version===void 0?kn:e.version;i!==null&&n.set("version",String(i));const r=await fetch(Nt(`/api/leaderboard?${n.toString()}`),{method:"GET",signal:e.signal});if(!r.ok)throw new Error(`Failed to load leaderboard (${r.status})`);if(!(r.headers.get("content-type")||"").includes("application/json")){const o=await r.text();throw new Error(`Unexpected response for leaderboard API. ${o.slice(0,120)}`)}return r.json()}function nn({artist:s,className:e="",children:n,onClick:i,...r}){const a=xt(l=>l.openArtist),o=String(s||"").trim();return o?t.jsx("button",{type:"button",className:`artistLink ${e}`.trim(),onClick:l=>{l.stopPropagation(),i?.(l),l.defaultPrevented||a(o)},"aria-label":`${o} の曲一覧を開く`,...r,children:n||o}):n||null}function xo({song:s,onBack:e}){const[n,i]=g.useState([]),[r,a]=g.useState({total_participants:0,average_score:0}),[o,l]=g.useState(!0),[d,m]=g.useState(null);return g.useEffect(()=>{let u=!1;return(async()=>{if(s?.id){l(!0),m(null);try{const c=await gr(s.id);if(!u){const f=c.results||[];i(f);const b=c.total_participants!==void 0?c.total_participants:f.length;let p=0;c.average_score!==void 0?p=c.average_score:f.length>0&&(p=f.reduce((S,N)=>S+(parseFloat(N.score)||0),0)/f.length),a({total_participants:b,average_score:p})}}catch(c){u||(console.error("Failed to load leaderboard",c),m("ランキングの読み込みに失敗しました。"))}finally{u||l(!1)}}})(),()=>{u=!0}},[s?.id]),t.jsxs(Zn,{fluid:!0,className:"py-3",children:[t.jsx(at,{className:"mb-3 shadow-none",style:{border:"1px solid #fab1da",backgroundColor:"#fff0f6",backgroundImage:`
          linear-gradient(rgba(233, 30, 99, 0.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(233, 30, 99, 0.05) 1px, transparent 1px),
          linear-gradient(135deg, #fff0f6 0%, #ffeaf2 50%, #e6f7ff 100%)
        `,backgroundSize:"20px 20px, 20px 20px, 100% 100%"},children:t.jsx(at.Body,{className:"p-4",children:t.jsxs(Pe,{className:"align-items-center",children:[t.jsxs(X,{children:[t.jsx("div",{className:"mb-1",children:t.jsx("span",{className:"px-3 py-1 rounded-pill fw-bold",style:{background:"linear-gradient(to bottom, #ffd700, #ffa500)",color:"#fff",border:"2px solid #fff",textShadow:"0 1px 2px rgba(0,0,0,0.3)"},children:"全国採点"})}),t.jsx("h1",{className:"fw-bold mb-0 lh-1",style:{fontFamily:'"Arial Black", Gadget, sans-serif',fontSize:"3.5rem",background:"#0071bc",backgroundClip:"text",WebkitBackgroundClip:"text",color:"transparent",WebkitTextStroke:"1px white",filter:"drop-shadow(0px 2px 0px rgba(0,0,0,0.2))"},children:s?.title||"Pretender"}),t.jsx("div",{className:"fs-2 fw-bold",style:{fontFamily:'"Arial Black", Gadget, sans-serif',background:"#0071bc",backgroundClip:"text",WebkitBackgroundClip:"text",color:"transparent",WebkitTextStroke:"1px white",filter:"drop-shadow(0px 2px 0px rgba(0,0,0,0.2))"},children:t.jsx(nn,{artist:s?.artist||"Official髭男dism"})})]}),t.jsxs(X,{xs:"auto",className:"text-end",children:[t.jsxs("div",{className:"mb-3",children:[t.jsx("div",{className:"fw-bold",style:{fontSize:"0.9rem",color:"#0056b3",textShadow:"1px 1px 0 #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff",letterSpacing:"0.05em"},children:"PARTICIPANTS"}),t.jsxs("div",{className:"fs-2 fw-bold lh-1",style:{color:"#0056b3",textShadow:"2px 2px 0 #fff, 0 0 5px rgba(0,0,0,0.1)"},children:[o?"---":r.total_participants.toLocaleString(),t.jsx("span",{className:"fs-5 ms-1",children:"人"})]})]}),t.jsxs("div",{children:[t.jsx("div",{className:"fw-bold",style:{fontSize:"0.9rem",color:"#0056b3",textShadow:"1px 1px 0 #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff",letterSpacing:"0.05em"},children:"AVG. SCORE"}),t.jsxs("div",{className:"fs-2 fw-bold lh-1",style:{color:"#0056b3",textShadow:"2px 2px 0 #fff, 0 0 5px rgba(0,0,0,0.1)"},children:[o?"---":r.average_score.toFixed(3),t.jsx("span",{className:"fs-5 ms-1",children:"点"})]})]})]})]})})}),t.jsxs(at,{className:"bg-white border text-dark shadow-sm",style:{minHeight:400},children:[t.jsx(at.Header,{className:"bg-light border-bottom py-3 d-flex justify-content-between align-items-center",children:t.jsxs("div",{className:"fw-bold fs-5 d-flex align-items-center",children:[t.jsx(Br,{className:"me-2 text-warning",size:20})," 月間ランキング"]})}),t.jsxs(at.Body,{className:"p-0",children:[o&&t.jsx("div",{className:"d-flex justify-content-center align-items-center py-5",children:t.jsx(Cn,{animation:"border",variant:"primary"})}),d&&t.jsx("div",{className:"p-4",children:t.jsx(ai,{variant:"danger",children:d})}),!o&&!d&&n.length===0&&t.jsx("div",{className:"text-center py-5 text-muted",children:"まだランキングデータがありません。"}),!o&&!d&&t.jsx(xs,{gap:0,children:n.map((u,h)=>{let c=null;return u.rank===1&&(c="gold"),u.rank===2&&(c="silver"),u.rank===3&&(c="bronze"),t.jsxs("div",{className:`d-flex align-items-center p-3 border-bottom ${h%2===0?"bg-light":""}`,children:[t.jsxs("div",{className:"text-center",style:{width:60},children:[c==="gold"&&t.jsx("div",{className:"mx-auto",style:{width:32},children:t.jsx(Bs,{className:"text-warning",size:32,fill:"currentColor"})}),c==="silver"&&t.jsx("div",{className:"mx-auto",style:{width:32},children:t.jsx(Bs,{className:"text-secondary",size:32,fill:"currentColor"})}),c==="bronze"&&t.jsx("div",{className:"mx-auto",style:{width:32},children:t.jsx(Bs,{className:"text-warning-emphasis",size:32,fill:"currentColor"})}),!c&&t.jsx("div",{className:"fs-4 fst-italic fw-bold text-muted",children:u.rank}),c&&t.jsx("div",{className:"small fw-bold mt-n1 text-uppercase text-muted",style:{fontSize:"0.6rem"},children:"RANK"}),!c&&t.jsx("div",{className:"small fw-bold text-uppercase text-muted",style:{fontSize:"0.6rem"},children:"RANK"})]}),t.jsx("div",{className:"mx-3",children:t.jsx("div",{className:"rounded-circle d-flex align-items-center justify-content-center bg-white border border-dark",style:{width:48,height:48},children:t.jsx(Ar,{size:24,className:"text-dark"})})}),t.jsxs("div",{className:"flex-grow-1",children:[t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{className:"fw-bold fs-5 text-dark",children:u.username||"Unknown User"}),u.rank===1&&t.jsx(Pr,{bg:"warning",text:"dark",className:"small",children:"全国制覇"})]}),t.jsxs("div",{className:"small text-muted d-flex align-items-center",children:[t.jsx(Er,{size:14,className:"me-1"})," ",u.shop_name||"Home"]})]}),t.jsxs("div",{className:"text-end",children:[t.jsxs("div",{className:"fs-2 fw-bold text-dark lh-1",children:[Number(u.score).toFixed(3),t.jsx("span",{className:"fs-6 fw-normal ms-1 text-muted",children:"点"})]}),t.jsx("div",{className:"small text-muted",children:u.updated_at?new Date(u.updated_at).toLocaleDateString():"N/A"})]})]},u.rank)})})]})]}),t.jsx("div",{className:"mt-4 text-center",children:t.jsx(D,{variant:"secondary",onClick:e,className:"px-5 rounded-pill",children:"閉じる"})})]})}function Ks({icon:s,label:e,value:n}){return t.jsxs("div",{className:"d-flex align-items-center gap-3 py-2 border-bottom",children:[t.jsx("div",{className:"d-flex align-items-center justify-content-center rounded-3 bg-secondary-subtle text-secondary-emphasis flex-shrink-0",style:{width:44,height:44},"aria-hidden":"true",children:t.jsx("span",{style:{fontSize:22},children:s})}),t.jsx("div",{className:"text-muted small",style:{width:72},children:e}),t.jsx("div",{className:"fw-semibold fs-5 flex-grow-1",children:n})]})}function bo({onBack:s,onConfirm:e}){const i=Be().pendingSong,r=Ot(j=>j.showAlert),a=Re(j=>j.status),o=Re(j=>j.accessToken),l=yt(j=>j.items),d=yt(j=>j.add),m=vn(j=>j.guideMelodyEnabled),[u,h]=g.useState("—"),[c,f]=g.useState(!1),[b,p]=g.useState(""),[x,S]=g.useState(!1),[N,w]=g.useState("loading"),[v,_]=g.useState(""),[R,k]=g.useState("info"),[E,se]=g.useState(m),F=!!i?.id&&l.some(j=>j.song_code===i.id),z=j=>String(j?.message||"Unknown error");return g.useEffect(()=>{let j=!1;return(async()=>{if(!i?.lrc){h(i?.preview||"—");return}try{const Y=await fetch(i.lrc);if(!Y.ok)throw new Error("LRC not found");const pe=await Y.text(),de=ys(pe).slice(0,3).map(Q=>Q.plainText||Q.text).join(" / ").trim(),I=28,q=de.length>I?`${de.slice(0,I)}…`:de;j||h(q||"—")}catch{j||h(i?.preview||"—")}})(),()=>{j=!0}},[i]),g.useEffect(()=>{let j=!1;return(async()=>{if(!i?.lrc){p("—");return}try{const Y=await fetch(i.lrc);if(!Y.ok)throw new Error("LRC not found");const pe=await Y.text(),me=ys(pe).map(de=>String(de.plainText||de.text||"").trim()).filter(Boolean);j||p(me.join(`
`)||"—")}catch{j||p("—")}})(),()=>{j=!0}},[i]),R==="ranking"?t.jsx(xo,{song:i,onBack:()=>k("info")}):t.jsxs(Zn,{fluid:!0,className:"py-3",children:[t.jsxs("div",{className:"bg-light border rounded-3 p-3",children:[t.jsx("div",{className:"text-muted small mb-2",children:"曲予約を確定します。よろしければ「予約」をタッチしてください。"}),t.jsxs(Pe,{className:"g-3",children:[t.jsxs(X,{xs:12,lg:9,children:[t.jsxs("div",{className:"bg-white border rounded-3 p-3",children:[t.jsx(Ks,{icon:"🆔",label:"曲番号",value:i?.id||"—"}),t.jsx(Ks,{icon:"👤",label:"歌手名",value:i?.artist?t.jsx(nn,{artist:i.artist}):"—"}),t.jsx(Ks,{icon:"🎵",label:"曲名",value:i?.title||"—"}),t.jsxs("div",{className:"d-flex align-items-center gap-3 py-2",children:[t.jsx("div",{className:"d-flex align-items-center justify-content-center rounded-3 bg-secondary-subtle text-secondary-emphasis flex-shrink-0",style:{width:44,height:44},"aria-hidden":"true",children:t.jsx("span",{style:{fontSize:22},children:"🎤"})}),t.jsx("div",{className:"text-muted small",style:{width:72},children:"歌い出し"}),t.jsx("div",{className:"fw-semibold fs-5 flex-grow-1",children:u}),t.jsx(D,{variant:"primary",className:"rounded-pill px-10",type:"button",onClick:()=>f(!0),children:"歌詞を見る"})]})]}),t.jsxs("div",{className:"mt-3",children:[t.jsxs(Pe,{className:"g-2",children:[t.jsx(X,{xs:12,md:4,children:t.jsxs(at,{className:"h-100",children:[t.jsx(at.Header,{className:"py-2 fw-semibold",children:"ガイドメロディ"}),t.jsxs(at.Body,{className:"py-2 d-flex align-items-center justify-content-between gap-3",children:[t.jsx("div",{className:"text-muted small",children:E?"あり":"なし"}),t.jsx(A.Check,{type:"switch",id:`guide-melody-${i?.id||"song"}`,checked:E,onChange:j=>se(j.currentTarget.checked),label:E?"ON":"OFF","aria-label":"ガイドメロディを切り替える"})]})]})}),t.jsx(X,{xs:12,md:4,children:t.jsxs(at,{className:"h-100",children:[t.jsx(at.Header,{className:"py-2 fw-semibold",children:"キー"}),t.jsx(at.Body,{className:"py-2",children:t.jsx("div",{className:"text-muted small",children:"原曲"})})]})}),t.jsx(X,{xs:12,md:4,children:t.jsxs(at,{className:"h-100",children:[t.jsx(at.Header,{className:"py-2 fw-semibold",children:"歌詞サイズ"}),t.jsx(at.Body,{className:"py-2",children:t.jsx("div",{className:"text-muted small",children:"ふつう"})})]})})]}),t.jsx("div",{className:"w-100 mt-3"}),t.jsxs("div",{className:"d-flex gap-2",children:[t.jsx(D,{variant:"secondary",className:"rounded-pill px-4",type:"button",onClick:s,children:"もどる"}),t.jsx(D,{variant:"secondary",className:"rounded-pill px-4",type:"button",children:"トップメニュー"})]})]})]}),t.jsx(X,{xs:12,lg:3,children:t.jsxs(xs,{gap:2,className:"h-100",children:[t.jsx(D,{variant:F?"secondary":"info",className:"fw-semibold",type:"button",disabled:a!=="authenticated"||F,onClick:async()=>{if(!(!i||a!=="authenticated"))try{if(!await d(i,o))return;r({message:`${i.title} をマイうたに追加しました`,variant:"success",timeoutMs:2500})}catch(j){r({message:String(j?.message||"Failed to add favorite"),variant:"danger",timeoutMs:3500})}},children:F?t.jsx(t.Fragment,{children:"登録済み"}):t.jsxs(t.Fragment,{children:["マイうたに",t.jsx("br",{}),"登録"]})}),t.jsx(D,{variant:"info",className:"fw-semibold",type:"button",onClick:()=>k("ranking"),children:"全国ランキング"}),t.jsx("div",{className:"flex-grow-1 d-flex align-items-end justify-content-center",children:t.jsx(D,{variant:"danger",className:"rounded-circle fw-bold fs-1",type:"button",style:{width:140,height:140},disabled:!i,onClick:async()=>{if(i){S(!0),w("loading"),_("通信中です…");try{await ks({...i,guideMelodyEnabled:E}),w("success"),_("読み込み完了しました。"),r({message:`${i.title} を予約しました。`,variant:"success",timeoutMs:2500}),setTimeout(()=>{S(!1),e&&e()},600)}catch(j){w("error");const L=z(j);_(L),r({message:L,variant:"danger",timeoutMs:3500})}}},children:"予約"})})]})})]})]}),t.jsxs(cr,{show:c,title:i?.title||"歌詞",showActions:!1,onClose:()=>f(!1),children:[t.jsx("div",{className:"text-start",style:{maxHeight:360,overflowY:"auto",whiteSpace:"pre-wrap"},children:b}),t.jsx("div",{className:"mt-3 d-flex justify-content-center",children:t.jsx(D,{variant:"secondary",type:"button",onClick:()=>f(!1),children:"閉じる"})})]}),t.jsx(Ms,{isOpen:x,status:N,message:v,onClose:()=>S(!1)})]})}function So(s){return(s?.queue||[]).map((n,i)=>({song:n,idx:i}))}function yo(s){return s?.history||[]}function No({onBack:s}){const e=Be(),n=So(e),i=yo(e),r=Ot(a=>a.showAlert);return t.jsxs(Zn,{className:"py-3",style:{maxWidth:860},children:[t.jsxs("div",{className:"d-flex justify-content-between align-items-center mb-3",children:[t.jsx("h1",{className:"h4 m-0",children:"現在の予約"}),t.jsxs("div",{className:"d-flex gap-2",children:[t.jsx(D,{variant:"secondary",type:"button",onClick:s,children:"Back"}),t.jsx(D,{variant:"outline-danger",type:"button",disabled:!e.queue.length,onClick:()=>Qa(),children:"Clear"})]})]}),t.jsxs("div",{className:"mb-3 text-muted small",children:["已予約: ",n.length," / 历史: ",i.length]}),t.jsxs(_s,{defaultActiveKey:"reserved",className:"mb-3",children:[t.jsx(Mt,{eventKey:"reserved",title:"已予約",children:t.jsx($t,{children:n.length?n.map(({song:a,idx:o},l)=>{const d=o===e.queueIndex,m=e.queueIndex>=0?e.queueIndex+1:0,u=o>m;return t.jsxs($t.Item,{className:"d-flex align-items-center gap-3",children:[t.jsxs("div",{className:"flex-grow-1",children:[t.jsxs("div",{className:"fw-semibold",children:[l+1,". ",a.title]}),t.jsx(nn,{artist:a.artist,className:"text-muted small"})]}),d?t.jsx("span",{className:"badge text-bg-primary",children:"Now Playing"}):u?t.jsx(D,{variant:"outline-primary",size:"sm",type:"button",onClick:()=>{Za(o),r({message:`${a.title} を割り込みしました`,variant:"info",timeoutMs:3e3})},children:"割り込み"}):null,d?null:t.jsx(D,{variant:"outline-secondary",size:"sm",type:"button",onClick:()=>Ja(o),children:"キャンセル"})]},`${a.title}-${o}`)}):t.jsx($t.Item,{className:"text-muted",children:"No songs queued."})})}),t.jsx(Mt,{eventKey:"history",title:"历史",children:t.jsx($t,{children:i.length?i.map((a,o)=>t.jsxs($t.Item,{className:"d-flex align-items-center gap-3",children:[t.jsxs("div",{className:"flex-grow-1",children:[t.jsxs("div",{className:"fw-semibold",children:[o+1,". ",a.title]}),t.jsx(nn,{artist:a.artist,className:"text-muted small"})]}),t.jsx("span",{className:"badge text-bg-secondary",children:"Played"})]},`${a.title}-history-${o}`)):t.jsx($t.Item,{className:"text-muted",children:"No history yet."})})})]})]})}function wo({onBack:s,onSelectSong:e,onConfirm:n}){const i=Ot(I=>I.showAlert),r=Re(I=>I.status),a=Re(I=>I.accessToken),o=yt(I=>I.items),l=yt(I=>I.add),[d,m]=g.useState(""),[u,h]=g.useState([]),[c,f]=g.useState(0),[b,p]=g.useState(1),[x,S]=g.useState(!0),[N,w]=g.useState(""),[v,_]=g.useState(!1),[R,k]=g.useState("loading"),[E,se]=g.useState(""),[F,z]=g.useState([]),[j,L]=g.useState(""),Y=I=>String(I?.message||"Unknown error"),pe=async I=>{if(I){_(!0),k("loading"),se("サーバーに接続中...");try{await ks(I),k("success"),se("接続完了。曲を読み込みました。"),i({message:`${I.title} を予約しました`,variant:"success",timeoutMs:2500}),setTimeout(()=>{_(!1),n&&n()},600)}catch(q){k("error");const Q=Y(q);se(Q),i({message:Q,variant:"danger",timeoutMs:3500})}}},ie=async(I,q)=>{if(q.stopPropagation(),!(!I||r!=="authenticated"))try{if(!await l(I,a))return;i({message:`${I.title} をマイうたに追加しました`,variant:"success",timeoutMs:2500})}catch(Q){i({message:String(Q?.message||"Failed to add favorite"),variant:"danger",timeoutMs:3500})}};g.useEffect(()=>{const I=new AbortController;let q=!1;return ca({signal:I.signal}).then(Q=>{if(q)return;const be=Array.isArray(Q)?Q.map(He=>He.name||He):[];z(be)}).catch(()=>{q||z([])}),()=>{q=!0,I.abort()}},[]),g.useEffect(()=>{const I=new AbortController;let q=!1;return Xn({q:d,tag:j||void 0,page:b,signal:I.signal}).then(Q=>{if(q)return;const be=Array.isArray(Q?.items)?Q.items:[];h(be),f(Number(Q?.count)||be.length)}).catch(Q=>{q||w(Q?.message||"Failed to load songs.")}).finally(()=>{q||S(!1)}),()=>{q=!0,I.abort()}},[j,b,d]);const me=g.useMemo(()=>Math.max(1,Math.ceil(c/10)),[c]),de=g.useMemo(()=>new Set(o.map(I=>I.song_code)),[o]);return t.jsxs("div",{className:"wiiFind h-100 d-flex flex-column",children:[t.jsxs("div",{className:"wiiFind__headerRed",children:[t.jsxs("a",{href:"#",className:"wiiFind__backRed",onClick:I=>{I.preventDefault(),s()},children:[t.jsx("span",{className:"wiiFind__backIcon",children:"←"})," 戻る"]}),t.jsxs("div",{className:"d-flex align-items-center flex-grow-1 mx-2",children:[t.jsx(A.Control,{className:"wiiFind__inputRed",value:d,onChange:I=>{m(I.target.value),p(1),S(!0),w("")}}),t.jsx("span",{className:"wiiFind__suffix",children:"で 始まる曲"})]}),t.jsx("div",{className:"wiiFind__countRed",children:c?`${c}件`:"0件"})]}),t.jsxs("div",{className:"wiiFind__tabs",children:[t.jsx(D,{className:`wiiFind__tabBtn ${j===""?"wiiFind__tabBtn--active":""}`,onClick:()=>{L(""),p(1),S(!0),w("")},children:"すべて"}),F.map(I=>t.jsx(D,{className:`wiiFind__tabBtn ${j===I?"wiiFind__tabBtn--active":""}`,onClick:()=>{L(I),p(1),S(!0),w("")},children:I},I))]}),t.jsxs(Pe,{className:"g-0 flex-grow-1 overflow-hidden",children:[t.jsx(X,{className:"h-100 d-flex flex-column",style:{minWidth:0},children:t.jsxs("div",{className:"wiiList h-100",children:[x?t.jsxs("div",{className:"text-muted small mt-2 d-flex align-items-center gap-2",children:[t.jsx(Cn,{animation:"border",size:"sm"}),"読み込み中…"]}):null,N?t.jsx("div",{className:"text-danger small mt-2",children:N}):null,u.length?u.map(I=>t.jsxs("div",{className:"wiiList__item",onClick:()=>e&&e(I),role:"button",children:[t.jsx("div",{className:"wiiList__iconBadgeContainer",children:I.tags?.length?t.jsx("div",{className:"wiiList__iconBadge wiiList__iconBadge--original",children:I.tags[0]}):null}),t.jsx("div",{className:"wiiList__title",children:I.title}),t.jsx(nn,{artist:I.artist,className:"wiiList__artist"}),t.jsxs("div",{className:"d-flex gap-2 ms-auto",children:[t.jsxs(D,{className:`wiiList__actionBtn ${de.has(I.id)?"wiiList__actionBtn--registered":""}`,disabled:r!=="authenticated"||de.has(I.id),onClick:q=>ie(I,q),children:[t.jsx("span",{className:`me-1 ${de.has(I.id)?"text-secondary":"text-warning"}`,style:{textShadow:"0 1px 0 rgba(0,0,0,0.2)"},children:"★"}),"マイうた"]}),t.jsx(D,{className:"wiiList__actionBtn wiiList__actionBtn--reserve",onClick:q=>{q.stopPropagation(),pe(I)},children:"予約"})]})]},I.id)):!x&&t.jsx("div",{className:"wiiList__empty text-muted",children:"該当する曲がありません。"})]})}),t.jsx(X,{xs:"auto",className:"h-100 ps-0",children:t.jsxs("div",{className:"wiiFind__navBar",style:{width:"50px"},children:[t.jsxs(D,{className:"wiiFind__navBtn",disabled:b<=1||x,onClick:()=>{p(I=>Math.max(1,I-1)),S(!0),w("")},children:[t.jsx("div",{style:{fontSize:"1.5rem"},children:"▲"}),"前"]}),t.jsxs(D,{className:"wiiFind__navBtn",disabled:b>=me||x,onClick:()=>{p(I=>Math.min(me,I+1)),S(!0),w("")},children:["次",t.jsx("div",{style:{fontSize:"1.5rem"},children:"▼"})]})]})})]}),t.jsx(Ms,{isOpen:v,status:R,message:E,onClose:()=>_(!1)})]})}function vo({onBack:s}){const[e,n]=g.useState([]),[i,r]=g.useState(""),[a,o]=g.useState([]),[l,d]=g.useState(!1),[m,u]=g.useState(!1),[h,c]=g.useState("");g.useEffect(()=>{const b=new AbortController;let p=!1;return d(!0),c(""),Xn({signal:b.signal,pageSize:200}).then(x=>{if(p)return;const S=Array.isArray(x?.items)?x.items:[];n(S),!i&&S.length&&r(S[0].id)}).catch(x=>{p||c(x?.message||"Failed to load songs.")}).finally(()=>{p||d(!1)}),()=>{p=!0,b.abort()}},[]),g.useEffect(()=>{if(!i){o([]);return}const b=new AbortController;let p=!1;return u(!0),c(""),gr(i,{signal:b.signal}).then(x=>{p||o(Array.isArray(x?.results)?x.results:[])}).catch(x=>{p||c(x?.message||"Failed to load leaderboard.")}).finally(()=>{p||u(!1)}),()=>{p=!0,b.abort()}},[i]);const f=g.useMemo(()=>e.find(b=>b.id===i),[e,i]);return t.jsxs("div",{className:"wiiFind h-100 d-flex flex-column",children:[t.jsx("div",{className:"wiiFind__header",children:t.jsx("div",{className:"wiiFind__hint",children:"ランキング"})}),t.jsx(Pe,{className:"g-3 flex-grow-1 overflow-hidden",children:t.jsxs(X,{xs:12,className:"d-flex flex-column h-100",children:[t.jsxs(Pe,{className:"g-2 align-items-center",children:[t.jsx(X,{xs:12,md:8,children:t.jsx(A.Select,{value:i,onChange:b=>r(b.target.value),disabled:l||!e.length,children:e.map(b=>t.jsxs("option",{value:b.id,children:[b.title," - ",b.artist]},b.id))})}),t.jsx(X,{xs:12,md:4,className:"d-flex gap-2 justify-content-md-end",children:t.jsx(D,{className:"wiiBottomMini wiiBottomMini--dark",type:"button",onClick:s,children:"Back"})})]}),f?t.jsxs("div",{className:"text-muted small mt-2",children:[f.title," / ",t.jsx(nn,{artist:f.artist})]}):null,l||m?t.jsxs("div",{className:"text-muted small mt-2 d-flex align-items-center gap-2",children:[t.jsx(Cn,{animation:"border",size:"sm"}),"Loading leaderboard…"]}):null,h?t.jsx("div",{className:"text-danger small mt-2",children:h}):null,t.jsx($t,{className:"mt-3",children:a.length?a.map(b=>t.jsxs($t.Item,{className:"d-flex align-items-center gap-3",children:[t.jsxs("div",{className:"fw-semibold",children:["#",b.rank]}),t.jsxs("div",{className:"flex-grow-1",children:[t.jsx("div",{className:"fw-semibold",children:b.username}),t.jsxs("div",{className:"text-muted small",children:["Score ",b.score,b.accuracy!=null?` · Acc ${b.accuracy}`:"",b.max_combo!=null?` · Combo ${b.max_combo}`:""]})]})]},`${b.username}-${b.rank}`)):t.jsx($t.Item,{className:"text-muted",children:"No results"})})]})})]})}const _o=({onBack:s,onStartScoring:e})=>t.jsxs("div",{className:"wiiScoringPage",children:[t.jsxs("div",{className:"wiiScoring__content",children:[t.jsxs("div",{className:"wiiScoring__banner",children:[t.jsxs("div",{className:"wiiScoring__bannerTitle",children:[t.jsx("span",{className:"wiiScoring__bannerTitleMain",children:"周波採点"}),t.jsx("span",{className:"wiiScoring__bannerTitleSub",children:"DX"})]}),t.jsx("div",{className:"wiiScoring__bannerSlogan",children:"新採点基準であなたの歌声を徹底分析!"})]}),t.jsxs("div",{className:"wiiScoring__mainBody",children:[t.jsxs("div",{className:"wiiScoring__leftCol",children:[t.jsxs("div",{className:"wiiScoring__pointRow",children:[t.jsx("div",{className:"wiiScoring__pointLabel wiiScoring__pointLabel--pitch",children:"音程"}),t.jsx("div",{className:"wiiScoring__pointDesc",children:"歌唱したフレーズ全体での音程一致率"})]}),t.jsxs("div",{className:"wiiScoring__pointRow",children:[t.jsx("div",{className:"wiiScoring__pointLabel wiiScoring__pointLabel--stability",children:"安定感"}),t.jsx("div",{className:"wiiScoring__pointDesc",children:"音程がブレずに安定して歌唱できているか"})]}),t.jsxs("div",{className:"wiiScoring__pointRow",children:[t.jsx("div",{className:"wiiScoring__pointLabel wiiScoring__pointLabel--tone",children:"ロングトーン"}),t.jsx("div",{className:"wiiScoring__pointDesc",children:"正しい音程で、安定して声を伸ばせているか"})]}),t.jsxs("div",{className:"wiiScoring__pointRow",children:[t.jsx("div",{className:"wiiScoring__pointLabel wiiScoring__pointLabel--rhythm",children:"抑揚"}),t.jsx("div",{className:"wiiScoring__pointDesc",children:"曲の展開に応じて正しく抑揚をつけられているか"})]}),t.jsxs("div",{className:"wiiScoring__pointRow",children:[t.jsx("div",{className:"wiiScoring__pointLabel wiiScoring__pointLabel--tech",children:"テクニック"}),t.jsx("div",{className:"wiiScoring__pointDesc",children:"こぶし、しゃくり、ビブラート、フォールなどの回数"})]})]}),t.jsxs("div",{className:"wiiScoring__rightCol",children:[t.jsx("div",{className:"wiiScoring__chartTitle",children:"♪ 歌唱データを細かく分析"}),t.jsx("div",{className:"wiiScoring__chartBox",children:t.jsx("div",{className:"wiiScoring__chartMock",children:t.jsx("div",{className:"wiiScoring__pentagon",children:t.jsx("span",{children:"97.3"})})})}),t.jsx("div",{className:"wiiScoring__chartFooter",children:"♪ 人の感覚に近い採点基準"})]})]})]}),t.jsx("div",{className:"wiiScoring__footer",children:t.jsx(D,{className:"wiiScoring__startBtn",onClick:e,children:"採点スタート"})})]});function ko({onBack:s}){const e=Re(j=>j.status),n=Re(j=>j.user),i=Re(j=>j.error),r=Re(j=>j.login),a=Re(j=>j.register),o=Re(j=>j.setGuest),l=Re(j=>j.logout),d=Re(j=>j.clearError),[m,u]=g.useState(""),[h,c]=g.useState(""),[f,b]=g.useState(""),[p,x]=g.useState(""),[S,N]=g.useState(""),[w,v]=g.useState(!1),[_,R]=g.useState(""),[k,E]=g.useState(""),se=e==="loading",F=g.useRef(e==="authenticated");g.useEffect(()=>{if(!s)return;const j=F.current,L=e==="authenticated";!j&&L&&s(),F.current=L},[s,e]);const z=j=>{const L=String(j?.message||"");try{const Y=JSON.parse(L);if(Y?.detail)return Y.detail;if(Y&&typeof Y=="object")return Object.entries(Y).map(([pe,ie])=>{const me=Array.isArray(ie)?ie.join(" / "):String(ie);return`${pe}: ${me}`}).join(`
`)}catch{}return L||"エラーが発生しました。"};return t.jsxs("div",{className:"wiiFind h-100 d-flex flex-column",children:[t.jsx("div",{className:"wiiFind__header",children:t.jsx("div",{className:"wiiFind__hint",children:"ログイン / 新規登録"})}),t.jsxs(Pe,{className:"g-3 flex-grow-1",children:[t.jsx(X,{xs:12,lg:6,children:t.jsx(at,{className:"p-3 h-100",children:e==="authenticated"?t.jsxs("div",{className:"d-flex flex-column gap-3",children:[t.jsxs("div",{children:[t.jsx("div",{className:"text-muted small",children:"ログイン中"}),t.jsx("div",{className:"fw-semibold fs-5",children:n?.profile?.display_name||n?.username}),t.jsx("div",{className:"text-muted small",children:n?.email})]}),t.jsx("div",{className:"d-flex gap-2",children:t.jsx(D,{variant:"danger",onClick:()=>l(),children:"ログアウト"})})]}):t.jsxs(t.Fragment,{children:[t.jsxs(_s,{defaultActiveKey:"login",className:"mb-3",onSelect:()=>d(),children:[t.jsx(Mt,{eventKey:"login",title:"ログイン",children:t.jsxs(A,{onSubmit:j=>{j.preventDefault(),r(m,h).catch(L=>{const Y=z(L);R("ログイン失敗"),E(Y),v(!0)})},children:[t.jsxs(A.Group,{className:"mb-3",children:[t.jsx(A.Label,{children:"メール / ユーザー名"}),t.jsx(A.Control,{value:m,onChange:j=>u(j.target.value)})]}),t.jsxs(A.Group,{className:"mb-3",children:[t.jsx(A.Label,{children:"パスワード"}),t.jsx(A.Control,{type:"password",value:h,onChange:j=>c(j.target.value)})]}),i?t.jsx("div",{className:"text-danger small mb-2",children:i}):null,t.jsx(D,{type:"submit",disabled:se,children:"ログイン"})]})}),t.jsx(Mt,{eventKey:"register",title:"新規登録",children:t.jsxs(A,{onSubmit:j=>{j.preventDefault(),a(f,p,S).catch(L=>{const Y=z(L);R("登録失敗"),E(Y),v(!0)})},children:[t.jsxs(A.Group,{className:"mb-3",children:[t.jsx(A.Label,{children:"ユーザー名"}),t.jsx(A.Control,{value:f,onChange:j=>b(j.target.value)})]}),t.jsxs(A.Group,{className:"mb-3",children:[t.jsx(A.Label,{children:"メール"}),t.jsx(A.Control,{type:"email",value:p,onChange:j=>x(j.target.value)})]}),t.jsxs(A.Group,{className:"mb-3",children:[t.jsx(A.Label,{children:"パスワード"}),t.jsx(A.Control,{type:"password",value:S,onChange:j=>N(j.target.value)})]}),i?t.jsx("div",{className:"text-danger small mb-2",children:i}):null,t.jsx(D,{type:"submit",disabled:se,children:"登録"})]})})]}),t.jsx("div",{className:"text-muted small",children:"Google ログインは後で追加できます。"})]})})}),t.jsx(X,{xs:12,lg:6,children:t.jsxs(at,{className:"p-3 h-100 d-flex flex-column justify-content-between",children:[t.jsxs("div",{children:[t.jsx("h5",{children:"ゲストで試す"}),t.jsx("p",{className:"text-muted small",children:"ゲストは全国ランキング・マイうたに参加できません。"})]}),t.jsx("div",{className:"d-flex gap-2",children:t.jsx(D,{variant:"outline-primary",onClick:()=>{o(),s&&s()},children:"ゲストで開始"})})]})})]}),t.jsxs(cr,{show:w,title:_,showActions:!1,onClose:()=>{v(!1)},children:[t.jsx("div",{className:"text-start",style:{whiteSpace:"pre-wrap"},children:k.split(`
`).map((j,L)=>t.jsx("div",{className:"fw-semibold mb-1",children:j},L))}),t.jsx("div",{className:"mt-3 d-flex justify-content-center",children:t.jsx(D,{variant:"secondary",type:"button",onClick:()=>{v(!1)},children:"閉じる"})})]})]})}function ci(s){const e=s?.length||0;if(!e)return 0;let n=0;for(let i=0;i<e;i+=1){const r=s[i];n+=r*r}return Math.sqrt(n/e)}function li(s){const e=Number(s);return!Number.isFinite(e)||e<=0?null:69+12*Math.log2(e/440)}function Mo(s,e){const n=Number(s),i=Number(e);return!Number.isFinite(n)||!Number.isFinite(i)?null:(n-i)*100}class Co{constructor(){this.id="pitchy",this.name="Pitchy",this._clarityGate=.1,this._detector=null,this._inputLength=0}configure(e){const n=Number(e?.clarityGate);Number.isFinite(n)&&(this._clarityGate=n)}_ensureDetector(e){this._detector&&this._inputLength===e||(this._inputLength=e,this._detector=$r.forFloat32Array(e))}detect(e){const n=e?.samples,i=Number(e?.sampleRate);if(!n||!Number.isFinite(i))return null;const r=Number.isFinite(e?.rms)?e.rms:ci(n);this._ensureDetector(n.length);const[a,o]=this._detector.findPitch(n,i),l=Number.isFinite(a)?li(a):null,d=Number.isFinite(o)?o:0;return{f0Hz:Number.isFinite(a)?a:null,midi:l,confidence:d,rms:r}}reset(){this._detector=null,this._inputLength=0}}class jo{constructor(){this.id="aubio",this.name="AubioJS",this._detector=null,this._inputLength=0,this._sampleRate=0,this._initializing=!1,this._ready=!1,this._aubioPromise=null,this._aubioError=null,this._tolerance=.5}configure(e){const n=Number(e?.aubioTolerance);Number.isFinite(n)&&(this._tolerance=n,this._detector?.setTolerance&&this._detector.setTolerance(n))}_ensureDetector(e,n){if(!(this._detector&&this._inputLength===e&&this._sampleRate===n)&&!this._initializing&&!this._aubioError){if(this._initializing=!0,this._inputLength=e,this._sampleRate=n,!this._aubioPromise)try{const i=typeof rs=="function"?rs:typeof rs?.default=="function"?rs.default:null;if(!i)throw new Error("aubiojs default export not found");this._aubioPromise=Promise.resolve(i()).catch(r=>(this._aubioError=r,console.warn("[AubioPlugin] init failed",r),null))}catch(i){this._aubioError=i,this._aubioPromise=Promise.resolve(null)}this._aubioPromise.then(i=>{if(!i)return;const{Pitch:r}=i;if(typeof r!="function"){this._aubioError=new Error("aubiojs Pitch not available");return}const a=Math.max(1,Math.floor(e/8));this._detector=new r("default",e,a,n),this._detector?.setTolerance&&this._detector.setTolerance(this._tolerance),this._ready=!0}).finally(()=>{this._initializing=!1})}}detect(e){const n=e?.samples,i=Number(e?.sampleRate);if(!n||!Number.isFinite(i)||(this._ensureDetector(n.length,i),!this._ready||!this._detector?.do))return null;const r=this._detector.do(n);return{f0Hz:Number.isFinite(r)?r:null,midi:null,confidence:Number.isFinite(r)?1:0}}reset(){this._detector=null,this._inputLength=0,this._sampleRate=0,this._ready=!1}}const At={pyinMu:.1,pyinPs:.99,pyinSpacing:Math.pow(2,1/120),pyinDf:30,pyinThreshold:.15,pyinProbabilityThreshold:.1,pyinMaxCandidates:8,fminHz:50,fmaxHz:2e3};function To(s){const e=Number(s);return Number.isFinite(e)?Math.max(0,Math.min(1,e)):0}class Fo{constructor(){this.id="pyin",this.name="pYIN (causal)",this._config={...At},this._sampleRate=0,this._K=0,this._fStates=null,this._transLog=null,this._logPs=Math.log(this._config.pyinPs),this._log1Ps=Math.log(1-this._config.pyinPs),this._stateKey="",this._LLast=null}configure(e){this._config={...this._config,...e};const n=Math.max(.001,Math.min(.999,Number(this._config.pyinPs)));this._config.pyinPs=n,this._logPs=Math.log(n),this._log1Ps=Math.log(1-n)}reset(){this._sampleRate=0,this._stateKey="",this._K=0,this._fStates=null,this._transLog=null,this._LLast=null}_ensureState(){const e=this._config,n=Number(e.pyinSpacing)||At.pyinSpacing,i=Math.max(1,Number(e.fminHz)||At.fminHz),r=Math.max(i+1,Number(e.fmaxHz)||At.fmaxHz),a=Math.max(1,Math.floor(Number(e.pyinDf)||At.pyinDf)),o=`${n}|${i}|${r}|${a}`;if(this._stateKey===o)return;const l=Math.max(2,Math.round(Math.log(r/i)/Math.log(n))+1),d=new Float32Array(l);for(let u=0;u<l;u+=1)d[u]=i*Math.pow(n,u);const m=new Float64Array(a);for(let u=0;u<a;u+=1){const h=1/a-u/(a*a);m[u]=Math.log(Math.max(1e-12,h))}this._stateKey=o,this._K=l,this._fStates=d,this._transLog=m,this._LLast=new Float64Array(2*l)}detect(e){const n=e?.samples,i=Number(e?.sampleRate);if(!n||!Number.isFinite(i))return null;this._ensureState(),this._sampleRate=i;const r=Number.isFinite(e?.rms)?e.rms:ci(n),a=this._getYinCandidates(n),o=a?.candidates||[],l=Number.isFinite(a?.dmin)?Number(a.dmin):null,d=!!a?.hasValley,m=this._updateCausalStates(o),u=d?m?.f0Hz??null:null,h=Number.isFinite(u)?li(u):null,c=d&&Number.isFinite(l)?To(1-l):0;return{f0Hz:Number.isFinite(u)?u:null,midi:h,confidence:c,rms:r}}_getYinCandidates(e){const n=this._config,i=Number(n.pyinThreshold)||At.pyinThreshold,r=Number(n.pyinProbabilityThreshold)||At.pyinProbabilityThreshold,a=Number(n.fminHz)||At.fminHz,o=Number(n.fmaxHz)||At.fmaxHz,l=Math.max(1,Math.floor(Number(n.pyinMaxCandidates)||At.pyinMaxCandidates));let d=1;for(;d<e.length;)d*=2;if(d/=2,d<2)return[];const m=d/2,u=new Float32Array(m);for(let x=1;x<m;x+=1){let S=0;for(let N=0;N<m;N+=1){const w=e[N]-e[N+x];S+=w*w}u[x]=S}u[0]=1,u[1]=1;let h=0;for(let x=1;x<m;x+=1)h+=u[x],u[x]*=x/h;const c=Math.max(2,Math.floor(this._sampleRate/Math.max(1,o))),f=Math.min(m-2,Math.ceil(this._sampleRate/Math.max(1,a)));let b=1/0;if(c<=f)for(let x=c;x<=f;x+=1){const S=u[x];Number.isFinite(S)&&S<b&&(b=S)}else for(let x=2;x<m-1;x+=1){const S=u[x];Number.isFinite(S)&&S<b&&(b=S)}Number.isFinite(b)||(b=null);const p=[];for(let x=2;x<m-1;x+=1){if(u[x]>=i||u[x]>u[x-1]||u[x]>=u[x+1]||1-u[x]<r)continue;const N=this._parabolicTau(u,x),w=this._sampleRate/N;!Number.isFinite(w)||w<a||w>o||p.push({f0:w,yin:u[x]})}return p.length?(p.sort((x,S)=>x.yin-S.yin),{candidates:p.slice(0,l),dmin:b,hasValley:!0}):{candidates:[],dmin:b,hasValley:!1}}_parabolicTau(e,n){let i=n<1?n:n-1,r=n+1<e.length?n+1:n;if(i===n)return e[n]<=e[r]?n:r;if(r===n)return e[n]<=e[i]?n:i;const a=e[i],o=e[n],l=e[r];return n+(l-a)/(2*(2*o-l-a))}_updateCausalStates(e){const n=this._K;if(!n)return null;const i=this._LLast||new Float64Array(2*n),r=new Float64Array(2*n),a=this._transLog,l=a.length-1,d=new Float64Array(n);for(let f=0;f<n;f+=1)d[f]=Number.NEGATIVE_INFINITY;let m=0;const u=Math.max(.001,Number(this._config.pyinMu)||At.pyinMu);for(const f of e){const b=Math.max(0,Math.min(n-1,Math.round(Math.log(f.f0/this._fStates[0])/Math.log(this._config.pyinSpacing)))),p=Math.pow(2,-f.yin/u)/e.length;if(!Number.isFinite(p)||p<=0)continue;m+=p;const x=Math.log(p);x>d[b]&&(d[b]=x)}for(let f=0;f<n;f+=1){let b=Number.NEGATIVE_INFINITY,p=Number.NEGATIVE_INFINITY;const x=Math.max(0,f-l),S=Math.min(n-1,f+l);for(let v=x;v<=S;v+=1){const _=Math.abs(v-f),R=a[_],k=i[n+v]+R,E=i[v]+R;k>b&&(b=k),E>p&&(p=E)}const N=Math.max(b+this._logPs,p+this._log1Ps),w=Math.max(1e-12,(1-m)/n);r[n+f]=N+Math.log(w)}for(let f=0;f<n;f+=1){if(!Number.isFinite(d[f])){r[f]=Number.NEGATIVE_INFINITY;continue}let b=Number.NEGATIVE_INFINITY,p=Number.NEGATIVE_INFINITY;const x=Math.max(0,f-l),S=Math.min(n-1,f+l);for(let w=x;w<=S;w+=1){const v=Math.abs(w-f),_=a[v],R=i[w]+_,k=i[n+w]+_;R>b&&(b=R),k>p&&(p=k)}const N=Math.max(b+this._logPs,p+this._log1Ps);r[f]=N+d[f]}this._LLast=r;let h=0,c=r[0];for(let f=1;f<r.length;f+=1)r[f]>c&&(c=r[f],h=f);return h>=n?{f0Hz:null}:{f0Hz:this._fStates[h]}}}const Ro="/crepe/model.json",Bo=16e3,cs=1024,Ao=1997.379408437619,Po=7180,Zs=360;let Vs=null,pr=null;function Eo(){return Vs||(Vs=(async()=>{await na("cpu"),await sa(),pr=ia(ra(0,Po,Zs),ar(Ao))})()),Vs}class Lo{constructor(){this.id="crepe-tf",this.name="CREPE (TF)",this._confidenceGate=.5,this._model=null,this._modelPromise=null}configure(e){const n=Number(e?.crepeConfidenceThreshold);Number.isFinite(n)&&(this._confidenceGate=n)}detect(e){const n=e?.samples,i=Number(e?.sampleRate);if(!n||!Number.isFinite(i))return null;if(!this._model)return this._ensureModel(),null;const r=ci(n),a=this._resampleToCrepe(n,i),{f0Hz:o,confidence:l}=this._predict(a);return!Number.isFinite(o)||l<this._confidenceGate?{f0Hz:null,midi:null,confidence:l,rms:r}:{f0Hz:o,midi:li(o),confidence:l,rms:r}}reset(){this._model=null,this._modelPromise=null}_ensureModel(){this._modelPromise||(this._modelPromise=(async()=>(await Eo(),this._model=await Ur(Ro),this._model))())}_predict(e){let n=0,i=null;return Xr(()=>{const r=Yr(e),a=Qr(r),o=Jr(r,a),l=Zr(o).dataSync()[0]/Math.sqrt(cs),m=(l>0?ea(o,ar(l)):o).reshape([1,cs]),u=this._model.predict(m).reshape([Zs]);n=u.max().dataSync()[0]||0;const h=u.argMax().dataSync()[0]||0,c=Math.max(0,h-4),f=Math.min(Zs,h+5),b=u.slice([c],[f-c]),p=pr.slice([c],[f-c]),S=ta(b,p).dataSync().reduce((v,_)=>v+_,0),N=b.dataSync().reduce((v,_)=>v+_,0),w=N>0?S/N:null;Number.isFinite(w)&&(i=10*Math.pow(2,w/1200))}),{f0Hz:i,confidence:n}}_resampleToCrepe(e,n){const i=new Float32Array(cs),r=n/Bo,a=e,o=a.length;for(let l=0;l<cs;l+=1){const d=l*r,m=Math.floor(d),u=Math.min(m+1,o-1),h=d-m,c=a[m]||0,f=a[u]||0;i[l]=c+(f-c)*h}return i}}class Io{constructor(){this._plugins=new Map}register(e){e?.id&&this._plugins.set(e.id,e)}list(){return Array.from(this._plugins.values())}get(e){return this._plugins.get(e)||null}}function Do(s={}){const e=s.includeCrepe!==!1,n=new Io;return n.register(new Co),n.register(new jo),n.register(new Fo),e&&n.register(new Lo),n}const Ho="/assets/pitchWorklet-BUY7BOk8.js";class Oo{constructor(e={}){this._audioContext=e.audioContext||null,this._getAudioContext=e.getAudioContext||null,this._listeners=new Set,this._debugListeners=new Set;const n=Do({includeCrepe:!1});this._detectors=n.list().map(i=>({id:i.id,name:i.name})),this._config={...Ne},this._algoId=Ne.pitchAlgoId,this._stream=null,this._source=null,this._workletNode=null,this._monitorGain=null,this._workletReady=null,this._debugAnalyser=null,this._debugHpf=null,this._debugGain=null,this._debugConnected=!1,this._debugWantsConnect=!1,this._starting=null,this._stopRequested=!1}listDetectors(){return this._detectors.slice()}getAudioContext(){return this._audioContext||(this._getAudioContext?this._getAudioContext():null)}configureDetector(e){this._config={...this._config,...e},this._postWorkletConfig()}setDetector(e){!e||this._algoId===e||(this._algoId=e,this._postWorkletConfig())}_connectDebugChain(){this._source&&(this._debugConnected||!this._debugAnalyser||!this._debugHpf||!this._debugGain||(this._source.connect(this._debugHpf),this._debugHpf.connect(this._debugAnalyser),this._debugAnalyser.connect(this._debugGain),this._debugConnected=!0,console.log("[PitchEngine] Debug chain connected")))}ensureDebugAnalyser(e={}){const n=this._ensureAudioContext();this._debugAnalyser||(this._debugAnalyser=n.createAnalyser()),this._debugHpf||(this._debugHpf=n.createBiquadFilter(),this._debugHpf.type="highpass"),this._debugGain||(this._debugGain=n.createGain(),this._debugGain.gain.value=0,this._debugGain.connect(n.destination)),this._debugWantsConnect=!0,this._connectDebugChain();const i=Number(e.fftSize);Number.isFinite(i)&&i>=32&&(this._debugAnalyser.fftSize=i);const r=Number(e.smoothingTimeConstant);Number.isFinite(r)&&(this._debugAnalyser.smoothingTimeConstant=Math.max(0,Math.min(1,r)));const a=Number.isFinite(e.hpfCutoffHz)?Number(e.hpfCutoffHz):Ne.hpfCutoffHz,o=e.enableHpf!==!1;return this._debugHpf.frequency.value=o?Math.max(0,a):0,this._debugAnalyser?console.log("[PitchEngine] ensureDebugAnalyser returning analyser",{frequencyBinCount:this._debugAnalyser.frequencyBinCount,fftSize:this._debugAnalyser.fftSize,numberOfInputs:this._debugAnalyser.numberOfInputs,numberOfOutputs:this._debugAnalyser.numberOfOutputs}):console.warn("[PitchEngine] ensureDebugAnalyser failed to create analyser"),this._debugAnalyser}onPitch(e){return typeof e!="function"?()=>{}:(this._listeners.add(e),()=>this._listeners.delete(e))}onDebug(e){return typeof e!="function"?()=>{}:(this._debugListeners.add(e),()=>this._debugListeners.delete(e))}async startMic(e={}){if(!this._stream){if(this._starting)return this._stopRequested=!1,this._starting;this._stopRequested=!1,this._starting=(async()=>{const n=this._ensureAudioContext();await Qn().resumeAudio(),await this._ensureWorklet(n),console.log("[PitchEngine] sampleRate",n.sampleRate);const i=this._config?.micConstraints||Ne.micConstraints||{},r=i.echoCancellation===!0,a=i.noiseSuppression===!0,o=i.autoGainControl===!0,l=String(e.deviceId||"").trim(),d={echoCancellation:r,noiseSuppression:a,autoGainControl:o};l&&(d.deviceId={exact:l});const m=await navigator.mediaDevices.getUserMedia({audio:d}),u=n.createMediaStreamSource(m),h=new AudioWorkletNode(n,"pitch-frame-processor",{numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[1]});h.port.onmessage=f=>{const b=f.data;if(b?.type){if(b.type==="pitch"){const p=b.result;if(!p||p.algoId&&p.algoId!==this._algoId)return;for(const x of this._listeners)x(p);return}if(b.type==="pipeline-debug")for(const p of this._debugListeners)p(b)}};const c=n.createGain();c.gain.value=0,u.connect(h),h.connect(c),c.connect(n.destination),this._stream=m,this._source=u,this._workletNode=h,this._monitorGain=c,this.configureDetector(this._config),this.setDetector(this._algoId),this._debugWantsConnect&&(console.log("[PitchEngine] startMic connecting debug chain"),this._connectDebugChain()),this._stopRequested&&this._stopMicInternal()})();try{await this._starting}finally{this._starting=null}}}stopMic(){this._stopRequested=!0,!(this._starting&&!this._stream)&&this._stopMicInternal()}_ensureAudioContext(){if(this._audioContext)return this._audioContext;let e=null;if(this._getAudioContext&&(e=this._getAudioContext()),!e){const n=Qn();n.setSampleRate(this._config.sampleRate),e=n.ensureAudioContext()}return this._audioContext=e,e}async _ensureWorklet(e){return this._workletReady?this._workletReady:(this._workletReady=e.audioWorklet.addModule(Ho),this._workletReady)}_postWorkletConfig(){this._workletNode&&this._workletNode.port.postMessage({type:"config",algoId:this._algoId,windowSize:this._config.windowSize,hopSize:this._config.hopSize,enableDoubleExponentialSmoothing:this._config.enableDoubleExponentialSmoothing,smoothAlpha:this._config.smoothAlpha,smoothBeta:this._config.smoothBeta,stepResetThresholdCents:this._config.stepResetThresholdCents,stepResetClusterCents:this._config.stepResetClusterCents,stepResetConfirmFrames:this._config.stepResetConfirmFrames,hpfCutoffHz:this._config.hpfCutoffHz,rmsGate:this._config.rmsGate,smoothing:this._config.smoothing,f0MinHz:this._config.f0MinHz,f0MaxHz:this._config.f0MaxHz,medianWindowSize:this._config.medianWindowSize,maxJumpSemitones:this._config.maxJumpSemitones,holdFrames:this._config.holdFrames,breakToleranceMs:this._config.breakToleranceMs,enablePitchSnap:this._config.enablePitchSnap,snapToleranceSemis:this._config.snapToleranceSemis,yinConfidenceGate:this._config.yinConfidenceGate,yinProbOutputUnvoiced:this._config.yinProbOutputUnvoiced,yinProbPreciseTime:this._config.yinProbPreciseTime,aubioTolerance:this._config.aubioTolerance,clarityGate:this._config.clarityGate,enableDcRemoval:this._config.enableDcRemoval,enableHpf:this._config.enableHpf,enableRmsGate:this._config.enableRmsGate,enableF0Validate:this._config.enableF0Validate,enableTemporalSmooth:this._config.enableTemporalSmooth,debugPipeline:this._config.debugPipeline,debugPipelineStride:this._config.debugPipelineStride})}_stopMicInternal(){if(this._stream){if(this._workletNode?.disconnect(),this._source?.disconnect(),this._monitorGain?.disconnect(),this._debugHpf&&this._debugConnected)try{this._source?.disconnect(this._debugHpf)}catch(e){console.warn("[PitchEngine] debug analyser disconnect failed",e)}this._debugAnalyser?.disconnect(),this._debugHpf?.disconnect(),this._debugGain?.disconnect(),this._debugAnalyser=null,this._debugHpf=null,this._debugGain=null,this._debugConnected=!1,this._debugWantsConnect=!1,this._workletNode=null,this._source=null,this._monitorGain=null,this._stream.getTracks().forEach(e=>e.stop()),this._stream=null,this._stopRequested=!1}}}const Xt=new Oo({getAudioContext:()=>Qn().getAudioContext()});let Ht=0,Jn=null;const ei=(s={})=>(Jn=Xt.ensureDebugAnalyser({fftSize:2048,smoothingTimeConstant:0,enableHpf:!0,hpfCutoffHz:Ne.hpfCutoffHz,...s})||null,Jn),Go=()=>Jn,xr=async()=>{if(Ht+=1,console.log("[mic] start request",{activeUsers:Ht}),Ht===1)try{console.log("[mic] starting stream"),await Xt.startMic({deviceId:mr().microphoneDeviceId}),ei(),console.log("[mic] stream active")}catch(s){throw Ht=Math.max(0,Ht-1),s}},zo=async s=>{if(Ht<=0)return!1;Xt.stopMic(),Jn=null;try{return await Xt.startMic({deviceId:s}),ei(),!0}catch(e){if(s)try{await Xt.startMic(),ei()}catch{}throw e}},ti=()=>{Ht<=0||(Ht-=1,console.log("[mic] stop request",{activeUsers:Ht}),Ht===0&&(console.log("[mic] stopping stream"),Xt.stopMic(),Jn=null,console.log("[mic] stream stopped")))};function qo({onBack:s}){const e=vn(p=>p.guideMelodyEnabled),n=vn(p=>p.microphoneDeviceId),i=vn(p=>p.setGuideMelodyEnabled),r=vn(p=>p.setMicrophoneDeviceId),[a,o]=g.useState("playback"),[l,d]=g.useState([]),[m,u]=g.useState(!1),[h,c]=g.useState(""),f=g.useCallback(async({requestPermission:p=!1}={})=>{if(!navigator.mediaDevices?.enumerateDevices){d([]),c("このブラウザではマイク入力を選択できません。");return}u(!0),c("");let x=null;try{let S=await navigator.mediaDevices.enumerateDevices();const N=S.some(v=>v.kind==="audioinput"&&v.deviceId&&v.label);p&&!N&&navigator.mediaDevices.getUserMedia&&(x=await navigator.mediaDevices.getUserMedia({audio:!0}),S=await navigator.mediaDevices.enumerateDevices());const w=S.filter(v=>v.kind==="audioinput"&&v.deviceId&&v.deviceId!=="default"&&v.deviceId!=="communications");d(w)}catch(S){d([]),c(S?.message||"マイク一覧を取得できませんでした。")}finally{x?.getTracks().forEach(S=>S.stop()),u(!1)}},[]);g.useEffect(()=>{f();const p=navigator.mediaDevices;return p?.addEventListener?.("devicechange",f),()=>p?.removeEventListener?.("devicechange",f)},[f]);const b=async p=>{const x=p.currentTarget.value;r(x),c("");try{const S=await zo(x);c(S?"マイク入力を切り替えました。":"次回の演奏から使用します。")}catch(S){r(""),c(S?.message||"マイク入力を切り替えられませんでした。")}};return t.jsxs("div",{className:"settingsPage",children:[t.jsxs("header",{className:"settingsPage__header",children:[t.jsxs("button",{className:"settingsPage__back wiiFind__backRed",type:"button",onClick:s,children:[t.jsx("span",{className:"wiiFind__backIcon","aria-hidden":"true",children:"←"}),"戻る"]}),t.jsxs("div",{className:"settingsPage__heading",children:[t.jsx("span",{className:"settingsPage__eyebrow",children:"SYSTEM SETTINGS"}),t.jsx("h1",{children:"設定"})]}),t.jsx("div",{className:"settingsPage__headerSpacer","aria-hidden":"true"})]}),t.jsxs("div",{className:"settingsPage__tabs",role:"tablist","aria-label":"設定カテゴリー",children:[t.jsxs("button",{type:"button",role:"tab","aria-selected":a==="playback",className:`settingsPage__tab ${a==="playback"?"settingsPage__tab--active":""}`,onClick:()=>o("playback"),children:[t.jsx("span",{className:"settingsPage__tabIcon","aria-hidden":"true",children:"♪"}),"演奏設定"]}),t.jsxs("button",{type:"button",role:"tab","aria-selected":a==="microphone",className:`settingsPage__tab ${a==="microphone"?"settingsPage__tab--active":""}`,onClick:()=>{o("microphone"),f({requestPermission:!0})},children:[t.jsx("span",{className:"settingsPage__tabIcon","aria-hidden":"true",children:"●"}),"マイク設定"]})]}),t.jsx("main",{className:"settingsPage__content",children:a==="playback"?t.jsx("section",{className:"settingsList",role:"tabpanel",children:t.jsxs("div",{className:"settingsList__item",children:[t.jsx("div",{className:"settingsList__icon settingsList__icon--playback","aria-hidden":"true",children:"♪"}),t.jsxs("div",{className:"settingsList__body",children:[t.jsx("div",{className:"settingsList__label",children:"ガイドメロディ"}),t.jsx("div",{className:"settingsList__description",children:"予約する曲のメロディガイドを標準で再生します。"})]}),t.jsxs("div",{className:"settingsList__control",children:[t.jsx("span",{className:`settingsList__state ${e?"is-on":"is-off"}`,children:e?"ON":"OFF"}),t.jsx(A.Check,{type:"switch",id:"settings-guide-melody",checked:e,onChange:p=>i(p.currentTarget.checked),"aria-label":"予約曲のガイドメロディ初期値を切り替える"})]})]})}):t.jsxs("section",{className:"settingsList",role:"tabpanel",children:[t.jsxs("div",{className:"settingsList__item",children:[t.jsx("div",{className:"settingsList__icon settingsList__icon--microphone","aria-hidden":"true",children:t.jsx("span",{})}),t.jsxs("div",{className:"settingsList__body",children:[t.jsx("label",{className:"settingsList__label",htmlFor:"settings-microphone-device",children:"MIC入力デバイス"}),t.jsx("div",{className:"settingsList__description",children:"採点に使用するマイクを選択してください。"}),h?t.jsx("div",{className:"settingsList__message",role:"status",children:h}):null]}),t.jsxs("div",{className:"settingsSelectWrap",children:[t.jsxs(A.Select,{id:"settings-microphone-device",className:"settingsSelect",value:n,disabled:m,onChange:b,children:[t.jsx("option",{value:"",children:"システム既定のマイク"}),l.map((p,x)=>t.jsx("option",{value:p.deviceId,children:p.label||`マイク ${x+1}`},p.deviceId))]}),m?t.jsx(Cn,{className:"settingsSelectWrap__spinner",animation:"border",size:"sm"}):null]})]}),t.jsxs("div",{className:"settingsList__item settingsList__item--disabled",children:[t.jsx("div",{className:"settingsList__icon","aria-hidden":"true",children:"…"}),t.jsxs("div",{className:"settingsList__body",children:[t.jsx("div",{className:"settingsList__label",children:"その他のマイク設定"}),t.jsx("div",{className:"settingsList__description",children:"今後追加予定です。"})]})]})]})})]})}function Ko({onBack:s,onLogin:e,onOpenKaraoke:n}){const i=Re(k=>k.status),r=Re(k=>k.accessToken),a=yt(k=>k.items),o=yt(k=>k.status),l=yt(k=>k.error),d=yt(k=>k.load),m=yt(k=>k.remove),u=Ot(k=>k.showAlert),[h,c]=g.useState(""),[f,b]=g.useState(""),[p,x]=g.useState(!1),[S,N]=g.useState("loading"),[w,v]=g.useState(""),_=async k=>{b(k.song_code),x(!0),N("loading"),v("サーバーに接続中...");try{const E=await oa(k.song_code);await ks(E),N("success"),v("接続完了。曲を読み込みました。"),u({message:`${k.title} を予約しました`,variant:"success",timeoutMs:2500}),setTimeout(()=>{x(!1),n&&n()},600)}catch(E){N("error"),v(E?.message||"曲を予約できませんでした"),u({message:E?.message||"曲を予約できませんでした",variant:"danger",timeoutMs:3500})}finally{b("")}},R=async k=>{c(k.song_code);try{await m(k.song_code,r),u({message:`${k.title} をマイうたから削除しました`,variant:"success",timeoutMs:2500})}catch(E){u({message:E?.message||"マイうたから削除できませんでした",variant:"danger",timeoutMs:3500})}finally{c("")}};return t.jsxs("div",{className:"wiiFind h-100 d-flex flex-column",children:[t.jsxs("div",{className:"wiiFind__headerRed",children:[t.jsxs("a",{href:"#",className:"wiiFind__backRed",onClick:k=>{k.preventDefault(),s()},children:[t.jsx("span",{className:"wiiFind__backIcon",children:"←"})," 戻る"]}),t.jsx("div",{className:"wiiFind__hint flex-grow-1 text-center",children:"マイうた"}),t.jsx("div",{className:"wiiFind__countRed",children:i==="authenticated"?`${a.length}件`:"—"})]}),i!=="authenticated"?t.jsx("div",{className:"wiiScreen flex-grow-1",children:t.jsxs("div",{className:"wiiScreen__card",children:[t.jsx("div",{className:"wiiScreen__title",children:"ログインが必要です"}),t.jsx("div",{className:"wiiScreen__subtitle",children:"マイうたを利用するにはログインしてください。"}),t.jsxs("div",{className:"wiiScreen__actions",children:[t.jsx(D,{type:"button",onClick:e,children:"ログイン"}),t.jsx(D,{variant:"secondary",type:"button",onClick:s,children:"戻る"})]})]})}):t.jsxs("div",{className:"flex-grow-1 d-flex flex-column overflow-hidden p-3",children:[o==="loading"?t.jsxs("div",{className:"d-flex align-items-center justify-content-center gap-2 py-4 text-muted",children:[t.jsx(Cn,{animation:"border",size:"sm"}),"読み込み中…"]}):null,o==="error"?t.jsxs(ai,{variant:"danger",className:"d-flex align-items-center justify-content-between gap-3",children:[t.jsx("span",{children:l||"マイうたを読み込めませんでした。"}),t.jsx(D,{variant:"outline-danger",size:"sm",type:"button",onClick:()=>d(r).catch(()=>{}),children:"再試行"})]}):null,o!=="loading"&&a.length===0?t.jsx("div",{className:"wiiList__empty text-muted text-center py-5",children:"マイうたに登録された曲はありません。"}):t.jsx("div",{className:"wiiList",children:a.map(k=>t.jsxs("div",{className:"wiiList__item",children:[t.jsx("div",{className:"wiiList__iconBadge wiiList__iconBadge--original",children:k.song_code}),t.jsx("div",{className:"wiiList__title",children:k.title}),t.jsx(nn,{artist:k.artist,className:"wiiList__artist"}),t.jsxs("div",{className:"d-flex gap-2 ms-auto",children:[t.jsx(D,{className:"wiiList__actionBtn wiiList__actionBtn--remove",type:"button",disabled:h===k.song_code,onClick:()=>R(k),children:h===k.song_code?"削除中…":"削除"}),t.jsx(D,{className:"wiiList__actionBtn wiiList__actionBtn--reserve",type:"button",disabled:f===k.song_code,onClick:()=>_(k),children:f===k.song_code?"予約中…":"予約"})]})]},k.song_code))})]}),t.jsx(Ms,{isOpen:p,status:S,message:w,onClose:()=>x(!1)})]})}function Vo({artist:s,onBack:e,onSelectSong:n,onConfirm:i}){const r=Re(F=>F.status),a=Re(F=>F.accessToken),o=yt(F=>F.items),l=yt(F=>F.add),d=Ot(F=>F.showAlert),[m,u]=g.useState([]),[h,c]=g.useState(!0),[f,b]=g.useState(""),[p,x]=g.useState(""),[S,N]=g.useState(!1),[w,v]=g.useState("loading"),[_,R]=g.useState("");g.useEffect(()=>{const F=new AbortController;let z=!1;return c(!0),b(""),(async()=>{const L=await Xn({artist:s,page:1,pageSize:200,signal:F.signal}),Y=Math.max(1,Math.ceil((Number(L?.count)||0)/200)),pe=Y>1?await Promise.all(Array.from({length:Y-1},(ie,me)=>Xn({artist:s,page:me+2,pageSize:200,signal:F.signal}))):[];return[...Array.isArray(L?.items)?L.items:[],...pe.flatMap(ie=>Array.isArray(ie?.items)?ie.items:[])]})().then(L=>{z||u(L)}).catch(L=>{z||b(L?.message||"曲を読み込めませんでした。")}).finally(()=>{z||c(!1)}),()=>{z=!0,F.abort()}},[s]);const k=g.useMemo(()=>new Set(o.map(F=>F.song_code)),[o]),E=async(F,z)=>{if(z.stopPropagation(),!(!F||r!=="authenticated"||k.has(F.id)))try{await l(F,a)&&d({message:`${F.title} をマイうたに追加しました`,variant:"success",timeoutMs:2500})}catch(j){d({message:j?.message||"マイうたに追加できませんでした",variant:"danger",timeoutMs:3500})}},se=async(F,z)=>{z.stopPropagation(),x(F.id),N(!0),v("loading"),R("サーバーに接続中...");try{await ks(F),v("success"),R("接続完了。曲を読み込みました。"),d({message:`${F.title} を予約しました`,variant:"success",timeoutMs:2500}),setTimeout(()=>{N(!1),i?.()},600)}catch(j){v("error"),R(j?.message||"曲を予約できませんでした")}finally{x("")}};return t.jsxs("div",{className:"wiiFind h-100 d-flex flex-column",children:[t.jsxs("div",{className:"artistPage__header",children:[t.jsxs("a",{href:"#",className:"wiiFind__backRed",onClick:F=>{F.preventDefault(),e()},children:[t.jsx("span",{className:"wiiFind__backIcon",children:"←"})," 戻る"]}),t.jsxs("div",{className:"artistPage__identity",children:[t.jsx("span",{className:"artistPage__eyebrow",children:"歌手名"}),t.jsx("h1",{className:"artistPage__title",children:s||"—"})]}),t.jsx("div",{className:"wiiFind__countRed",children:h?"—":`${m.length}件`})]}),t.jsxs("div",{className:"artistPage__body",children:[h?t.jsxs("div",{className:"artistPage__status",children:[t.jsx(Cn,{animation:"border",size:"sm"}),"読み込み中…"]}):null,f?t.jsx("div",{className:"artistPage__status text-danger",children:f}):null,!h&&!f&&!m.length?t.jsx("div",{className:"wiiList__empty text-muted text-center py-5",children:"この歌手の曲はありません。"}):t.jsx("div",{className:"wiiList",children:m.map(F=>{const z=k.has(F.id);return t.jsxs("div",{className:"wiiList__item artistPage__song",role:"button",tabIndex:0,onClick:()=>n?.(F),onKeyDown:j=>{(j.key==="Enter"||j.key===" ")&&(j.preventDefault(),n?.(F))},children:[t.jsx("div",{className:"wiiList__iconBadgeContainer",children:t.jsx("div",{className:"wiiList__iconBadge wiiList__iconBadge--original",children:F.tags?.[0]||F.id})}),t.jsxs("div",{className:"artistPage__songMeta",children:[t.jsx("div",{className:"wiiList__title",children:F.title}),t.jsx("div",{className:"wiiList__artist",children:F.artist})]}),t.jsxs("div",{className:"d-flex gap-2 ms-auto",children:[t.jsxs(D,{className:`wiiList__actionBtn ${z?"wiiList__actionBtn--registered":""}`,type:"button",disabled:r!=="authenticated"||z,onClick:j=>E(F,j),children:[t.jsx("span",{className:"me-1","aria-hidden":"true",children:"★"}),z?"登録済み":"マイうた"]}),t.jsx(D,{className:"wiiList__actionBtn wiiList__actionBtn--reserve",type:"button",disabled:p===F.id,onClick:j=>se(F,j),children:p===F.id?"予約中…":"予約"})]})]},F.id)})})]}),t.jsx(Ms,{isOpen:S,status:w,message:_,onClose:()=>N(!1)})]})}const Wo="/assets/logo-Biz8u1Mk.png";function Ai({title:s,subtitle:e,onBack:n}){return t.jsx("div",{className:"wiiScreen",children:t.jsxs("div",{className:"wiiScreen__card",children:[t.jsx("div",{className:"wiiScreen__title",children:s}),e?t.jsx("div",{className:"wiiScreen__subtitle",children:e}):null,t.jsx("div",{className:"wiiScreen__actions",children:t.jsx(D,{className:"wiiBtn wiiScreen__back",type:"button",onClick:n,children:"Back"})})]})})}function $o({screen:s,onNavigate:e,onOpenKaraoke:n,karaokeTargetRef:i,mainRef:r}){const a=xt(h=>h.selectedArtist),o=xt(h=>h.songSearchMode),l=xt(h=>h.openSongSearch),d=xt(h=>h.closeArtist),m=xt(h=>h.songDetailReturnScreen),u=xt(h=>h.setSongDetailReturnScreen);if(s!==V.home)switch(s){case V.findSongs:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(ua,{initialMode:o,onBack:()=>e(V.home),onSelectSong:h=>{u(V.findSongs),e(V.comfirmSongs),zs(h)}})});case V.myRoom:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(Ai,{title:"My Room",subtitle:"TODO: profile / history / favorites",onBack:()=>e(V.home)})});case V.moreModes:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(_o,{onBack:()=>e(V.home)})});case V.mySongs:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(Ko,{onBack:()=>e(V.home),onLogin:()=>e(V.auth),onOpenKaraoke:()=>n&&n()})});case V.settings:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(qo,{onBack:()=>e(V.home)})});case V.comfirmSongs:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(bo,{onBack:()=>e(m||V.findSongs),onConfirm:()=>{n&&n()}})});case V.karaoke:return t.jsx("main",{className:"wiiHome__main wiiHome__main--karaoke",ref:r});case V.queue:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(No,{onBack:()=>e(V.home),onOpenKaraoke:()=>n&&n()})});case V.findSongKeywords:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(wo,{onBack:()=>e(V.home),onSelectSong:h=>{u(V.findSongKeywords),e(V.comfirmSongs),zs(h)},onConfirm:()=>{n&&n()}})});case V.artist:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(Vo,{artist:a,onBack:d,onSelectSong:h=>{u(V.artist),e(V.comfirmSongs),zs(h)},onConfirm:()=>n?.()})});case V.leaderboard:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(vo,{onBack:()=>e(V.home)})});case V.auth:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(ko,{onBack:()=>e(V.home)})});default:return t.jsx("main",{className:"wiiHome__main",ref:r,children:t.jsx(Ai,{title:"Unknown",subtitle:"Unknown screen",onBack:()=>e(V.home)})})}return t.jsxs("main",{className:"wiiHome__main joyHome",ref:r,children:[t.jsx("div",{className:"joyHeader",children:t.jsx("div",{className:"joyBrand",children:t.jsxs("span",{className:"joyBrand__main",style:{display:"inline-flex",alignItems:"center"},children:[t.jsx("img",{src:Wo,alt:"RAKUSONG",style:{height:"1.8em",marginRight:"0.2em"}}),t.jsx("span",{className:"joyBrand__sub",children:"v1.231"})]})})}),t.jsxs(Pe,{className:"g-3 joyHero",children:[t.jsxs(X,{xs:12,lg:8,children:[t.jsxs(Pe,{className:"g-3",children:[t.jsx(X,{xs:12,md:6,children:t.jsxs(D,{className:"joyCard joyCard--artist w-100",type:"button",onClick:()=>l("artist"),children:[t.jsx("div",{className:"joyCard__icon",children:"🎤"}),t.jsx("div",{className:"joyCard__title",children:"歌手名"}),t.jsx("div",{className:"joyCard__sub",children:"ARTIST"})]})}),t.jsx(X,{xs:12,md:6,children:t.jsxs(D,{className:"joyCard joyCard--song w-100",type:"button",onClick:()=>l("title"),children:[t.jsx("div",{className:"joyCard__icon",children:"🎵"}),t.jsx("div",{className:"joyCard__title",children:"曲 名"}),t.jsx("div",{className:"joyCard__sub",children:"SONG"})]})})]}),t.jsxs(Pe,{className:"g-3 joyTiles mt-1",children:[t.jsx(X,{xs:6,md:6,lg:3,children:t.jsxs(D,{className:"joyTile w-100",type:"button",children:["ジャンル",t.jsx("span",{className:"joyTile__sub",children:"GENRE"})]})}),t.jsx(X,{xs:6,md:6,lg:3,children:t.jsxs(D,{className:"joyTile w-100",type:"button",onClick:()=>e(V.leaderboard),children:["ランキング",t.jsx("span",{className:"joyTile__sub",children:"RANKING"})]})}),t.jsx(X,{xs:6,md:6,lg:3,children:t.jsxs(D,{className:"joyTile w-100",type:"button",onClick:()=>e(V.findSongKeywords),children:["キーワード",t.jsx("span",{className:"joyTile__sub",children:"KEYWORD"})]})}),t.jsx(X,{xs:6,md:6,lg:3,children:t.jsxs(D,{className:"joyTile w-100",type:"button",children:["選曲番号",t.jsx("span",{className:"joyTile__sub",children:"SONG NUMBER"})]})})]})]}),t.jsx(X,{xs:12,lg:4,children:t.jsxs("div",{className:"joyInfo",children:[t.jsx("div",{className:"joyInfo__label",children:"演奏画面"}),t.jsx("div",{className:"joyInfo__media",ref:i,children:t.jsx("div",{className:"joyInfo__overlay",children:"ARENA SOUND"})})]})})]}),t.jsxs(Pe,{className:"g-3 joyBottom",children:[t.jsx(X,{xs:12,md:6,children:t.jsxs("button",{className:"willInfoBtn",type:"button",children:[t.jsx("span",{className:"willInfoBtn__top",children:"FOREIGN"}),t.jsx("span",{className:"willInfoBtn__bottom",children:"中文 / 한글 / English / Others"})]})}),t.jsx(X,{xs:12,md:3,children:t.jsxs(D,{className:"willInfoBtn",type:"button",children:[t.jsx("span",{className:"willInfoBtn__top",children:"NURU ENGINE"}),t.jsx("span",{className:"willInfoBtn__bottom",children:"最新音源情報"})]})}),t.jsx(X,{xs:12,md:3,children:t.jsxs(D,{className:"willInfoBtn",type:"button",children:[t.jsx("span",{className:"willInfoBtn__top",children:"APPID"}),t.jsx("span",{className:"willInfoBtn__bottom",children:"システム更新履歴ー覧"})]})})]})]})}const Pi=5,Uo=.3,Xo=.6;function Yo(s,e=.4){if(!s||s.length===0)return[];const n=[...s].sort((a,o)=>a.t0Sec-o.t0Sec),i=[];let r={...n[0]};for(let a=1;a<n.length;a++){const o=n[a];o.t0Sec-r.t1Sec<=e?r.t1Sec=Math.max(r.t1Sec,o.t1Sec):(i.push(r),r={...o})}return i.push(r),i}function Qo(s,e=Pi){if(!Array.isArray(s)||s.length<2)return[];const n=Number.isFinite(Number(e))?Math.max(0,Number(e)):Pi,i=s.map(l=>({t0Sec:Number(l?.t0Sec),t1Sec:Number(l?.t1Sec)})).filter(l=>Number.isFinite(l.t0Sec)&&Number.isFinite(l.t1Sec)&&l.t1Sec>l.t0Sec).sort((l,d)=>l.t0Sec-d.t0Sec||l.t1Sec-d.t1Sec);if(i.length<2)return[];const r=[];let a={...i[0]};for(let l=1;l<i.length;l+=1){const d=i[l];d.t0Sec<=a.t1Sec?a.t1Sec=Math.max(a.t1Sec,d.t1Sec):(r.push(a),a={...d})}r.push(a);const o=[];for(let l=1;l<r.length;l+=1){const d=r[l-1].t1Sec,m=r[l].t0Sec,u=m-d;u>n&&o.push({startSec:d,endSec:m,durationSec:u})}return o}function Jo(s,e,{fadeSec:n=Uo,endLeadSec:i=Xo}={}){const r={isInterlude:!1,lyricsVisible:!0,promptVisible:!1};if(!Array.isArray(s)||!Number.isFinite(Number(e)))return r;const a=Number(e),o=s.find(({startSec:m,endSec:u})=>a>=m&&a<u);if(!o)return r;const l=Math.max(0,Number(n)||0),d=Math.max(l,Number(i)||0);return{isInterlude:!0,lyricsVisible:a>=o.endSec-l,promptVisible:a>=o.startSec+l&&a<o.endSec-d}}function ls(s,e=0){const n=Number(s);return Number.isFinite(n)?n:e}function Ei(...s){for(const e of s){const n=Number(e);if(Number.isFinite(n))return n}return NaN}function Zo(s,e,n){const i=Array.isArray(s?.tracks)?s.tracks:[];if(!i.length)return[];const r=n?.ticksPerBeat||480,a=[],o=new Map,l=(u,h,c,f)=>{const b=`${u}:${h}`,p=o.get(b)||[];p.push({tick:c,velocity:f}),o.set(b,p)},d=(u,h)=>{const c=`${u}:${h}`,f=o.get(c);return!f||!f.length?null:f.shift()},m=u=>{if(!Number.isFinite(u))return NaN;if(typeof s?.midiTicksToSeconds=="function"){const h=s.midiTicksToSeconds(u);if(Number.isFinite(h))return h}return ps(n,u)};return i.forEach((u,h)=>{(Array.isArray(u?.events)?u.events:[]).forEach(f=>{const b=Number(f?.ticks);if(!Number.isFinite(b))return;let p=f?.type||null,x=Number(f?.channel),S=Number(f?.note??f?.noteNumber??f?.midiNote),N=Number(f?.velocity??f?.vel??f?.v);const w=Number(f?.statusByte??f?.status),v=f?.data||f?.bytes||f?.message||null,_=v!=null&&typeof v!="string"&&Number.isFinite(Number(v.length)),R=_?Number(v[0]):NaN,k=_?Number(v[1]):NaN;if(!p&&Number.isFinite(w)){const pe=w&240;x=w&15,pe===144&&(p="note_on"),pe===128&&(p="note_off"),Number.isFinite(S)||(S=R),Number.isFinite(N)||(N=k)}if(Number.isFinite(x)||(x=0),!Number.isFinite(S)||Number.isFinite(e)&&x!==e)return;const E=p==="note_on"&&Number.isFinite(N)?N>0:p==="note_on",se=p==="note_off"||p==="note_on"&&Number.isFinite(N)&&N<=0;if(!E&&!se)return;if(E){l(x,S,b,Number.isFinite(N)?N:void 0);return}const F=d(x,S);if(!F)return;const z=F.tick,j=b,L=m(z),Y=m(j);a.push({t0Tick:z,t1Tick:j,t0Beat:z/r,t1Beat:j/r,t0Sec:L,t1Sec:Y,midi:S,velocity:F.velocity,channel:x,trackIndex:h,type:"normal"})})}),a.sort((u,h)=>u.t0Tick-h.t0Tick||u.t1Tick-h.t1Tick),a}function ec(s){const e=Number(s?.timeDivision),n=Number.isFinite(e)&&e>0?e:480,i=Array.isArray(s?.tempoChanges)?s.tempoChanges.slice():[];i.length||i.push({ticks:0,tempo:120}),i.sort((u,h)=>Number(u.ticks)-Number(h.ticks));const r=[];for(let u=0;u<i.length;u+=1){const h=i[u],c=Number(h.ticks)||0,f=r[r.length-1];f&&Number(f.ticks)===c?r[r.length-1]=h:r.push(h)}const a=[];let o=0,l=Number(r[0]?.ticks)||0,d=Number(r[0]?.tempo)||120,m=0;for(let u=0;u<r.length;u+=1){const h=r[u],c=Number(h.ticks)||0,f=Number(h.tempo)||120;if(u>0){const p=c-l;o+=p/n*(60/d)}let b=o;if(typeof s?.midiTicksToSeconds=="function"){const p=s.midiTicksToSeconds(c);if(Number.isFinite(p)){const x=Math.abs(p-o)<=.02,S=p+1e-6>=m;x&&S&&(b=p)}}m=b,a.push({startTick:c,startSec:b,bpm:f,beatsPerSec:f/60,ticksPerBeat:n}),l=c,d=f}return{segments:a,ticksPerBeat:n}}function gs(s,e){const n=Number(e);if(!Number.isFinite(n))return 0;const i=s.segments;if(!i.length)return 0;let r=i[0];for(let o=1;o<i.length&&n>=i[o].startSec;o+=1)r=i[o];const a=r.ticksPerBeat*r.beatsPerSec;return r.startTick+Math.max(0,n-r.startSec)*a}function Li(s,e){const n=Number(e);if(!Number.isFinite(n))return s.segments[0]||null;const i=s.segments;if(!i.length)return null;let r=i[0];for(let a=1;a<i.length&&n>=i[a].startSec;a+=1)r=i[a];return r}function tc(s,e){const n=Number(e);if(!Number.isFinite(n))return s.segments[0]||null;const i=s.segments;if(!i.length)return null;const r=n*s.ticksPerBeat;let a=i[0];for(let o=1;o<i.length&&r>=i[o].startTick;o+=1)a=i[o];return a}function nc(s,e){return gs(s,e)/s.ticksPerBeat}function ps(s,e){const n=Number(e);if(!Number.isFinite(n))return 0;const i=s.segments;if(!i.length)return 0;let r=i[0];for(let o=1;o<i.length&&n>=i[o].startTick;o+=1)r=i[o];const a=r.ticksPerBeat*r.beatsPerSec;return r.startSec+Math.max(0,n-r.startTick)/a}function sc(s,e){const n=Number(e);if(!Number.isFinite(n))return 0;const i=s.segments;if(!i.length)return 0;const r=n*s.ticksPerBeat;let a=i[0];for(let l=1;l<i.length&&r>=i[l].startTick;l+=1)a=i[l];const o=a.ticksPerBeat*a.beatsPerSec;return a.startSec+Math.max(0,r-a.startTick)/o}function Vn(s,e={}){const n=Number.isFinite(Number(e.channel))?Number(e.channel):0,i=typeof e.noteTypeResolver=="function"?e.noteTypeResolver:null;if(!s?.tracks?.length)return{notes:[],channelUsed:n,durationSec:0};const r=ec(s),a=[];typeof s.getNoteTimes=="function"&&(s.getNoteTimes()?.[n]||[]).forEach(h=>{const c=ls(h.start,0),f=ls(h.length,0),b=c+Math.max(0,f),p=ls(h.midiNote,NaN);if(!Number.isFinite(p))return;let x=Ei(h.ticks,h.tick,h.startTick,h.startTicks);const S=Ei(h.durationTicks,h.lengthTicks,h.ticksLength,h.tickLength);let N=Number.isFinite(x)&&Number.isFinite(S)?x+Math.max(0,S):NaN;Number.isFinite(x)||(x=gs(r,c)),Number.isFinite(N)||(N=gs(r,b));const w=Number.isFinite(x)?ps(r,x):c,v=Number.isFinite(N)?ps(r,N):b,_=x/r.ticksPerBeat,R=N/r.ticksPerBeat,k=i?i({note:h,midi:s,channel:n}):null,E=typeof k=="string"&&k.length?k:"normal";a.push({t0Sec:w,t1Sec:v,t0Beat:_,t1Beat:R,t0Tick:Number.isFinite(x)?x:void 0,t1Tick:Number.isFinite(N)?N:void 0,midi:p,velocity:Number.isFinite(Number(h.velocity))?Number(h.velocity):void 0,type:E,channel:n,trackIndex:-1})}),a.sort((m,u)=>{const h=Number.isFinite(m.t0Tick)?m.t0Tick:m.t0Sec,c=Number.isFinite(u.t0Tick)?u.t0Tick:u.t0Sec;if(h!==c)return h-c;const f=Number.isFinite(m.t1Tick)?m.t1Tick:m.t1Sec,b=Number.isFinite(u.t1Tick)?u.t1Tick:u.t1Sec;return f-b});const o=Zo(s,n,r);!a.length&&o.length&&a.push(...o);const l=ls(s.duration,0),d=a.length?Math.max(...a.map(m=>m.t1Sec)):l;return{notes:a,rawNotes:o.length?o:[],channelUsed:n,durationSec:Math.max(l,d),timeDivision:r.ticksPerBeat,tempoChanges:Array.isArray(s?.tempoChanges)?s.tempoChanges:[],getBeatAtTime:m=>nc(r,m),getBeatsPerSecond:m=>{const u=Number(m);return Number.isFinite(u)?Li(r,u)?.beatsPerSec??2:r.segments[0]?.beatsPerSec??2},beatsToSeconds:m=>sc(r,m),getTickAtTime:m=>gs(r,m),ticksToSeconds:m=>ps(r,m),getTempoSegmentAtTime:m=>Li(r,m),getTempoSegmentAtBeat:m=>tc(r,m)}}function ic(s,e,n={}){if(!s?.notes?.length)return null;const i=Number(e);if(!Number.isFinite(i))return null;const r=Number.isFinite(n.maxGap)?n.maxGap:0,a=Number.isFinite(n.edgeToleranceSec)?n.edgeToleranceSec:0,o=s.notes;let l=0,d=o.length-1;for(;l<=d;){const m=l+d>>1,u=o[m];if(i<u.t0Sec)d=m-1;else if(i>=u.t1Sec)l=m+1;else return u}if(r>0){const m=o[l-1],u=o[l];if(m&&u&&u.t0Sec-m.t1Sec<=r&&i>=m.t1Sec&&i<u.t0Sec)return m}if(a>0){const m=o[l-1],u=o[l];if(m&&i>=m.t0Sec-a&&i<=m.t1Sec+a)return m;if(u&&i>=u.t0Sec-a&&i<=u.t1Sec+a)return u}return null}function rc(s,e,n={}){const i=ic(s,e,n);return i?i.midi:null}function ws(s,e,n={}){if(!s?.notes?.length)return null;const i=Number(e);if(!Number.isFinite(i))return null;const r=Number.isFinite(n.maxGapTick)?n.maxGapTick:0,a=Number.isFinite(n.edgeToleranceTick)?n.edgeToleranceTick:0,o=Number(s?.timeDivision)||480,l=s.notes;let d=0,m=l.length-1;const u=(h,c)=>{const f=Number(h?.[c]);if(Number.isFinite(f))return f;const b=Number(c==="t0Tick"?h?.t0Beat:h?.t1Beat);return Number.isFinite(b)?b*o:null};for(;d<=m;){const h=d+m>>1,c=l[h],f=u(c,"t0Tick"),b=u(c,"t1Tick");if(!Number.isFinite(f)||!Number.isFinite(b))return null;if(i<f)m=h-1;else if(i>=b)d=h+1;else return c}if(r>0){const h=l[d-1],c=l[d];if(h&&c){const f=u(h,"t1Tick"),b=u(c,"t0Tick");if(Number.isFinite(f)&&Number.isFinite(b)&&b-f<=r&&i>=f&&i<b)return h}}if(a>0){const h=l[d-1],c=l[d];if(h){const f=u(h,"t0Tick"),b=u(h,"t1Tick");if(Number.isFinite(f)&&Number.isFinite(b)&&i>=f-a&&i<=b+a)return h}if(c){const f=u(c,"t0Tick"),b=u(c,"t1Tick");if(Number.isFinite(f)&&Number.isFinite(b)&&i>=f-a&&i<=b+a)return c}}return null}function ac(s=[],e={}){if(!Array.isArray(s)||s.length===0)return[];const n=Number.isFinite(e.maxGapSec)?e.maxGapSec:0,i=Number.isFinite(e.maxGapBeat)?e.maxGapBeat:0,r=e.useBeat===!0,a=Number.isFinite(e.pitchToleranceSemis)?e.pitchToleranceSemis:0,o=[...s].sort((m,u)=>m.t0Sec-u.t0Sec||m.t1Sec-u.t1Sec),l=[];let d={...o[0]};for(let m=1;m<o.length;m+=1){const u=o[m],h=r?(Number.isFinite(u.t0Beat)?u.t0Beat:u.t0Sec)-(Number.isFinite(d.t1Beat)?d.t1Beat:d.t1Sec):u.t0Sec-d.t1Sec,c=Math.abs(Number(u.midi)-Number(d.midi));if(h<=(r?i:n)&&Number.isFinite(c)&&c<=a){if(d.t1Sec=Math.max(d.t1Sec,u.t1Sec),Number.isFinite(d.t1Beat)||Number.isFinite(u.t1Beat)){const p=Number.isFinite(d.t1Beat)?d.t1Beat:d.t1Sec,x=Number.isFinite(u.t1Beat)?u.t1Beat:u.t1Sec;d.t1Beat=Math.max(p,x)}if(Number.isFinite(d.t1Tick)||Number.isFinite(u.t1Tick)){const p=Number.isFinite(d.t1Tick)?d.t1Tick:-1/0,x=Number.isFinite(u.t1Tick)?u.t1Tick:-1/0,S=Math.max(p,x);Number.isFinite(S)&&(d.t1Tick=S)}}else l.push(d),d={...u}}return l.push(d),l}const Mn={emissionRate:200,maxParticles:650,lifetime:{min:.45,max:1},speed:{min:80,max:260},angle:{min:Math.PI,max:Math.PI},rotationSpeed:{min:-4,max:6},spawnRadius:30,scale:{start:2,end:1.25},alpha:{start:1,end:0},tint:{start:16765258,end:16775111}},vs=(s=Mn)=>({...s,lifetime:{...s.lifetime},speed:{...s.speed},angle:{...s.angle},rotationSpeed:{...s.rotationSpeed},scale:{...s.scale},alpha:{...s.alpha},tint:{...s.tint}}),Ii=s=>{if(!s)return vs(Mn);const e=vs(Mn);return{...e,...s,lifetime:{...e.lifetime,...s.lifetime||{}},speed:{...e.speed,...s.speed||{}},angle:{...e.angle,...s.angle||{}},rotationSpeed:{...e.rotationSpeed,...s.rotationSpeed||{}},scale:{...e.scale,...s.scale||{}},alpha:{...e.alpha,...s.alpha||{}},tint:{...e.tint,...s.tint||{}}}},hn=(s,e,n)=>s+(e-s)*n,oc=(s,e,n)=>{const i=s>>16&255,r=s>>8&255,a=s&255,o=e>>16&255,l=e>>8&255,d=e&255,m=Math.round(hn(i,o,n)),u=Math.round(hn(r,l,n)),h=Math.round(hn(a,d,n));return m<<16|u<<8|h},st=(s,e)=>s+Math.random()*(e-s),br=s=>{const e=new sr({dynamicProperties:{position:!0,rotation:!0,color:!0,vertex:!0},roundPixels:!1});e.texture=bs.WHITE;let n=Ii(s),i=s;const r=[],a=[];let o=0;const l=(f,b)=>{if(a.length>=n.maxParticles)return;const p=r.pop()||new ir({texture:bs.WHITE}),x=st(0,Math.PI*2),S=st(0,n.spawnRadius),N=f+Math.cos(x)*S,w=b+Math.sin(x)*S,v=st(n.angle.min,n.angle.max),_=st(n.speed.min,n.speed.max),R=st(n.rotationSpeed.min,n.rotationSpeed.max),k=st(n.lifetime.min,n.lifetime.max);p.x=N,p.y=w,p.anchorX=.5,p.anchorY=.5,p.scaleX=n.scale.start,p.scaleY=n.scale.start,p.rotation=st(0,Math.PI*2),p.tint=n.tint.start,p.alpha=n.alpha.start,e.addParticle(p),a.push({particle:p,vx:Math.cos(v)*_,vy:Math.sin(v)*_,life:0,maxLife:k,rotationSpeed:R})};return{container:e,setConfig:f=>{f!==i&&(i=f,n=Ii(f))},setBounds:f=>{e.boundsArea=f},update:(f,b,p,x)=>{if(b&&Number.isFinite(p)&&Number.isFinite(x)){o+=f*n.emissionRate;const S=n.maxParticles-a.length,N=Math.min(Math.floor(o),Math.max(0,S));if(N>0){o-=N;for(let w=0;w<N;w+=1)l(p,x)}}else o=0;for(let S=a.length-1;S>=0;S-=1){const N=a[S];N.life+=f;const w=N.life/N.maxLife;if(w>=1){e.removeParticle(N.particle),r.push(N.particle),a.splice(S,1);continue}N.particle.x+=N.vx*f,N.particle.y+=N.vy*f,N.particle.rotation+=N.rotationSpeed*f;const v=hn(n.scale.start,n.scale.end,w);N.particle.scaleX=v,N.particle.scaleY=v,N.particle.alpha=hn(n.alpha.start,n.alpha.end,w),N.particle.tint=oc(n.tint.start,n.tint.end,w)}},burst:(f,b,p=12)=>{if(!Number.isFinite(f)||!Number.isFinite(b))return;const x=Math.max(0,Math.round(Number(p)||0)),S=Math.max(0,n.maxParticles-a.length);for(let N=0;N<Math.min(x,S);N+=1)l(f,b)},destroy:()=>{e.particleChildren.length=0,a.length=0,r.length=0,e.destroy()}}},cc=()=>{const s=new sr({dynamicProperties:{position:!0,scale:!0,rotation:!0,color:!0,alpha:!0}});s.texture=bs.WHITE;const e=[],n=[],i=[],r=(d,m,u,h="trail")=>{const c=e.pop()||new ir({texture:bs.WHITE});c.x=d,c.y=m,c.anchorX=.5,c.anchorY=.5,c.rotation=Math.random()*Math.PI*2,c.tint=u;let f=.5,b=0,p=0,x=1;if(h==="trail")f=st(.3,.6),x=st(2.5,5),c.alpha=.6,c.scaleX=x,c.scaleY=x,b=st(-20,20),p=st(-20,20);else if(h==="burst"){f=st(.4,.8),x=st(4,8),c.alpha=1,c.scaleX=x,c.scaleY=x;const S=st(0,Math.PI*2),N=st(50,200);b=Math.cos(S)*N,p=Math.sin(S)*N}s.addParticle(c),n.push({p:c,vx:b,vy:p,life:f,maxLife:f,scale:x,type:h})};return{container:s,spawnCombo:(d,m,u,h,c)=>{i.push({x:d,y:m,targetX:u,targetY:h,color:c,progress:0,duration:.6})},update:d=>{for(let m=i.length-1;m>=0;m--){const u=i[m];if(u.progress+=d/u.duration,u.progress>=1){for(let b=0;b<20;b++)r(u.targetX,u.targetY,u.color,"burst");i.splice(m,1);continue}const h=u.progress*(2-u.progress),c=hn(u.x,u.targetX,h),f=hn(u.y,u.targetY,h);for(let b=0;b<2;b++)r(c+st(-5,5),f+st(-5,5),u.color,"trail")}for(let m=n.length-1;m>=0;m--){const u=n[m];if(u.life-=d,u.life<=0){s.removeParticle(u.p),e.push(u.p),n.splice(m,1);continue}u.p.x+=u.vx*d,u.p.y+=u.vy*d;const h=1-u.life/u.maxLife;u.p.alpha=1-h;const c=u.scale*(1-h*.5);u.p.scaleX=c,u.p.scaleY=c}},destroy:()=>{s.destroy()}}},Sr=60,yr=1e3,Di=Sr,Hi=yr,tn=[{t:0,c:[0,0,4]},{t:.13,c:[27,12,65]},{t:.25,c:[74,12,107]},{t:.38,c:[120,28,109]},{t:.5,c:[165,44,96]},{t:.63,c:[207,68,70]},{t:.75,c:[237,105,37]},{t:.88,c:[251,155,6]},{t:1,c:[252,255,164]}],lc=s=>{const e=Math.max(1,s),n=new Array(e);for(let i=0;i<e;i+=1){const r=i/Math.max(1,e-1);let a=tn[0],o=tn[tn.length-1];for(let c=0;c<tn.length-1;c+=1)if(r>=tn[c].t&&r<=tn[c+1].t){a=tn[c],o=tn[c+1];break}const l=o.t-a.t||1,d=(r-a.t)/l,m=Math.round(a.c[0]+(o.c[0]-a.c[0])*d),u=Math.round(a.c[1]+(o.c[1]-a.c[1])*d),h=Math.round(a.c[2]+(o.c[2]-a.c[2])*d);n[i]=`rgb(${m},${u},${h})`}return n},uc=lc(256),Dn=s=>2595*Math.log10(1+s/700),dc=s=>700*(10**(s/2595)-1),Oi=(s,e)=>{const n=Number.isFinite(s)?s:e;return Math.max(Sr,Math.min(yr,n))};function Nr({analyser:s,f0Hz:e,f0Color:n="#ffffff",rawF0Hz:i,rawF0Color:r="#00ffff",userMidi:a,userMidiColor:o="#00ffff",height:l=140,minHz:d=Di,maxHz:m=Hi,className:u,style:h}){const c=g.useRef(null),f=g.useRef(null),b=g.useRef(s),p=g.useRef(e),x=g.useRef(n),S=g.useRef(i),N=g.useRef(r),w=g.useRef(a),v=g.useRef(o),_=g.useRef(0),R=g.useRef({width:0,height:0,data:null,melMap:null}),k=g.useRef({minHz:d,maxHz:m,height:l});g.useEffect(()=>{k.current={minHz:d,maxHz:m,height:l}},[d,m,l]),g.useEffect(()=>{b.current=s},[s]),g.useEffect(()=>{p.current=e},[e]),g.useEffect(()=>{x.current=n},[n]),g.useEffect(()=>{S.current=i},[i]),g.useEffect(()=>{N.current=r},[r]),g.useEffect(()=>{w.current=a},[a]),g.useEffect(()=>{v.current=o},[o]);const E=F=>440*2**((F-69)/12);g.useEffect(()=>{const F=f.current,z=F?.getContext("2d",{willReadFrequently:!1,alpha:!1});if(!F||!z)return;let j=!0;const L=()=>{if(!j)return;_.current=requestAnimationFrame(L);const Y=c.current;if(!Y)return;const pe=Math.max(1,Math.floor(Y.clientWidth)),ie=Math.max(1,Math.floor(k.current.height));if(F.width!==pe||F.height!==ie){const we=document.createElement("canvas");we.width=F.width,we.height=F.height,we.getContext("2d").drawImage(F,0,0),F.width=pe,F.height=ie,z.fillStyle="#000",z.fillRect(0,0,pe,ie),z.drawImage(we,0,0,pe,ie)}const me=F.width,de=F.height,I=b.current;if(z.globalCompositeOperation="copy",z.drawImage(F,-1,0),z.globalCompositeOperation="source-over",!I)return;const q=I.frequencyBinCount||1,Q=R.current;(!Q.data||Q.data.length!==q)&&(Q.data=new Uint8Array(q)),I.getByteFrequencyData(Q.data);const{minHz:be,maxHz:He}=k.current,Me=Oi(be,Di),Ae=Oi(He,Hi),Ce=Math.min(Me,Ae),ot=Math.max(Me,Ae),P=I.context.sampleRate/2,Ke=de,Oe=Dn(Ce),et=Dn(ot),ye=Math.max(1e-6,et-Oe),Ge=`${de}-${q}-${P}-${Ce}-${ot}`;if(Q.melMap?.key!==Ge){const we=new Array(Ke);for(let De=0;De<Ke;De+=1){const Ue=Ke>1?De/(Ke-1):0,ke=Oe+Ue*ye,Ct=dc(ke),te=Math.max(0,Math.min(P,Ct)),ue=Math.round(te/P*(q-1));we[De]=Math.max(0,Math.min(q-1,ue))}Q.melMap={key:Ge,bins:we}}const H=Q.melMap.bins,ae=me-1;for(let we=0;we<de;we+=1){const Ue=H[we],ke=Q.data[Ue];z.fillStyle=uc[ke],z.fillRect(ae,de-1-we,1,1)}const xe=p.current;if(Number.isFinite(xe)&&xe>0&&xe>=Ce&&xe<=ot){const De=(Dn(xe)-Oe)/ye,Ue=de-1-De*(de-1);z.fillStyle=x.current,z.fillRect(ae,Ue-1,1,3)}const je=S.current;if(Number.isFinite(je)&&je>0&&je>=Ce&&je<=ot){const De=(Dn(je)-Oe)/ye,Ue=de-1-De*(de-1);z.fillStyle=N.current,z.fillRect(ae,Ue-1,1,3)}const Ve=w.current;if(Number.isFinite(Ve)){const we=E(Ve);if(we>0&&we>=Ce&&we<=ot){const Ue=(Dn(we)-Oe)/ye,ke=de-1-Ue*(de-1);z.fillStyle=v.current,z.fillRect(ae,ke-1,1,3)}}};return _.current=requestAnimationFrame(L),()=>{j=!1,cancelAnimationFrame(_.current)}},[]);const se={width:"100%",height:l,position:"relative",background:"#000",...h};return t.jsx("div",{ref:c,className:u,style:se,children:t.jsx("canvas",{ref:f,style:{display:"block",width:"100%",height:"100%"}})})}const Gi=(s,e)=>{if(typeof s!="string")return e;let n=s.trim();return n.startsWith("#")&&(n=n.slice(1)),(n.startsWith("0x")||n.startsWith("0X"))&&(n=n.slice(2)),n.length===3&&(n=n.split("").map(i=>i+i).join("")),n.length!==6?e:`#${n}`};function dn({data:s,height:e=80,color:n="#4ec3ff",background:i="#0f1115"}){const r=g.useRef(null),[a,o]=g.useState({width:0,height:0});g.useEffect(()=>{const u=r.current;if(!u)return;const h=new ResizeObserver(c=>{for(const f of c){const{width:b,height:p}=f.contentRect;o({width:b,height:p||e})}});return h.observe(u),()=>h.disconnect()},[e]);const l=g.useMemo(()=>{if(!s||!s.length||!a.width)return"";const{width:u,height:h}=a,c=h/2,f=h/2,b=s.length,p=Math.max(1,b-1),x=Math.max(1,Math.floor(b/u));let S="";for(let N=0;N<b;N+=x){const w=N/p*u,v=Math.max(-1,Math.min(1,s[N])),_=c-v*f;S+=`${w.toFixed(1)},${_.toFixed(1)} `}return S},[s,a]),d=Gi(i,"#0f1115"),m=Gi(n,"#4ec3ff");return t.jsx("div",{ref:r,style:{width:"100%",height:e,background:d,overflow:"hidden",position:"relative"},children:a.width>0&&t.jsx("svg",{width:"100%",height:"100%",viewBox:`0 0 ${a.width} ${a.height}`,style:{display:"block"},preserveAspectRatio:"none",children:t.jsx("polyline",{points:l,fill:"none",stroke:m,strokeWidth:"1.5",strokeLinejoin:"round",strokeLinecap:"round"})})})}const js=.25,hc=.08,mc=.16;function fc(s,e,n,i=.08){if(!Number.isFinite(e))return null;const r=Number(e);if(!Number.isFinite(s))return r;const a=Number(s),o=Math.max(0,Number(n)||0),l=Math.max(1e-4,Number(i)||.08),d=1-Math.exp(-o/l);return a+(r-a)*d}function gc(s,e,{durationSec:n=2,rmsGate:i=0,maxGapSec:r=.15}={}){const a=Number(e);if(!Number.isFinite(a)||!Array.isArray(s))return[];const o=Math.max(0,Number(n)||0),l=a-o,d=Math.max(0,Number(i)||0),m=Math.max(0,Number(r)||0),u=[];let h=null;for(const c of s){const f=Number(c?.t),b=Number.isFinite(c?.userMidi)?Number(c.userMidi):null,p=Number.isFinite(c?.rms)?Number(c.rms):null;if(!(Number.isFinite(f)&&f>=l&&f<=a+.05&&Number.isFinite(b)&&(!Number.isFinite(p)||p>=d))){h=null;continue}const S={timeSec:f,midi:b};if(h&&S.timeSec>h.timeSec&&S.timeSec-h.timeSec<=m){const N=Math.max(0,a-S.timeSec),w=o>0?Math.max(0,1-N/o):1;u.push({t0Sec:h.timeSec,t1Sec:S.timeSec,midi0:h.midi,midi1:S.midi,alpha:w*w})}h=S}return u}function pc(s,e){if(!Number.isFinite(e)||!Array.isArray(s))return null;const n=Number(e);let i=null,r=1/0;for(const a of s){const o=Number(a?.t0Sec),l=Number(a?.t1Sec),d=Number.isFinite(a?.midi)?Number(a.midi):null;if(!Number.isFinite(o)||!Number.isFinite(l)||!Number.isFinite(d))continue;const m=n<o?o-n:n>l?n-l:0;m<r&&(r=m,i=d)}return i}function xc(s=[],e=0){const n=Math.max(0,Number(e)||0),i=(s||[]).filter(a=>Number.isFinite(Number(a?.t0))&&Number.isFinite(Number(a?.t1))).map(a=>({...a,t0:Number(a.t0),t1:Number(a.t1),showAt:Number.isFinite(Number(a.showAt))?Number(a.showAt):0})).filter(a=>a.t1>a.t0).sort((a,o)=>a.t0-o.t0);if(!i.length)return[];const r=[{...i[0]}];for(let a=1;a<i.length;a+=1){const o=i[a],l=r[r.length-1];o.t0<=l.t1+n+1e-9?(l.t1=Math.max(l.t1,o.t1),l.showAt=Math.max(l.showAt,o.showAt)):r.push({...o})}return r}function bc(s,e,n=1){const i=Number(s?.t0Sec),r=Number(s?.t1Sec);if(!Number.isFinite(i)||!Number.isFinite(r)||r<=i)return null;const a=Number(s?.confirmedAtSec);if(!Number.isFinite(a))return r;const o=Number(e),l=Math.max(0,Number(n)||0);return!Number.isFinite(o)||o<=a?i:Math.min(r,i+(o-a)*l)}function Sc(s,e=[],n=0){const i=(e||[]).find(d=>d?.noteId===s?.noteId),r=Number(i?.note?.midi),a=Number(s?.midi),o=Number.isFinite(r)?r:a;if(!Number.isFinite(o))return null;const l=Number(n);return o+(Number.isFinite(l)?l:0)}function yc(s,e,n=mc){const i=Number(s);if(!Number.isFinite(i))return null;const r=i+js,a=Number(e),o=Math.max(0,Number(n)||0);return Number.isFinite(a)?Math.max(r,a+o):r}function Nc(s,e,n=js){const i=Number(e);if(!Number.isFinite(i))return 0;const r=i+Math.max(0,Number(n)||0),a=(s||[]).flatMap(d=>{const m=Number(d?.t0Sec),u=Number(d?.t1Sec);if(!Number.isFinite(m)||!Number.isFinite(u))return[];const h=Math.max(i,m),c=Math.min(r,u);return c>h?[{start:h,end:c}]:[]}).sort((d,m)=>d.start-m.start);let o=0,l=null;for(const d of a)!l||d.start>l.end?(l&&(o+=l.end-l.start),l={...d}):l.end=Math.max(l.end,d.end);return o+(l?l.end-l.start:0)}function wc(s,e,n={}){const i=Number(n.windowSec)||js,r=Number(n.minStableSec)||hc;return Nc(s,e,i)>=r-1e-9}const kt={glissup:{id:"glissup",label:"しゃくり",color:16716784,svg:'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 18 C5 18 10 18 12 14 C14 10 18 6 18 6" /><path d="M15 6 L19 6 L19 10" /></svg>',icon:t.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",style:{width:"100%",height:"100%"},children:[t.jsx("path",{d:"M5 18 C5 18 10 18 12 14 C14 10 18 6 18 6",stroke:"currentColor",strokeWidth:"3",fill:"none",strokeLinecap:"round"}),t.jsx("path",{d:"M15 6 L19 6 L19 10",stroke:"currentColor",strokeWidth:"3",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"})]})},kobushi:{id:"kobushi",label:"こぶし",color:65520,svg:'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="2"><circle cx="12" cy="12" r="3" fill="white" stroke="none" /><path d="M12 2 C 18 2 22 12 12 22 C 2 12 6 2 12 2" /></svg>',icon:t.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",style:{width:"100%",height:"100%"},children:[t.jsx("circle",{cx:"12",cy:"12",r:"3"}),t.jsx("path",{d:"M12 2 C 18 2 22 12 12 22 C 2 12 6 2 12 2",stroke:"currentColor",strokeWidth:"2",fill:"none"})]})},glissdown:{id:"glissdown",label:"フォール",color:16760576,svg:'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 6 C5 6 10 6 12 10 C14 14 18 18 18 18" /><path d="M15 18 L19 18 L19 14" /></svg>',icon:t.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",style:{width:"100%",height:"100%"},children:[t.jsx("path",{d:"M5 6 C5 6 10 6 12 10 C14 14 18 18 18 18",stroke:"currentColor",strokeWidth:"3",fill:"none",strokeLinecap:"round"}),t.jsx("path",{d:"M15 18 L19 18 L19 14",stroke:"currentColor",strokeWidth:"3",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"})]})},vibrato:{id:"vibrato",label:"ビブラート",color:2948869,svg:'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round"><path d="M2 12 Q 5 6 8 12 T 14 12 T 20 12" /></svg>',icon:t.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",style:{width:"100%",height:"100%"},children:t.jsx("path",{d:"M2 12 Q 5 6 8 12 T 14 12 T 20 12",stroke:"currentColor",strokeWidth:"3",fill:"none",strokeLinecap:"round"})})}},Pt={background:0,grid:16777215,melodyFill:0,melodyOutFill:4868682,userGlowFill:16765258,playhead:16777215},Vt={background:0,grid:.2,melodyFill:.5,melodyOutFill:.5,melodyStroke:1,userGlowFill:.95,playheadOuter:.15,playheadMid:.35,playheadInner:.9},Hn={grid:1,melody:2,playheadOuter:8,playheadMid:4,playheadInner:2},On=9,vc=20,_c=3,kc="MS PGothic",Mc=12,Cc=.2,zi=1.5,jc=.3,ni=50,Tc={coverageRatio:.7},qi=1,Fc=["ﾄﾞ","ﾄﾞ#","ﾚ","ﾚ#","ﾐ","ﾌｧ","ﾌｧ#","ｿ","ｿ#","ﾗ","ﾗ#","ｼ"],Rc=new Hr({fontFamily:kc,fontSize:Mc,fill:16777215,stroke:0,strokeThickness:4});function Bc(s){const e=Number(s);if(!Number.isFinite(e))return null;const n=Ec(Math.round(e));return Fc[n]||null}function Ac(s,e,n,i){if(!s?.length)return{minMidi:n,maxMidi:i};let r=1/0,a=-1/0;return s.forEach(o=>{const l=Number(o.midi);if(!Number.isFinite(l))return;const d=l+e;d<r&&(r=d),d>a&&(a=d)}),!Number.isFinite(r)||!Number.isFinite(a)?{minMidi:n,maxMidi:i}:{minMidi:r,maxMidi:a}}function Pc(s,e,n,i){if(!s?.length)return null;const r=[];for(const o of s){if(o.t1Sec<e||o.t0Sec>n)continue;const l=Number(o.midi);Number.isFinite(l)&&r.push(l+i)}if(!r.length)return null;r.sort((o,l)=>o-l);const a=Math.floor(r.length/2);return r.length%2?r[a]:(r[a-1]+r[a])/2}function Ec(s){const e=s%12;return e<0?e+12:e}function si(s){if(!s?.length)return null;const e=s.slice().sort((i,r)=>i-r),n=Math.floor(e.length/2);return e.length%2?e[n]:(e[n-1]+e[n])/2}function Lc(s){if(!s?.length)return null;if(s.length<2)return 0;const e=s.reduce((i,r)=>i+r,0)/s.length,n=s.reduce((i,r)=>i+(r-e)**2,0)/s.length;return Math.sqrt(n)}function Ic(s){const e=si(s);if(!Number.isFinite(e))return null;const n=s.map(r=>Math.abs(r-e)),i=si(n);return Number.isFinite(i)?i*1.4826:null}function Dc(s){const e=(s||[]).map(r=>Number(r)).filter(r=>Number.isFinite(r)&&r>0);if(e.length<2)return{n:e.length,stdCents:null,robustCents:null};const n=si(e);if(!Number.isFinite(n)||n<=0)return{n:e.length,stdCents:null,robustCents:null};const i=e.map(r=>1200*Math.log2(r/n));return{n:e.length,stdCents:Lc(i),robustCents:Ic(i)}}function Hc(s,e=ni){const n=Math.max(0,Number(s));if(!Number.isFinite(n))return-1;const i=Math.max(1e-6,Number(e)||ni);return Math.max(-1,Math.min(1,n/i*2-1))}function Oc(s,e,n={}){if(!s)return null;const i=Number(s?.timeDivision)||480,r=c=>s.getTickAtTime?s.getTickAtTime(c):c,a=s.getBeatsPerSecond?s.getBeatsPerSecond(e):2,o=(Number.isFinite(a)?a:2)*i,l=Number(n.breakToleranceSec)||0,d=Number(n.edgeToleranceSec)||0,m=l*o,u=d*o,h=c=>{const f=r(c);return ws(s,f,{maxGapTick:m,edgeToleranceTick:u})};if(n.gateUserByTarget){const c=Number(n.userOffsetSec)||0;return h(e-c)}return h(e)}function ii({reference:s,historyRef:e,pitchFrameHistoryRef:n=null,scoringVisualRef:i=null,lastPitchRef:r,currentTimeRef:a,transpositionRef:o,rmsGate:l=0,gateUserByTarget:d=!1,forceUserOnScoring:m=!1,userOffsetSec:u=0,width:h=900,height:c=220,windowSec:f=8,minMidi:b=36,maxMidi:p=96,smoothAlpha:x=.1,particleConfig:S=Mn,glissandoUpCount:N=0,kobushiCount:w=0,glissandoDownCount:v=0,vibratoCount:_=0,techniqueEventsRef:R,currentSection:k=1,totalSections:E=6,className:se,style:F,onTechniqueCountsChange:z,showSolfeges:j=!0,debug:L=!1,debugAnalyser:Y=null,debugF0Hz:pe=null,debugRawF0Hz:ie=null,debugUserMidi:me=null,debugF0Color:de="#ffffff",debugSpectrogramHeight:I=90}){const q=g.useRef(null),Q=g.useRef([]),be=g.useRef(null),He=g.useRef(null),Me=g.useRef(null),Ae=g.useRef(null),[Ce,ot]=g.useState({glissup:0,kobushi:0,glissdown:0,vibrato:0}),[P,Ke]=g.useState(null),[Oe,et]=g.useState(new Float32Array(0)),ye=g.useRef({app:null,bg:null,grid:null,notes:null,miss:null,user:null,userGlowContainer:null,userGlow:null,particleSystem:null,comboSystem:null,playhead:null,lastSize:{w:0,h:0},lastGrid:{w:0,h:0,lineCount:12},lastCenterPitch:null,lastCenterSnap:null,centerSnap:null,lastCounts:{shakuri:0,kobushi:0,fall:0,vibrato:0},techniqueSprites:[],techniqueTextureCache:new Map,solfegeLabels:null,solfegeLabelPool:[],confirmedNoteIds:new Set}),Ge=g.useRef({reference:s,historyRef:e,scoringVisualRef:i,lastPitchRef:r,currentTimeRef:a,transpositionRef:o,rmsGate:l,gateUserByTarget:d,forceUserOnScoring:m,userOffsetSec:u,windowSec:f,minMidi:b,maxMidi:p,smoothAlpha:x,particleConfig:S,glissandoUpCount:N,kobushiCount:w,glissandoDownCount:v,vibratoCount:_,showSolfeges:j,debug:L});g.useEffect(()=>{ye.current.confirmedNoteIds=new Set},[s]);const H=(ke,Ct)=>{ke.current&&ke.current.animate([{transform:"scale(1)",filter:"brightness(1)",backgroundColor:"transparent"},{transform:"scale(1.3)",filter:"brightness(2)",backgroundColor:Ct,offset:.1},{transform:"scale(1)",filter:"brightness(1)",backgroundColor:"transparent"}],{duration:800,easing:"ease-out"})};g.useEffect(()=>{Ge.current={reference:s,historyRef:e,scoringVisualRef:i,lastPitchRef:r,currentTimeRef:a,transpositionRef:o,rmsGate:l,gateUserByTarget:d,forceUserOnScoring:m,userOffsetSec:u,windowSec:f,minMidi:b,maxMidi:p,smoothAlpha:x,particleConfig:S,glissandoUpCount:N,kobushiCount:w,glissandoDownCount:v,vibratoCount:_,techniqueEventsRef:R,showSolfeges:j,debug:L}},[s,e,i,r,a,o,l,d,m,u,f,b,p,x,S,N,w,v,_,R,z,j,L]),g.useEffect(()=>{ye.current&&(ye.current.processedNotesRef&&ye.current.processedNotesRef.clear(),ye.current.lastTechniqueEventIndex=0,ye.current.lastCounts={shakuri:0,kobushi:0,fall:0,vibrato:0}),Q.current=[],et(new Float32Array(0)),ot({glissup:0,kobushi:0,glissdown:0,vibrato:0})},[s]),g.useEffect(()=>{z&&z(Ce)},[Ce,z]),g.useEffect(()=>{if(!L)return Ke(null),()=>{};const ke=Number(Ne.breakToleranceMs)/1e3,Ct=Math.min(.08,Math.max(0,ke/2)),te=.6,ue=window.setInterval(()=>{const ze=a?.current??0,Yt=o?.current??0,wt=e?.current||[],mn=n?.current||wt,Xe=r?.current,ct=wt.length?wt[wt.length-1]:null,Ye=Number.isFinite(Xe?.midi)?Number(Xe.midi):Number.isFinite(ct?.userMidi)?Number(ct.userMidi):null,Qt=Number.isFinite(Xe?.rms)?Number(Xe.rms):Number.isFinite(ct?.rms)?Number(ct.rms):null,Et=Number.isFinite(Xe?.f0Hz)?Number(Xe.f0Hz):null,rn=Number.isFinite(ie)?Number(ie):null,bt=Oc(s,ze,{breakToleranceSec:ke,edgeToleranceSec:Ct,gateUserByTarget:d,userOffsetSec:u}),Gt=Number.isFinite(bt?.midi)?Number(bt.midi)+Yt:null,vt=Cs(Ye,Gt).centsError,zt=Number.isFinite(vt)?vt/100:null,an=ze-te,Lt=wt.filter(fe=>fe.t>=an&&fe.t<=ze).filter(fe=>Number.isFinite(fe.userMidi)).filter(fe=>!Number.isFinite(fe.rms)||fe.rms>=l).map(fe=>Number(fe.userMidi));let M=null;if(Lt.length>=2){const fe=Lt.reduce((Je,W)=>Je+W,0)/Lt.length,We=Lt.reduce((Je,W)=>Je+(W-fe)**2,0)/Lt.length;M=Math.sqrt(We)}const Se=ze-jc,Qe=Number.isFinite(bt?.t0Sec)?Number(bt.t0Sec):null,Te=Number.isFinite(bt?.t1Sec)?Number(bt.t1Sec):null,it=Number.isFinite(Qe)?Math.max(Se,Qe):Se,J=Number.isFinite(Te)?Math.min(ze,Te):ze,re=mn.filter(fe=>Number.isFinite(fe?.t)&&fe.t>=it&&fe.t<=J).filter(fe=>!Number.isFinite(fe?.rms)||!Number.isFinite(l)||fe.rms>=l).map(fe=>Number.isFinite(fe?.rawF0Hz)?Number(fe.rawF0Hz):Number(fe?.f0Hz)),ut=Dc(re);{const fe=Q.current;let We=fe.length?fe[fe.length-1]:-1;for(Number.isFinite(ut?.robustCents)&&(We=Hc(ut.robustCents,ni)),fe.push(We);fe.length>160;)fe.shift();et(new Float32Array(fe))}Ke({userMidi:Ye,targetMidi:Gt,distance:zt,rms:Qt,f0Hz:Et,rawF0Hz:rn,stabilityStd:M,jitterStdCents:ut.stdCents,jitterRobustCents:ut.robustCents,jitterN:ut.n})},200);return()=>window.clearInterval(ue)},[L,s,d,u,l,ie,a,o,r,n,e,i]),g.useEffect(()=>{let ke=!0;return(async()=>{const te=q.current;if(!te)return;const ue=new rr;if(await ue.init({width:h,height:c,backgroundAlpha:0,antialias:!0,autoDensity:!0,resolution:window.devicePixelRatio||1,powerPreference:"high-performance",preference:"webgl"}),!ke){ue.destroy(!0);return}te.appendChild(ue.canvas),ue.canvas.style.width="100%",ue.canvas.style.height="100%",ue.canvas.style.display="block";const ze=new _t,Yt=new _t,wt=new _t,mn=new _t,Xe=new _t,ct=new As,Ye=new _t,Qt=new _t,Et=new As,rn=new As,bt=[],Gt=br(S),vt=cc(),zt=new _t,an=new _t,Lt={};Object.values(kt).forEach(M=>{if(M.svg){const Se=new _t().svg(M.svg),Qe=ue.renderer.generateTexture(Se);Lt[M.id]=Qe}}),ct.addChild(Gt.container,vt.container,Ye,Qt),ct.filters=[new Or({strength:4,quality:2,threshold:.2})],ue.stage.addChild(ze,Yt,wt,mn,rn,Xe,ct,zt,Et,an),ye.current={app:ue,bg:ze,grid:Yt,notes:wt,miss:mn,user:Xe,userGlowContainer:ct,userGlow:Ye,trail:Qt,techniqueIcons:Et,techniqueSpritePool:bt,solfegeLabels:rn,solfegeLabelPool:[],confirmedNoteIds:new Set,particleSystem:Gt,comboSystem:vt,playhead:zt,debugTrace:an,lastSize:{w:0,h:0},lastGrid:{w:0,h:0,lineCount:12},lastCenterPitch:null,lastCenterSnap:null,centerSnap:null,lastCounts:{shakuri:N,kobushi:w,fall:v,vibrato:_},techniqueEventsRef:R,lastTechniqueEventIndex:0,techniqueSprites:[],processedNotesRef:new Set},ue.ticker.add(()=>{const M=ye.current,{app:Se}=M;if(!Se)return;const Qe=Se.screen.width,Te=Se.screen.height;if(!Qe||!Te)return;const it=Se.ticker.deltaMS/1e3,J=Ge.current;if(M.comboSystem){M.comboSystem.update(it);const B=M.techniqueEventsRef?.current||[],$=M.lastTechniqueEventIndex||0;for(let K=$;K<B.length;K++){const G=B[K],U=G.t;if(J.reference){const oe=J.reference?.getTickAtTime?J.reference.getTickAtTime(U):U;let ce=ws(J.reference,oe,{maxGapTick:0,edgeToleranceTick:0});if(!ce&&(G.type==="glissup"||G.type==="glissdown")&&(ce=(J.reference.notes||[]).find(Le=>Number(Le.t0Sec)>=U&&Number(Le.t0Sec)<=U+js)||null),ce){const Le=ce.t0Sec;if(M.processedNotesRef&&M.processedNotesRef.has(Le))continue;G.isValid=!1,G.isPending=!0,G._noteId=Le,G._scoringNoteId=`${ce.t0Sec}:${ce.t1Sec}:${ce.midi}`,G._noteEndSec=Number(ce.t1Sec),G._type=G.type}}}M.lastTechniqueEventIndex=B.length}const re=J.currentTimeRef?.current??0,ut=Number(Ne.breakToleranceMs)/1e3,fe=Math.min(.08,Math.max(0,ut/2)),We=J.transpositionRef?.current??0,Je=J.reference?.notes||[],W=J.reference?.getBeatsPerSecond?J.reference.getBeatsPerSecond(re):2,jn=ut*(Number.isFinite(W)?W:2),Tn=Je.length?ac(Je,{maxGapBeat:jn,pitchToleranceSemis:0,useBeat:!0}):[],fn=Ac(Je,We,J.minMidi,J.maxMidi),dt=12,Fn=Math.max(1,dt-1),gn=Math.min(20,Math.max(6,Te*.06)),pn=gn,Rn=Te-gn,y=Math.max(1,Rn-pn),C=B=>pn+(1-B/Fn)*y,T=re,Z=re+J.windowSec,ne=Pc(Je,T,Z,We);let he=Number.isFinite(ne)?ne:M.lastCenterPitch;if(!Number.isFinite(he)){const B=(fn.minMidi+fn.maxMidi)/2;he=Number.isFinite(B)?B:(J.minMidi+J.maxMidi)/2}let O=M.lastCenterSnap;if(Number.isFinite(O)||(O=Math.round(he/12)*12),Number.isFinite(ne)){for(;ne>O+8;)O+=12;for(;ne<O-8;)O-=12}M.lastCenterPitch=he,M.lastCenterSnap=O;const _e=Math.max(0,Math.min(1,Number(J.smoothAlpha)||0));!Number.isFinite(M.centerSnap)||_e<=0?M.centerSnap=O:(M.centerSnap+=(O-M.centerSnap)*_e,Math.abs(M.centerSnap-O)<.001&&(M.centerSnap=O));const Fe=M.centerSnap,rt=18,ht=Fe+rt,Jt=Fe-rt,Ts=Math.max(1,ht-Jt),es=M.lastSize.w!==Qe||M.lastSize.h!==Te;if(es&&(M.lastSize={w:Qe,h:Te},M.bg.clear(),M.bg.setFillStyle({color:Pt.background,alpha:Vt.background}),M.bg.beginPath(),M.bg.rect(0,0,Qe,Te),M.bg.fill(),M.userGlowContainer&&(M.userGlowContainer.filterArea=Se.screen),M.particleSystem?.setBounds(Se.screen)),es||M.lastGrid.lineCount!==dt){M.lastGrid={w:Qe,h:Te,lineCount:dt},M.grid.clear(),M.grid.setStrokeStyle({width:Hn.grid,color:Pt.grid,alpha:Vt.grid}),M.grid.beginPath();for(let B=0;B<dt;B+=1){const $=C(B),K=Math.max(.5,Math.min(Te-.5,Math.round($)+.5));M.grid.moveTo(0,K),M.grid.lineTo(Qe,K)}M.grid.stroke()}const Ee=Qe*.7,tt=Qe/J.windowSec,mt=re-Ee/tt,ft=re+(Qe-Ee)/tt,jt=B=>{const $=Number(B);if(!Number.isFinite($))return{y:Rn,inRange:!1};const K=(ht-$)/Ts,G=pn+K*y;return{y:Math.max(pn,Math.min(Rn,G)),inRange:$<=ht&&$>=Jt}},xn=10,Ze=5,nt=(B,$,K)=>{M.notes.setFillStyle({color:B,alpha:$}),M.notes.beginPath(),Je.forEach(G=>{if(G.t1Sec<mt||G.t0Sec>ft)return;const U=G.midi+We,oe=Ee+(G.t0Sec-re)*tt,ce=Ee+(G.t1Sec-re)*tt,{y:Le,inRange:Bt}=jt(U);if(K!==Bt)return;const le=Math.max(6,ce-oe);M.notes.roundRect(oe,Le-xn/2,le,xn,Ze)}),M.notes.fill(),M.notes.stroke()};if(M.notes.clear(),M.notes.setStrokeStyle({width:Hn.melody,color:Pt.grid,alpha:Vt.melodyStroke}),nt(Pt.melodyFill,Vt.melodyFill,!0),nt(Pt.melodyOutFill,Vt.melodyOutFill,!1),M.solfegeLabels){const B=M.solfegeLabelPool||[];let $=0;if(J.showSolfeges){let K=null,G=null;for(const U of Je){const oe=Number(U.midi);if(!Number.isFinite(oe)){K=null,G=null;continue}G&&U.t0Sec-G.t1Sec>ut&&(K=null);const ce=K==null||oe!==K;if(K=oe,G=U,!ce||U.t1Sec<mt||U.t0Sec>ft)continue;const Le=Bc(oe+We);if(!Le)continue;const Bt=Ee+(U.t0Sec-re)*tt,{y:le}=jt(oe+We);let ve=B[$];ve||(ve=new Gr({text:Le,style:Rc}),ve.anchor.set(0,1),M.solfegeLabels.addChild(ve),B.push(ve)),ve.text=Le,ve.x=Bt,ve.y=le-xn/2-_c,ve.visible=!0,$+=1}}for(let K=$;K<B.length;K+=1)B[K].visible=!1;M.solfegeLabelPool=B}const Tt=J.historyRef?.current||[],Ft=J.scoringVisualRef?.current||{},It=Array.isArray(Ft.recentNotes)?Ft.recentNotes:[],bn=Ft.liveNote?[...It.filter(B=>B.noteId!==Ft.liveNote.noteId),Ft.liveNote]:It,Zt=Array.isArray(Ft.confirmedSegments)?Ft.confirmedSegments:[],Sn=M.confirmedNoteIds||new Set;M.confirmedNoteIds=Sn;for(const B of It){if(Sn.has(B.noteId))continue;const K=Zt.filter(ce=>ce.noteId===B.noteId)[0];if(!K||(Sn.add(B.noteId),K.t0Sec<mt||K.t0Sec>ft))continue;const G=Ee+(K.t0Sec-re)*tt,U=Number(B.note?.midi)+We,{y:oe}=jt(U);M.particleSystem?.burst(G,oe,12)}const Rt=J.reference?{...J.reference,notes:Tn}:null,Fs=(B,$={})=>{if(!Rt)return null;const K=Number(Rt?.timeDivision)||480,G=Rt.getTickAtTime?Rt.getTickAtTime(B):B,U=Rt.getBeatsPerSecond?Rt.getBeatsPerSecond(B):2,oe=(Number.isFinite(U)?U:2)*K,ce=ut*oe,Le=fe*oe;return ws(Rt,G,{maxGapTick:ce,edgeToleranceTick:Le,...$})},di=(B,$={})=>{const K=Fs(B,$);return K?K.midi:null},kr=B=>{if(!J.reference)return null;if(J.gateUserByTarget){const $=Number(J.userOffsetSec)||0;return di(B-$)}return di(B)},hi=[];if(J.reference&&typeof J.reference.getTickAtTime=="function"){const B=Number(J.reference.timeDivision)||480,$=typeof J.reference.ticksToSeconds=="function"?ce=>J.reference.ticksToSeconds(ce):ce=>typeof J.reference.beatsToSeconds=="function"?J.reference.beatsToSeconds(ce/B):0,K=J.reference.getTickAtTime(mt),G=J.reference.getTickAtTime(ft),U=Math.floor(K/B);let oe=Math.ceil(G/B);oe-U>500&&(oe=U+500);for(let ce=U;ce<oe;ce+=1){const Le=ce*B,Bt=(ce+1)*B,le=$(Le),ve=$(Bt);if(!Number.isFinite(le)||!Number.isFinite(ve)||ve<mt||le>ft||re<ve)continue;const St=Math.max(0,ve-le);let Dt=0;for(const on of Zt){const Pn=Math.max(le,on.t0Sec),En=Math.min(ve,on.t1Sec);En>Pn&&(Dt+=En-Pn)}const yn=St>0?Math.min(1,Dt/St):0;hi.push({t0:le,t1:ve,beatIdx:ce,correct:yn>=Tc.coverageRatio,showAt:ve+Cc})}}if(M.techniqueEventsRef?.current){const B=Se.screen.width*.7,$=Number.isFinite(M.playheadDotY)?M.playheadDotY:Te/2,K=Te-30;for(const G of M.techniqueEventsRef.current){if(!G.isPending)continue;const U=Number(G.t);if(!Number.isFinite(U)){G.isPending=!1;continue}const oe=G._scoringNoteId?Zt.filter(le=>le.noteId===G._scoringNoteId):[],ce=G._scoringNoteId?bn.find(le=>le.noteId===G._scoringNoteId):null;if(ce?.pendingConfirmation)continue;const Le=wc(oe,U),Bt=yc(U,G._noteEndSec,ce?.visualDelaySec);if(!(!Le&&Number.isFinite(Bt)&&re<Bt)){if(Le){G.isValid=!0,M.processedNotesRef&&G._noteId!=null&&M.processedNotesRef.add(G._noteId);const le=G._type||G.type;ot(ve=>({...ve,[le]:(ve[le]||0)+1})),le==="glissup"?(M.comboSystem.spawnCombo(B,$,60,K,kt.glissup.color),setTimeout(()=>H(be,_n(kt.glissup.color)),600)):le==="kobushi"?(M.comboSystem.spawnCombo(B,$,170,K,kt.kobushi.color),setTimeout(()=>H(He,_n(kt.kobushi.color)),600)):le==="glissdown"?(M.comboSystem.spawnCombo(B,$,280,K,kt.glissdown.color),setTimeout(()=>H(Me,_n(kt.glissdown.color)),600)):le==="vibrato"&&(M.comboSystem.spawnCombo(B,$,390,K,kt.vibrato.color),setTimeout(()=>H(Ae,_n(kt.vibrato.color)),600))}else G.isValid=!1;G.isPending=!1}}}const mi=10,Mr=5;if(M.miss.clear(),M.user.clear(),M.userGlow&&M.userGlow.clear(),M.userGlow?.setFillStyle({color:Pt.userGlowFill,alpha:Vt.userGlowFill}),M.userGlow?.beginPath(),Je.length)for(const B of Je){if(B.t1Sec<mt||B.t0Sec>ft)continue;const $=Math.max(B.t0Sec,mt);if(Math.min(B.t1Sec,ft)<=$)continue;const G=B.midi+We,{y:U}=jt(G),oe=[];for(const le of Zt){if(le.t1Sec<=B.t0Sec)continue;if(le.t0Sec>=B.t1Sec)break;const ve=Math.max(B.t0Sec,le.t0Sec),St=Math.min(B.t1Sec,le.t1Sec);St<=ve||oe.push({t0:ve,t1:St,correct:!0,showAt:Number.isFinite(Number(le.confirmedAtSec))?Number(le.confirmedAtSec):0})}if(!oe.length||!M.userGlow)continue;const ce=[];if(oe.forEach(le=>{le.correct&&re>=le.showAt&&ce.push({t0:le.t0,t1:le.t1,showAt:le.showAt})}),!ce.length)continue;const Le=fr(B);xc(ce,Le).forEach(le=>{const St=Math.max(0,re-le.showAt)*zi,Dt=le.t0,yn=Dt+St;if(yn<=Dt)return;const on=Math.min(le.t1,yn);if(on>Dt){const Pn=Math.max(Dt,mt),En=Math.min(on,ft);if(En>Pn){const Si=Ee+(Pn-re)*tt,Tr=Ee+(En-re)*tt,yi=Math.max(1,Tr-Si);yi>0&&M.userGlow.roundRect(Si,U-mi/2,yi,mi,Mr)}}})}if(M.userGlow?.fill(),M.trail){M.trail.clear();const B=gc(Tt,re,{durationSec:2,rmsGate:J.rmsGate,maxGapSec:.15});for(const $ of B){const K=jt($.midi0),G=jt($.midi1);if(!K.inRange||!G.inRange)continue;const U=Ee+($.t0Sec-re)*tt,oe=Ee+($.t1Sec-re)*tt;M.trail.setStrokeStyle({width:3,color:Pt.userGlowFill,alpha:$.alpha,cap:"round",join:"round"}),M.trail.beginPath(),M.trail.moveTo(U,K.y),M.trail.lineTo(oe,G.y),M.trail.stroke()}}if(M.debugTrace&&(M.debugTrace.clear(),J.debug)){M.debugTrace.setStrokeStyle({width:2,color:65535,alpha:.8}),M.debugTrace.beginPath();let $=!1;J.reference?.tempoChanges?.length&&typeof J.reference.ticksToSeconds=="function"&&(M.debugTrace.setStrokeStyle({width:2,color:16761856,alpha:.6}),M.debugTrace.beginPath(),J.reference.tempoChanges.forEach(K=>{const G=Number(K?.ticks);if(!Number.isFinite(G))return;const U=J.reference.ticksToSeconds(G);if(!Number.isFinite(U)||U<mt||U>ft)return;const oe=Ee+(U-re)*tt;M.debugTrace.moveTo(oe,0),M.debugTrace.lineTo(oe,Te)}),M.debugTrace.stroke()),hi.forEach(K=>{const G=Ee+(K.t0-re)*tt,oe=Ee+(K.t1-re)*tt-G;oe>0&&(M.debugTrace.roundRect(G,10,oe,Te-20,0),M.debugTrace.setStrokeStyle({width:1,color:16777215,alpha:.2}),M.debugTrace.stroke(),K.correct?M.debugTrace.setFillStyle({color:65280,alpha:.1}):M.debugTrace.setFillStyle({color:16711680,alpha:.05}),M.debugTrace.fill())}),M.debugTrace.setStrokeStyle({width:2,color:65535,alpha:.8}),M.debugTrace.beginPath(),Tt.forEach(K=>{if(K.t<mt||K.t>ft)return;const G=Number.isFinite(K.userMidi)?Number(K.userMidi):null;if(G===null||G<=0){$=!1;return}const U=Ee+(K.t-re)*tt,{y:oe}=jt(G),ce=Math.max(0,Math.min(Te,oe));$?M.debugTrace.lineTo(U,ce):(M.debugTrace.moveTo(U,ce),$=!0)}),M.debugTrace.stroke()}let fi=null;const ts=J.lastPitchRef?.current;let ns=Number.isFinite(ts?.midi)?Number(ts.midi):null,ss=Number.isFinite(ts?.rms)?Number(ts.rms):null;if(!Number.isFinite(ns)){const B=J.historyRef?.current||[],$=B.length?B[B.length-1]:null;Number.isFinite($?.userMidi)&&(ns=Number($.userMidi),ss=Number.isFinite($?.rms)?Number($.rms):ss)}if(Number.isFinite(ns)&&(!Number.isFinite(ss)||ss>=(Number(J.rmsGate)||0))){let B=null;J.reference&&(B=kr(re));const $=J.forceUserOnScoring===!0;if(B==null&&$){const K=J.gateUserByTarget?re-(Number(J.userOffsetSec)||0):re;B=pc(Tn,K)}if(!(J.gateUserByTarget&&J.reference&&B==null&&!$)){const K=Number.isFinite(B)?Number(B)+We:null,G=go(ns,K);if(Number.isFinite(G)){const{y:U,inRange:oe}=jt(G);oe&&(fi=U)}}}const Bn=fc(M.playheadDotY,fi,it);M.playheadDotY=Bn;let gi=null,pi=null,xi=!1,bi=-1/0;for(const B of Zt){const $=Number(B?.t0Sec),K=Number(B?.t1Sec);if(!Number.isFinite($)||!Number.isFinite(K))continue;const G=bc(B,re,zi);if(!Number.isFinite(G))continue;const U=Sc(B,bn,We);if(!Number.isFinite(U))continue;const oe=jt(U);if(!oe.inRange)continue;const ce=Number(B.confirmedAtSec);Number.isFinite(ce)&&ce>=bi&&G<K-1e-7&&(bi=ce,gi=Ee+(G-re)*tt,pi=oe.y,xi=!0)}const Cr=(J.techniqueEventsRef?.current||[]).filter(B=>B.t>=mt&&B.t<=ft),An=M.techniqueSpritePool||[];M.techniqueSpritePool||(M.techniqueSpritePool=An);const is=M.techniqueTextureCache||new Map;M.techniqueTextureCache||(M.techniqueTextureCache=is);const jr=B=>{if(is.has(B))return is.get(B);const $=kt[B];if(!$||!$.svg)return null;const K=new _t().svg($.svg),G=Se.renderer.generateTexture(K);return K.destroy(!0),is.set(B,G),G};let Rs=0;Cr.forEach(B=>{if(!B.isValid)return;const $=kt[B.type];if(!$)return;let K=Je.find(le=>B.t>=le.t0Sec-.2&&B.t<=le.t1Sec+.2);if(!K){const ve=Je.filter(St=>B.t>=St.t0Sec-1&&B.t<=St.t1Sec+1);ve.length>0&&(ve.sort((St,Dt)=>{const yn=Math.min(Math.abs(B.t-St.t0Sec),Math.abs(B.t-St.t1Sec)),on=Math.min(Math.abs(B.t-Dt.t0Sec),Math.abs(B.t-Dt.t1Sec));return yn-on}),K=ve[0])}if(!K)return;const G=jr(B.type);if(!G)return;let U=An[Rs];U||(U=new zr(G),U.anchor.set(.5,1),U.scale.set(.65),M.techniqueIcons.addChild(U),An.push(U)),U.texture!==G&&(U.texture=G),U.tint=$.color;const oe=K.midi+We,{y:ce}=jt(oe),Le=ce-vc,Bt=Ee+(B.t-re)*tt;U.x=Bt,U.y=Le,U.visible=!0,Rs++});for(let B=Rs;B<An.length;B++)An[B].visible=!1;M.playhead.clear();const qt=Math.round(Ee)+.5;M.playhead.setStrokeStyle({width:Hn.playheadOuter,color:Pt.playhead,alpha:Vt.playheadOuter}),M.playhead.beginPath(),M.playhead.moveTo(qt,0),M.playhead.lineTo(qt,Te),M.playhead.stroke(),M.playhead.setStrokeStyle({width:Hn.playheadMid,color:Pt.playhead,alpha:Vt.playheadMid}),M.playhead.beginPath(),M.playhead.moveTo(qt,0),M.playhead.lineTo(qt,Te),M.playhead.stroke(),M.playhead.setStrokeStyle({width:Hn.playheadInner,color:Pt.playhead,alpha:Vt.playheadInner}),M.playhead.beginPath(),M.playhead.moveTo(qt,0),M.playhead.lineTo(qt,Te),M.playhead.stroke(),Number.isFinite(Bn)&&(M.playhead.setFillStyle({color:Pt.playhead,alpha:1}),M.playhead.beginPath(),M.playhead.moveTo(qt+On,Bn),M.playhead.lineTo(qt-On,Bn-On),M.playhead.lineTo(qt-On,Bn+On),M.playhead.closePath(),M.playhead.fill()),M.particleSystem&&(M.particleSystem.setConfig(J.particleConfig),M.particleSystem.update(it,xi,gi,pi))})})(),()=>{ke=!1;const te=ye.current.app,ue=ye.current.particleSystem,ze=ye.current.comboSystem;ue&&ue.destroy(),ze&&ze.destroy(),te&&te.destroy(!0),q.current&&(q.current.innerHTML=""),ye.current={app:null,bg:null,grid:null,notes:null,miss:null,user:null,userGlowContainer:null,userGlow:null,particleSystem:null,comboSystem:null,playhead:null,lastSize:{w:0,h:0},lastGrid:{w:0,h:0,lineCount:12},lastCenterPitch:null,lastCenterSnap:null,centerSnap:null,lastCounts:{shakuri:0,kobushi:0,fall:0,vibrato:0}}}},[]),g.useEffect(()=>{const ke=ye.current.app;ke&&ke.renderer.resize(h,c)},[h,c]);const ae=Number.isFinite(pe)?pe:Number.isFinite(r?.current?.f0Hz)?r.current.f0Hz:null,xe=Number.isFinite(ie)?ie:null,je=Number.isFinite(me)?me:Number.isFinite(r?.current?.midi)?r.current.midi:null,Ve=Y||Go?.(),we=!!(L&&Ve&&Ve.frequencyBinCount>0),De=Math.max(28,Math.round(I*.35)),Ue=Math.max(1,I-De);return t.jsxs("div",{className:se,style:{...F,position:"relative"},children:[t.jsx("div",{ref:q,style:{width:"100%",height:"100%"}}),t.jsx(Gc,{glissandoUpCount:Ce.glissup,kobushiCount:Ce.kobushi,glissandoDownCount:Ce.glissdown,vibratoCount:Ce.vibrato,currentSection:k,totalSections:E,shakuriRef:be,kobushiRef:He,fallRef:Me,vibratoRef:Ae,debugInfo:P,showDebug:L,rmsGate:l}),we?t.jsx("div",{style:{position:"absolute",right:8,bottom:8,width:"32%",height:I,overflow:"hidden",border:"1px solid rgba(255,255,255,0.2)",background:"#000",boxShadow:"0 6px 16px rgba(0,0,0,0.4)"},children:t.jsxs("div",{style:{display:"flex",flexDirection:"column",width:"100%",height:"100%"},children:[t.jsxs("div",{style:{position:"relative",width:"100%",flex:"0 0 auto"},children:[t.jsx("div",{style:{position:"absolute",top:4,left:6,zIndex:2,pointerEvents:"none",fontSize:11,lineHeight:1,color:"rgba(255,255,255,0.85)",textShadow:"0 1px 2px rgba(0,0,0,0.8)"},children:"F0 稳定度 (robust std, cents)"}),t.jsxs("div",{style:{position:"absolute",top:4,right:6,zIndex:2,pointerEvents:"none",fontSize:11,lineHeight:1,color:"rgba(255,255,255,0.85)",textShadow:"0 1px 2px rgba(0,0,0,0.8)",textAlign:"right"},children:["σ~:",Number.isFinite(P?.jitterRobustCents)?P.jitterRobustCents.toFixed(2):"n/a","c"," ","n:",Number.isFinite(P?.jitterN)?P.jitterN:0]}),t.jsx(dn,{data:Oe,height:De,color:"#ffcc66",background:"#000"})]}),t.jsx("div",{style:{width:"100%",flex:"1 1 auto",borderTop:"1px solid rgba(255,255,255,0.12)"},children:t.jsx(Nr,{analyser:Ve,f0Hz:ae,f0Color:de,rawF0Hz:xe,userMidi:je,rawF0Color:"#00ffff",userMidiColor:"#00ffff",height:Ue,minHz:Ne.f0MinHz,maxHz:Ne.f0MaxHz})})]})}):null]})}const ge={container:{position:"absolute",top:0,left:0,width:"100%",height:"100%",pointerEvents:"none",display:"flex",flexDirection:"column",justifyContent:"space-between",padding:"8px 12px",boxSizing:"border-box",fontFamily:'"Hiragino Kaku Gothic ProN", "Meiryo", sans-serif'},perfInterval:{container:{alignSelf:"flex-end",display:"flex",alignItems:"center",gap:8},label:{color:"#fff",fontSize:18,fontWeight:"bold",textShadow:"0 1px 2px rgba(0,0,0,0.8)",marginRight:6},circle:{width:24,height:24,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:"900"},activeCircle:{background:"linear-gradient(180deg, #ffeb3b 0%, #fbc02d 100%)",border:"2px solid #fff",color:"#000",boxShadow:"0 0 8px rgba(255, 235, 59, 0.6)"},inactiveCircle:{background:"rgba(0,0,0,0.6)",border:"1px solid #555",color:"#888",boxShadow:"none"}},debugPanel:{container:{alignSelf:"flex-end",display:"flex",flexDirection:"column",gap:4,background:"rgba(0,0,0,0.55)",border:"1px solid rgba(255,255,255,0.15)",borderRadius:6,padding:"6px 8px",color:"#e6e6e6",fontSize:12,lineHeight:1.2,textShadow:"0 1px 2px rgba(0,0,0,0.8)",minWidth:220},row:{display:"flex",gap:8,flexWrap:"wrap"},label:{color:"#9fd7ff"},value:{color:"#fff"},warn:{color:"#ffcc66"}},countBox:{container:{display:"flex",gap:12,alignItems:"flex-end"},box:{background:"linear-gradient(180deg, rgba(30,30,30,0.9) 0%, rgba(10,10,10,0.95) 100%)",borderRadius:8,padding:"4px 10px",display:"flex",alignItems:"center",gap:10,height:32,minWidth:90},label:{fontSize:13,fontWeight:"bold"},count:{color:"#fff",fontSize:18,fontWeight:"900",marginLeft:"auto",fontFamily:"Arial, sans-serif",lineHeight:1},iconSize:{width:15,height:15}}},_n=s=>"#"+s.toString(16).padStart(6,"0");function Gc({glissandoUpCount:s=0,kobushiCount:e=0,glissandoDownCount:n=0,vibratoCount:i=0,currentSection:r=0,totalSections:a=6,shakuriRef:o,kobushiRef:l,fallRef:d,vibratoRef:m,debugInfo:u,showDebug:h=!1,rmsGate:c=0}){const f=(x,S=2)=>Number.isFinite(x)?Number(x).toFixed(S):"n/a",b={glissup:s,kobushi:e,glissdown:n,vibrato:i},p={glissup:o,kobushi:l,glissdown:d,vibrato:m};return t.jsxs("div",{style:ge.container,children:[t.jsxs("div",{style:ge.perfInterval.container,children:[t.jsx("span",{style:ge.perfInterval.label,children:"演奏区間"}),Array.from({length:a}).map((x,S)=>{const N=S+1,w=N===r,v={...ge.perfInterval.circle,...w?ge.perfInterval.activeCircle:ge.perfInterval.inactiveCircle};return t.jsx("div",{style:v,children:N},N)})]}),h&&u?t.jsxs("div",{style:ge.debugPanel.container,children:[t.jsxs("div",{style:ge.debugPanel.row,children:[t.jsx("span",{style:ge.debugPanel.label,children:"User"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.userMidi,2)}),t.jsx("span",{style:ge.debugPanel.label,children:"Target"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.targetMidi,2)}),t.jsx("span",{style:ge.debugPanel.label,children:"Diff"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.distance,2)})]}),t.jsxs("div",{style:ge.debugPanel.row,children:[t.jsx("span",{style:ge.debugPanel.label,children:"RMS"}),t.jsx("span",{style:Number.isFinite(u.rms)&&Number.isFinite(c)&&u.rms>=c?ge.debugPanel.value:ge.debugPanel.warn,children:f(u.rms,3)}),t.jsx("span",{style:ge.debugPanel.label,children:"F0"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.f0Hz,2)}),t.jsx("span",{style:ge.debugPanel.label,children:"RAW"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.rawF0Hz,2)})]}),t.jsxs("div",{style:ge.debugPanel.row,children:[t.jsx("span",{style:ge.debugPanel.label,children:"Stability"}),t.jsx("span",{style:ge.debugPanel.value,children:f(u.stabilityStd,2)}),t.jsx("span",{style:ge.debugPanel.label,children:"F0 稳定度"}),t.jsxs("span",{style:ge.debugPanel.value,children:[f(u.jitterRobustCents,2),"c"]}),t.jsx("span",{style:ge.debugPanel.label,children:"State"}),t.jsx("span",{style:Number.isFinite(u.stabilityStd)&&u.stabilityStd>qi?ge.debugPanel.warn:ge.debugPanel.value,children:Number.isFinite(u.stabilityStd)?u.stabilityStd>qi?"Shaky":"Stable":"n/a"})]})]}):null,t.jsx("div",{style:ge.countBox.container,children:Object.values(kt).map(x=>t.jsx(wr,{ref:p[x.id],label:x.label,count:b[x.id],color:_n(x.color),borderColor:_n(x.color),icon:t.jsx("div",{style:{...ge.countBox.iconSize,display:"flex",alignItems:"center",justifyContent:"center",marginTop:"-2px"},children:x.icon})},x.id))})]})}const wr=g.forwardRef(({label:s,count:e,borderColor:n,icon:i,labelColor:r},a)=>t.jsxs("div",{ref:a,style:{...ge.countBox.box,border:`2px solid ${n}`,boxShadow:`0 0 5px ${n}40, inset 0 1px 0 rgba(255,255,255,0.2)`},children:[t.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6},children:[t.jsx("span",{style:{...ge.countBox.label,color:r||"#eee"},children:s}),t.jsx("span",{style:{color:n,display:"flex",alignItems:"center"},children:i})]}),t.jsx("div",{style:ge.countBox.count,children:e})]}));wr.displayName="CountBox";const Wt=sn(s=>({visible:!1,value:0,previousValue:0,animationId:0,timeoutMs:2e3,showKeyChangeAlert:(e,n)=>s(i=>({visible:!0,value:Number(e)||0,previousValue:i.visible?i.value:0,animationId:i.animationId+1,timeoutMs:Number(n)||3e3})),hideKeyChangeAlert:()=>s({visible:!1}),clearKeyChangeAlert:()=>s({visible:!1,value:0,previousValue:0,timeoutMs:1400})}));function Ki(s,e,n){return Math.min(n,Math.max(e,s))}function vr(){const s=Wt(h=>h.visible),e=Wt(h=>h.value),n=Wt(h=>h.previousValue),i=Wt(h=>h.animationId),r=Wt(h=>h.timeoutMs),a=Wt(h=>h.hideKeyChangeAlert),o=Wt(h=>h.clearKeyChangeAlert),l=g.useMemo(()=>Array.from({length:13},(h,c)=>c-6),[]),d=Ki(Math.round(e)+6,0,l.length-1),u=(Ki(Math.round(n)+6,0,l.length-1)-d)*20;return g.useEffect(()=>{if(!s||r<=0)return;const h=setTimeout(()=>a(),r);return()=>clearTimeout(h)},[s,r,e,a]),t.jsx(tr,{in:s,onExited:o,mountOnEnter:!0,unmountOnExit:!0,children:t.jsx("div",{className:"position-fixed top-0 start-50 translate-middle-x mt-3",style:{zIndex:1200,top:"-30px"},children:t.jsxs("div",{className:"keyAlert",children:[t.jsx("div",{className:"keyAlert__label",children:"キー"}),t.jsxs("div",{className:"keyAlert__track",children:[t.jsx("div",{className:"keyAlert__circle",children:"♭"}),t.jsxs("div",{className:"keyAlert__dots",children:[t.jsx("div",{className:"keyAlert__indicator",style:{"--key-alert-index":d,"--key-alert-travel-x":`${u}px`},children:t.jsx("svg",{className:"keyAlert__triangle",viewBox:"0 0 24 20",role:"presentation","aria-hidden":"true",children:t.jsx("polygon",{points:"12,20 0,0 24,0",fill:"#d32f2f",stroke:"#ffffff",strokeWidth:"2"})})},i),l.map((h,c)=>{const f=e!==0&&c===d,b=h===0;return t.jsx("div",{className:`keyAlert__dot ${f?"keyAlert__dot--selected":""}`,children:b?t.jsx("div",{className:"keyAlert__origin",children:t.jsx("div",{className:"keyAlert__originCircle",children:"原"})}):null},h)})]}),t.jsx("div",{className:"keyAlert__circle",children:"♯"})]})]})})})}function zc({ready:s,midiName:e,midiUrl:n,queueIndex:i}){const[r,a]=g.useState(null);return g.useEffect(()=>{if(!s||!e){a(null);return}let o=!0;return ee.getMidiData().then(l=>{o&&a(l?Vn(l,{channel:0}):null)}).catch(()=>{o&&a(null)}),()=>{o=!1}},[s,e,n,i]),r}function qc({pitchEngine:s,reference:e,currentTimeRef:n,transpositionRef:i,rmsGate:r=0,resetKey:a=""}){const o=g.useRef(null),l=g.useRef([]),d=g.useRef([]),m=g.useRef([]),u=g.useRef(null);return g.useEffect(()=>{l.current=[],d.current=[],m.current=[],o.current=null,u.current=null},[a]),g.useEffect(()=>{const h=s.onPitch(c=>{o.current=c;const f=n.current;if(!Number.isFinite(f))return;{const z=Number.isFinite(c?.tAcSec)?Number(c.tAcSec):null,j={t:f,tAcSec:z,f0Hz:Number.isFinite(c?.f0Hz)?Number(c.f0Hz):null,rawF0Hz:Number.isFinite(c?.rawF0Hz)?Number(c.rawF0Hz):null,rawMidi:Number.isFinite(c?.rawMidi)?Number(c.rawMidi):null,confidence:Number.isFinite(c?.confidence)?Number(c.confidence):0,rawConfidence:Number.isFinite(c?.rawConfidence)?Number(c.rawConfidence):0,rms:c?.rms??null},L=m.current;L.push(j);const pe=(Number.isFinite(z)?z:f)-12;for(;L.length;){const ie=L[0],me=Number.isFinite(ie?.tAcSec)?ie.tAcSec:ie?.t;if(!Number.isFinite(me)||me>=pe)break;L.shift()}L.length>4096&&L.splice(0,L.length-4096)}if(Number.isFinite(u.current)&&f<=u.current)return;u.current=f;const b=e,p=b?.getTickAtTime?b.getTickAtTime(f):f,x=b?ws(b,p):null,S=x?x.midi:null,N=S!=null?S+i.current:null,v=!Number.isFinite(c?.rms)||c.rms>=r,_=Number.isFinite(c?.rawMidi)&&v?Number(c.rawMidi):null,R=Cs(_,N),k=R.normalizedMidi,E=l.current,se={t:f,userMidi:k,rawMidi:_,octaveFoldSemitones:R.octaveFoldSemitones,targetMidi:N,rms:c?.rms??null,f0Hz:Number.isFinite(c?.rawF0Hz)?Number(c.rawF0Hz):null,rawF0Hz:Number.isFinite(c?.rawF0Hz)?Number(c.rawF0Hz):null,confidence:Number.isFinite(c?.confidence)?Number(c.confidence):0};E.push(se),d.current.push(se);const F=f-12;for(;E.length&&E[0].t<F;)E.shift()});return()=>h()},[s,e,r,n,i]),{lastPitchRef:o,pitchHistoryRef:l,fullHistoryRef:d,framePitchHistoryRef:m}}function Kc({midiUrl:s,midiName:e,queue:n,queueIndex:i,playbackSessionId:r,transposition:a,showKeyChangeAlert:o,reference:l,currentTime:d=0}){const[m,u]=g.useState(!1),[h,c]=g.useState({title:"",artist:"",code:""}),f=Be(_=>_.lastIntroMidiUrl),b=Be(_=>_.setLastIntroMidiUrl),p=g.useRef(null),x=i>=0?n?.[i]:null,S=x?.title||e||"",N=x?.artist||"",w=x?.id||x?.code||"",v=s||e?`${r??0}:${s||`${i??-1}:${e||""}`}`:"";return g.useEffect(()=>{if(!m||!l?.notes?.length)return;l.notes[0].t0Sec<d+3&&m&&u(!1)},[m,l,d]),g.useEffect(()=>{S&&(h.title!==S||h.artist!==N||h.code!==w)&&c({title:S,artist:N,code:w})},[N,w,h.artist,h.code,h.title,S]),g.useEffect(()=>{!v||!S||v===f||(b(v),o&&o(a??0,5e3),u(!0),p.current&&clearTimeout(p.current),p.current=setTimeout(()=>{p.current=null,u(!1)},5e3))},[v,S,a,o,f,b]),g.useEffect(()=>()=>{p.current&&clearTimeout(p.current)},[]),{showSongInfo:m,songInfo:h}}function _r(s,e,n){const i=g.useRef(null),[r,a]=g.useState({vibrato:0,kobushi:0,glissup:0,glissdown:0}),[o,l]=g.useState({}),d=300,m=g.useRef([]),[u]=g.useState(()=>({vibrato:new Array(d).fill(0),kobushi:new Array(d).fill(0),glissando:new Array(d).fill(0)}));g.useEffect(()=>{if(!s||!n)return;const c=new Worker(new URL("/assets/technique.worker-blRvQ5hd.js",import.meta.url),{type:"module"});i.current=c,c.postMessage({type:"init"}),c.onmessage=b=>{const{type:p,events:x,activeTechniques:S}=b.data;if(p==="update"&&(x&&Object.keys(x).length>0&&a(N=>{const w={...N};let v=!1;for(const _ in x)if(x[_]){const R=x[_],k=R.type||_;w[k]!==void 0&&(w[k]++,v=!0);const E=e?.current??0;m.current.push({type:k,t:E,...R})}return m.current.length>500&&(m.current=m.current.slice(-500)),v?w:N}),S)){const N=S,w=u;w.vibrato.push(N.vibrato?1:0),w.vibrato.length>d&&w.vibrato.shift(),w.kobushi.push(N.kobushi?1:0),w.kobushi.length>d&&w.kobushi.shift();let v=0;N.glissup?v=1:N.glissdown&&(v=-1),w.glissando.push(v),w.glissando.length>d&&w.glissando.shift(),l({...N})}};const f=s.onPitch(b=>{const p=b.time||performance.now()/1e3,x=b.f0Hz;c.postMessage({type:"push",payload:{time:p,f0:x}})});return()=>{f(),i.current?.postMessage({type:"stop"}),i.current?.terminate()}},[s,n,u,e]);const h=g.useCallback(()=>{a({vibrato:0,kobushi:0,glissup:0,glissdown:0}),i.current&&i.current.postMessage({type:"reset"}),m.current=[];const c=u;c.vibrato.fill(0),c.kobushi.fill(0),c.glissando.fill(0)},[u]);return{counts:r,activeTechniques:o,techniqueHistory:u,techniqueEventsRef:m,resetCounts:h}}function Vc({pitch:s,songTimeSec:e,userOffsetSec:n=0,audioContext:i}){const r=Number(e);if(!Number.isFinite(r))return null;const a=Number.isFinite(n)?Number(n):0;let o=r-a;const l=Number(i?.currentTime),d=Number(s?.tAcSec);if(Number.isFinite(l)&&Number.isFinite(d)){const m=Math.max(0,Math.min(.25,l-d)),u=Number(i?.sampleRate)||Ne.sampleRate,h=Number(Ne.windowSize)/(2*u);o-=m+h}return o}function Wc({pitchEngine:s,reference:e,currentTimeRef:n,transpositionRef:i,rmsGate:r=.01,userOffsetSec:a=0,enabled:o=!0,resetKey:l,debug:d=!1,debugIntervalMs:m=1e3,debugRef:u,onDebug:h,onScoreChange:c}){const f=g.useRef(new po),b=g.useRef({algorithmVersion:kn,octaveShift:0,octavePolicy:"pitch-class",currentFrame:null,liveNote:null,recentNotes:[],confirmedSegments:[],pendingDecisionCount:0,decisionWindowSec:null,confirmedThroughSec:null}),p=g.useRef(0),x=g.useRef(0),S=g.useRef(null);g.useEffect(()=>{const _=e?.notes||[];f.current.reset(_,{reference:e,rmsGate:r}),x.current=0,S.current=null,b.current=f.current.getVisualState(),typeof c=="function"&&c(0,{ready:!0,finalizedNotes:0,cumulative:!0,initialization:!0})},[l,e,r,c]),g.useEffect(()=>{if(!(!s||!o||!e))return s.onPitch(_=>{const R=Number(n.current);if(!Number.isFinite(R))return;const k=Vc({pitch:_,songTimeSec:R,userOffsetSec:a,audioContext:s.getAudioContext?.()});Number.isFinite(S.current)&&k<S.current-.05&&(x.current=0,typeof c=="function"&&c(0,{ready:!0,finalizedNotes:0,cumulative:!0,reset:!0})),S.current=k,f.current.process({userPitch:_,transposition:Number(i.current)||0,timeSec:k}),b.current=f.current.getVisualState();const E=f.current.getFinalizeInfo();if(Number(E.count)>0){const se=f.current.getLiveScoreInfo(),F=f.current.getScore(),z={...se,score:F,ready:!0,cumulative:!0};Math.abs(F-x.current)>.001&&(x.current=F),typeof c=="function"&&c(F,z)}if(d||u||h){const se=performance.now();if(se-p.current>=m){const F=f.current.getDebugInfo();u&&(u.current=F),typeof h=="function"&&h(F),d&&console.log(`[KaraokeScore:${kn}]`,F),p.current=se}}})},[s,o,e,n,i,a,d,m,u,h,c]);const N=g.useCallback(()=>f.current.getScore(),[]),w=g.useCallback(()=>f.current.getLiveScore(),[]),v=g.useCallback(_=>{const R=Number(n.current),k=Number.isFinite(Number(_))?Number(_):R,E=f.current.finalize(k);return b.current=f.current.getVisualState(),x.current=E,typeof c=="function"&&c(E,{ready:!0,final:!0,cumulative:!0,finalizedNotes:f.current.getLiveScoreInfo().finalizedNotes}),E},[n,c]);return{getScore:N,getLiveScore:w,finalizeScore:v,scoringVisualRef:b}}const Vi=1e3,$c=2e3,Uc=3e3;function Xc({score:s=0,ready:e=!1,label:n="現在の得点",updateKey:i=0}){const[r,a]=g.useState(0),[o,l]=g.useState(0),d=g.useRef(0),m=g.useRef(0),u=g.useRef(null),h=g.useRef(null),c=g.useRef(!1),f=g.useRef(!1),b=g.useRef([]),p=g.useRef(i),x=g.useCallback(()=>{b.current.forEach(w=>window.clearTimeout(w)),b.current=[]},[]),S=g.useCallback(function w(){if(f.current||u.current==null)return;const v=u.current;u.current=null,h.current=v,f.current=!0,c.current=!0,m.current-=90,l(m.current);const _=window.setTimeout(()=>{const R=Math.max(h.current??0,Number.isFinite(u.current)?u.current:0);u.current=null,h.current=R,c.current=!1,d.current=R,a(R),m.current-=90,l(m.current);const k=window.setTimeout(()=>{const E=window.setTimeout(()=>{h.current=null,f.current=!1,w()},Uc);b.current.push(E)},Vi);b.current.push(k)},Vi+$c);b.current.push(_)},[]);g.useEffect(()=>{if(!e||i===p.current)return;p.current=i;const w=Math.max(0,Math.min(100,Number(s)||0)),v=Number.isFinite(h.current)?h.current:d.current,_=Math.max(d.current,v);w<=_+.001||(u.current=Math.max(Number.isFinite(u.current)?u.current:_,w),!c.current&&S())},[e,S,s,i]),g.useEffect(()=>()=>x(),[x]);const N=Math.round(e?r:0);return t.jsx("div",{className:"score-cube-scene",children:t.jsxs("div",{className:"score-cube",style:{transform:`rotateY(${o}deg)`},children:[t.jsxs("div",{className:"score-cube-face front",children:[t.jsx("div",{className:"score-cube-label",children:n}),t.jsx("div",{className:"score-cube-value",children:e?N:t.jsx("span",{className:"score-cube-pending",children:"集計中"})}),t.jsx("div",{className:"score-cube-sub",children:"100"})]}),t.jsx("div",{className:"score-cube-face right",children:t.jsx("div",{className:"score-cube-value score-cube-calculating",children:"集計中"})}),t.jsxs("div",{className:"score-cube-face back",children:[t.jsx("div",{className:"score-cube-label",children:n}),t.jsx("div",{className:"score-cube-value",children:N}),t.jsx("div",{className:"score-cube-sub",children:"100"})]}),t.jsx("div",{className:"score-cube-face left",children:t.jsx("div",{className:"score-cube-value score-cube-calculating",children:"集計中"})}),t.jsx("div",{className:"score-cube-face top"}),t.jsx("div",{className:"score-cube-face bottom"})]})})}const Wn={glissup:0,kobushi:0,glissdown:0,vibrato:0},Gn={scoreSessionId:null,liveScore:0,liveScoreReady:!1,finalScore:0,techniqueCounts:{...Wn},scoreMeta:{ratio:0,correctWeightedBeats:0,totalWeightedBeats:0},songInfo:null,f0Curve:null,hasResults:!1},gt=sn(s=>({...Gn,beginPlayerScoreSession:e=>{if(e==null)return!1;let n=!1;return s(i=>i.scoreSessionId===e?i:(n=!0,{...Gn,scoreSessionId:e,techniqueCounts:{...Wn}})),n},resetPlayerScore:()=>s({...Gn,techniqueCounts:{...Wn}}),setLiveScore:(e,n=!0)=>s({liveScore:Number.isFinite(e)?e:0,liveScoreReady:n===!0}),setFinalScore:e=>s({finalScore:Number.isFinite(e)?e:0,hasResults:!0}),setTechniqueCounts:e=>s({techniqueCounts:{...Wn,...e||{}}}),setScoreMeta:e=>s({scoreMeta:{...Gn.scoreMeta,...e||{}}}),setSongInfo:e=>s({songInfo:e||null}),setF0Curve:e=>s({f0Curve:e||null}),setResults:(e={})=>s({finalScore:Number.isFinite(e.score)?e.score:0,techniqueCounts:{...Wn,...e.techniques||{}},scoreMeta:{...Gn.scoreMeta,...e.scoreMeta||{}},songInfo:e.songInfo||null,f0Curve:e.f0Curve||null,hasResults:!0})})),Yc="/assets/logo_title-i1eLCpJi.png";function Nn(s,e="base"){const n=e==="fill"?"karaokeRun--fill":"karaokeRun--base";return s.map((i,r)=>{const a=`karaokeRun ${n}${i.falsetto?" karaokeRun--falsetto":""}`,o=`karaokeRubyRt karaokeRubyRt--${e}${i.falsetto?" karaokeRubyRt--falsetto":""}`;return i.ruby?t.jsxs("ruby",{className:`karaokeRuby ${a}`,children:[i.text,t.jsx("rt",{className:o,children:i.ruby})]},`${e}-${i.text}-${i.ruby}-${i.falsetto?"falsetto":"normal"}-${r}`):t.jsx("span",{className:a,children:i.text},`${e}-${i.text}-${i.falsetto?"falsetto":"normal"}-${r}`)})}function Qc(s){if(!s)return null;if(Array.isArray(s.segments)&&s.segments.length)return{segments:s.segments,plainText:typeof s.plainText=="string"?s.plainText:s.segments.map(n=>n.text).join("")};const e=Ss(s.text);return{segments:e.segments,plainText:e.plainText}}const Wi=s=>{if(!s.length)return null;const e=[...s].sort((i,r)=>i-r),n=Math.floor(e.length/2);return e.length%2?e[n]:(e[n-1]+e[n])/2},Jc=({history:s,reference:e,rmsGate:n})=>{if(!Array.isArray(s)||!s.length)return[];if(!e||typeof e.getTickAtTime!="function")return s.filter(c=>Number.isFinite(c?.t)).map(c=>({t:Number(c.t),f0Hz:Number.isFinite(c?.f0Hz)?Number(c.f0Hz):null,midi:Number.isFinite(c?.userMidi)?Number(c.userMidi):null}));const i=Number(e.timeDivision)||480,r=typeof e.ticksToSeconds=="function"?c=>e.ticksToSeconds(c):c=>typeof e.beatsToSeconds=="function"?e.beatsToSeconds(c/i):0,a=Number.isFinite(e.durationSec)?Number(e.durationSec):Number(s[s.length-1]?.t)||0,o=e.getTickAtTime(a),l=Math.ceil(o/i),d=Array.isArray(e.notes)?e.notes:[],m=[];let u=0,h=0;for(let c=0;c<l;c+=1){const f=c*i,b=(c+1)*i,p=r(f),x=r(b);if(!Number.isFinite(p)||!Number.isFinite(x))continue;if(p>a)break;for(;h<d.length&&d[h].t1Sec<=p;)h+=1;let S=!1;for(let R=h;R<d.length;R+=1){const k=d[R];if(k.t0Sec>=x)break;if(k.t1Sec>p&&k.t0Sec<x){S=!0;break}}if(!S)continue;const N=[],w=[];for(;u<s.length&&s[u].t<p;)u+=1;for(let R=u;R<s.length;R+=1){const k=s[R];if(!Number.isFinite(k?.t)||k.t>=x){if(Number.isFinite(k?.t)&&k.t>=x)break;continue}const E=Number.isFinite(k?.rms)?Number(k.rms):null;Number.isFinite(E)&&E<n||(Number.isFinite(k?.f0Hz)&&k.f0Hz>0&&N.push(Number(k.f0Hz)),Number.isFinite(k?.userMidi)&&w.push(Number(k.userMidi)))}const v=Wi(N),_=Wi(w);m.push({t:(p+x)*.5,f0Hz:Number.isFinite(v)?v:null,midi:Number.isFinite(_)?_:null})}return m};function Zc({onFinish:s,showInterludePrompt:e=!0}){const n=Be(),i=Xt,[r,a]=g.useState(!1),o=g.useRef(0),l=g.useRef(0),d=g.useRef(null),m=g.useRef(null),u=g.useRef(null),h=g.useRef(!1),c=g.useRef(-1),[f,b]=g.useState(0),p=.01,x=gt(H=>H.liveScore),S=gt(H=>H.liveScoreReady),N=gt(H=>H.setLiveScore),w=gt(H=>H.setTechniqueCounts),v=gt(H=>H.setResults),_=gt(H=>H.setF0Curve),R=gt(H=>H.scoreSessionId),k=gt(H=>H.beginPlayerScoreSession),E=gt(H=>H.setSongInfo),se=Wt(H=>H.showKeyChangeAlert),F=zc({ready:n.ready,midiName:n.midiName,midiUrl:n.midiUrl,queueIndex:n.queueIndex}),z=g.useCallback((H,ae)=>{ae?.initialization===!0&&R===n.playbackSessionId||(N(H,ae?.ready===!0),ae?.ready===!0&&ae?.reset!==!0&&Number(ae?.finalizedNotes)>0&&b(xe=>xe+1))},[R,N,n.playbackSessionId]),{showSongInfo:j,songInfo:L}=Kc({midiUrl:n.midiUrl,midiName:n.midiName,queue:n.queue,queueIndex:n.queueIndex,playbackSessionId:n.playbackSessionId,transposition:n.transposition,showKeyChangeAlert:se,reference:F,currentTime:n.currentTime}),Y=g.useMemo(()=>Yo(F?.notes,.4),[F?.notes]),pe=g.useMemo(()=>{if(!Y||n.currentTime==null)return!1;const H=n.currentTime,ae=Y.find(xe=>xe.t1Sec>=H);return ae?ae.t0Sec<=H:!1},[Y,n.currentTime]),ie=g.useMemo(()=>Qo(F?.notes),[F?.notes]),me=g.useMemo(()=>Jo(ie,n.currentTime),[ie,n.currentTime]),{pitchHistoryRef:de,fullHistoryRef:I,lastPitchRef:q,framePitchHistoryRef:Q}=qc({pitchEngine:i,reference:F,currentTimeRef:o,transpositionRef:l,rmsGate:p,resetKey:n.playbackSessionId}),{techniqueEventsRef:be,resetCounts:He}=_r(i,o,r),{finalizeScore:Me,scoringVisualRef:Ae}=Wc({pitchEngine:i,reference:F,currentTimeRef:o,transpositionRef:l,rmsGate:p,debug:!1,debugIntervalMs:500,onScoreChange:z,resetKey:n.playbackSessionId}),Ce=g.useRef({glissup:0,kobushi:0,glissdown:0,vibrato:0}),ot=H=>{Ce.current=H,w(H)};g.useEffect(()=>{i&&i.configureDetector({rmsGate:p,enableRmsGate:p>0})},[i,p]);const P=Math.round((n.karaokeProgress??0)*1e3)/10,{lineRowsTwo:Ke,lineRowsThree:Oe,measureLeftSegments:et,measureRightSegments:ye}=g.useMemo(()=>{const H=n.lrcEntries||[],ae=n.activeLyricIndex??-1,xe={segments:[{text:"…",ruby:"",falsetto:!1}],plainText:"…"},je=ue=>Qc(ue)||xe,Ve=ae>=0?ae-ae%2:-1,we=Ve>=0?je(H[Ve]):xe,De=Ve+1<H.length?je(H[Ve+1]):xe,Ue=ae>=0?ae%2:0,ke=ae-1>=0?je(H[ae-1]):xe,Ct=ae>=0?je(H[ae]):xe,te=ae+1<H.length?je(H[ae+1]):xe;return{lineRowsTwo:[{segments:we.segments,align:"text-left",progress:Ue===0?P:100},{segments:De.segments,align:"text-right lyric-row--indent",progress:Ue===1?P:0}],lineRowsThree:[{segments:ke.segments,align:"text-center",progress:ae-1>=0?100:0},{segments:Ct.segments,align:"text-center",progress:P},{segments:te.segments,align:"text-center",progress:0}],measureLeftSegments:we.segments,measureRightSegments:De.segments}},[P,n.activeLyricIndex,n.lrcEntries]);g.useLayoutEffect(()=>{const H=()=>{const xe=d.current,je=m.current,Ve=u.current;if(!xe||!je||!Ve)return;const we=xe.clientWidth,De=je.scrollWidth,Ue=Ve.scrollWidth,ke=Math.max(De,Ue),ue=h.current?ke>we-24:ke>we+1,ze=Number.isFinite(n.activeLyricIndex)?n.activeLyricIndex:-1,Yt=ze>=0?ze-ze%2:-1;if(ue){h.current=!0,c.current=Yt,xe.dataset.layout!=="three"&&(xe.dataset.layout="three");return}c.current>=0&&ze<=c.current+1||(h.current=!1,c.current=-1,xe.dataset.layout!=="two"&&(xe.dataset.layout="two"))};if(H(),typeof ResizeObserver>"u"||!d.current)return;const ae=new ResizeObserver(H);return ae.observe(d.current),()=>ae.disconnect()},[et,ye,n.activeLyricIndex,n.lrcEntries]),g.useEffect(()=>{n.ready&&ee.playQueueIfIdle().catch(()=>{})},[n.ready]),g.useEffect(()=>{o.current=n.currentTime??0},[n.currentTime]),g.useEffect(()=>{l.current=Number(n.transposition)||0},[n.transposition]),g.useEffect(()=>{k(n.playbackSessionId)&&(He(),_(null))},[k,He,_,n.playbackSessionId]),g.useEffect(()=>{L&&E(L)},[E,L]),g.useEffect(()=>{let H=!1;return(async()=>{try{await xr(),H||a(!0)}catch(xe){H||console.error(xe)}})(),()=>{H=!0,ti(),a(!1)}},[i]);const Ge=g.useRef(!1);return g.useEffect(()=>{Ge.current=!1},[n.playbackSessionId]),g.useEffect(()=>{if(!(!n.duration||n.duration<10)&&!Ge.current&&(n.currentTime>=n.duration-.03||n.status==="Finished")&&(Ge.current=!0,s)){const H=Me(n.duration),ae={...Ce.current},xe=Array.isArray(I.current)?I.current:[],je=Jc({history:xe,reference:F,rmsGate:p});v({score:H,techniques:ae,songInfo:L,f0Curve:je}),_(je),s({score:H,techniques:ae,songInfo:L,f0Curve:je})}},[n.currentTime,n.duration,s,Me,L,n.status,v,_,F,I,p]),t.jsxs("div",{className:`karaokePage${j?" karaokePage--intro":""}`,children:[t.jsx(Xc,{score:x,ready:S,label:"現在の得点",updateKey:f},n.playbackSessionId),t.jsx(vr,{}),t.jsxs("div",{className:"karaokeSongIntro",children:[t.jsxs("div",{className:"karaokeSongIntro__content",children:[t.jsx("div",{className:"karaokeSongIntro__title",children:L.title}),L.artist?t.jsxs("div",{className:"karaokeSongIntro__artist",children:["♪",L.artist]}):null]}),t.jsx("img",{src:Yc,alt:"Logo",className:"karaokeSongIntro__logo"})]}),t.jsx("div",{className:"karaoke-stage",children:t.jsxs("div",{className:"karaoke-screen",children:[t.jsxs("div",{className:"top-section",children:[t.jsx("div",{className:"info-container",children:pe&&t.jsx("div",{className:"scoring-badge",children:t.jsx("span",{className:"scoring-text",children:"🎤 採点中"})})}),t.jsx("div",{className:"melody-guide",children:t.jsx(ii,{className:"melodyGuideCanvas",reference:F,historyRef:de,pitchFrameHistoryRef:Q,scoringVisualRef:Ae,lastPitchRef:q,currentTimeRef:o,transpositionRef:l,rmsGate:p,gateUserByTarget:!0,forceUserOnScoring:pe,width:800,height:220,techniqueEventsRef:be,onTechniqueCountsChange:ot,totalSections:6,currentSection:n.duration>0?Math.min(6,Math.floor(n.currentTime/n.duration*6)+1):1})})]}),t.jsx("div",{className:"bottom-section",children:t.jsxs("div",{className:"lyrics-container",ref:d,"data-layout":"two",children:[t.jsxs("span",{className:"lyrics-measure","aria-hidden":"true",children:[t.jsx("span",{className:"text",ref:m,children:t.jsx("span",{className:"karaokeTextWrap",children:t.jsx("span",{className:"karaokeTextBase",children:Nn(et,"base")})})}),t.jsx("span",{className:"text",ref:u,children:t.jsx("span",{className:"karaokeTextWrap",children:t.jsx("span",{className:"karaokeTextBase",children:Nn(ye,"base")})})})]}),t.jsx("div",{className:`lyrics-lines lyrics-lines--two${me.lyricsVisible?" lyrics-lines--visible":""}`,children:Ke.map((H,ae)=>t.jsx("div",{className:`lyric-row ${H.align}`,children:t.jsx("span",{className:"text",children:t.jsxs("span",{className:"karaokeTextWrap",style:{"--karaoke-progress":`${H.progress}%`},children:[t.jsx("span",{className:"karaokeTextBase",children:Nn(H.segments,"base")}),t.jsx("span",{className:"karaokeTextFill","aria-hidden":"true",children:Nn(H.segments,"fill")})]})})},`two-${H.align}-${ae}`))}),t.jsx("div",{className:`lyrics-lines lyrics-lines--three${me.lyricsVisible?" lyrics-lines--visible":""}`,children:Oe.map((H,ae)=>t.jsx("div",{className:`lyric-row ${H.align}`,children:t.jsx("span",{className:"text",children:t.jsxs("span",{className:"karaokeTextWrap",style:{"--karaoke-progress":`${H.progress}%`},children:[t.jsx("span",{className:"karaokeTextBase",children:Nn(H.segments,"base")}),t.jsx("span",{className:"karaokeTextFill","aria-hidden":"true",children:Nn(H.segments,"fill")})]})})},`three-${H.align}-${ae}`))}),t.jsxs("div",{className:`interlude-prompt${e&&me.promptVisible?" interlude-prompt--visible":""}`,"aria-label":"間奏","aria-hidden":!e||!me.promptVisible,children:[t.jsx("span",{"aria-hidden":"true",children:"間奏("}),t.jsx("span",{className:"interlude-prompt__dot","aria-hidden":"true",children:"・"}),t.jsx("span",{className:"interlude-prompt__dot","aria-hidden":"true",children:"・"}),t.jsx("span",{className:"interlude-prompt__dot","aria-hidden":"true",children:"・"}),t.jsx("span",{"aria-hidden":"true",children:")"})]})]})})]})})]})}const zn=({label:s,score:e,maxScoreDisplay:n})=>{const i=Math.max(0,Math.min(Number(e)||0,100)),r=Math.floor(i/100*n),[a]=nr.useState(()=>{const o=Math.random()*2.5;return[{size:14,left:18,duration:3.2,delay:.1+o},{size:10,left:48,duration:2.6,delay:.6+o},{size:18,left:70,duration:3.8,delay:.2+o}]});return t.jsxs("div",{className:"liquid-tube-container",children:[t.jsx("div",{className:"lt-label",children:s}),t.jsxs("div",{className:"lt-tube-wrapper",children:[t.jsx("div",{style:{position:"absolute",top:0,width:"100%",height:"4%",background:"linear-gradient(to bottom, #cbd5e1, #f1f5f9, #94a3b8)",zIndex:30,borderBottom:"1px solid #64748b"}}),t.jsx("div",{style:{position:"absolute",top:"4%",width:"100%",height:"1%",backgroundColor:"#1e293b",zIndex:20}}),t.jsx("div",{style:{position:"absolute",top:0,left:"20%",width:"15%",height:"100%",backgroundColor:"rgba(255,255,255,0.1)",zIndex:20,filter:"blur(2px)",pointerEvents:"none"}}),t.jsx("div",{style:{position:"absolute",top:0,right:"20%",width:"5%",height:"100%",backgroundColor:"rgba(255,255,255,0.05)",zIndex:20,filter:"blur(1px)",pointerEvents:"none"}}),t.jsx("div",{style:{position:"absolute",inset:0,backgroundColor:"rgba(2, 6, 23, 0.8)"}}),t.jsxs("div",{className:"lt-liquid",style:{"--fill":i/100},children:[t.jsx("div",{className:"lt-liquid-fill"}),t.jsx("div",{style:{position:"absolute",top:0,width:"100%",backgroundColor:"rgba(255,255,255,0.8)",filter:"blur(2px)",transform:"translateY(-50%) scaleX(1.25)",borderRadius:"100%",height:"3%",boxSizing:"content-box",borderTop:"2px solid white"}}),t.jsx("div",{className:"lt-bubbles",children:a.map((o,l)=>t.jsx("div",{className:"lt-bubble animate-bubble",style:{"--bubble-size":`${o.size}%`,"--bubble-left":`${o.left}%`,"--bubble-duration":`${o.duration}s`,"--bubble-delay":`${o.delay}s`}},l))})]}),t.jsx("div",{style:{position:"absolute",bottom:0,width:"100%",background:"linear-gradient(to top, #1e293b, #475569, #94a3b8)",zIndex:30,borderTop:"2px solid #64748b",height:"5%"}})]}),t.jsxs("div",{className:"lt-score-box",children:[t.jsxs("div",{className:"font-digital",style:{color:"#facc15",fontWeight:"bold",lineHeight:1,fontSize:"2.2em",filter:"drop-shadow(0 0 5px rgba(234,179,8,0.8))"},children:[r,t.jsx("span",{style:{color:"#64748b",marginLeft:"2px",fontSize:"0.5em"},children:"/"})]}),t.jsxs("div",{style:{color:"#94a3b8",fontWeight:"bold",lineHeight:1,marginTop:"2px",fontSize:"1em"},children:[n,"点"]})]})]})},el=({score:s})=>{const e=g.useMemo(()=>{const r=Number(s)||0;return Math.min(Math.max(r,0),100)},[s]),n=e/100,i=e>80?"danger":e>60?"warning":"";return t.jsxs("div",{className:`center-score-wrapper ${i}`,children:[t.jsx("div",{className:"cs-outer-ring-glow"}),t.jsx("div",{className:"cs-inner-ring"}),t.jsx("div",{className:"cs-main-container",children:t.jsx("div",{className:"cs-liquid",style:{"--fill":n},children:t.jsxs("div",{className:"cs-liquid-level",children:[t.jsx("div",{className:"cs-wave"}),t.jsx("div",{className:"cs-wave-mask"})]})})}),t.jsxs("div",{className:"cs-score-text-container",children:[t.jsx("div",{style:{color:"#fed7aa",fontWeight:"bold",letterSpacing:"0.1em",textTransform:"uppercase",textShadow:"0 0 10px rgba(234,179,8,0.9), 0 0 20px rgba(234,179,8,0.6)",fontSize:"1em",marginBottom:"1%"},children:"TOTAL"}),t.jsx("div",{style:{color:"white",fontWeight:"bold",letterSpacing:"0.05em",marginTop:"-2%",marginBottom:"2%",opacity:.9,fontSize:"1em",backgroundColor:"rgba(153, 27, 27, 0.6)",padding:"0 10%",borderRadius:"9999px",border:"1px solid rgba(239, 68, 68, 0.8)",boxShadow:"0 0 15px rgba(242, 0, 0, 0.5)",textShadow:"0 0 10px rgba(234, 88, 12, 0.8)"},children:"総合得点"}),t.jsx("div",{className:"cs-score-large",style:{filter:"drop-shadow(0 0 8px rgba(249, 115, 22, 0.9)) drop-shadow(0 0 15px rgba(234, 88, 12, 0.7))"},children:Number(s||0).toFixed(2)}),t.jsx("div",{style:{color:"#fdba74",fontWeight:"bold",marginTop:"2%",textShadow:"0 0 15px rgba(249, 115, 22, 0.8), 2px 2px 4px rgba(0,0,0,0.8)",fontSize:"2em"},children:"点"})]})]})},tl=()=>t.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"animate-pulse-flame",style:{height:"80%",aspectRatio:"1/1",color:"#f97316",fill:"#f97316",filter:"drop-shadow(0 0 5px rgba(249,115,22,0.8))"},children:[t.jsx("path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-2.246-3.646-3.729-4.821a.249.249 0 0 1 .15-.434C9.596 3.996 11.233 4.5 12.5 5.5c-1.072 2.143-2.246 3.646-3.729 4.821a.249.249 0 0 0 .15.434c2.825-.256 4.462.248 5.729 1.245-1.072 2.143-2.246 3.646-3.729 4.821a.249.249 0 0 1 .15.434C14.596 17.996 16.233 18.5 17.5 19.5c0 1.27-1.12 2.5-2.5 2.5a2.5 2.5 0 0 1-2.5-2.5c0-1.27.5-2 1-3"}),t.jsx("path",{d:"M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5 .5 1.5.5 3.5-1 5"})]}),nl=({data:s})=>t.jsxs("div",{className:"song-info-container",children:[t.jsx(us,{label:"曲名",value:s.title,type:"cyan"}),t.jsx(us,{label:"歌手名",value:t.jsxs(nn,{artist:s.artist,children:["♪ ",s.artist]}),type:"cyan"}),t.jsx(us,{label:"全国平均",value:`${(s.avgScore||0).toFixed(3)} 点`,type:"magenta"}),t.jsx(us,{label:"全国順位",value:`${s.rank} 位`,type:"magenta"}),t.jsxs("div",{className:"si-row",children:[t.jsx("div",{style:{position:"absolute",inset:0,backgroundColor:"rgba(236, 72, 153, 0.2)",filter:"blur(12px)",borderRadius:"0.5rem",opacity:.5,transition:"opacity 0.2s"}}),t.jsx("div",{className:"si-label-box",style:{borderColor:"#ec4899",boxShadow:"inset 0 0 10px rgba(236,72,153,0.3)"},children:t.jsx("span",{className:"si-content-unskew",style:{color:"#f9a8d4",fontWeight:"bold",fontSize:"1.2em",filter:"drop-shadow(0 4px 6px rgba(0,0,0,0.1))"},children:"消費"})}),t.jsx("div",{className:"si-value-box",style:{borderColor:"#ec4899",background:"linear-gradient(to right, rgba(131, 24, 67, 0.8), #0f172a)",boxShadow:"inset 0 0 20px rgba(236,72,153,0.2)"},children:t.jsxs("span",{className:"si-content-unskew",style:{color:"white",fontWeight:"bold",display:"flex",alignItems:"center",gap:"5%",fontSize:"1.5em",filter:"drop-shadow(0 4px 6px rgba(0,0,0,0.1))"},children:[s.calories,"kcal",t.jsx(tl,{})]})})]})]}),us=({label:s,value:e,type:n})=>{const i=n==="cyan",r=i?"#22d3ee":"#ec4899",a=i?"#67e8f9":"#f9a8d4",o=i?"rgba(34,211,238,0.2)":"rgba(236,72,153,0.2)",l=i?"rgba(34,211,238,0.3)":"rgba(236,72,153,0.3)",d=i?"rgba(22, 78, 99, 0.8)":"rgba(131, 24, 67, 0.8)";return t.jsxs("div",{className:"si-row",children:[t.jsx("div",{style:{position:"absolute",inset:0,backgroundColor:o,filter:"blur(12px)",borderRadius:"0.5rem",opacity:.5}}),t.jsx("div",{className:"si-label-box",style:{borderColor:r,boxShadow:`inset 0 0 10px ${l}`},children:t.jsx("span",{className:"si-content-unskew",style:{color:a,fontWeight:"bold",fontSize:"1em",filter:"drop-shadow(0 4px 6px rgba(0,0,0,0.1))"},children:s})}),t.jsx("div",{className:"si-value-box",style:{borderColor:r,background:`linear-gradient(to right, ${d}, #0f172a)`},children:t.jsx("span",{className:"si-content-unskew",style:{color:"white",fontWeight:"bold",fontSize:"1.3em",filter:"drop-shadow(0 4px 6px rgba(0,0,0,0.1))",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},children:e})})]})},sl=nr.memo(({counts:s})=>t.jsxs("div",{className:"bp-container",children:[["top-left","top-right","bottom-left","bottom-right"].map(e=>t.jsx("div",{style:{position:"absolute",width:"1.5%",aspectRatio:"1/1",borderRadius:"9999px",backgroundColor:"#94a3b8",border:"1px solid #64748b",boxShadow:"inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)",display:"flex",alignItems:"center",justifyContent:"center",...il(e)},children:t.jsx("div",{style:{width:"60%",height:"1px",backgroundColor:"#475569",transform:"rotate(45deg)"}})},e)),t.jsxs("div",{className:"bp-dashboard",children:[t.jsxs("div",{style:{display:"flex",flexDirection:"row",flexShrink:0,alignItems:"stretch",width:"50%"},children:[t.jsx("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",aspectRatio:"1/1",height:"100%",padding:"1%"},children:t.jsxs("div",{style:{height:"100%",aspectRatio:"1/1",borderRadius:"9999px",background:"linear-gradient(to bottom right, #334155, black)",border:"3px solid rgba(6, 182, 212, 0.5)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 10px 15px -3px rgba(0, 0, 0, 0.1)",position:"relative",cursor:"pointer",boxSizing:"border-box"},children:[t.jsx("div",{style:{position:"absolute",inset:"8%",borderRadius:"9999px",border:"2px solid #22d3ee",boxShadow:"0 0 10px rgba(34,211,238,0.5)"}}),t.jsxs("div",{style:{textAlign:"center",zIndex:10,lineHeight:1.25},children:[t.jsx("div",{style:{color:"#cbd5e1",fontSize:"0.8em",fontWeight:"bold"},children:"テクニック"}),t.jsx("div",{style:{color:"white",fontWeight:"900",letterSpacing:"0.1em",fontSize:"1.5em",textShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:"詳細"})]})]})}),t.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(2, 1fr)",gridTemplateRows:"repeat(2, 1fr)",height:"100%",flex:1,gap:"2%"},children:[t.jsx(ds,{label:"こぶし",count:s.kobushi,icon:"-",type:"cyan"}),t.jsx(ds,{label:"フォール",count:s.fall,icon:"⤵",type:"yellow"}),t.jsx(ds,{label:"しゃくり",count:s.shakuri,icon:"⤴",type:"purple"}),t.jsx(ds,{label:"ビブラート",count:s.vibrato,icon:"〰",type:"orange"})]})]}),t.jsxs("div",{style:{flex:1,backgroundColor:"black",borderRadius:"0.25rem",border:"2px solid #475569",position:"relative",overflow:"hidden",boxShadow:"inset 0 0 20px rgba(0,0,0,1)",margin:"0 0.5%"},children:[t.jsx("div",{style:{position:"absolute",top:0,left:0,right:0,background:"linear-gradient(to bottom, rgba(20, 83, 45, 0.3), transparent)",height:"40%",pointerEvents:"none"}}),t.jsx("div",{style:{position:"absolute",top:"5%",left:"2%",color:"#cbd5e1",zIndex:10,fontWeight:"bold",letterSpacing:"0.05em",whiteSpace:"nowrap",fontSize:"0.9em",textShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:"ビブラートタイプ"}),t.jsx("div",{style:{position:"absolute",inset:0,display:"flex",justifyContent:"space-evenly",pointerEvents:"none",opacity:.2},children:[1,2,3,4].map(e=>t.jsx("div",{style:{height:"100%",width:"1px",backgroundColor:"#22c55e"}},e))}),t.jsx("div",{style:{position:"absolute",left:"2%",top:"25%",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"早い"}),t.jsx("div",{style:{position:"absolute",left:"2%",top:"50%",transform:"translateY(-50%)",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"標準"}),t.jsx("div",{style:{position:"absolute",left:"2%",bottom:"15%",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"遅い"}),t.jsx("div",{style:{position:"absolute",bottom:"2%",left:"15%",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"浅い"}),t.jsx("div",{style:{position:"absolute",bottom:"2%",left:"50%",transform:"translateX(-50%)",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"標準"}),t.jsx("div",{style:{position:"absolute",bottom:"2%",right:"5%",color:"#94a3b8",fontWeight:"bold",fontSize:"0.8em"},children:"深い"}),t.jsx(rl,{})]}),t.jsxs("div",{style:{width:"20%",backgroundColor:"black",borderRadius:"0.25rem",border:"2px solid #475569",position:"relative",overflow:"hidden",boxShadow:"inset 0 0 20px rgba(0,0,0,1)",display:"flex",flexDirection:"column",justifyContent:"space-between",padding:"0.5%"},children:[t.jsx("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"0 2%",paddingTop:"1%"},children:t.jsx("span",{style:{color:"#cbd5e1",fontWeight:"bold",letterSpacing:"0.05em",fontSize:"0.9em"},children:"リズム"})}),t.jsx("div",{style:{flex:1,display:"flex",alignItems:"center",justifyContent:"space-evenly",padding:"0 5%",paddingBottom:"1%"},children:[40,65,80,100,80,65,40].map((e,n)=>{const i=n===1;return t.jsx("div",{style:{height:"80%",width:"10%",display:"flex",alignItems:"center",justifyContent:"center"},children:t.jsxs("div",{style:{width:"100%",height:`${e}%`,backgroundColor:"#14b8a6",borderRadius:"0.2em",position:"relative",opacity:i?1:.6,boxShadow:i?"0 0 10px rgba(45, 212, 191, 0.5)":"none"},children:[i&&t.jsx("div",{style:{position:"absolute",top:"-10%",bottom:"-10%",left:"-20%",right:"-20%",border:"2px solid #ccfbf1",borderRadius:"0.3em",boxShadow:"0 0 8px rgba(20, 184, 166, 0.8)",zIndex:10}}),t.jsx("div",{style:{width:"100%",height:"100%",background:"linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%)"}})]})},n)})}),t.jsxs("div",{style:{display:"flex",justifyContent:"space-between",padding:"1% 2%"},children:[t.jsx("span",{style:{color:"#cbd5e1",fontWeight:"bold",fontSize:"0.8em"},children:"後ろノリ"}),t.jsx("span",{style:{color:"#cbd5e1",fontWeight:"bold",fontSize:"0.8em"},children:"前ノリ"})]})]})]})]})),il=s=>{switch(s){case"top-left":return{top:"5%",left:"1%"};case"top-right":return{top:"5%",right:"1%"};case"bottom-left":return{bottom:"5%",left:"1%"};case"bottom-right":return{bottom:"5%",right:"1%"};default:return{}}},ds=({label:s,count:e,icon:n,type:i})=>{const r={cyan:{bg:"#134e4a",border:"#14b8a6",text:"white"},yellow:{bg:"#713f12",border:"#eab308",text:"white"},purple:{bg:"#581c87",border:"#a855f7",text:"white"},orange:{bg:"#7f1d1d",border:"#ef4444",text:"white"}}[i];return t.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",backgroundColor:r.bg,borderLeft:`4px solid ${r.border}`,borderRadius:"0.125rem",height:"100%",padding:"0 5%",width:"100%",position:"relative",overflow:"hidden",boxSizing:"border-box"},children:[t.jsx("div",{style:{position:"absolute",top:0,left:0,width:"100%",height:"50%",backgroundColor:"rgba(255,255,255,0.05)",pointerEvents:"none"}}),t.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"5%",zIndex:10},children:[t.jsx("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"9999px",border:"1px solid rgba(255,255,255,0.5)",backgroundColor:"rgba(0,0,0,0.8)",width:"1.4em",height:"1.4em"},children:t.jsx("span",{style:{fontWeight:"bold",color:"white",fontSize:"0.9em"},children:n})}),t.jsx("span",{style:{color:"white",fontWeight:"bold",letterSpacing:"-0.025em",whiteSpace:"nowrap",fontSize:"1em",textShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:s})]}),t.jsxs("div",{style:{display:"flex",alignItems:"baseline",zIndex:10},children:[t.jsx("span",{className:"font-digital",style:{color:"white",lineHeight:1,letterSpacing:"-0.05em",fontSize:"1.3em",textShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:e}),t.jsx("span",{style:{color:"#cbd5e1",marginLeft:"2px",fontSize:"0.8em"},children:"回"})]})]})},rl=()=>{const a=40*Math.PI,o=g.useMemo(()=>{let l="M 0 50";for(let d=0;d<=400+a;d+=1){const m=50+Math.sin(d*.05)*25+Math.sin(d*.2)*5;l+=` L ${d} ${m}`}return l},[400,a,50,25]);return t.jsx("div",{style:{width:"100%",height:"100%"},children:t.jsxs("svg",{viewBox:"0 0 400 100",preserveAspectRatio:"none",shapeRendering:"optimizeSpeed",style:{width:"100%",height:"100%",display:"block"},children:[t.jsx("line",{x1:"0",y1:50,x2:400,y2:50,stroke:"rgba(255, 255, 255, 0.2)",strokeWidth:"1"}),t.jsxs("g",{children:[t.jsx("animateTransform",{attributeName:"transform",type:"translate",from:"0 0",to:`${-a} 0`,dur:"2s",repeatCount:"indefinite"}),t.jsx("path",{d:o,fill:"none",stroke:"rgba(34, 197, 94, 0.4)",strokeWidth:"6"}),t.jsx("path",{d:o,fill:"none",stroke:"#22c55e",strokeWidth:"1.5"})]})]})})};async function al(s,e){const n=await fetch(Nt("/api/scores"),{method:"POST",headers:{"Content-Type":"application/json",...e?{Authorization:`Bearer ${e}`}:{}},body:JSON.stringify(s)});if(!n.ok){const r=await n.text();throw new Error(r||`Failed to submit score (${n.status})`)}return(n.headers.get("content-type")||"").includes("application/json")?n.json():{status:"ok"}}const ol="/assets/result-CJr2bwSu.mp3";function cl({score:s,techniques:e,songInfo:n,onNext:i}){const r=gt(_=>_.finalScore),a=gt(_=>_.techniqueCounts),o=gt(_=>_.songInfo),l=gt(_=>_.f0Curve),d=Re(_=>_.status),m=Re(_=>_.isGuest),u=Re(_=>_.accessToken),h=g.useRef(!1),c=g.useMemo(()=>({pitch:{label:"音程",val:0,max:40},stability:{label:"安定感",val:0,max:30},intonation:{label:"抑揚",val:0,max:15},longTone:{label:`ロング
トーン`,val:0,max:10},technique:{label:`テク
ニック`,val:0,max:5}}),[]),f=Number.isFinite(s)?s:r,b=e||a,p=n||o,x=p?.code||p?.id||"",S=(Number(f)||0)/100,N=g.useCallback(_=>{Ns().stopBgm({fadeMs:_,reset:!1})},[]),w=g.useMemo(()=>({kobushi:b?.kobushi||0,fall:b?.glissdown||0,shakuri:b?.glissup||0,vibrato:b?.vibrato||0}),[b]);g.useEffect(()=>{if(h.current||d!=="authenticated"||m||!u||!x)return;const _=Number(f);if(!Number.isFinite(_))return;h.current=!0;const R={song:x,score:Math.round(_),play_mode:"competitive",version:kn,technique_counts:b||{}};Array.isArray(l)&&l.length&&(R.f0_curve=l),al(R,u).catch(k=>{console.error("Failed to submit score",k)})},[d,m,u,x,f,b,l]),g.useEffect(()=>{const _=Ns();return _.playBgm(ol,{loop:!0}).catch(()=>{}),()=>{_.stopBgm({fadeMs:Ys.karaokeTransitionMs,reset:!1})}},[]);const v=g.useCallback(()=>{N(Ys.karaokeTransitionMs),i?.()},[i,N]);return t.jsxs("div",{className:"resultsPageNew",children:[t.jsxs("div",{className:"tech-grid-wrapper",children:[t.jsx("div",{className:"tech-header-overlay"}),t.jsx("div",{className:"tech-grid-floor"}),t.jsx("div",{className:"tech-horizon-glow"}),t.jsx("div",{className:"tech-vignette"})]}),t.jsxs("div",{className:"rp-container font-mono-tech",children:[t.jsxs("header",{className:"rp-header",children:[t.jsx("div",{className:"rp-header-left",children:t.jsxs("h1",{className:"rp-header-logo-text font-digital",children:["周波採点",t.jsx("span",{className:"font-digital",style:{color:"#ee9c22ff",fontStyle:"normal",fontSize:"0.5em",marginLeft:"5px"},children:"DX"})]})}),t.jsxs("div",{style:{textAlign:"right",display:"flex",flexDirection:"column",alignItems:"flex-end",justifyContent:"center",height:"100%"},children:[t.jsxs("div",{style:{fontWeight:"bold",fontSize:"1.5em",whiteSpace:"nowrap"},children:["ゲスト ",t.jsx("span",{style:{color:"#94a3b8",fontSize:"0.7em"},children:"さん"})]}),t.jsx("div",{className:"font-mono-tech",style:{color:"#bae6fd",letterSpacing:"0.1em",opacity:.8,fontSize:"1.2em"},children:new Date().toLocaleString("ja-JP",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"})})]})]}),t.jsxs("div",{className:"rp-main-display",children:[t.jsxs("div",{style:{width:"33%",display:"flex",justifyContent:"space-between",gap:"2%",height:"100%",alignItems:"flex-end",paddingBottom:"1%"},children:[t.jsx(zn,{label:c.pitch.label,score:S*92,maxScoreDisplay:40}),t.jsx(zn,{label:c.stability.label,score:S*85,maxScoreDisplay:30}),t.jsx(zn,{label:c.intonation.label,score:S*98,maxScoreDisplay:15}),t.jsx(zn,{label:c.longTone.label,score:S*70,maxScoreDisplay:10}),t.jsx(zn,{label:c.technique.label,score:S*88,maxScoreDisplay:5})]}),t.jsx("div",{style:{width:"34%",display:"flex",justifyContent:"center",alignItems:"center",height:"100%",position:"relative"},children:t.jsx(el,{score:Number(f)||0})}),t.jsx("div",{style:{width:"33%",display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"flex-end",height:"100%",padding:"2% 0"},children:t.jsx(nl,{data:{title:p?.title||"Unknown Title",artist:p?.artist||"Unknown Artist",avgScore:74.123,rank:0,calories:12.5}})})]}),t.jsx("div",{style:{height:"22%",width:"100%",flexShrink:0},children:t.jsx(sl,{counts:w})}),t.jsxs("div",{className:"rp-footer",children:[t.jsxs("button",{className:"rp-btn rp-btn-red",onClick:v,children:[t.jsx(Lr,{style:{fill:"white",height:"50%",aspectRatio:"1/1"}}),t.jsx("span",{children:"演奏停止"})]}),t.jsxs("div",{style:{display:"flex",height:"100%",alignItems:"center"},children:[t.jsx("button",{className:"rp-btn rp-btn-blue",children:t.jsx("span",{children:"音程強化モード"})}),t.jsx("button",{className:"rp-btn rp-btn-blue",children:t.jsx("span",{children:"マイルームに保存"})}),t.jsxs("button",{className:"rp-btn rp-btn-cyan",onClick:v,children:[t.jsx(Ir,{style:{fill:"white",height:"50%",aspectRatio:"1/1"}}),t.jsx("span",{children:"プレビュー"})]})]})]})]})]})}function ll(){return t.jsx("div",{className:"karaokeMessagePage",children:t.jsx("div",{className:"karaokeMessagePage__text",children:"現在、予約リストに曲がありません。曲を予約してください。"})})}function ul({onStop:s,resetKey:e,transitionPhase:n="idle",displayMode:i="full"}){const r=Be(h=>h.karaokeView),a=Be(h=>h.setKaraokeView),o=Be(h=>h.midiName),l=Be(h=>h.queueIndex),d=Be(h=>h.queue.length),m=Be(h=>h.playbackSessionId),u=g.useCallback(()=>{a("results")},[a]);return g.useEffect(()=>{if(e!=null){if(!d&&l<0){a("message");return}a("singing")}},[l,d,e,a]),g.useEffect(()=>{!d&&l<0||!o&&!Number.isInteger(l)||a("singing")},[o,l,d,a]),t.jsxs("div",{className:`karaokeTransitionRoot karaokeTransitionRoot--${i}`,children:[t.jsx("div",{className:["karaokeTransition",n==="in"?"karaokeTransition--in":"",n==="out"?"karaokeTransition--out":""].join(" ")}),r==="results"?t.jsx(cl,{onNext:s}):r==="message"?t.jsx(ll,{}):t.jsx(Zc,{onFinish:u,showInterludePrompt:i!=="parked"},`${m}-${e}`)]})}function dl(){const s=Ot(m=>m.alert),e=Ot(m=>m.visible),n=Ot(m=>m.hideAlert),i=Ot(m=>m.clearAlert),[r,a]=g.useState(0),o=g.useMemo(()=>Number(s?.timeoutMs)||0,[s?.timeoutMs]);g.useEffect(()=>{if(!s||!e||o<=0)return;const m=performance.now(),u=setInterval(()=>{const h=performance.now()-m,c=Math.max(0,o-h);a(c),c<=0&&n()},200);return()=>clearInterval(u)},[s,e,o,n]),g.useEffect(()=>{!s||!e||a(o)},[s,e,o]);const l=o>0,d=l?`${Math.ceil(r/1e3)}s`:"";return t.jsx(tr,{in:e,onExited:i,mountOnEnter:!0,unmountOnExit:!0,children:t.jsx("div",{className:"position-fixed top-0 start-50 translate-middle-x mt-3",style:{zIndex:1200},children:t.jsxs(ai,{variant:s?.variant||"primary",className:"d-flex align-items-center gap-3 mb-0 px-4 py-3 text-nowrap",children:[t.jsx("div",{className:"fw-semibold",children:s?.message||""}),l?t.jsx("div",{className:"small opacity-75",children:d}):null]})})})}const hs=Ys.karaokeTransitionMs,$i=720,Ui=s=>new Promise(e=>setTimeout(e,s));function hl({onNavigate:s}){const e=xt(P=>P.screen),n=xt(P=>P.karaokeActive),i=xt(P=>P.karaokeMini),r=xt(P=>P.setScreen),a=xt(P=>P.setKaraokeMini),o=xt(P=>P.openKaraoke),[l,d]=g.useState({x:0,y:0,sx:1,sy:1}),m=g.useRef(null),u=g.useRef(null),h=g.useRef(null),[c,f]=g.useState({left:0,top:0,width:0,height:0}),b=Be(),p=Be(P=>P.setKaraokeView),x=gt(P=>P.resetPlayerScore),[S,N]=g.useState("idle"),w=g.useRef(!1),v=g.useRef(null),[_,R]=g.useState(!1),[k,E]=g.useState(0),se=Wt(P=>P.showKeyChangeAlert),F=Ot(P=>P.showAlert),z=Re(P=>P.refresh),j=Re(P=>P.status),L=Re(P=>P.accessToken),Y=Re(P=>P.isGuest),pe=Re(P=>P.user),ie=yt(P=>P.load),me=yt(P=>P.reset),de=g.useMemo(()=>e===V.karaoke&&n&&!i,[e,n,i]),I=!(e===V.karaoke&&n&&!i),q=e===V.karaoke||n,Q=e===V.karaoke&&!i?"full":e===V.home&&n?"mini":"parked",be=g.useCallback(P=>{s?s(P):window.location.assign(P)},[s]),He=g.useCallback(()=>{v.current&&(clearTimeout(v.current),v.current=null),R(!1)},[]),Me=g.useCallback(()=>{v.current&&clearTimeout(v.current),R(!0),v.current=setTimeout(()=>{v.current=null,R(!1)},$i)},[]),Ae=g.useCallback(P=>{He(),P!==V.karaoke&&n&&a(!0),r(P)},[He,n,a,r]);g.useEffect(()=>{if(!n||i||e!==V.karaoke)return;const P=()=>{Me(),a(!0),r(V.home)};return window.addEventListener("mousemove",P,{once:!0}),()=>window.removeEventListener("mousemove",P)},[n,i,e,a,r,Me]),g.useEffect(()=>()=>{v.current&&clearTimeout(v.current)},[]),g.useLayoutEffect(()=>{if(!n)return;const P=()=>{if(!m.current||!u.current)return;const ye=m.current.getBoundingClientRect(),Ge=u.current.getBoundingClientRect();if(f({left:Ge.left-ye.left,top:Ge.top-ye.top,width:Ge.width,height:Ge.height}),!h.current){d({x:0,y:0,sx:1,sy:1});return}const H=h.current.getBoundingClientRect(),ae=H.left-Ge.left,xe=H.top-Ge.top,je=H.width/Ge.width,Ve=H.height/Ge.height;d({x:ae,y:xe,sx:je,sy:Ve})};if(!m.current||!u.current)return;P();const Ke=new ResizeObserver(P),Oe=new ResizeObserver(P);Ke.observe(m.current),Oe.observe(u.current);const et=h.current?new ResizeObserver(P):null;return et&&h.current&&et.observe(h.current),window.addEventListener("resize",P),()=>{Ke.disconnect(),Oe.disconnect(),et&&et.disconnect(),window.removeEventListener("resize",P)}},[n,i,e]),g.useEffect(()=>{const P=Ns(),Ke=Oe=>{Oe.target.closest('button, a, [role="button"]')&&qr(async()=>{const{SFX:ye}=await Promise.resolve().then(()=>so);return{SFX:ye}},void 0).then(({SFX:ye})=>{P.playSfx(ye.SELECT).catch(()=>{})})};return window.addEventListener("click",Ke,{capture:!0}),()=>window.removeEventListener("click",Ke,{capture:!0})},[]),g.useEffect(()=>{z()},[z]),g.useEffect(()=>{if(j==="authenticated"&&L){ie(L).catch(()=>{});return}me()},[L,j,ie,me]);const Ce=g.useCallback(async P=>{w.current||(w.current=!0,N("in"),await Ui(hs),P&&await P(),N("out"),await Ui(hs),N("idle"),w.current=!1)},[]),ot=g.useCallback(async()=>{const P=Array.isArray(b.queue)&&b.queue.length>0;!b.midiName&&!P||(F({message:"演奏を停止しました",variant:"warning",timeoutMs:3e3}),await Ce(async()=>{x(),E(et=>et+1),await ee.stopAndAdvance({fadeMs:hs});const{queue:Ke,queueIndex:Oe}=qe();!Ke.length&&Oe<0?p("message"):p("singing")}))},[x,Ce,p,F,b.midiName,b.queue]);return t.jsxs("div",{className:"wiiHome",children:[t.jsx(dl,{}),t.jsx(vr,{}),t.jsxs(Zn,{className:`wiiHome__frame ${de?"wiiHome__frame--karaoke":""}`,fluid:"lg",ref:m,children:[t.jsx("header",{className:`wiiHome__top ${I?"":"wiiHome__top--hidden"}`,children:t.jsxs("div",{className:"wiiTopBar joyTopBar",children:[t.jsxs(_s,{className:"joyTopNav",variant:"tabs",activeKey:e,onSelect:P=>{P&&(P===V.home&&Ae(V.home),P===V.moreModes&&Ae(V.moreModes),P===V.settings&&Ae(V.settings),P===V.mySongs&&Ae(V.mySongs))},id:"joy-top-tabs",children:[t.jsx(Mt,{eventKey:V.home,title:"曲を選ぶ"}),t.jsx(Mt,{eventKey:V.moreModes,title:"採点"}),t.jsx(Mt,{eventKey:V.mySongs,title:"マイうた"}),t.jsx(Mt,{eventKey:V.settings,title:"設定"})]}),t.jsxs("div",{className:"joyTopStatus",children:[t.jsxs("div",{className:"joyTopUser",children:[t.jsx("div",{className:"joyTopUser__icon","aria-hidden":"true"}),t.jsx("div",{className:"joyTopUser__name",children:Y?"GUEST":j==="authenticated"?pe?.profile?.display_name||pe?.username||"USER":"GUEST"}),t.jsx("button",{className:"joyTopUser__switch",type:"button",onClick:()=>Ae(V.auth),children:"ユーザー切替"})]}),t.jsxs("div",{className:"joyTopSignal","aria-hidden":"true",children:[t.jsx("span",{}),t.jsx("span",{}),t.jsx("span",{}),t.jsx("span",{})]})]})]})}),t.jsx($o,{screen:e,onNavigate:Ae,onOpenKaraoke:o,karaokeTargetRef:h,mainRef:u}),q?t.jsx("div",{className:["karaokeDock",`karaokeDock--${Q}`,_?"karaokeDock--animate-resize":""].join(" "),style:{top:`${c.top}px`,left:`${c.left}px`,width:c.width?`${c.width}px`:"100%",height:c.height?`${c.height}px`:"100%","--karaoke-mini-x":`${l.x}px`,"--karaoke-mini-y":`${l.y}px`,"--karaoke-mini-sx":l.sx,"--karaoke-mini-sy":l.sy,"--karaoke-mini-transition-ms":`${$i}ms`},onClick:()=>{e!==V.home||!i||(Me(),o())},role:"button",tabIndex:Q==="parked"?-1:0,"aria-label":"Karaoke view","aria-hidden":Q==="parked",children:t.jsx("div",{className:"karaokeDock__move",children:t.jsx("div",{className:"karaokeDock__scale",style:{"--karaoke-transition-ms":`${hs}ms`},children:t.jsx(ul,{onStop:ot,resetKey:k,transitionPhase:S,displayMode:Q})})})}):null,t.jsx("footer",{className:`wiiHome__footer ${I?"":"wiiHome__footer--hidden"}`,children:t.jsxs("div",{className:"wiiFooterBar",children:[t.jsxs("div",{className:"wiiFooterGroup",children:[t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--dark",type:"button",children:"◀ 遅"}),t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--dark",type:"button",children:"速 ▶"}),t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--dark",type:"button",onClick:async()=>{await ee.resumeAudio(),ee.shiftTransposition(-1),se((b.transposition||0)-1)},children:"▼ ♭"}),t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--dark",type:"button",onClick:async()=>{await ee.resumeAudio(),ee.shiftTransposition(1),se((b.transposition||0)+1)},children:"▲ ♯"}),t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--dark",type:"button",onClick:async()=>{await ee.resumeAudio(),ee.setTransposition(0),se(0)},children:"原曲キー"}),t.jsx(D,{className:"wiiFooterBtn wiiFooterBtn--red",type:"button",onClick:ot,children:"演奏停止"})]}),t.jsxs("div",{className:"wiiFooterKaraokeControl","aria-label":"Transport",children:[t.jsxs(D,{className:"wiiFooterKaraokeControl__btn",type:"button",onClick:()=>ee.seek(Math.max(0,b.currentTime-5)),disabled:!b.midiName,children:["◀◀",t.jsx("span",{children:"巻戻し"})]}),t.jsxs(D,{className:"wiiFooterKaraokeControl__btn",type:"button",onClick:async()=>{await ee.resumeAudio(),b.isPlaying?ee.pause():ee.play()},disabled:!b.midiName,children:[b.isPlaying?"Ⅱ":"▶",t.jsx("span",{children:"一時停止"})]}),t.jsxs(D,{className:"wiiFooterKaraokeControl__btn",type:"button",onClick:()=>ee.seek(Math.min(b.duration||0,b.currentTime+5)),disabled:!b.midiName,children:["▶▶",t.jsx("span",{children:"早送り"})]})]}),t.jsxs("div",{className:"wiiFooterRight",children:[t.jsx(D,{className:"wiiFooterAction wiiFooterBtn--dark",type:"button",onClick:()=>be("/synth"),children:"DEBUG"}),t.jsx(D,{className:"wiiFooterAction wiiFooterBtn--blue",type:"button",children:"音量/操作"}),t.jsxs(D,{className:"wiiFooterAction wiiFooterBtn--green",type:"button",onClick:()=>Ae(V.queue),children:["予約確認 ",t.jsxs("span",{className:"wiiFooterAction__count",children:["(",b.queue.length,"曲)"]})]})]})]})})]})]})}function ml(){const s=Be(o=>o.ready),e=Be(o=>o.midiName),n=Be(o=>o.isPlaying),i=Be(o=>o.duration),r=Be(o=>o.currentTime),a=!!e&&s;return t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Playback"}),t.jsxs("div",{className:"d-flex flex-wrap gap-2 mb-2",children:[t.jsx(D,{onClick:()=>ee.play(),disabled:!a||n,variant:"outline-primary",type:"button",children:"Play"}),t.jsx(D,{onClick:()=>ee.pause(),disabled:!a||!n,variant:"outline-secondary",type:"button",children:"Pause"}),t.jsx(D,{onClick:()=>ee.stop(),disabled:!a,variant:"outline-danger",type:"button",children:"Stop"}),t.jsx(D,{onClick:()=>ee.panic(),disabled:!s,variant:"outline-secondary",type:"button",title:"Send All Notes Off / All Sound Off to all channels",children:"Panic!"})]}),t.jsx(A.Range,{min:0,max:Math.max(0,i),step:.01,value:Math.min(r,Math.max(0,i)),disabled:!a||i<=0,onChange:o=>ee.seek(Number(o.currentTarget.value))}),t.jsxs("div",{className:"small text-muted",children:[r.toFixed(2)," / ",i.toFixed(2)," s"]})]})}function fl({particleConfig:s,emit:e=!0,width:n=760,height:i=160,background:r=987413,className:a,style:o}){const l=g.useRef(null),d=g.useRef({app:null,bg:null,particleSystem:null,lastSize:{w:0,h:0},emit:e,config:s});return g.useEffect(()=>{d.current.emit=e},[e]),g.useEffect(()=>{d.current.config=s,d.current.particleSystem?.setConfig(s)},[s]),g.useEffect(()=>{let m=!0;return(async()=>{const h=l.current;if(!h)return;const c=new rr;if(await c.init({width:n,height:i,backgroundAlpha:0,antialias:!0,autoDensity:!0,resolution:window.devicePixelRatio||1,powerPreference:"high-performance",preference:"webgl"}),!m){c.destroy(!0);return}h.appendChild(c.canvas),c.canvas.style.width="100%",c.canvas.style.height="100%",c.canvas.style.display="block";const f=new _t,b=br(d.current.config);c.stage.addChild(f,b.container),d.current={app:c,bg:f,particleSystem:b,lastSize:{w:0,h:0},emit:d.current.emit,config:d.current.config},c.ticker.add(()=>{const p=d.current,x=p.app;if(!x)return;const S=Math.max(1,Math.floor(x.screen.width)),N=Math.max(1,Math.floor(x.screen.height));(p.lastSize.w!==S||p.lastSize.h!==N)&&(p.lastSize={w:S,h:N},p.bg.clear(),p.bg.setFillStyle({color:r,alpha:1}),p.bg.beginPath(),p.bg.rect(0,0,S,N),p.bg.fill(),p.particleSystem?.setBounds(x.screen));const w=x.ticker.lastTime/1e3,v=S*.5+Math.sin(w*1.6)*S*.08,_=N*.5+Math.cos(w*1.2)*N*.12;p.particleSystem?.update(x.ticker.deltaMS/1e3,p.emit,v,_)})})(),()=>{m=!1;const h=d.current.app,c=d.current.particleSystem;c&&c.destroy(),h&&h.destroy(!0),l.current&&(l.current.innerHTML=""),d.current={app:null,bg:null,particleSystem:null,lastSize:{w:0,h:0},emit:d.current.emit,config:d.current.config}}},[n,i,r]),g.useEffect(()=>{const m=d.current.app;m&&m.renderer.resize(n,i)},[n,i]),t.jsx("div",{ref:l,className:a,style:o})}const qn=8,Xi=1,gl="rgba(70, 32, 0, 0.75)",pl="rgba(110, 58, 0, 0.18)",xl="rgba(80, 45, 0, 0.8)",bl="rgba(80, 45, 0, 0.44)",Sl="rgba(70, 32, 0, 0.41)",yl="rgba(110, 58, 0, 0.1)";function Nl({levels:s,enabledChannels:e,height:n=64,isPlaying:i=!1,hasActivity:r=!1,className:a,style:o}){const l=g.useRef(null),d=g.useRef(null),m=g.useRef({levels:s,enabledChannels:e});return g.useEffect(()=>{m.current={levels:s,enabledChannels:e}},[s,e]),g.useEffect(()=>{const u=l.current,h=u?.getContext("2d",{alpha:!0});if(!u||!h)return;let c=!0,f=0;const b=()=>{const p=d.current;if(p){const j=Math.floor(p.clientWidth),L=Math.floor(n),Y=window.devicePixelRatio||1;(u.width!==j*Y||u.height!==L*Y)&&(u.width=j*Y,u.height=L*Y,u.style.width=j+"px",u.style.height=L+"px",h.scale(Y,Y))}const x=u.width/(window.devicePixelRatio||1),S=u.height/(window.devicePixelRatio||1);h.clearRect(0,0,x,S);const{levels:N,enabledChannels:w}=m.current,v=16,_=2,R=(x-(v-1)*_)/v,k=Math.max(4,R-2),E=0,se=12,z=(S-se-(qn-1)*Xi)/qn;h.font='bold 10px "VCR OSD Mono", "Courier New", monospace',h.textAlign="center",h.textBaseline="bottom";for(let j=0;j<v;j++){const L=E+j*(R+_)+R/2,Y=L-k/2,pe=N&&N[j]!=null?N[j]:0,ie=w?w[j]!==!1:!0,me=ie?gl:Sl,de=ie?pl:yl,I=ie?xl:bl;h.fillStyle=I,h.fillText(`${j+1}`,L,S);const q=Math.max(0,Math.min(qn,Math.ceil(pe*qn)));for(let Q=0;Q<qn;Q++){const be=S-se-(Q+1)*z-Q*Xi;h.fillStyle=Q<q?me:de,h.fillRect(Y,be,k,z)}}c&&i&&r&&(f=requestAnimationFrame(b))};return b(),()=>{c=!1,cancelAnimationFrame(f)}},[n,i,r]),t.jsx("div",{ref:d,className:a,style:{...o,width:"100%",height:n},children:t.jsx("canvas",{ref:l,style:{display:"block"}})})}const Ws={};function wl(s){if(Ws[s])return Ws[s];const e=Math.log2(s);if(Math.floor(e)!==e)throw new Error("FFT size must be power of 2");const n=new Int32Array(s);for(let o=0;o<s;o++){let l=0,d=o;for(let m=0;m<e;m++)l=l<<1|d&1,d>>=1;n[o]=l}const i=new Float32Array(s/2),r=new Float32Array(s/2);for(let o=0;o<s/2;o++){const l=-2*Math.PI*o/s;i[o]=Math.cos(l),r[o]=Math.sin(l)}const a={bitRev:n,cosTable:i,sinTable:r,size:s};return Ws[s]=a,a}function vl(s,e){const n=s.length;if((n&n-1)!==0)return;const{bitRev:i,cosTable:r,sinTable:a}=wl(n),o=new Float32Array(n),l=new Float32Array(n);for(let m=0;m<n;m++)o[m]=s[i[m]],l[m]=0;for(let m=1;m<n;m<<=1){const u=n/(m*2);for(let h=0;h<n;h+=m*2)for(let c=0;c<m;c++){const f=c*u,b=r[f],p=a[f],x=b*o[h+c+m]-p*l[h+c+m],S=b*l[h+c+m]+p*o[h+c+m];o[h+c+m]=o[h+c]-x,l[h+c+m]=l[h+c]-S,o[h+c]=o[h+c]+x,l[h+c]=l[h+c]+S}}const d=n/2;for(let m=0;m<=d;m++){const u=o[m],h=l[m];e[m]=20*Math.log10(Math.sqrt(u*u+h*h)+1e-6)}}function $s({data:s,height:e=80,color:n="#4ec3ff",background:i="#0f1115"}){const r=g.useRef(null),a=g.useRef(null),[o,l]=g.useState({width:0,height:0});return g.useEffect(()=>{const d=r.current;if(!d)return;const m=new ResizeObserver(u=>{for(const h of u){const{width:c,height:f}=h.contentRect;l({width:c,height:f||e})}});return m.observe(d),()=>m.disconnect()},[e]),g.useEffect(()=>{const d=a.current;if(!d||!s||!o.width)return;const m=1024;if(s.length===0)return;const u=new Float32Array(m),h=Math.max(0,s.length-m),c=Math.min(s.length,m);if(c>1)for(let k=0;k<c;k++){const E=.5*(1-Math.cos(2*Math.PI*k/(c-1)));u[k]=s[h+k]*E}else c===1&&(u[0]=s[h]);const f=new Float32Array(m/2+1);try{vl(u,f)}catch(k){console.error(k);return}const b=d.getContext("2d"),p=o.width,x=o.height;d.width=p,d.height=x,b.fillStyle=i,b.fillRect(0,0,p,x),b.strokeStyle=n,b.lineWidth=1.5,b.beginPath();const S=f.length;let N=-100;for(let k=0;k<S;k++)f[k]>N&&(N=f[k]);const w=60,v=-40,_=w-v;let R=!0;for(let k=0;k<S;k++){const E=k/S*p;let F=(f[k]-v)/_;F=Math.max(0,Math.min(1,F));const z=x-F*x;R?(b.moveTo(E,z),R=!1):b.lineTo(E,z)}b.stroke()},[s,o,n,i]),t.jsx("div",{ref:r,style:{width:"100%",height:e,background:i,overflow:"hidden"},children:t.jsx("canvas",{ref:a,style:{display:"block"}})})}const _l="data:image/svg+xml,%3c?xml%20version='1.0'%20encoding='utf-8'?%3e%3c!--%20Generator:%20Adobe%20Illustrator%2021.0.0,%20SVG%20Export%20Plug-In%20.%20SVG%20Version:%206.00%20Build%200)%20--%3e%3csvg%20version='1.1'%20id='_x3C_图层_x3E_'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20x='0px'%20y='0px'%20viewBox='0%200%20105%2075.8'%20style='enable-background:new%200%200%20105%2075.8;'%20xml:space='preserve'%3e%3cg%3e%3cpath%20d='M0.6,59.1V19.1h33.4c3.4,0,5,2.3,5,4.9v35.1h-9.3V28.6h-5.3v30.4h-9.2V28.6h-5.2v30.4H0.6z'/%3e%3crect%20x='43.8'%20y='19.1'%20width='9.7'%20height='39.9'/%3e%3cpath%20d='M58,19.1h27.7c2.8,0,4.7,2,4.7,4.8v30.3c0,2.9-2.6,4.9-4.7,4.9H58V34.4h9.4v15h13.7V28.9H58V19.1z'/%3e%3crect%20x='95.2'%20y='19.1'%20width='9.7'%20height='39.9'/%3e%3crect%20x='0.6'%20y='62.5'%20width='104.4'%20height='13.2'/%3e%3cg%3e%3cpath%20d='M2.7,8c0,0.9,0.1,1.7,0.4,2.4c0.2,0.7,0.6,1.3,1,1.8S5,13,5.5,13.2c0.6,0.2,1.1,0.4,1.8,0.4c0.5,0,1-0.1,1.5-0.3%20c0.5-0.2,0.9-0.5,1.3-0.9c0.4-0.4,0.7-0.8,1-1.3c0.3-0.5,0.4-1,0.5-1.6H7V7.1h7.3v8.4h-2L12,13.8c-0.3,0.3-0.6,0.6-1,0.8%20c-0.4,0.3-0.8,0.5-1.2,0.7c-0.4,0.2-0.8,0.4-1.2,0.5S7.8,16,7.3,16c-1.1,0-2.2-0.2-3.1-0.6s-1.7-1-2.3-1.7%20c-0.6-0.7-1.1-1.6-1.5-2.5C0.2,10.2,0,9.1,0,8C0,7,0.2,6,0.5,5.1c0.3-1,0.8-1.8,1.4-2.6c0.6-0.8,1.4-1.4,2.3-1.8S6.1,0,7.2,0%20c1,0,1.9,0.1,2.6,0.4c0.8,0.3,1.5,0.7,2,1.1s1.1,1.1,1.5,1.7s0.7,1.4,1,2.2h-2.8c-0.4-1.1-0.9-1.8-1.6-2.4%20C9.2,2.6,8.3,2.3,7.2,2.3C6.6,2.3,6,2.5,5.4,2.8C4.8,3.1,4.4,3.5,4,4C3.5,4.5,3.2,5.1,3,5.8C2.8,6.5,2.7,7.2,2.7,8z'/%3e%3cpath%20d='M28.9,0.4v2.4h-8.4v3.8h7.9V9h-7.9v4.2h8.8v2.4H17.8V0.4H28.9z'/%3e%3cpath%20d='M35.6,0.4l6.8,10.8V0.4H45v15.2h-3L35.2,4.8v10.8h-2.7V0.4H35.6z'/%3e%3cpath%20d='M59.5,0.4v2.4h-8.4v3.8H59V9h-7.9v4.2h8.8v2.4H48.4V0.4H59.5z'/%3e%3cpath%20d='M74.9,5c0,0.6-0.1,1.2-0.4,1.8c-0.3,0.6-0.6,1.1-1.1,1.5c0.3,0.2,0.5,0.3,0.7,0.5c0.2,0.2,0.3,0.4,0.4,0.7%20c0.1,0.3,0.2,0.5,0.2,0.8c0,0.3,0,0.6,0,0.9v2.1c0,0.2,0.1,0.6,0.2,1c0.2,0.4,0.4,0.8,0.6,1.2h-3c-0.2-0.4-0.4-0.8-0.5-1.2%20c-0.1-0.4-0.1-0.7-0.1-1v-2.3c0-0.2,0-0.4-0.1-0.6c-0.1-0.2-0.2-0.4-0.4-0.5c-0.2-0.2-0.4-0.3-0.7-0.4c-0.3-0.1-0.6-0.2-1-0.2h-4%20v6.1h-2.7V0.4h6.7c0.8,0,1.5,0.1,2.2,0.4c0.6,0.3,1.2,0.6,1.6,1.1c0.4,0.4,0.8,0.9,1,1.5C74.8,3.9,74.9,4.4,74.9,5z%20M65.8,7.1h4%20c0.3,0,0.6-0.1,0.9-0.2c0.3-0.1,0.5-0.3,0.8-0.5c0.2-0.2,0.4-0.4,0.5-0.7s0.2-0.6,0.2-0.9c0-0.6-0.2-1.1-0.7-1.5%20c-0.4-0.4-1-0.6-1.7-0.6h-4V7.1z'/%3e%3cpath%20d='M86.4,0.4l5.9,15.2h-2.8l-1.7-4.3h-5.6l-1.7,4.3h-2.9l5.9-15.2H86.4z%20M84.9,3.9l-1.9,5h3.9L84.9,3.9z'/%3e%3cpath%20d='M97.3,0.4v12.8h7.6v2.4H94.6V0.4H97.3z'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",kl="/assets/gs-CvX8pS-a.svg",Ml="/assets/xg-BT7SdrUj.svg",Cl="/assets/sc-4yYAHMs7.png",jl=new URL("/assets/sc55-C8Cgxxnd.mid",import.meta.url).toString(),Tl=s=>s===240||s===247,Fl=s=>Number(s).toString(16).padStart(2,"0").toUpperCase(),Rl=s=>[s.status,...s.data].map(Fl).join(" "),ri=(s,e,n)=>Math.min(n,Math.max(e,s)),ms=180/Math.PI,Yi=Math.PI/180,Bl=8;Array.from({length:Bl},(s,e)=>e);const Qi=.12,Al=.65,Pl="rgba(70, 32, 0, 0.75)",El="rgba(110, 58, 0, 0.18)",Ji=s=>`#${ri(Number(s)||0,0,16777215).toString(16).padStart(6,"0")}`,Zi=(s,e)=>{if(typeof s!="string")return e;let n=s.trim();if(n.startsWith("#")&&(n=n.slice(1)),n.length===3&&(n=n.split("").map(r=>r+r).join("")),n.length!==6)return e;const i=Number.parseInt(n,16);return Number.isNaN(i)?e:i},Ll=s=>{const e=Array.isArray(s?.data)?s.data.slice():[];if(!e.length)return"SysEx";if(e[e.length-1]===247&&e.pop(),e.length>=4&&e[0]===126&&e[1]===127&&e[2]===9){if(e[3]===1)return"GM System On";if(e[3]===2)return"GM System Off";if(e[3]===3)return"GM2 System On"}return e.length>=9&&e[0]===65&&e[2]===66&&e[3]===18&&e[4]===64&&e[5]===0&&e[6]===127&&e[7]===0?"GS Reset":e.length>=7&&e[0]===67&&e[2]===76&&e[3]===0&&e[4]===0&&e[5]===126&&e[6]===0?"XG System On":e[0]===65?"Roland SysEx":e[0]===67?"Yamaha SysEx":e[0]===126?"Universal SysEx":e[0]===127?"Universal Real-Time SysEx":"SysEx"},fs=s=>{if(!s?.tracks?.length)return[];const e=[];return s.tracks.forEach((n,i)=>{const r=n?.events||[];Array.isArray(r)&&r.forEach(a=>{const o=Number(a?.statusByte);if(!Number.isFinite(o)||!Tl(o))return;const l=a?.data?Array.from(a.data):[];e.push({trackIndex:i,ticks:Number(a?.ticks)||0,status:o,data:l})})}),e},Il=(s,e={})=>{const n=Array.isArray(s?.rawNotes)&&s.rawNotes.length?s.rawNotes:s?.notes;if(!n?.length)return null;const i=Number.isFinite(e.width)?e.width:760,r=Number.isFinite(e.height)?e.height:180,a=Number.isFinite(s.timeDivision)&&s.timeDivision>0?s.timeDivision:480;let o=1/0,l=-1/0,d=0;n.forEach(w=>{const v=Number(w.midi);if(!Number.isFinite(v))return;const _=Number(w.t1Tick);Number.isFinite(_)&&(d=Math.max(d,_)),o=Math.min(o,v),l=Math.max(l,v)}),(!Number.isFinite(o)||!Number.isFinite(l)||o===l)&&(o=48,l=72);let m=0;const u=Array.isArray(s.tempoChanges)?s.tempoChanges:[];u.length&&Number.isFinite(s.timeDivision)&&u.forEach(w=>{const v=Number(w?.ticks);Number.isFinite(v)&&(m=Math.max(m,v))});const h=Math.max(1,Math.ceil(Math.max(d,m))),c=Math.max(1,Math.ceil(h/a)),f=Number.isFinite(e.maxBeatLines)?Math.max(1,e.maxBeatLines):2e3,b=Math.max(1,Math.ceil(c/f)),p=[];for(let w=0;w<=c;w+=b)p.push({beat:w,tick:w*a});const x=[],S=[],N=[];if(u.length&&Number.isFinite(s.timeDivision)){u.map(_=>({ticks:Number(_?.ticks),tempo:Number(_?.tempo)})).filter(_=>Number.isFinite(_.ticks)).sort((_,R)=>_.ticks-R.ticks).forEach((_,R)=>{const k=Number(_?.ticks);if(!Number.isFinite(k))return;const E=k/a;x.push({tick:k,tempo:Number(_?.tempo)}),N.push({index:R,ticks:k,beat:E,tempo:Number(_?.tempo)})});const v=x.slice().sort((_,R)=>_.tick-R.tick);for(let _=0;_<v.length;_+=1){const R=v[_].tick,k=_+1<v.length?v[_+1].tick:h;!Number.isFinite(R)||!Number.isFinite(k)||S.push({startTick:R,endTick:k,tempo:v[_].tempo})}}return{width:i,height:r,ticksPerBeat:a,totalTicks:h,totalBeats:c,maxNoteTick:d,maxTempoTick:m,minMidi:o,maxMidi:l,beatAxisLines:p,tempoLinesTick:x,tempoSegmentsTick:S,tempoDebug:N,notes:n}};function Dl({onNavigateHome:s}){const e=Be(),n=e.midiMapState?.detectedStandard,i=n==="GM2"||n==="SMF"?"GM":n,r=i==="XG",a=i==="GS",o=i==="GM",l=e.midiMapState?.detectedModule,d=l==="55"||l==="88"||l==="88PRO",m=y=>({opacity:y?.7:.1,color:y?Pl:El}),[u,h]=g.useState(""),[c,f]=g.useState(null),[b,p]=g.useState([]),[x,S]=g.useState(!1),[N,w]=g.useState(Ne.windowSize),[v,_]=g.useState(Ne.hopSize),[R,k]=g.useState(Ne.rmsGate),[E,se]=g.useState(0),[F,z]=g.useState(300),[j,L]=g.useState(Ne.micConstraints?.echoCancellation??!1),[Y,pe]=g.useState(Ne.micConstraints?.noiseSuppression??!1),[ie,me]=g.useState(Ne.micConstraints?.autoGainControl??!1),[de,I]=g.useState(Ne.enableDoubleExponentialSmoothing),[q,Q]=g.useState(Ne.pitchAlgoId),[be,He]=g.useState(Ne.enableDcRemoval!==!1),[Me,Ae]=g.useState(Ne.enableHpf!==!1),[Ce,ot]=g.useState(Ne.enableRmsGate!==!1),[P,Ke]=g.useState(Ne.enableF0Validate!==!1),[Oe,et]=g.useState(Ne.enableTemporalSmooth!==!1),[ye,Ge]=g.useState(!!Ne.debugPipeline),[H,ae]=g.useState(Math.max(1,Number(Ne.debugPipelineStride)||4)),[xe,je]=g.useState(!1),[Ve,we]=g.useState(!1),[De,Ue]=g.useState(!1),[ke,Ct]=g.useState(!0),[te,ue]=g.useState(()=>vs(Mn)),[ze,Yt]=g.useState({stages:{},metrics:{},sampleRate:null}),[wt,mn]=g.useState({raw:new Float32Array(0),post:new Float32Array(0)}),[Xe,ct]=g.useState(null),[Ye,Qt]=g.useState({songTimeSec:0,targetMidi:null,targetPitchClass:null,userMidi:null,userPitchClass:null,pitchErrorCents:null,f0Hz:null,confidence:0,rms:0,algoName:"n/a",micSampleRate:null}),Et=g.useRef(null),rn=g.useRef(null),bt=g.useRef([]),Gt=g.useRef([]),vt=g.useRef(0),zt=g.useRef(0),an=g.useRef(!1),Lt=g.useRef([]),M=g.useRef([]),Se=Xt,Qe=g.useMemo(()=>Se.listDetectors(),[Se]),Te=ze.stages||{},it=ze.metrics||{},J=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"],re=(y,C=2)=>Number.isFinite(y)?y.toFixed(C):"n/a",ut=y=>{const C=Number(y);return Number.isFinite(C)?(Math.round(C)%12+12)%12:null},fe=y=>{const C=ut(y);return C==null?"n/a":`${J[C]} (pc ${C})`},We=g.useCallback(async()=>{try{await xr();const y=Se.ensureDebugAnalyser?.({fftSize:2048,smoothingTimeConstant:0,enableHpf:Me,hpfCutoffHz:Ne.hpfCutoffHz});y||console.warn("[Synth] debugAnalyser not ready after start"),y&&y instanceof AnalyserNode&&y.frequencyBinCount>0?ct(y):(console.warn("[Synth] Got invalid debugAnalyser from startMic",y),ct(null));const C=Se.getAudioContext?.();Qt(T=>({...T,micSampleRate:C?.sampleRate??null})),S(!0)}catch(y){console.error(y)}},[Me,Se]),Je=g.useCallback(()=>{ti(),Qt(y=>({...y,micSampleRate:null})),S(!1)},[]),W=g.useMemo(()=>Il(c,{width:760,height:180,maxBeatLines:2e3}),[c]);g.useEffect(()=>{W&&(console.log("[Beatmap Debug] reference stats",{ticksPerBeat:W.ticksPerBeat,totalTicks:W.totalTicks,maxNoteTick:W.maxNoteTick,maxTempoTick:W.maxTempoTick,notes:W.notes.length,tempoChanges:Array.isArray(c?.tempoChanges)?c.tempoChanges.length:0,totalBeats:W.totalBeats}),W.tempoDebug?.length&&console.log("[Beatmap Debug] tempo changes",W.tempoDebug))},[W,c]);const jn=(y,C,T)=>{if(!y)return T;const Z=getComputedStyle(y).getPropertyValue(C);return Z?Z.trim():T};g.useEffect(()=>{const y=Se.onPitch(C=>{Et.current=C;const T=vt.current;if(!Number.isFinite(T))return;const Z=Number.isFinite(C?.tAcSec)?Number(C.tAcSec):null,ne=Gt.current;ne.push({t:T,tAcSec:Z,f0Hz:Number.isFinite(C?.f0Hz)?Number(C.f0Hz):null,rawF0Hz:Number.isFinite(C?.rawF0Hz)?Number(C.rawF0Hz):null,confidence:Number.isFinite(C?.confidence)?Number(C.confidence):0,rawConfidence:Number.isFinite(C?.rawConfidence)?Number(C.rawConfidence):0,rms:C?.rms??null});const O=(Number.isFinite(Z)?Z:T)-12;for(;ne.length;){const _e=ne[0],Fe=Number.isFinite(_e?.tAcSec)?_e.tAcSec:_e?.t;if(!Number.isFinite(Fe)||Fe>=O)break;ne.shift()}ne.length>4096&&ne.splice(0,ne.length-4096)});return()=>{y()}},[Se]),g.useEffect(()=>{an.current=x},[x]),g.useEffect(()=>{Se.configureDetector({micConstraints:{echoCancellation:!!j,noiseSuppression:!!Y,autoGainControl:!!ie}}),an.current&&(Je(),We())},[j,Y,ie,Se,We,Je]),g.useEffect(()=>{vt.current=e.currentTime},[e.currentTime]),g.useEffect(()=>{zt.current=Number(e.transposition)||0},[e.transposition]),g.useEffect(()=>{Se.configureDetector({windowSize:N,hopSize:v,rmsGate:R,enableDoubleExponentialSmoothing:de,enableDcRemoval:be,enableHpf:Me,enableRmsGate:Ce,enableF0Validate:P,enableTemporalSmooth:Oe,debugPipeline:ye,debugPipelineStride:H})},[Se,N,v,R,de,be,Me,Ce,P,Oe,ye,H]),g.useEffect(()=>{if(!x){ct(null);return}let y=!1;const C=()=>{if(y)return;const T=Se.ensureDebugAnalyser?.({fftSize:2048,smoothingTimeConstant:0,enableHpf:Me,hpfCutoffHz:Ne.hpfCutoffHz});if(!T){console.warn("[Synth] debugAnalyser not ready, retrying..."),window.setTimeout(C,200);return}T instanceof AnalyserNode&&T.frequencyBinCount>0?ct(T):(console.warn("[Synth] debugAnalyser invalid on attach",T),window.setTimeout(C,200))};return C(),()=>{y=!0}},[Se,x,Me]),g.useEffect(()=>{if(!Xe||!x)return()=>{};const y=new Uint8Array(Xe.frequencyBinCount||1);let C=0,T=0;const Z=()=>{C=window.requestAnimationFrame(Z);const ne=performance.now();if(ne-T<500)return;T=ne,Xe.getByteFrequencyData(y);let he=0,O=0;for(let Fe=0;Fe<y.length;Fe+=1){const rt=y[Fe];rt>he&&(he=rt),O+=rt}const _e=y.length?O/y.length:0;console.debug("[debugAnalyser]",{bins:y.length,max:Math.round(he),avg:Math.round(_e)})};return Z(),()=>{C&&window.cancelAnimationFrame(C)}},[Xe,x]),g.useEffect(()=>{if(!e.midiName){p([]);return}let y=!0;return ee.getMidiData().then(C=>{y&&p(C?fs(C):[])}).catch(()=>{y&&p([])}),()=>{y=!1}},[e.midiName,e.midiUrl,e.queueIndex]),g.useEffect(()=>{Se.setDetector(q)},[Se,q]),g.useEffect(()=>{if(!x)return;const y=Se.onDebug(C=>{const T=Number.isFinite(C?.metrics?.rawF0Hz)?C.metrics.rawF0Hz:0,Z=Number.isFinite(C?.metrics?.result?.f0Hz)?C.metrics.result.f0Hz:0,ne=Lt.current.slice();ne.push(T),ne.length>160&&ne.shift(),Lt.current=ne;const he=M.current.slice();he.push(Z),he.length>160&&he.shift(),M.current=he;const O=_e=>new Float32Array(_e.map(Fe=>Math.max(-1,Math.min(1,Fe/1e3*2-1))));mn({raw:O(ne),post:O(he)}),Yt({stages:C?.stages||{},metrics:C?.metrics||{},sampleRate:Number.isFinite(C?.sampleRate)?C.sampleRate:null})});return()=>{y()}},[Se,x]),g.useEffect(()=>{if(!e.isPlaying||!x)return;const y=window.setInterval(()=>{const C=Math.max(0,vt.current+E/1e3),T=c?rc(c,C):null,Z=T!=null?T+zt.current:null,ne=Et.current,he=ne?.midi??null,O=Number.isFinite(he)&&Number.isFinite(ne?.rms)&&ne.rms>=R?Number(he):null,_e=Z!=null&&O!=null?Mo(O,Z):null,Fe=Qe.find(Jt=>Jt.id===(ne?.algoId??q))?.name||"n/a";Qt(Jt=>({...Jt,songTimeSec:C,targetMidi:Z,targetPitchClass:ut(Z),userMidi:O,userPitchClass:ut(O),pitchErrorCents:_e,f0Hz:ne?.f0Hz??null,confidence:ne?.confidence??0,rms:ne?.rms??0,algoName:Fe}));const rt=bt.current;rt.push({t:C,userMidi:O,targetMidi:Z,rms:ne?.rms??null,f0Hz:Number.isFinite(ne?.f0Hz)?Number(ne.f0Hz):null,confidence:Number.isFinite(ne?.confidence)?Number(ne.confidence):0});const ht=2e3;rt.length>ht&&rt.splice(0,rt.length-ht)},16);return()=>window.clearInterval(y)},[c,E,Qe,q,x,e.isPlaying]),g.useEffect(()=>{if(!e.isPlaying)return;let y=0;const C=36,T=96,Z=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"],ne=()=>{const he=rn.current;if(!he){y=window.requestAnimationFrame(ne);return}const O=he.getContext("2d");if(!O){y=window.requestAnimationFrame(ne);return}const _e=he.width,Fe=he.height;O.clearRect(0,0,_e,Fe),O.fillStyle="#0f1115",O.fillRect(0,0,_e,Fe);const rt=T-C,ht=Fe/Math.max(1,rt),Jt=Math.max(1,Math.ceil(14/Math.max(1,ht))),Ts=jn(he,"--synth-miss-note-fill","#090909"),es=jn(he,"--synth-miss-note-stroke","#ffffff"),ui=jn(he,"--synth-miss-note-shadow","rgba(0,0,0,0.45)");O.lineWidth=1;for(let Ze=C;Ze<=T;Ze+=1){const nt=Fe-(Ze-C+1)*ht,Tt=Ze%12===0;O.strokeStyle=Tt?"rgba(30, 30, 30, 0.9)":"rgba(255,255,255,0.12)",O.beginPath(),O.moveTo(0,nt),O.lineTo(_e,nt),O.stroke();const Ft=Math.floor(Ze/12)-1,It=`${Z[Ze%12]}${Ft}`;if(Ze%Jt===0){O.fillStyle=Tt?"rgba(20, 20, 20, 0.9)":"rgba(90, 140, 255, 0.9)",O.font=Tt?"12px system-ui":"11px system-ui",O.fillText(It,6,nt-2);const bn=O.measureText(It).width;O.fillText(It,_e-bn-6,nt-2)}}const Ee=bt.current,mt=_e/Math.max(1,240-1),ft=(Ze,nt,Tt,Ft=!1)=>{if(Ze==null)return;const It=Number(Ze);if(!Number.isFinite(It))return;const bn=Math.max(C,Math.min(T,It)),Zt=Fe-(bn-C+.5)*ht;if(Ft){const Sn=Math.max(6,mt*.6),Rt=Math.max(4,ht*.45),Fs=Math.min(6,Rt/2);O.save(),O.fillStyle=Ts,O.strokeStyle=es,O.lineWidth=1,O.shadowColor=ui,O.shadowBlur=6,O.beginPath(),O.roundRect(nt-Sn/2,Zt-Rt/2,Sn,Rt,Fs),O.fill(),O.shadowBlur=0,O.stroke(),O.restore()}else O.fillStyle=Tt,O.beginPath(),O.arc(nt,Zt,2,0,Math.PI*2),O.fill()};Ee.forEach((Ze,nt)=>{const Tt=nt*mt;ft(Ze.targetMidi,Tt,"rgba(70, 210, 120, 0.6)",Ze.userMidi==null),ft(Ze.userMidi,Tt,"rgba(255, 255, 255, 0.9)")});const xn=(Ee.length?Ee[Ee.length-1]:null)?.userMidi;if(Number.isFinite(Number(xn))){const Ze=Math.max(C,Math.min(T,Number(xn))),nt=Fe-(Ze-C+.5)*ht;O.strokeStyle="rgba(255, 255, 255, 0.8)",O.lineWidth=2,O.beginPath(),O.moveTo(0,nt),O.lineTo(_e,nt),O.stroke(),O.fillStyle="rgba(255, 255, 255, 0.95)",O.beginPath(),O.arc(6,nt,5,0,Math.PI*2),O.fill(),O.beginPath(),O.arc(_e-6,nt,5,0,Math.PI*2),O.fill()}y=window.requestAnimationFrame(ne)};return y=window.requestAnimationFrame(ne),()=>window.cancelAnimationFrame(y)},[e.isPlaying]),g.useEffect(()=>()=>ti(),[Se]),g.useEffect(()=>{if(!e.ready||!e.midiName){f(null);return}let y=!0;return ee.getMidiData().then(C=>{y&&f(C?Vn(C,{channel:0}):null)}).catch(()=>{y&&f(null)}),()=>{y=!1}},[e.ready,e.midiName,e.midiUrl,e.queueIndex]);const Tn=y=>{if(!Array.isArray(y))return"—";const C=[];return y.forEach((T,Z)=>{T&&C.push(Z+1)}),C.length?C.join(", "):"—"},fn=g.useMemo(()=>{const y=Array.isArray(e.channelActivityTime)?e.channelActivityTime:[],C=Array.isArray(e.channelActivityVelocity)?e.channelActivityVelocity:[],T=Number(e.currentTime)||0;return Array.from({length:16},(Z,ne)=>{const he=Number(y[ne]),O=ri(Number(C[ne])||0,0,1);if(!Number.isFinite(he)||he<0||T<he)return 0;const _e=T-he;if(_e<=Qi)return O;const Fe=(_e-Qi)/Al;return ri(O*(1-Fe),0,1)})},[e.channelActivityTime,e.channelActivityVelocity,e.currentTime]),{activeTechniques:dt,techniqueHistory:Fn}=_r(Xt,vt,x),[gn,pn]=g.useState("pitch-debug"),Rn=e.isPlaying&&Array.isArray(fn)&&fn.some(y=>y>0);return t.jsxs(Zn,{className:"py-3 synthDebug",style:{maxWidth:860},children:[t.jsxs("div",{className:"d-flex justify-content-between align-items-center mb-3",children:[t.jsx("h1",{className:"h4 m-0",children:"SynthEngine"}),t.jsxs("div",{className:"d-flex gap-2",children:[t.jsx(D,{variant:"secondary",onClick:s,type:"button",children:"Back"}),t.jsx(D,{variant:"outline-primary",onClick:()=>ee.resumeAudio(),disabled:!e.ready,type:"button",children:"Resume Audio"})]})]}),t.jsxs("div",{className:"mb-3",children:[t.jsx("div",{className:"small text-muted",children:"Status"}),t.jsx("div",{children:e.status})]}),t.jsxs(Pe,{className:"g-3",children:[t.jsx(X,{xs:12,children:t.jsx("div",{className:"p-3 border rounded-3",children:t.jsx("div",{className:"d-flex justify-content-between align-items-center",children:t.jsxs("div",{children:[t.jsx("div",{className:"fw-semibold",children:"SoundFont"}),t.jsx("div",{className:"small text-muted",children:e.soundFontName})]})})})}),t.jsx(X,{xs:12,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"MIDI"}),t.jsxs(Pe,{className:"g-2 align-items-center",children:[t.jsx(X,{xs:12,md:!0,children:t.jsx(A.Control,{placeholder:"MIDI URL (e.g. /songs/demo.mid)",value:u,onChange:y=>h(y.target.value)})}),t.jsx(X,{xs:"auto",children:t.jsx(D,{onClick:async()=>{await ee.resumeAudio(),await ee.loadMidiFromUrl(u);const y=await ee.getMidiData();y?(f(Vn(y,{channel:0})),p(fs(y))):(f(null),p([]))},disabled:!u||!e.ready,type:"button",children:"Load URL"})}),t.jsx(X,{xs:"auto",children:t.jsx(D,{variant:"outline-secondary",onClick:async()=>{await ee.resumeAudio(),await ee.loadMidiFromUrl(jl);const y=await ee.getMidiData();y?(f(Vn(y,{channel:0})),p(fs(y))):(f(null),p([]))},disabled:!e.ready,type:"button",children:"DEMO"})}),t.jsx(X,{xs:12,md:"auto",children:t.jsx(A.Control,{type:"file",accept:".mid,.midi",onChange:async y=>{const C=y.target.files?.[0];if(!C)return;await ee.resumeAudio(),await ee.loadMidiFromFile(C);const T=await ee.getMidiData();T?(f(Vn(T,{channel:0})),p(fs(T))):(f(null),p([]))},disabled:!e.ready})})]}),t.jsxs("div",{className:"small text-muted mt-2",children:["Loaded: ",e.midiName||"—"]}),t.jsxs("div",{className:"small text-muted mt-2",children:["SysEx (",b.length,")"]}),b.length?t.jsx("div",{className:"small mt-1",style:{maxHeight:140,overflowY:"auto"},children:b.map((y,C)=>t.jsxs("div",{children:["T",y.trackIndex+1," @ ",y.ticks,": ",Ll(y)," ·"," ",Rl(y)]},`${y.trackIndex}-${y.ticks}-${C}`))}):t.jsx("div",{className:"small text-muted mt-1",children:"SysEx: none"})]})}),t.jsx(X,{xs:12,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"MIDI Standard Mapping"}),t.jsx(Pe,{className:"g-2 align-items-center",children:t.jsx(X,{xs:12,md:12,children:t.jsx(A.Check,{type:"switch",id:"midi-map-enabled",label:"Enable auto-mapping",checked:!!e.enableMIDIStandardMapping,onChange:y=>ee.setEnableMIDIStandardMapping(y.currentTarget.checked)})})}),t.jsxs("div",{className:"small text-muted mt-2",children:["Detected Standard: ",e.midiMapState?.detectedStandard||"unknown"]}),t.jsxs("div",{className:"small text-muted",children:["Detected Module: ",e.midiMapState?.detectedModule||"—"]}),t.jsxs("div",{className:"small text-muted",children:["Active Config: ",e.midiMapState?.configName||"None"]}),t.jsxs("div",{className:"small text-muted",children:["Current Mode: ",e.midiMapState?.globalMode||"unknown"]}),t.jsxs("div",{className:"small text-muted",children:["Detected by: ",e.midiMapState?.detectedBy||"—"]}),t.jsxs("div",{className:"small text-muted",children:["Drum channels: ",Tn(e.midiChannels?.map(y=>y?.isDrum))]}),t.jsxs("div",{className:"small text-muted",children:["Brush channels: ",Tn(e.midiMapState?.brushChannels)]})]})}),t.jsx(X,{xs:12,children:t.jsx(ml,{})}),t.jsx(X,{xs:12,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsxs("div",{className:"d-flex align-items-center justify-content-between mb-2",children:[t.jsx("div",{className:"fw-semibold",children:"Sound Canvas LCD"}),t.jsx("div",{className:"small text-muted",children:"Channel Activity"})]}),t.jsxs("div",{className:"sc-lcd",children:[t.jsxs("div",{className:"sc-lcd__meta",children:[t.jsxs("div",{className:"sc-lcd__metaLabel",children:["POLY:",e.polyphonyCount??0]}),t.jsxs("div",{className:"sc-lcd__metaMarks",children:[t.jsx("img",{src:Cl,alt:"Sound Canvas",className:"sc-lcd__metaIcon sc-lcd__metaIcon--sc",style:m(d)}),t.jsx("img",{src:kl,alt:"GS",className:"sc-lcd__metaIcon",style:m(a)}),t.jsx("img",{src:Ml,alt:"XG",className:"sc-lcd__metaIcon",style:m(r)}),t.jsx("img",{src:_l,alt:"GM",className:"sc-lcd__metaIcon",style:m(o)})]})]}),t.jsx(Nl,{levels:fn,enabledChannels:e.enabledChannels,height:64,isPlaying:e.isPlaying,hasActivity:Rn})]})]})}),t.jsx(X,{xs:12,md:6,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Effects"}),t.jsxs(A.Label,{className:"small",children:["Reverb (",e.reverbGain.toFixed(2),")"]}),t.jsx(A.Range,{min:0,max:5,step:.05,value:e.reverbGain,disabled:!e.ready,onChange:y=>ee.setReverbGain(Number(y.currentTarget.value))}),t.jsxs(A.Label,{className:"small",children:["Chorus (",e.chorusGain.toFixed(2),")"]}),t.jsx(A.Range,{min:0,max:5,step:.05,value:e.chorusGain,disabled:!e.ready,onChange:y=>ee.setChorusGain(Number(y.currentTarget.value))}),t.jsxs("div",{className:"d-flex align-items-center justify-content-between mt-3",children:[t.jsxs("div",{children:[t.jsx("div",{className:"small text-muted",children:"Transposition"}),t.jsxs("div",{className:"fw-semibold",children:[e.transposition>0?`+${e.transposition}`:String(e.transposition)," semitones"]})]}),t.jsxs("div",{className:"d-flex gap-2",children:[t.jsx(D,{variant:"outline-secondary",type:"button",disabled:!e.ready,onClick:()=>ee.shiftTransposition(-1),children:"-1"}),t.jsx(D,{variant:"outline-secondary",type:"button",disabled:!e.ready,onClick:()=>ee.setTransposition(0),children:"0"}),t.jsx(D,{variant:"outline-secondary",type:"button",disabled:!e.ready,onClick:()=>ee.shiftTransposition(1),children:"+1"})]})]})]})}),t.jsx(X,{xs:12,md:6,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Lyrics"}),t.jsx(A.Control,{type:"file",accept:".lrc,text/plain",disabled:!e.ready,onChange:async y=>{const C=y.target.files?.[0];C&&await ee.loadLrcFromFile(C)}}),t.jsxs("div",{className:"small text-muted mt-2",children:["Loaded: ",e.lrcName||"—"]}),t.jsxs(A.Label,{className:"small mt-2",children:["Offset (ms): ",e.lyricOffsetMs]}),t.jsx(A.Range,{min:-3e3,max:3e3,step:10,value:e.lyricOffsetMs,disabled:!e.ready,onChange:y=>ee.setLyricOffsetMs(Number(y.currentTarget.value))})]})}),t.jsx(X,{xs:12,children:t.jsx("div",{className:"p-3 border rounded-3",children:t.jsxs(_s,{activeKey:gn,onSelect:y=>{y&&pn(y)},mountOnEnter:!0,unmountOnExit:!0,className:"mb-3",children:[t.jsxs(Mt,{eventKey:"pitch-debug",title:"Pitch Debug",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Karaoke Pitch Debug"}),t.jsxs(Pe,{className:"g-2 align-items-center mb-3",children:[t.jsx(X,{xs:"auto",children:t.jsx(D,{type:"button",disabled:!e.ready||x,onClick:We,children:"Start Mic"})}),t.jsx(X,{xs:"auto",children:t.jsx(D,{type:"button",variant:"secondary",disabled:!x,onClick:Je,children:"Stop Mic"})}),t.jsx(X,{xs:12,md:!0,children:t.jsx(A.Select,{value:q,onChange:y=>Q(y.currentTarget.value),children:Qe.map(y=>t.jsx("option",{value:y.id,children:y.name},y.id))})})]}),t.jsxs(Pe,{className:"g-3",children:[t.jsxs(X,{xs:12,md:6,children:[t.jsx(A.Label,{className:"small",children:"Window Size"}),t.jsxs(A.Select,{value:N,onChange:y=>w(Number(y.currentTarget.value)),children:[t.jsx("option",{value:2048,children:"2048"}),t.jsx("option",{value:4096,children:"4096"})]}),t.jsx(A.Label,{className:"small mt-2",children:"Hop Size"}),t.jsxs(A.Select,{value:v,onChange:y=>_(Number(y.currentTarget.value)),children:[t.jsx("option",{value:128,children:"128"}),t.jsx("option",{value:256,children:"256"}),t.jsx("option",{value:512,children:"512"})]}),t.jsxs(A.Label,{className:"small mt-2",children:["RMS Gate (",R.toFixed(3),")"]}),t.jsx(A.Range,{min:0,max:.05,step:.001,value:R,onChange:y=>k(Number(y.currentTarget.value))}),t.jsxs("div",{className:"mt-3",children:[t.jsx("div",{className:"small text-muted mb-1",children:"Mic Constraints"}),t.jsx(A.Check,{type:"switch",id:"mic-echo-cancellation",label:"Echo Cancellation",checked:j,onChange:y=>L(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"mic-noise-suppression",label:"Noise Suppression",checked:Y,onChange:y=>pe(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"mic-auto-gain",label:"Auto Gain Control",checked:ie,onChange:y=>me(y.currentTarget.checked)})]})]}),t.jsxs(X,{xs:12,md:6,children:[t.jsxs(A.Label,{className:"small",children:["Latency Comp (ms): ",E]}),t.jsx(A.Range,{min:-300,max:300,step:1,value:E,onChange:y=>se(Number(y.currentTarget.value))}),t.jsxs(A.Label,{className:"small mt-2",children:["User Pitch Offset (ms): ",F]}),t.jsx(A.Range,{min:-300,max:300,step:1,value:F,onChange:y=>z(Number(y.currentTarget.value))}),t.jsx(A.Check,{type:"switch",id:"pitch-smoothing",className:"mt-2",label:"Double Exp Smooth",checked:de,onChange:y=>I(y.currentTarget.checked)})]})]}),t.jsx("div",{className:"d-flex align-items-center justify-content-between mt-3",children:t.jsxs("div",{className:"small text-muted",children:["Melody Guide                    ",t.jsx(A.Check,{type:"switch",id:"debug-pitch-guide",label:"Melody Guide",checked:xe,onChange:y=>je(y.currentTarget.checked),className:"text-nowrap"}),t.jsx(A.Check,{type:"switch",id:"debug-pitch-raw",label:"Debug",checked:Ve,onChange:y=>we(y.currentTarget.checked),className:"text-nowrap"})]})}),xe&&e.isPlaying?t.jsx("div",{className:"mt-2",style:{backgroundColor:"black",borderRadius:8,overflow:"hidden"},children:t.jsx(ii,{className:"melodyGuideCanvas",reference:c,historyRef:bt,pitchFrameHistoryRef:Gt,lastPitchRef:Et,currentTimeRef:vt,transpositionRef:zt,rmsGate:R,gateUserByTarget:!1,windowSec:8,debug:Ve,debugAnalyser:Xe,debugF0Hz:it?.result?.f0Hz??Ye?.f0Hz,debugRawF0Hz:it?.rawF0Hz,debugUserMidi:Et.current?.midi,width:830,height:220,style:{width:"100%",height:220}})}):null,t.jsxs("div",{className:"d-flex align-items-center justify-content-between mt-3",children:[t.jsx("div",{className:"small text-muted",children:"Full Pitch Trace (target vs mic)"}),t.jsx(D,{size:"sm",variant:"outline-secondary",onClick:()=>Ue(y=>!y),children:De?"Hide":"Show"})]}),De?t.jsx("canvas",{ref:rn,width:760,height:300,style:{width:"100%",height:300,borderRadius:8,background:"#0f1115"}}):null,t.jsxs("div",{className:"small mt-3",children:[t.jsxs("div",{children:["songTimeSec: ",re(Ye.songTimeSec,2)]}),t.jsxs("div",{children:["targetMidi: ",re(Ye.targetMidi,2)]}),t.jsxs("div",{children:["targetPitchClass: ",fe(Ye.targetMidi)]}),t.jsxs("div",{children:["userMidi: ",re(Ye.userMidi,2)]}),t.jsxs("div",{children:["userPitchClass: ",fe(Ye.userMidi)]}),t.jsxs("div",{children:["pitchErrorCents: ",re(Ye.pitchErrorCents,1)]}),t.jsxs("div",{children:["f0Hz: ",re(Ye.f0Hz,2)]}),t.jsxs("div",{children:["confidence: ",re(Ye.confidence,3)]}),t.jsxs("div",{children:["rms: ",re(Ye.rms,4)]}),t.jsxs("div",{children:["algoName: ",Ye.algoName||"n/a"]}),t.jsxs("div",{children:["micSampleRate: ",re(Ye.micSampleRate,0)]})]})]}),t.jsxs(Mt,{eventKey:"pipeline-debug",title:"DSP Pipeline Debug",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Signal Pipeline"}),t.jsxs(Pe,{className:"g-3",children:[t.jsxs(X,{xs:12,md:5,children:[t.jsx(A.Check,{type:"switch",id:"pipeline-debug-enabled",label:"Debug Stream",checked:ye,onChange:y=>{const C=y.currentTarget.checked;if(Ge(C),C&&x){const T=Se.ensureDebugAnalyser?.({fftSize:2048,smoothingTimeConstant:0,enableHpf:Me,hpfCutoffHz:Ne.hpfCutoffHz});T||console.warn("[Synth] debugAnalyser not ready after toggle"),ct(T||null)}}}),t.jsxs(A.Label,{className:"small mt-2",children:["Debug Stride: ",H," frame(s)"]}),t.jsx(A.Range,{min:1,max:12,step:1,value:H,onChange:y=>ae(Number(y.currentTarget.value))}),t.jsxs("div",{className:"mt-3",children:[t.jsx(A.Check,{type:"switch",id:"pipeline-dc",label:"DC Removal",checked:be,onChange:y=>He(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"pipeline-hpf",label:"HPF",checked:Me,onChange:y=>Ae(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"pipeline-rms",label:"RMS Gate",checked:Ce,onChange:y=>ot(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"pipeline-validate",label:"f0 Validate",checked:P,onChange:y=>Ke(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"pipeline-smooth",label:"Temporal Smooth",checked:Oe,onChange:y=>et(y.currentTarget.checked)}),t.jsx(A.Check,{type:"switch",id:"pipeline-double-smooth",label:"Double Exp Smooth",checked:de,onChange:y=>I(y.currentTarget.checked)})]})]}),t.jsxs(X,{xs:12,md:7,children:[t.jsx("div",{className:"small text-muted mb-2",children:"Mic Input"}),t.jsx(dn,{data:Te.input,height:70}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Post DC Removal filter"}),t.jsx($s,{data:Te.dcRemoved,height:70,color:"#3498db"}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Post High Pass Filter (80HzCut)"}),t.jsx($s,{data:Te.hpf,height:70,color:"#9b59b6"}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Post RMS Gate"}),t.jsx($s,{data:Te.gated,height:70,color:"#e67e22"}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Raw f0 Trace"}),t.jsx(dn,{data:wt.raw,height:60,color:"#f1c40f"}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Post f0 Vaildate"}),t.jsx(dn,{data:wt.post,height:60,color:"#8bd17c"}),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Spectrogram + F0"}),(()=>{let y="#ffffff";return dt.vibrato&&(y="#2ecc71"),dt.kobushi&&(y="#4fc3f7"),(dt.glissup||dt.glissdown)&&(y="#9c27b0"),Xe&&Xe.frequencyBinCount>0?t.jsx(Nr,{analyser:Xe,f0Hz:it.result?.f0Hz,f0Color:y,height:140,minHz:Ne.f0MinHz,maxHz:Ne.f0MaxHz}):t.jsx("div",{style:{width:"100%",height:140,background:"#000"}})})(),t.jsx("div",{className:"small text-muted mt-3 mb-2",children:"Sing Technique"}),t.jsxs(Pe,{children:[t.jsxs(X,{xs:4,children:[t.jsx("div",{className:"small text-muted mb-1",children:"Vibrato"}),t.jsx(dn,{data:Fn.vibrato.slice(),height:40,color:"#2ecc71"})]}),t.jsxs(X,{xs:4,children:[t.jsx("div",{className:"small text-muted mb-1",children:"Kobushi"}),t.jsx(dn,{data:Fn.kobushi.slice(),height:40,color:"#4fc3f7"})]}),t.jsxs(X,{xs:4,children:[t.jsx("div",{className:"small text-muted mb-1",children:"Glissando"}),t.jsx(dn,{data:Fn.glissando.slice(),height:40,color:"#9c27b0"})]})]}),t.jsx("div",{className:"d-flex gap-2 mt-3",children:["vibrato","kobushi","glissando"].map(y=>{let C=!1;y==="glissando"?C=dt.glissup||dt.glissdown:C=dt[y];let T=y.charAt(0).toUpperCase()+y.slice(1);y==="glissando"&&(dt.glissup&&(T="Gliss Up"),dt.glissdown&&(T="Gliss Down"));let Z="#666";return y==="vibrato"&&(Z="#2ecc71"),y==="kobushi"&&(Z="#4fc3f7"),y==="glissando"&&(Z="#9c27b0"),t.jsx("div",{className:"px-3 py-2 rounded fw-bold d-flex align-items-center justify-content-center",style:{background:C?Z:"transparent",color:C?"#fff":Z,border:`2px solid ${Z}`,boxShadow:C?`0 0 10px ${Z}`:"none",transition:"all 0.1s",minWidth:100,fontSize:14},children:T},y)})}),t.jsxs("div",{className:"small mt-3",children:[t.jsxs("div",{children:["rms: ",re(it.rms,4)]}),t.jsxs("div",{children:["gateOpen: ",it.gateOpen?"yes":"no"]}),t.jsxs("div",{children:["rawF0Hz: ",re(it.rawF0Hz,2)]}),t.jsxs("div",{children:["rawConfidence: ",re(it.rawConfidence,3)]}),t.jsxs("div",{children:["f0Hz: ",re(it.result?.f0Hz,2)]}),t.jsxs("div",{children:["confidence: ",re(it.result?.confidence,3)]}),t.jsxs("div",{children:["midi: ",re(it.result?.midi,2)]})]})]})]})]}),t.jsxs(Mt,{eventKey:"particle-debug",title:"Particle Debug",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Particle Tuning"}),t.jsxs(Pe,{className:"g-3",children:[t.jsxs(X,{xs:12,md:6,children:[t.jsxs(A.Label,{className:"small",children:["Emission Rate: ",te.emissionRate]}),t.jsx(A.Range,{min:0,max:400,step:1,value:te.emissionRate,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,emissionRate:C}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Max Particles: ",te.maxParticles]}),t.jsx(A.Range,{min:50,max:1500,step:10,value:te.maxParticles,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,maxParticles:C}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Lifetime Min: ",te.lifetime.min.toFixed(2),"s"]}),t.jsx(A.Range,{min:.05,max:2,step:.05,value:te.lifetime.min,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,lifetime:{...T.lifetime,min:Math.min(C,T.lifetime.max)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Lifetime Max: ",te.lifetime.max.toFixed(2),"s"]}),t.jsx(A.Range,{min:.1,max:3,step:.05,value:te.lifetime.max,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,lifetime:{...T.lifetime,max:Math.max(C,T.lifetime.min)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Speed Min: ",te.speed.min.toFixed(0)]}),t.jsx(A.Range,{min:0,max:400,step:5,value:te.speed.min,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,speed:{...T.speed,min:Math.min(C,T.speed.max)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Speed Max: ",te.speed.max.toFixed(0)]}),t.jsx(A.Range,{min:0,max:600,step:5,value:te.speed.max,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,speed:{...T.speed,max:Math.max(C,T.speed.min)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Angle Min: ",(te.angle.min*ms).toFixed(0),"°"]}),t.jsx(A.Range,{min:-180,max:180,step:1,value:te.angle.min*ms,onChange:y=>{const T=Number(y.currentTarget?.value??y.target?.value??0)*Yi;ue(Z=>({...Z,angle:{...Z.angle,min:Math.min(T,Z.angle.max)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Angle Max: ",(te.angle.max*ms).toFixed(0),"°"]}),t.jsx(A.Range,{min:-180,max:180,step:1,value:te.angle.max*ms,onChange:y=>{const T=Number(y.currentTarget?.value??y.target?.value??0)*Yi;ue(Z=>({...Z,angle:{...Z.angle,max:Math.max(T,Z.angle.min)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Spawn Radius: ",te.spawnRadius]}),t.jsx(A.Range,{min:0,max:24,step:1,value:te.spawnRadius,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,spawnRadius:C}))}})]}),t.jsxs(X,{xs:12,md:6,children:[t.jsxs(A.Label,{className:"small",children:["Scale Start: ",te.scale.start.toFixed(2)]}),t.jsx(A.Range,{min:.05,max:2,step:.05,value:te.scale.start,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,scale:{...T.scale,start:Math.max(C,T.scale.end)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Scale End: ",te.scale.end.toFixed(2)]}),t.jsx(A.Range,{min:.05,max:1.5,step:.05,value:te.scale.end,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,scale:{...T.scale,end:Math.min(C,T.scale.start)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Alpha Start: ",te.alpha.start.toFixed(2)]}),t.jsx(A.Range,{min:0,max:1,step:.05,value:te.alpha.start,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,alpha:{...T.alpha,start:Math.max(C,T.alpha.end)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Alpha End: ",te.alpha.end.toFixed(2)]}),t.jsx(A.Range,{min:0,max:1,step:.05,value:te.alpha.end,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,alpha:{...T.alpha,end:Math.min(C,T.alpha.start)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Rotation Speed Min: ",te.rotationSpeed.min.toFixed(1)]}),t.jsx(A.Range,{min:-12,max:0,step:.5,value:te.rotationSpeed.min,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,rotationSpeed:{...T.rotationSpeed,min:Math.min(C,T.rotationSpeed.max)}}))}}),t.jsxs(A.Label,{className:"small mt-2",children:["Rotation Speed Max: ",te.rotationSpeed.max.toFixed(1)]}),t.jsx(A.Range,{min:0,max:12,step:.5,value:te.rotationSpeed.max,onChange:y=>{const C=Number(y.currentTarget?.value??y.target?.value??0);ue(T=>({...T,rotationSpeed:{...T.rotationSpeed,max:Math.max(C,T.rotationSpeed.min)}}))}}),t.jsxs(Pe,{className:"g-2 mt-2",children:[t.jsxs(X,{xs:6,children:[t.jsx(A.Label,{className:"small",children:"Tint Start"}),t.jsx(A.Control,{type:"color",value:Ji(te.tint.start),onChange:y=>{const C=y.currentTarget?.value??y.target?.value??"",T=Zi(C,te.tint.start);ue(Z=>({...Z,tint:{...Z.tint,start:T}}))}})]}),t.jsxs(X,{xs:6,children:[t.jsx(A.Label,{className:"small",children:"Tint End"}),t.jsx(A.Control,{type:"color",value:Ji(te.tint.end),onChange:y=>{const C=y.currentTarget?.value??y.target?.value??"",T=Zi(C,te.tint.end);ue(Z=>({...Z,tint:{...Z.tint,end:T}}))}})]})]}),t.jsx("div",{className:"mt-3",children:t.jsx(D,{size:"sm",variant:"outline-secondary",onClick:()=>ue(vs(Mn)),children:"Reset Defaults"})})]})]}),t.jsxs("div",{className:"d-flex align-items-center justify-content-between mt-3",children:[t.jsx("div",{className:"small text-muted",children:"Particle Preview (auto emit)"}),t.jsx(A.Check,{type:"switch",id:"particle-preview-toggle",label:"Emit",checked:ke,onChange:y=>Ct(y.currentTarget?.checked??!1)})]}),t.jsx("div",{className:"mt-2",children:gn==="particle-debug"&&e.isPlaying?t.jsx(fl,{particleConfig:te,emit:ke,width:760,height:160,style:{width:"100%",height:160,borderRadius:8}}):t.jsx("div",{style:{width:"100%",height:160,borderRadius:8,background:"#0f1115"}})}),t.jsx("div",{className:"small text-muted mt-3",children:"Hit the correct note to emit particles on the melody guide (mic required)."}),t.jsx("div",{className:"mt-2",style:{backgroundColor:"grey"},children:gn==="particle-debug"&&e.isPlaying?t.jsx(ii,{className:"melodyGuideCanvas",reference:c,historyRef:bt,pitchFrameHistoryRef:Gt,lastPitchRef:Et,currentTimeRef:vt,transpositionRef:zt,rmsGate:R,gateUserByTarget:!0,userOffsetSec:F/1e3,width:760,height:180,particleConfig:te,style:{width:"100%",height:180,borderRadius:8}}):t.jsx("div",{style:{width:"100%",height:180,borderRadius:8,background:"#0f1115"}})})]}),t.jsxs(Mt,{eventKey:"beatmap-debug",title:"Beatmap Debug",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Beat Map Debug"}),W?t.jsxs("svg",{width:W.width,height:W.height,viewBox:`0 0 ${W.width} ${W.height}`,style:{width:"100%",height:W.height,background:"#0f1115",borderRadius:8},children:[t.jsx("rect",{width:W.width,height:W.height,fill:"#0f1115"}),W.tempoSegmentsTick.map((y,C)=>{const T=y.startTick/W.totalTicks*W.width,Z=y.endTick/W.totalTicks*W.width,ne=Math.max(0,Z-T),he=C%2===0?"rgba(255,255,255,0.03)":"rgba(255,255,255,0.08)";return t.jsx("rect",{x:T,y:0,width:ne,height:W.height,fill:he},`seg-${C}`)}),Number.isFinite(W.maxNoteTick)&&W.maxNoteTick>0?t.jsx("line",{x1:W.maxNoteTick/W.totalTicks*W.width,x2:W.maxNoteTick/W.totalTicks*W.width,y1:0,y2:W.height,stroke:"rgba(0,200,255,0.7)",strokeWidth:2}):null,t.jsx("line",{x1:W.width-1,x2:W.width-1,y1:0,y2:W.height,stroke:"rgba(255,0,255,0.7)",strokeWidth:2}),W.beatAxisLines.map(y=>{const C=y.tick/W.totalTicks*W.width;return t.jsx("line",{x1:C,x2:C,y1:0,y2:W.height,stroke:"rgba(255,255,255,0.08)",strokeWidth:1},`beat-${y.beat}`)}),W.tempoLinesTick.map((y,C)=>{const T=y.tick/W.totalTicks*W.width;return t.jsx("line",{x1:T,x2:T,y1:0,y2:W.height,stroke:"rgba(255,196,0,0.5)",strokeWidth:2},`tempo-${C}`)}),W.notes.map((y,C)=>{const T=Number(y.midi),Z=Number(y.t0Tick),ne=Number(y.t1Tick);if(!Number.isFinite(Z)||!Number.isFinite(ne)||!Number.isFinite(T))return null;const he=Z/W.totalTicks*W.width,O=ne/W.totalTicks*W.width,_e=Math.max(1,W.maxMidi-W.minMidi),Fe=W.height-(T-W.minMidi)/_e*W.height,rt=Math.max(2,W.height/(_e+1)),ht=Math.max(1,O-he);return t.jsx("rect",{x:he,y:Fe-rt/2,width:ht,height:rt,fill:"rgba(255,255,255,0.8)"},`note-${C}`)})]}):t.jsx("div",{style:{width:"100%",height:180,borderRadius:8,background:"#0f1115"}}),t.jsxs("div",{className:"small text-muted mt-2 d-flex flex-wrap align-items-center gap-3",style:{lineHeight:1.4},children:[t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,background:"rgba(255,255,255,0.8)",display:"inline-block",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Melody notes"})]}),t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,background:"rgba(255,255,255,0.08)",display:"inline-block",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Beats"})]}),t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,background:"rgba(255,196,0,0.5)",display:"inline-block",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Tempo changes"})]}),t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,background:"rgba(0,200,255,0.7)",display:"inline-block",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Max note tick"})]}),t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,background:"rgba(255,0,255,0.7)",display:"inline-block",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Tick range end"})]}),t.jsxs("div",{className:"d-flex align-items-center gap-2",children:[t.jsx("span",{style:{width:10,height:10,display:"inline-block",background:"repeating-linear-gradient(90deg, rgba(255,255,255,0.03), rgba(255,255,255,0.03) 3px, rgba(255,255,255,0.08) 3px, rgba(255,255,255,0.08) 6px)",boxShadow:"0 0 0 1px rgba(0,0,0,0.6)"}}),t.jsx("span",{children:"Tempo segments"})]})]})]})]})})}),t.jsx(X,{xs:12,children:t.jsxs("div",{className:"p-3 border rounded-3",children:[t.jsx("div",{className:"fw-semibold mb-2",children:"Channels"}),t.jsx(Pe,{className:"g-2",children:e.enabledChannels.map((y,C)=>t.jsx(X,{xs:12,sm:6,md:4,lg:3,children:t.jsx(A.Check,{type:"switch",id:`ch-${C+1}`,checked:y,disabled:!e.ready,onChange:T=>ee.setChannelEnabled(C,T.currentTarget.checked),label:`Ch ${C+1}: ${e.channelInstrumentNames[C]}`})},C))})]})})]})]})}const Hl={starting:"起動の準備をしています…",audio:"オーディオエンジンを起動しています…","soundfont-download":"音色ライブラリをダウンロードしています…","soundfont-load":"音色ライブラリを読み込んでいます…",player:"プレーヤーを準備しています…"};function Ol({onRetry:s}){const e=Be(m=>m.ready),n=Be(m=>m.engineLoadStage),i=Be(m=>m.engineLoadError),r=g.useRef(null),[a,o]=g.useState(!1),l=n==="error";if(g.useEffect(()=>{if(e)return;const m=document.body.style.overflow;document.body.style.overflow="hidden",r.current?.focus();const u=h=>{l&&(h.key==="Enter"||h.key===" ")&&r.current?.querySelector("button")?.click(),h.preventDefault(),h.stopImmediatePropagation()};return window.addEventListener("keydown",u,!0),()=>{document.body.style.overflow=m,window.removeEventListener("keydown",u,!0)}},[l,e]),e)return null;const d=async()=>{if(!a){o(!0);try{await s?.()}catch{o(!1)}}};return t.jsx("div",{className:"synthLoadingOverlay",children:t.jsxs("section",{className:"synthLoadingModal",role:"alertdialog","aria-modal":"true","aria-labelledby":"synth-loading-title","aria-describedby":"synth-loading-message",ref:r,tabIndex:-1,children:[t.jsx("header",{className:"synthLoadingModal__header",id:"synth-loading-title",children:l?"読み込みエラー":"ただいま準備中"}),t.jsxs("div",{className:"synthLoadingModal__body",children:[t.jsx("div",{className:`synthLoadingModal__disc ${l?"synthLoadingModal__disc--error":""}`,"aria-hidden":"true",children:t.jsx("span",{children:l?"!":"♪"})}),t.jsx("div",{className:"synthLoadingModal__english",children:l?"LOAD ERROR":"NOW LOADING…"}),t.jsx("p",{className:"synthLoadingModal__message",id:"synth-loading-message","aria-live":"polite",children:l?"シンセエンジンを準備できませんでした。":Hl[n]||"シンセエンジンを準備しています…"}),l&&i?t.jsx("p",{className:"synthLoadingModal__detail",children:i}):null,l?t.jsx("button",{className:"synthLoadingModal__retry",type:"button",onClick:d,disabled:a,children:a?"再試行しています…":"もう一度試す"}):t.jsx("div",{className:"synthLoadingModal__progress",role:"progressbar","aria-label":"読み込み中",children:t.jsx("span",{})}),t.jsx("p",{className:"synthLoadingModal__notice",children:l?"下のボタンを押して、もう一度お試しください。":"準備が完了するまで、そのままお待ちください。"})]})]})})}function Gl({children:s}){return g.useEffect(()=>{ee.ensureInitialized().catch(e=>{console.error(e)})},[]),t.jsxs(t.Fragment,{children:[t.jsx(Ol,{onRetry:()=>ee.ensureInitialized()}),s]})}function Us(s){return s?s.endsWith("/")&&s!=="/"?s.slice(0,-1):s:"/"}function zl(){const[s,e]=g.useState(()=>Us(window.location.pathname));g.useEffect(()=>{const r=()=>e(Us(window.location.pathname));return window.addEventListener("popstate",r),()=>window.removeEventListener("popstate",r)},[]);const n=g.useMemo(()=>r=>{const a=Us(r);a!==s&&(window.history.pushState({},"",a),e(a))},[s]),i=g.useMemo(()=>s==="/synth"||s==="/debug"?t.jsx(Dl,{onNavigateHome:()=>n("/")}):t.jsx(hl,{onNavigate:n}),[n,s]);return t.jsx(Gl,{children:i})}const er=document.getElementById("root");er&&Dr.createRoot(er).render(t.jsx(g.StrictMode,{children:t.jsx(zl,{})}));
