import{d as m1,L as g1,s as pu}from"./vendor-Ukah3R8y.js";const x1=1e-7,b1=1e-4;class Ff{constructor(t,e){this.backend=t,this.dataMover=e,this.data=new WeakMap,this.dataIdsCount=0}get(t){return this.data.has(t)||this.dataMover.moveData(this.backend,t),this.data.get(t)}set(t,e){this.dataIdsCount++,this.data.set(t,e)}has(t){return this.data.has(t)}delete(t){return this.dataIdsCount--,this.data.delete(t)}numDataIds(){return this.dataIdsCount}}class fu{refCount(t){return Be("refCount")}incRef(t){return Be("incRef")}timerAvailable(){return!0}time(t){return Be("time")}read(t){return Be("read")}readSync(t){return Be("readSync")}readToGPU(t,e){return Be("readToGPU")}numDataIds(){return Be("numDataIds")}disposeData(t,e){return Be("disposeData")}write(t,e,s){return Be("write")}move(t,e,s,o,r){return Be("move")}createTensorFromGPUData(t,e,s){return Be("createTensorFromGPUData")}memory(){return Be("memory")}floatPrecision(){return Be("floatPrecision")}epsilon(){return this.floatPrecision()===32?x1:b1}dispose(){return Be("dispose")}}function Be(n){throw new Error(`'${n}' not yet implemented or not found in the registry. This kernel may not be supported by the tfjs backend you have chosen`)}function y1(n){let t=n.length,e=0;for(;t>0;)e=Math.random()*t|0,t--,xo(n,t,e)}function Ws(n,t,e){return Math.max(n,Math.min(t,e))}function mu(n){return n%2===0?n:n+1}function xo(n,t,e){const s=n[t];n[t]=n[e],n[e]=s}function w1(n){let t=0;for(let e=0;e<n.length;e++)t+=n[e];return t}function $(n,t){if(!n)throw new Error(typeof t=="string"?t:t())}function gu(n,t,e=""){$(Et(n,t),()=>e+` Shapes ${n} and ${t} must match`)}function Of(n){$(n!=null,()=>"The input to the tensor constructor must be a non-null value.")}function W(n){if(n.length===0)return 1;let t=n[0];for(let e=1;e<n.length;e++)t*=n[e];return t}function Et(n,t){if(n===t)return!0;if(n==null||t==null||n.length!==t.length)return!1;for(let e=0;e<n.length;e++)if(n[e]!==t[e])return!1;return!0}function vo(n){return n%1===0}function Dc(n){const t=Math.ceil(Math.sqrt(n));return[t,Math.ceil(n/t)]}function wo(n,t){return t<=n.length?n:n+" ".repeat(t-n.length)}function Zd(n,t=o=>0,e,s){return new Promise((o,r)=>{let i=0;const a=()=>{if(n()){o();return}i++;const l=t(i);if(e!=null&&i>=e){r();return}s!=null?s(a,l):setTimeout(a,l)};a()})}function _f(n,t){let e=1,s=-1;for(let r=0;r<n.length;++r)if(n[r]>=0)e*=n[r];else if(n[r]===-1){if(s!==-1)throw Error(`Shapes can only have 1 implicit size. Found -1 at dim ${s} and dim ${r}`);s=r}else if(n[r]<0)throw Error(`Shapes can not be < 0. Found ${n[r]} at dim ${r}`);if(s===-1){if(t>0&&t!==e)throw Error(`Size(${t}) must match the product of shape ${n}`);return n}if(e===0)throw Error(`Cannot infer the missing size in [${n}] when there are 0 elements`);if(t%e!==0)throw Error(`The implicit shape can't be a fractional number. Got ${t} / ${e}`);const o=n.slice();return o[s]=t/e,o}function Ct(n,t){const e=t.length;return n=n==null?t.map((s,o)=>o):[].concat(n),$(n.every(s=>s>=-e&&s<e),()=>`All values in axis param must be in range [-${e}, ${e}) but got axis ${n}`),$(n.every(s=>vo(s)),()=>`All values in axis param must be integers but got axis ${n}`),n.map(s=>s<0?e+s:s)}function ys(n,t){const e=[],s=[],o=t!=null&&Array.isArray(t)&&t.length===0,r=t==null||o?null:Ct(t,n).sort();let i=0;for(let a=0;a<n.length;++a){if(r!=null){if(r[i]===a&&n[a]!==1)throw new Error(`Can't squeeze axis ${a} since its dim '${n[a]}' is not 1`);(r[i]==null||r[i]>a)&&n[a]===1&&(e.push(n[a]),s.push(a)),r[i]<=a&&i++}n[a]!==1&&(e.push(n[a]),s.push(a))}return{newShape:e,keptDims:s}}function Ce(n,t){return Xt(n,t)}function Xt(n,t){let e=null;if(n==null||n==="float32")e=new Float32Array(t);else if(n==="int32")e=new Int32Array(t);else if(n==="bool")e=new Uint8Array(t);else if(n==="string")e=new Array(t);else throw new Error(`Unknown data type ${n}`);return e}function C1(n,t){for(let e=0;e<n.length;e++){const s=n[e];if(isNaN(s)||!isFinite(s))throw Error(`A tensor of type ${t} being uploaded contains ${s}.`)}}function $1(n){return n==="bool"||n==="complex64"||n==="float32"||n==="int32"||n==="string"}function Lf(n,t){return!(t==="complex64"||t==="float32"&&n!=="complex64"||t==="int32"&&n!=="float32"&&n!=="complex64"||t==="bool"&&n==="bool")}function ra(n){if(n==="float32"||n==="int32")return 4;if(n==="complex64")return 8;if(n==="bool")return 1;throw new Error(`Unknown dtype ${n}`)}function I1(n){if(n==null)return 0;let t=0;return n.forEach(e=>t+=e.length),t}function vr(n){return typeof n=="string"||n instanceof String}function k1(n){return typeof n=="boolean"}function Ac(n){return typeof n=="number"}function Lo(n){return Array.isArray(n)?Lo(n[0]):n instanceof Float32Array?"float32":n instanceof Int32Array||n instanceof Uint8Array||n instanceof Uint8ClampedArray?"int32":Ac(n)?"float32":vr(n)?"string":k1(n)?"bool":"float32"}function Fc(n){return!!(n&&n.constructor&&n.call&&n.apply)}function Oc(n,t){for(let e=t;e<n;++e)if(n%e===0)return e;return n}function lt(n){const t=n.length;if(t<2)return[];const e=new Array(t-1);e[t-2]=n[t-1];for(let s=t-3;s>=0;--s)e[s]=e[s+1]*n[s+1];return e}function Mf(n,t,e,s=!1){const o=new Array;if(t.length===1){const r=t[0]*(s?2:1);for(let i=0;i<r;i++)o[i]=e[n+i]}else{const r=t[0],i=t.slice(1),a=i.reduce((l,c)=>l*c)*(s?2:1);for(let l=0;l<r;l++)o[l]=Mf(n+l*a,i,e,s)}return o}function xn(n,t,e=!1){if(n.length===0)return t[0];const s=n.reduce((o,r)=>o*r)*(e?2:1);if(s===0)return[];if(s!==t.length)throw new Error(`[${n}] does not match the input size ${t.length}${e?" for a complex tensor":""}.`);return Mf(0,n,t,e)}function v1(n,t){if(Array.isArray(n))return n;if(t==="float32")return n instanceof Float32Array?n:new Float32Array(n);if(t==="int32")return n instanceof Int32Array?n:new Int32Array(n);if(t==="bool"||t==="string")return Uint8Array.from(new Int32Array(n));throw new Error(`Unknown dtype ${t}`)}function xu(n,t){const e=$e(n,t);for(let s=0;s<e.length;s++)e[s]=1;return e}function $e(n,t){if(t==null||t==="float32"||t==="complex64")return new Float32Array(n);if(t==="int32")return new Int32Array(n);if(t==="bool")return new Uint8Array(n);throw new Error(`Unknown data type ${t}`)}function Pf(n,t){const e=n.reduce((s,o)=>s*o,1);if(t==null||t==="float32")return xn(n,new Float32Array(e));if(t==="int32")return xn(n,new Int32Array(e));if(t==="bool")return xn(n,new Uint8Array(e));throw new Error(`Unknown data type ${t}`)}function Jn(n){n.forEach(t=>{$(Number.isInteger(t)&&t>=0,()=>`Tensor must have a shape comprised of positive integers but got shape [${n}].`)})}function Rn(n,t,e){if(t===0)return 0;if(t===1)return n[0];let s=n[n.length-1];for(let o=0;o<n.length-1;++o)s+=e[o]*n[o];return s}function Mo(n,t,e){if(t===0)return[];if(t===1)return[n];const s=new Array(t);for(let o=0;o<s.length-1;++o)s[o]=Math.floor(n/e[o]),n-=s[o]*e[o];return s[s.length-1]=n,s}function bu(n){return n&&n.then&&typeof n.then=="function"}const Qd="tfjsflags";class S1{constructor(t){this.global=t,this.flags={},this.flagRegistry={},this.urlFlags={},this.getQueryParams=N1,this.populateURLFlags()}setPlatform(t,e){this.platform!=null&&(L().getBool("IS_TEST")||L().getBool("PROD")||console.warn(`Platform ${this.platformName} has already been set. Overwriting the platform with ${t}.`)),this.platformName=t,this.platform=e}registerFlag(t,e,s){if(this.flagRegistry[t]={evaluationFn:e,setHook:s},this.urlFlags[t]!=null){const o=this.urlFlags[t];L().getBool("IS_TEST")||L().getBool("PROD")||console.warn(`Setting feature override from URL ${t}: ${o}.`),this.set(t,o)}}async getAsync(t){return t in this.flags?this.flags[t]:(this.flags[t]=await this.evaluateFlag(t),this.flags[t])}get(t){if(t in this.flags)return this.flags[t];const e=this.evaluateFlag(t);if(bu(e))throw new Error(`Flag ${t} cannot be synchronously evaluated. Please use getAsync() instead.`);return this.flags[t]=e,this.flags[t]}getNumber(t){return this.get(t)}getBool(t){return this.get(t)}getString(t){return this.get(t)}getFlags(){return this.flags}get features(){return this.flags}set(t,e){if(this.flagRegistry[t]==null)throw new Error(`Cannot set flag ${t} as it has not been registered.`);this.flags[t]=e,this.flagRegistry[t].setHook!=null&&this.flagRegistry[t].setHook(e)}evaluateFlag(t){if(this.flagRegistry[t]==null)throw new Error(`Cannot evaluate flag '${t}': no evaluation function found.`);return this.flagRegistry[t].evaluationFn()}setFlags(t){this.flags=Object.assign({},t)}reset(){this.flags={},this.urlFlags={},this.populateURLFlags()}populateURLFlags(){if(typeof this.global>"u"||typeof this.global.location>"u"||typeof this.global.location.search>"u")return;const t=this.getQueryParams(this.global.location.search);Qd in t&&t[Qd].split(",").forEach(s=>{const[o,r]=s.split(":");this.urlFlags[o]=E1(o,r)})}}function N1(n){const t={};return n.replace(/[?&]([^=?&]+)(?:=([^&]*))?/g,(e,...s)=>(T1(t,s[0],s[1]),s.join("="))),t}function T1(n,t,e){n[decodeURIComponent(t)]=decodeURIComponent(e||"")}function E1(n,t){const e=t.toLowerCase();return e==="true"||e==="false"?e==="true":`${+e}`===e?+e:t}function L(){return zf}let zf=null;function R1(n){zf=n}let pc;function Bf(){if(pc==null){let n;if(typeof window<"u")n=window;else if(typeof global<"u")n=global;else if(typeof process<"u")n=process;else if(typeof self<"u")n=self;else throw new Error("Could not find a global object");pc=n}return pc}function D1(){const n=Bf();return n._tfGlobals==null&&(n._tfGlobals=new Map),n._tfGlobals}function yu(n,t){const e=D1();if(e.has(n))return e.get(n);{const s=t();return e.set(n,s),e.get(n)}}const _a="Abs",Sr="Acos",Nr="Acosh",Po="Add",wu="AddN",Cu="All",$u="Any",La="ArgMax",Ma="ArgMin",Tr="Asin",Er="Asinh",Rr="Atan",Dr="Atanh",Ar="Atan2",Pa="AvgPool",Iu="AvgPoolGrad",za="AvgPool3D",ku="AvgPool3DGrad",Ba="BatchMatMul",Va="BatchToSpaceND",vu="Bincount",Su="BitwiseAnd",A1="BroadcastTo",Vf="BroadcastArgs",Fr="Cast",Or="Ceil",_r="ClipByValue",Nu="Complex",Wa="ComplexAbs",Ua="Concat",Ga="Conv2D",Tu="Conv2DBackpropFilter",Ha="Conv2DBackpropInput",Ka="Conv3D",Eu="Conv3DBackpropFilterV2",Ru="Conv3DBackpropInputV2",Lr="Cos",Mr="Cosh",Du="Cumprod",ja="Cumsum",Au="CropAndResize",Fu="DenseBincount",Ou="DepthToSpace",qa="DepthwiseConv2dNative",_u="DepthwiseConv2dNativeBackpropFilter",Lu="DepthwiseConv2dNativeBackpropInput",Wf="Diag",Xa="Dilation2D",_c="Dilation2DBackpropInput",Lc="Dilation2DBackpropFilter",F1="Draw",Pr="RealDiv",Mu="Einsum",zr="Elu",Pu="EluGrad",Br="Erf",Ya="Equal",Vr="Exp",Ja="ExpandDims",Wr="Expm1",zu="FFT",Bu="Fill",Vu="FlipLeftRight",Ur="Floor",Gr="FloorDiv",Za="FusedBatchNorm",Qa="GatherV2",Uf="GatherNd",tl="Greater",Hr="GreaterEqual",Kr="Identity",Wu="IFFT",Uu="Imag",jr="IsFinite",qr="IsInf",Xr="IsNan",el="LeakyRelu",nl="Less",sl="LessEqual",Gu="LinSpace",Yr="Log",Jr="Log1p",ol="LogicalAnd",rl="LogicalNot",il="LogicalOr",O1="LogSoftmax",al="LRN",Hu="LRNGrad",ll="Max",Zr="Maximum",cl="MaxPool",Ku="MaxPoolGrad",ul="MaxPool3D",ju="MaxPool3DGrad",Gf="MaxPoolWithArgmax",hl="Mean",dl="Min",Qr="Minimum",pl="MirrorPad",ti="Mod",Hf="Multinomial",ei="Multiply",fl="Neg",ml="NotEqual",qu="NonMaxSuppressionV3",Xu="NonMaxSuppressionV4",Yu="NonMaxSuppressionV5",gl="OnesLike",xl="OneHot",bl="Pack",yl="PadV2",ni="Pow",wl="Prelu",Cl="Prod",Kf="RaggedGather",jf="RaggedRange",qf="RaggedTensorToTensor",Ju="Range",Zu="Real",si="Reciprocal",oi="Relu",$l="Reshape",Il="ResizeNearestNeighbor",Qu="ResizeNearestNeighborGrad",kl="ResizeBilinear",th="ResizeBilinearGrad",ri="Relu6",vl="Reverse",ii="Round",ai="Rsqrt",Xf="ScatterNd",Yf="TensorScatterUpdate",Jf="SearchSorted",Sl="Select",li="Selu",Nl="Slice",ci="Sin",ui="Sinh",hi="Sign",di="Sigmoid",pi="Softplus",fi="Sqrt",Tl="Sum",El="SpaceToBatchND",Rl="SplitV",Dl="Softmax",Zf="SparseFillEmptyRows",Qf="SparseReshape",tm="SparseSegmentMean",em="SparseSegmentSum",nm="SparseToDense",mi="SquaredDifference",eh="Square",nh="StaticRegexReplace",sh="StridedSlice",sm="StringNGrams",om="StringSplit",rm="StringToHashBucketFast",gi="Sub",xi="Tan",bi="Tanh",yi="Tile",oh="TopK",rh="Transform",Co="Transpose",ih="Unique",Al="Unpack",Fl="UnsortedSegmentSum",Ol="ZerosLike",wi="Step",_1="FromPixels",ah="RotateWithOffset",ia="_FusedMatMul",aa="FusedConv2D",im="FusedDepthwiseConv2D";function je(...n){L().getBool("IS_TEST")||L().getBool("PROD")||console.warn(...n)}function L1(...n){L().getBool("IS_TEST")||L().getBool("PROD")||console.log(...n)}const la=yu("kernelRegistry",()=>new Map),Mc=yu("gradRegistry",()=>new Map);function tp(n,t){const e=lm(n,t);return la.get(e)}function ep(n){return Mc.get(n)}function np(n){const t=la.entries(),e=[];for(;;){const{done:s,value:o}=t.next();if(s)break;const[r,i]=o,[a]=r.split("_");a===n&&e.push(i)}return e}function am(n){const{kernelName:t,backendName:e}=n,s=lm(t,e);la.has(s)&&je(`The kernel '${t}' for backend '${e}' is already registered`),la.set(s,n)}function M1(n){const{kernelName:t}=n;Mc.has(t)&&L().getBool("DEBUG")&&je(`Overriding the gradient for '${t}'`),Mc.set(t,n)}function lm(n,t){return`${t}_${n}`}function cm(n){return n instanceof Float32Array||n instanceof Int32Array||n instanceof Uint8Array||n instanceof Uint8ClampedArray}const Os=m1||g1;function _l(n){return Os.fromString(n,!0,16)}const um=_l("c3a5c85c97cb3127"),Fs=_l("b492b66fbe98f273"),Te=_l("9ae16a3b2f90404f");function Pc(n){return n.xor(n.shru(47))}function hm(n,t,e){const s=n.slice(t,t+e);return Os.fromBytes(Array.from(s),!0,!0)}function Pt(n,t){return hm(n,t,8)}function sp(n,t){return hm(n,t,4)}function he(n,t){return t===0?n:n.shru(t).or(n.shl(64-t))}function cs(n,t,e=_l("9ddfea08eb382d69")){let s=n.xor(t).mul(e);s=s.xor(s.shru(47));let o=t.xor(s).mul(e);return o=o.xor(o.shru(47)),o=o.mul(e),o}function P1(n,t,e,s,o,r){o=o.add(n),r=he(r.add(o).add(s),21);const i=o;return o=o.add(t),o=o.add(e),r=r.add(he(o,44)),[o.add(s),r.add(i)]}function Gi(n,t,e,s){return P1(Pt(n,t),Pt(n,t+8),Pt(n,t+16),Pt(n,t+24),e,s)}function z1(n,t=n.length){if(t>=8){const e=Te.add(t*2),s=Pt(n,0).add(Te),o=Pt(n,t-8),r=he(o,37).mul(e).add(s),i=he(s,25).add(o).mul(e);return cs(r,i,e)}if(t>=4){const e=Te.add(t*2),s=sp(n,0);return cs(s.shl(3).add(t),sp(n,t-4),e)}if(t>0){const e=n[0],s=n[t>>1],o=n[t-1],r=e+(s<<8),i=t+(o<<2);return Pc(Te.mul(r).xor(um.mul(i))).mul(Te)}return Te}function B1(n,t=n.length){const e=Te.add(t*2),s=Pt(n,0).mul(Fs),o=Pt(n,8),r=Pt(n,t-8).mul(e),i=Pt(n,t-16).mul(Te);return cs(he(s.add(o),43).add(he(r,30)).add(i),s.add(he(o.add(Te),18)).add(r),e)}function V1(n,t=n.length){const e=Te.add(t*2),s=Pt(n,0).mul(Te),o=Pt(n,8),r=Pt(n,t-8).mul(e),i=Pt(n,t-16).mul(Te),a=he(s.add(o),43).add(he(r,30)).add(i),l=cs(a,s.add(he(o.add(Te),18)).add(r),e),c=Pt(n,16).mul(e),u=Pt(n,24),h=a.add(Pt(n,t-32)).mul(e),d=l.add(Pt(n,t-24)).mul(e);return cs(he(c.add(u),43).add(he(h,30)).add(d),c.add(he(u.add(s),18)).add(h),e)}function W1(n,t=n.length){const e=Os.fromNumber(81,!0);if(t<=32)return t<=16?z1(n,t):B1(n,t);if(t<=64)return V1(n,t);let s=e,o=e.mul(Fs).add(113),r=Pc(o.mul(Te).add(113)).mul(Te),i=[Os.UZERO,Os.UZERO],a=[Os.UZERO,Os.UZERO];s=s.mul(Te).add(Pt(n,0));let l=0;const c=(t-1>>6)*64,u=c+(t-1&63)-63;do s=he(s.add(o).add(i[0]).add(Pt(n,l+8)),37).mul(Fs),o=he(o.add(i[1]).add(Pt(n,l+48)),42).mul(Fs),s=s.xor(a[1]),o=o.add(i[0]).add(Pt(n,l+40)),r=he(r.add(a[0]),33).mul(Fs),i=Gi(n,l,i[1].mul(Fs),s.add(a[0])),a=Gi(n,l+32,r.add(a[1]),o.add(Pt(n,l+16))),[r,s]=[s,r],l+=64;while(l!==c);const h=Fs.add(r.and(255).shl(1));return l=u,a[0]=a[0].add(t-1&63),i[0]=i[0].add(a[0]),a[0]=a[0].add(i[0]),s=he(s.add(o).add(i[0]).add(Pt(n,l+8)),37).mul(h),o=he(o.add(i[1]).add(Pt(n,l+48)),42).mul(h),s=s.xor(a[1].mul(9)),o=o.add(i[0].mul(9).add(Pt(n,l+40))),r=he(r.add(a[0]),33).mul(h),i=Gi(n,l,i[1].mul(h),s.add(a[0])),a=Gi(n,l+32,r.add(a[1]),o.add(Pt(n,l+16))),[r,s]=[s,r],cs(cs(i[0],a[0],h).add(Pc(o).mul(um)).add(r),cs(i[1],a[1],h).add(s),h)}function ws(n,t){return t==="string"?us(n):so([n],t)}function U1(n,t){return n instanceof Float32Array&&t==="float32"||n instanceof Int32Array&&t==="int32"||n instanceof Uint8Array&&t==="bool"}function so(n,t){if(t==="string")throw new Error("Cannot convert a string[] to a TypedArray");if(Array.isArray(n)&&(n=Us(n)),L().getBool("DEBUG")&&C1(n,t),U1(n,t))return n;if(t==null||t==="float32"||t==="complex64")return new Float32Array(n);if(t==="int32")return new Int32Array(n);if(t==="bool"){const e=new Uint8Array(n.length);for(let s=0;s<e.length;++s)Math.round(n[s])!==0&&(e[s]=1);return e}else throw new Error(`Unknown data type ${t}`)}function Fe(){return L().platform.now()}function us(n,t="utf-8"){return t=t||"utf-8",L().platform.encode(n,t)}function ps(n,t="utf-8"){return t=t||"utf-8",L().platform.decode(n,t)}function rn(n){return L().platform.isTypedArray!=null?L().platform.isTypedArray(n):cm(n)}function Us(n,t=[],e=!1){if(t==null&&(t=[]),typeof n=="boolean"||typeof n=="number"||typeof n=="string"||bu(n)||n==null||rn(n)&&e)t.push(n);else if(Array.isArray(n)||rn(n))for(let s=0;s<n.length;++s)Us(n[s],t,e);else{let s=-1;for(const o of Object.keys(n))/^([1-9]+[0-9]*|0)$/.test(o)&&(s=Math.max(s,Number(o)));for(let o=0;o<=s;o++)Us(n[o],t,e)}return t}class G1{constructor(t,e){this.backendTimer=t,this.logger=e,e==null&&(this.logger=new K1)}profileKernel(t,e,s){let o;const r=()=>{o=s()};let i;const a=Fe();if(this.backendTimer.timerAvailable())i=this.backendTimer.time(r);else{r();for(const c of o)c.dataSync();i=Promise.resolve({kernelMs:Fe()-a})}if(L().getBool("CHECK_COMPUTATION_FOR_ERRORS"))for(let c=0;c<o.length;c++){const u=o[c];u.data().then(h=>{H1(h,u.dtype,t)})}return{kernelName:t,outputs:o,inputs:e,timeMs:i.then(c=>c.kernelMs),extraInfo:i.then(c=>c.getExtraProfileInfo!=null?c.getExtraProfileInfo():"")}}logKernelProfile(t){const{kernelName:e,outputs:s,timeMs:o,inputs:r,extraInfo:i}=t;s.forEach(a=>{Promise.all([a.data(),o,i]).then(l=>{this.logger.logKernelProfile(e,a,l[0],l[1],r,l[2])})})}}function H1(n,t,e){if(t!=="float32")return!1;for(let s=0;s<n.length;s++){const o=n[s];if(isNaN(o)||!isFinite(o))return console.warn(`Found ${o} in the result of '${e}'`),!0}return!1}class K1{logKernelProfile(t,e,s,o,r,i){const a=typeof o=="number"?wo(`${o}ms`,9):o.error,l=wo(t,25),c=e.rank,u=e.size,h=wo(e.shape.toString(),14);let d="";for(const p in r){const f=r[p];if(f!=null){const m=f.shape||e.shape,g=m.length;d+=`${p}: ${g}D ${g>0?m:""} `}}console.log(`%c${l}	%c${a}	%c${c}D ${h}	%c${u}	%c${d}	%c${i}`,"font-weight:bold","color:red","color:blue","color: orange","color: green","color: steelblue")}}function j1(n,t,e){const s={},o={};for(let l=0;l<t.length;l++)s[t[l].id]=!0;for(let l=0;l<n.length;l++){const c=n[l],u=c.inputs;for(const h in u){const d=u[h];let p=!1;for(let f=0;f<t.length;f++)if(s[d.id]){c.outputs.forEach(m=>s[m.id]=!0),p=!0,o[c.id]=!0;break}if(p)break}}const r={};r[e.id]=!0;const i={};for(let l=n.length-1;l>=0;l--){const c=n[l],u=c.inputs;for(let h=0;h<c.outputs.length;h++)if(r[c.outputs[h].id]){for(const d in u)r[u[d].id]=!0,i[c.id]=!0;break}}const a=[];for(let l=0;l<n.length;l++){const c=n[l];if(o[c.id]&&i[c.id]){const u={};for(const d in c.inputs){const p=c.inputs[d];s[p.id]&&(u[d]=p)}const h=Object.assign({},c);h.inputs=u,h.outputs=c.outputs,a.push(h)}}return a}function q1(n,t,e,s){for(let o=t.length-1;o>=0;o--){const r=t[o],i=[];if(r.outputs.forEach(l=>{const c=n[l.id];c!=null?i.push(c):i.push(null)}),r.gradient==null)throw new Error(`Cannot compute gradient: gradient function not found for ${r.kernelName}.`);const a=r.gradient(i);for(const l in r.inputs){if(!(l in a))throw new Error(`Cannot backprop through input ${l}. Available gradients found: ${Object.keys(a)}.`);const c=e(()=>a[l]());if(c.dtype!=="float32")throw new Error(`Error in gradient for op ${r.kernelName}. The gradient of input ${l} must have 'float32' dtype, but has '${c.dtype}'`);const u=r.inputs[l];if(!Et(c.shape,u.shape))throw new Error(`Error in gradient for op ${r.kernelName}. The gradient of input '${l}' has shape '${c.shape}', which does not match the shape of the input '${u.shape}'`);if(n[u.id]==null)n[u.id]=c;else{const h=n[u.id];n[u.id]=s(h,c),h.dispose()}}}}const op=20,Qo=3,fc=7;function X1(n,t,e,s){const o=lt(t),r=Y1(n,t,e,o),i=t.length,a=sa(n,t,e,o,r),l=["Tensor"];return s&&(l.push(`  dtype: ${e}`),l.push(`  rank: ${i}`),l.push(`  shape: [${t}]`),l.push("  values:")),l.push(a.map(c=>"    "+c).join(`
`)),l.join(`
`)}function Y1(n,t,e,s){const o=W(t),r=s[s.length-1],i=new Array(r).fill(0),a=t.length,l=e==="complex64"?or(n):n;if(a>1)for(let c=0;c<o/r;c++){const u=c*r;for(let h=0;h<r;h++)i[h]=Math.max(i[h],sr(l[u+h],0,e).length)}return i}function sr(n,t,e){let s;return Array.isArray(n)?s=`${parseFloat(n[0].toFixed(fc))} + ${parseFloat(n[1].toFixed(fc))}j`:vr(n)?s=`'${n}'`:e==="bool"?s=dm(n):s=parseFloat(n.toFixed(fc)).toString(),wo(s,t)}function dm(n){return n===0?"false":"true"}function sa(n,t,e,s,o,r=!0){const i=e==="complex64"?2:1,a=t[0],l=t.length;if(l===0){if(e==="complex64"){const m=or(n);return[sr(m[0],0,e)]}return e==="bool"?[dm(n[0])]:[n[0].toString()]}if(l===1){if(a>op){const g=Qo*i;let x=Array.from(n.slice(0,g)),b=Array.from(n.slice((a-Qo)*i,a*i));return e==="complex64"&&(x=or(x),b=or(b)),["["+x.map((w,y)=>sr(w,o[y],e)).join(", ")+", ..., "+b.map((w,y)=>sr(w,o[a-Qo+y],e)).join(", ")+"]"]}return["["+(e==="complex64"?or(n):Array.from(n)).map((g,x)=>sr(g,o[x],e)).join(", ")+"]"]}const c=t.slice(1),u=s.slice(1),h=s[0]*i,d=[];if(a>op){for(let m=0;m<Qo;m++){const g=m*h,x=g+h;d.push(...sa(n.slice(g,x),c,e,u,o,!1))}d.push("...");for(let m=a-Qo;m<a;m++){const g=m*h,x=g+h;d.push(...sa(n.slice(g,x),c,e,u,o,m===a-1))}}else for(let m=0;m<a;m++){const g=m*h,x=g+h;d.push(...sa(n.slice(g,x),c,e,u,o,m===a-1))}const p=l===2?",":"";d[0]="["+(a>0?d[0]+p:"");for(let m=1;m<d.length-1;m++)d[m]=" "+d[m]+p;let f=`,
`;for(let m=2;m<l;m++)f+=`
`;return d[d.length-1]=" "+d[d.length-1]+"]"+(r?"":f),d}function or(n){const t=[];for(let e=0;e<n.length;e+=2)t.push([n[e],n[e+1]]);return t}class xe{constructor(t,e,s){if(this.dtype=e,this.shape=t.slice(),this.size=W(t),s!=null){const o=s.length;$(o===this.size,()=>`Length of values '${o}' does not match the size inferred by the shape '${this.size}'.`)}if(e==="complex64")throw new Error("complex64 dtype TensorBuffers are not supported. Please create a TensorBuffer for the real and imaginary parts separately and call tf.complex(real, imag).");this.values=s||Xt(e,this.size),this.strides=lt(t)}set(t,...e){e.length===0&&(e=[0]),$(e.length===this.rank,()=>`The number of provided coordinates (${e.length}) must match the rank (${this.rank})`);const s=this.locToIndex(e);this.values[s]=t}get(...t){t.length===0&&(t=[0]);let e=0;for(const o of t){if(o<0||o>=this.shape[e]){const r=`Requested out of range element at ${t}.   Buffer shape=${this.shape}`;throw new Error(r)}e++}let s=t[t.length-1];for(let o=0;o<t.length-1;++o)s+=this.strides[o]*t[o];return this.values[s]}locToIndex(t){if(this.rank===0)return 0;if(this.rank===1)return t[0];let e=t[t.length-1];for(let s=0;s<t.length-1;++s)e+=this.strides[s]*t[s];return e}indexToLoc(t){if(this.rank===0)return[];if(this.rank===1)return[t];const e=new Array(this.shape.length);for(let s=0;s<e.length-1;++s)e[s]=Math.floor(t/this.strides[s]),t-=e[s]*this.strides[s];return e[e.length-1]=t,e}get rank(){return this.shape.length}toTensor(){return fn().makeTensor(this.values,this.shape,this.dtype)}}let fn=null,bo=null;function J1(n){fn=n}function Z1(n){bo=n}class se{constructor(t,e,s,o){this.kept=!1,this.isDisposedInternal=!1,this.shape=t.slice(),this.dtype=e||"float32",this.size=W(t),this.strides=lt(t),this.dataId=s,this.id=o,this.rankType=this.rank<5?this.rank.toString():"higher"}get rank(){return this.shape.length}async buffer(){const t=await this.data();return bo.buffer(this.shape,this.dtype,t)}bufferSync(){return bo.buffer(this.shape,this.dtype,this.dataSync())}async array(){const t=await this.data();return xn(this.shape,t,this.dtype==="complex64")}arraySync(){return xn(this.shape,this.dataSync(),this.dtype==="complex64")}async data(){this.throwIfDisposed();const t=fn().read(this.dataId);if(this.dtype==="string"){const e=await t;try{return e.map(s=>ps(s))}catch{throw new Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().")}}return t}dataToGPU(t){return this.throwIfDisposed(),fn().readToGPU(this.dataId,t)}dataSync(){this.throwIfDisposed();const t=fn().readSync(this.dataId);if(this.dtype==="string")try{return t.map(e=>ps(e))}catch{throw new Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().")}return t}async bytes(){this.throwIfDisposed();const t=await fn().read(this.dataId);return this.dtype==="string"?t:new Uint8Array(t.buffer)}dispose(){this.isDisposed||(this.kerasMask&&this.kerasMask.dispose(),fn().disposeTensor(this),this.isDisposedInternal=!0)}get isDisposed(){return this.isDisposedInternal}throwIfDisposed(){if(this.isDisposed)throw new Error("Tensor is disposed.")}print(t=!1){return bo.print(this,t)}clone(){return this.throwIfDisposed(),bo.clone(this)}toString(t=!1){const e=this.dataSync();return X1(e,this.shape,this.dtype,t)}cast(t){return this.throwIfDisposed(),bo.cast(this,t)}variable(t=!0,e,s){return this.throwIfDisposed(),fn().makeVariable(this,t,e,s)}}Object.defineProperty(se,Symbol.hasInstance,{value:n=>!!n&&n.data!=null&&n.dataSync!=null&&n.throwIfDisposed!=null});function V(){return yu("Tensor",()=>se)}V();class ca extends se{constructor(t,e,s,o){super(t.shape,t.dtype,t.dataId,o),this.trainable=e,this.name=s}assign(t){if(t.dtype!==this.dtype)throw new Error(`dtype of the new value (${t.dtype}) and previous value (${this.dtype}) must match`);if(!Et(t.shape,this.shape))throw new Error(`shape of the new value (${t.shape}) and previous value (${this.shape}) must match`);fn().disposeTensor(this),this.dataId=t.dataId,fn().incRef(this,null)}dispose(){fn().disposeVariable(this),this.isDisposedInternal=!0}}Object.defineProperty(ca,Symbol.hasInstance,{value:n=>n instanceof se&&n.assign!=null&&n.assign instanceof Function});var rp;(function(n){n.R0="R0",n.R1="R1",n.R2="R2",n.R3="R3",n.R4="R4",n.R5="R5",n.R6="R6"})(rp||(rp={}));var zc;(function(n){n.float32="float32",n.int32="int32",n.bool="int32",n.complex64="complex64"})(zc||(zc={}));var Bc;(function(n){n.float32="float32",n.int32="int32",n.bool="bool",n.complex64="complex64"})(Bc||(Bc={}));var Vc;(function(n){n.float32="float32",n.int32="float32",n.bool="float32",n.complex64="complex64"})(Vc||(Vc={}));var Wc;(function(n){n.float32="complex64",n.int32="complex64",n.bool="complex64",n.complex64="complex64"})(Wc||(Wc={}));const Q1={float32:Vc,int32:zc,bool:Bc,complex64:Wc};function Ue(n,t){if(n==="string"||t==="string"){if(n==="string"&&t==="string")return"string";throw new Error(`Can not upcast ${n} with ${t}`)}return Q1[n][t]}function lh(n){return Ue(n,"int32")}function pm(n){return n!=null&&typeof n=="object"&&"texture"in n&&n.texture instanceof WebGLTexture}function fm(n){return typeof GPUBuffer<"u"&&n!=null&&typeof n=="object"&&"buffer"in n&&n.buffer instanceof GPUBuffer}function Jt(n,t){if(n.dtype===t.dtype)return[n,t];const e=Ue(n.dtype,t.dtype);return[n.cast(e),t.cast(e)]}function mm(n){const t=[];return gm(n,t,new Set),t}function gm(n,t,e){if(n==null)return;if(n instanceof se){t.push(n);return}if(!tw(n))return;const s=n;for(const o in s){const r=s[o];e.has(r)||(e.add(r),gm(r,t,e))}}function tw(n){return Array.isArray(n)||typeof n=="object"}function mc(n){return n.kernelName!=null}class ip{constructor(){this.registeredVariables={},this.nextTapeNodeId=0,this.numBytes=0,this.numTensors=0,this.numStringTensors=0,this.numDataBuffers=0,this.gradientDepth=0,this.kernelDepth=0,this.scopeStack=[],this.numDataMovesStack=[],this.nextScopeId=0,this.tensorInfo=new WeakMap,this.profiling=!1,this.activeProfile={newBytes:0,newTensors:0,peakBytes:0,kernels:[],result:null,get kernelNames(){return Array.from(new Set(this.kernels.map(t=>t.name)))}}}dispose(){for(const t in this.registeredVariables)this.registeredVariables[t].dispose()}}class So{constructor(t){this.ENV=t,this.registry={},this.registryFactory={},this.pendingBackendInitId=0,this.state=new ip}async ready(){if(this.pendingBackendInit!=null)return this.pendingBackendInit.then(()=>{});if(this.backendInstance!=null)return;const t=this.getSortedBackends();for(let e=0;e<t.length;e++){const s=t[e];if(await this.initializeBackend(s).success){await this.setBackend(s);return}}throw new Error("Could not initialize any backends, all backend initializations failed.")}get backend(){if(this.pendingBackendInit!=null)throw new Error(`Backend '${this.backendName}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);if(this.backendInstance==null){const{name:t,asyncInit:e}=this.initializeBackendsAndReturnBest();if(e)throw new Error(`The highest priority backend '${t}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);this.setBackend(t)}return this.backendInstance}backendNames(){return Object.keys(this.registryFactory)}findBackend(t){if(!(t in this.registry))if(t in this.registryFactory){const{asyncInit:e}=this.initializeBackend(t);if(e)return null}else return null;return this.registry[t]}findBackendFactory(t){return t in this.registryFactory?this.registryFactory[t].factory:null}registerBackend(t,e,s=1){return t in this.registryFactory?(je(`${t} backend was already registered. Reusing existing backend factory.`),!1):(this.registryFactory[t]={factory:e,priority:s},!0)}async setBackend(t){if(this.registryFactory[t]==null)throw new Error(`Backend name '${t}' not found in registry`);if(this.backendName=t,this.registry[t]==null){this.backendInstance=null;const{success:e,asyncInit:s}=this.initializeBackend(t);if(!(s?await e:e))return!1}return this.backendInstance=this.registry[t],this.setupRegisteredKernels(),this.profiler=new G1(this.backendInstance),!0}setupRegisteredKernels(){np(this.backendName).forEach(e=>{e.setupFunc!=null&&e.setupFunc(this.backendInstance)})}disposeRegisteredKernels(t){np(t).forEach(s=>{s.disposeFunc!=null&&s.disposeFunc(this.registry[t])})}initializeBackend(t){const e=this.registryFactory[t];if(e==null)throw new Error(`Cannot initialize backend ${t}, no registration found.`);try{const s=e.factory();if(s&&!(s instanceof fu)&&typeof s.then=="function"){const o=++this.pendingBackendInitId,r=s.then(i=>o<this.pendingBackendInitId?!1:(this.registry[t]=i,this.pendingBackendInit=null,!0)).catch(i=>(o<this.pendingBackendInitId||(this.pendingBackendInit=null,je(`Initialization of backend ${t} failed`),je(i.stack||i.message)),!1));return this.pendingBackendInit=r,{success:r,asyncInit:!0}}else return this.registry[t]=s,{success:!0,asyncInit:!1}}catch(s){return je(`Initialization of backend ${t} failed`),je(s.stack||s.message),{success:!1,asyncInit:!1}}}removeBackend(t){if(!(t in this.registryFactory))throw new Error(`${t} backend not found in registry`);this.backendName===t&&this.pendingBackendInit!=null&&this.pendingBackendInitId++,t in this.registry&&(this.disposeRegisteredKernels(t),this.registry[t].dispose(),delete this.registry[t]),delete this.registryFactory[t],this.backendName===t&&(this.pendingBackendInit=null,this.backendName=null,this.backendInstance=null)}getSortedBackends(){if(Object.keys(this.registryFactory).length===0)throw new Error("No backend found in registry.");return Object.keys(this.registryFactory).sort((t,e)=>this.registryFactory[e].priority-this.registryFactory[t].priority)}initializeBackendsAndReturnBest(){const t=this.getSortedBackends();for(let e=0;e<t.length;e++){const s=t[e],{success:o,asyncInit:r}=this.initializeBackend(s);if(r||o)return{name:s,asyncInit:r}}throw new Error("Could not initialize any backends, all backend initializations failed.")}moveData(t,e){const s=this.state.tensorInfo.get(e),o=s.backend,r=this.readSync(e),i=o.refCount(e);o.disposeData(e,!0),s.backend=t,t.move(e,r,s.shape,s.dtype,i),this.shouldCheckForMemLeaks()&&this.state.numDataMovesStack[this.state.numDataMovesStack.length-1]++}tidy(t,e){let s=null;if(e==null){if(typeof t!="function")throw new Error("Please provide a function to tidy()");e=t}else{if(typeof t!="string"&&!(t instanceof String))throw new Error("When calling with two arguments, the first argument to tidy() must be a string");if(typeof e!="function")throw new Error("When calling with two arguments, the 2nd argument to tidy() must be a function");s=t}let o;return this.scopedRun(()=>this.startScope(s),()=>this.endScope(o),()=>(o=e(),o instanceof Promise&&console.error("Cannot return a Promise inside of tidy."),o))}scopedRun(t,e,s){t();try{const o=s();return e(),o}catch(o){throw e(),o}}nextTensorId(){return So.nextTensorId++}nextVariableId(){return So.nextVariableId++}clone(t){const e=D.runKernel(Kr,{x:t}),s={x:t},o=i=>({x:()=>{const a="float32",l={x:i},c={dtype:a};return D.runKernel(Fr,l,c)}}),r=[];return this.addTapeNode(this.state.activeScope.name,s,[e],o,r,{}),e}runKernel(t,e,s){if(this.backendName==null&&this.backend,!(tp(t,this.backendName)!=null))throw new Error(`Kernel '${t}' not registered for backend '${this.backendName}'`);return this.runKernelFunc({kernelName:t,inputs:e,attrs:s})}shouldCheckForMemLeaks(){return this.ENV.getBool("IS_TEST")}checkKernelForMemLeak(t,e,s){const o=this.backend.numDataIds();let r=0;s.forEach(l=>{r+=l.dtype==="complex64"?3:1});const i=this.state.numDataMovesStack[this.state.numDataMovesStack.length-1],a=o-e-r-i;if(a>0)throw new Error(`Backend '${this.backendName}' has an internal memory leak (${a} data ids) after running '${t}'`)}runKernelFunc(t){let e,s=[];const o=this.isTapeOn(),r=this.state.numBytes,i=this.state.numTensors;this.shouldCheckForMemLeaks()&&this.state.numDataMovesStack.push(0);let a;this.backendName==null&&this.backend;let l;const c=mc(t)?t.kernelName:this.state.activeScope!=null?this.state.activeScope.name:"";if(mc(t)){const{kernelName:f,inputs:m,attrs:g}=t;this.backendName==null&&this.backend;const x=tp(f,this.backendName);$(x!=null,()=>`Cannot find registered kernel '${f}' for backend '${this.backendName}'`),a=()=>{const b=this.backend.numDataIds();l=x.kernelFunc({inputs:m,attrs:g,backend:this.backend});const w=Array.isArray(l)?l:[l];this.shouldCheckForMemLeaks()&&this.checkKernelForMemLeak(f,b,w);const y=w.map(C=>C.rank!=null?C:this.makeTensorFromTensorInfo(C));if(o){const C=this.getTensorsForGradient(f,m,y);s=this.saveTensorsForBackwardMode(C)}return y}}else{const{forwardFunc:f}=t,m=g=>{o&&(s=g.map(x=>this.keep(this.clone(x))))};a=()=>{const g=this.backend.numDataIds();l=this.tidy(()=>f(this.backend,m));const x=Array.isArray(l)?l:[l];return this.shouldCheckForMemLeaks()&&this.checkKernelForMemLeak(c,g,x),x}}const{inputs:u,attrs:h}=t,d=mc(t)?null:t.backwardsFunc;let p;return this.scopedRun(()=>this.state.kernelDepth++,()=>this.state.kernelDepth--,()=>{!this.ENV.getBool("DEBUG")&&!this.state.profiling?e=a():(p=this.profiler.profileKernel(c,u,()=>a()),this.ENV.getBool("DEBUG")&&this.profiler.logKernelProfile(p),e=p.outputs)}),o&&this.addTapeNode(c,u,e,d,s,h),this.state.profiling&&this.state.activeProfile.kernels.push({name:c,bytesAdded:this.state.numBytes-r,totalBytesSnapshot:this.state.numBytes,tensorsAdded:this.state.numTensors-i,totalTensorsSnapshot:this.state.numTensors,inputShapes:Object.keys(u).map(f=>u[f]!=null?u[f].shape:null),outputShapes:e.map(f=>f.shape),kernelTimeMs:p.timeMs,extraInfo:p.extraInfo}),Array.isArray(l)?e:e[0]}saveTensorsForBackwardMode(t){return t.map(s=>this.keep(this.clone(s)))}getTensorsForGradient(t,e,s){const o=ep(t);if(o!=null){const r=o.inputsToSave||[],i=o.outputsToSave||[];let a;o.saveAllInputs?($(Array.isArray(e),()=>"saveAllInputs is true, expected inputs to be an array."),a=Object.keys(e).map(c=>e[c])):a=r.map(c=>e[c]);const l=s.filter((c,u)=>i[u]);return a.concat(l)}return[]}makeTensor(t,e,s,o){if(t==null)throw new Error("Values passed to engine.makeTensor() are null");s=s||"float32",o=o||this.backend;let r=t;s==="string"&&vr(t[0])&&(r=t.map(l=>us(l)));const i=o.write(r,e,s),a=new se(e,s,i,this.nextTensorId());if(this.trackTensor(a,o),s==="string"){const l=this.state.tensorInfo.get(i),c=I1(r);this.state.numBytes+=c-l.bytes,l.bytes=c}return a}makeTensorFromDataId(t,e,s,o){s=s||"float32";const r={dataId:t,shape:e,dtype:s};return this.makeTensorFromTensorInfo(r,o)}makeTensorFromTensorInfo(t,e){const{dataId:s,shape:o,dtype:r}=t,i=new se(o,r,s,this.nextTensorId());return this.trackTensor(i,e),i}makeVariable(t,e=!0,s,o){s=s||this.nextVariableId().toString(),o!=null&&o!==t.dtype&&(t=t.cast(o));const r=new ca(t,e,s,this.nextTensorId());if(this.state.registeredVariables[r.name]!=null)throw new Error(`Variable with name ${r.name} was already registered`);return this.state.registeredVariables[r.name]=r,this.incRef(r,this.backend),r}trackTensor(t,e){this.state.numTensors++,t.dtype==="string"&&this.state.numStringTensors++;let s=0;t.dtype!=="complex64"&&t.dtype!=="string"&&(s=t.size*ra(t.dtype)),this.state.numBytes+=s,this.state.tensorInfo.has(t.dataId)||(this.state.numDataBuffers++,this.state.tensorInfo.set(t.dataId,{backend:e||this.backend,dtype:t.dtype,shape:t.shape,bytes:s})),t instanceof ca||this.track(t)}incRef(t,e){this.trackTensor(t,e),this.backend.incRef(t.dataId)}removeDataId(t,e){this.state.tensorInfo.has(t)&&this.state.tensorInfo.get(t).backend===e&&(this.state.tensorInfo.delete(t),this.state.numDataBuffers--)}disposeTensor(t){if(!this.state.tensorInfo.has(t.dataId))return;const e=this.state.tensorInfo.get(t.dataId);if(this.state.numTensors--,t.dtype==="string"&&(this.state.numStringTensors--,this.state.numBytes-=e.bytes),t.dtype!=="complex64"&&t.dtype!=="string"){const s=t.size*ra(t.dtype);this.state.numBytes-=s}e.backend.disposeData(t.dataId)&&this.removeDataId(t.dataId,e.backend)}disposeVariables(){for(const t in this.state.registeredVariables){const e=this.state.registeredVariables[t];this.disposeVariable(e)}}disposeVariable(t){this.disposeTensor(t),this.state.registeredVariables[t.name]!=null&&delete this.state.registeredVariables[t.name]}memory(){const t=this.backend.memory();return t.numTensors=this.state.numTensors,t.numDataBuffers=this.state.numDataBuffers,t.numBytes=this.state.numBytes,this.state.numStringTensors>0&&(t.unreliable=!0,t.reasons==null&&(t.reasons=[]),t.reasons.push("Memory usage by string tensors is approximate (2 bytes per character)")),t}async profile(t){this.state.profiling=!0;const e=this.state.numBytes,s=this.state.numTensors;this.state.activeProfile.kernels=[],this.state.activeProfile.result=await t(),this.state.profiling=!1,this.state.activeProfile.peakBytes=Math.max(...this.state.activeProfile.kernels.map(o=>o.totalBytesSnapshot)),this.state.activeProfile.newBytes=this.state.numBytes-e,this.state.activeProfile.newTensors=this.state.numTensors-s;for(const o of this.state.activeProfile.kernels)o.kernelTimeMs=await o.kernelTimeMs,o.extraInfo=await o.extraInfo;return this.state.activeProfile}isTapeOn(){return this.state.gradientDepth>0&&this.state.kernelDepth===0}addTapeNode(t,e,s,o,r,i){const a={id:this.state.nextTapeNodeId++,kernelName:t,inputs:e,outputs:s,saved:r},l=ep(t);l!=null&&(o=l.gradFunc),o!=null&&(a.gradient=c=>(c=c.map((u,h)=>{if(u==null){const d=s[h],p=$e(d.size,d.dtype);return this.makeTensor(p,d.shape,d.dtype)}return u}),o(c.length>1?c:c[0],r,i))),this.state.activeTape.push(a)}keep(t){return t.kept=!0,t}startTape(){this.state.gradientDepth===0&&(this.state.activeTape=[]),this.state.gradientDepth++}endTape(){this.state.gradientDepth--}startScope(t){const e={track:[],name:"unnamed scope",id:this.state.nextScopeId++};t&&(e.name=t),this.state.scopeStack.push(e),this.state.activeScope=e}endScope(t){const e=mm(t),s=new Set(e.map(r=>r.id));for(let r=0;r<this.state.activeScope.track.length;r++){const i=this.state.activeScope.track[r];!i.kept&&!s.has(i.id)&&i.dispose()}const o=this.state.scopeStack.pop();this.state.activeScope=this.state.scopeStack.length===0?null:this.state.scopeStack[this.state.scopeStack.length-1],e.forEach(r=>{!r.kept&&r.scopeId===o.id&&this.track(r)})}gradients(t,e,s,o=!1){if($(e.length>0,()=>"gradients() received an empty list of xs."),s!=null&&s.dtype!=="float32")throw new Error(`dy must have 'float32' dtype, but has '${s.dtype}'`);const r=this.scopedRun(()=>this.startTape(),()=>this.endTape(),()=>this.tidy("forward",t));$(r instanceof se,()=>"The result y returned by f() must be a tensor.");const i=j1(this.state.activeTape,e,r);if(!o&&i.length===0&&e.length>0)throw new Error("Cannot compute gradient of y=f(x) with respect to x. Make sure that the f you passed encloses all operations that lead from x to y.");return this.tidy("backward",()=>{const a={};a[r.id]=s??ew(r.shape),q1(a,i,c=>this.tidy(c),nw);const l=e.map(c=>a[c.id]);return this.state.gradientDepth===0&&(this.state.activeTape.forEach(c=>{for(const u of c.saved)u.dispose()}),this.state.activeTape=null),{value:r,grads:l}})}customGrad(t){return $(Fc(t),()=>"The f passed in customGrad(f) must be a function."),(...e)=>{$(e.every(a=>a instanceof se),()=>"The args passed in customGrad(f)(x1, x2,...) must all be tensors");let s;const o={};e.forEach((a,l)=>{o[l]=a});const r=(a,l)=>(s=t(...e,l),$(s.value instanceof se,()=>"The function f passed in customGrad(f) must return an object where `obj.value` is a tensor"),$(Fc(s.gradFunc),()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function."),s.value),i=(a,l)=>{const c=s.gradFunc(a,l),u=Array.isArray(c)?c:[c];$(u.length===e.length,()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns the same number of tensors as inputs passed to f(...)."),$(u.every(d=>d instanceof se),()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns a list of only tensors.");const h={};return u.forEach((d,p)=>{h[p]=()=>d}),h};return this.runKernelFunc({forwardFunc:r,backwardsFunc:i,inputs:o})}}readSync(t){return this.state.tensorInfo.get(t).backend.readSync(t)}read(t){return this.state.tensorInfo.get(t).backend.read(t)}readToGPU(t,e){return this.state.tensorInfo.get(t).backend.readToGPU(t,e)}async time(t){const e=Fe(),s=await this.backend.time(t);return s.wallMs=Fe()-e,s}track(t){return this.state.activeScope!=null&&(t.scopeId=this.state.activeScope.id,this.state.activeScope.track.push(t)),t}get registeredVariables(){return this.state.registeredVariables}reset(){this.pendingBackendInitId++,this.state.dispose(),this.ENV.reset(),this.state=new ip;for(const t in this.registry)this.disposeRegisteredKernels(t),this.registry[t].dispose(),delete this.registry[t];this.backendName=null,this.backendInstance=null,this.pendingBackendInit=null}}So.nextTensorId=0;So.nextVariableId=0;function ew(n){const t=xu(W(n),"float32");return D.makeTensor(t,n,"float32")}function xm(){const n=Bf();if(n._tfengine==null){const t=new S1(n);n._tfengine=new So(t)}return R1(n._tfengine.ENV),J1(()=>n._tfengine),n._tfengine}const D=xm();function nw(n,t){const e={a:n,b:t};return D.runKernel(Po,e)}function sw(){return typeof navigator<"u"&&navigator!=null}function bm(n){if(n||sw()){if(n||(n=navigator),n.product==="ReactNative")return!0;const t=n.userAgent||n.vendor||(typeof window<"u"?window.opera:"");if(!t){const e=n;return e.userAgentData&&e.userAgentData.mobile}return/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(t)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(t.substr(0,4))}return!1}function ym(){return typeof window<"u"&&window.document!=null||typeof WorkerGlobalScope<"u"}const Me=L();Me.registerFlag("DEBUG",()=>!1,n=>{n&&console.warn("Debugging mode is ON. The output of every math call will be downloaded to CPU and checked for NaNs. This significantly impacts performance.")});Me.registerFlag("IS_BROWSER",()=>ym());Me.registerFlag("IS_NODE",()=>typeof process<"u"&&typeof process.versions<"u"&&typeof process.versions.node<"u");Me.registerFlag("IS_CHROME",()=>typeof navigator<"u"&&navigator!=null&&navigator.userAgent!=null&&/Chrome/.test(navigator.userAgent)&&/Google Inc/.test(navigator.vendor));Me.registerFlag("IS_SAFARI",()=>typeof navigator<"u"&&navigator!=null&&navigator.userAgent!=null&&/Safari/.test(navigator.userAgent)&&/Apple/.test(navigator.vendor));Me.registerFlag("PROD",()=>!1);Me.registerFlag("TENSORLIKE_CHECK_SHAPE_CONSISTENCY",()=>Me.getBool("DEBUG"));Me.registerFlag("DEPRECATION_WARNINGS_ENABLED",()=>!0);Me.registerFlag("IS_TEST",()=>!1);Me.registerFlag("CHECK_COMPUTATION_FOR_ERRORS",()=>Me.getBool("DEBUG"));Me.registerFlag("WRAP_TO_IMAGEBITMAP",()=>!1);Me.registerFlag("CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU",()=>!1);Me.registerFlag("USE_SETTIMEOUTCUSTOM",()=>!1);function Ll(n,t){let e=n;if(rn(n))return t==="string"?[]:[n.length];if(pm(n)){const o=n.channels||"RGBA";return[n.height,n.width*o.length]}else if(fm(n))return[n.buffer.size/(t==null?4:ra(t))];if(!Array.isArray(n))return[];const s=[];for(;Array.isArray(e)||rn(e)&&t!=="string";)s.push(e.length),e=e[0];return Array.isArray(n)&&L().getBool("TENSORLIKE_CHECK_SHAPE_CONSISTENCY")&&wm(n,s,[]),s}function wm(n,t,e){if(e=e||[],!Array.isArray(n)&&!rn(n)){$(t.length===0,()=>`Element arr[${e.join("][")}] is a primitive, but should be an array/TypedArray of ${t[0]} elements`);return}$(t.length>0,()=>`Element arr[${e.join("][")}] should be a primitive, but is an array of ${n.length} elements`),$(n.length===t[0],()=>`Element arr[${e.join("][")}] should have ${t[0]} elements, but has ${n.length} elements`);const s=t.slice(1);for(let o=0;o<n.length;++o)wm(n[o],s,e.concat(o))}function ap(n,t,e,s){if(n!=="string_or_numeric"){if(n==null)throw new Error("Expected dtype cannot be null.");if(n!=="numeric"&&n!==t||n==="numeric"&&t==="string")throw new Error(`Argument '${e}' passed to '${s}' must be ${n} tensor, but got ${t} tensor`)}}function S(n,t,e,s="numeric"){if(n instanceof V())return ap(s,n.dtype,t,e),n;let o=Lo(n);if(o!=="string"&&["bool","int32","float32"].indexOf(s)>=0&&(o=s),ap(s,o,t,e),n==null||!rn(n)&&!Array.isArray(n)&&typeof n!="number"&&typeof n!="boolean"&&typeof n!="string"){const l=n==null?"null":n.constructor.name;throw new Error(`Argument '${t}' passed to '${e}' must be a Tensor or TensorLike, but got '${l}'`)}const r=Ll(n,o);!rn(n)&&!Array.isArray(n)&&(n=[n]);const a=o!=="string"?so(n,o):Us(n,[],!0);return D.makeTensor(a,r,o)}function Cm(n,t,e,s="numeric"){if(!Array.isArray(n))throw new Error(`Argument ${t} passed to ${e} must be a \`Tensor[]\` or \`TensorLike[]\``);return n.map((r,i)=>S(r,`${t}[${i}]`,e,s))}const ow="__op";function F(n){const t=Object.keys(n);if(t.length!==1)throw new Error(`Please provide an object with a single key (operation name) mapping to a function. Got an object with ${t.length} keys.`);let e=t[0];const s=n[e];e.endsWith("_")&&(e=e.substring(0,e.length-1)),e=e+ow;const o=(...r)=>{D.startScope(e);try{const i=s(...r);return bu(i)&&console.error("Cannot return a Promise inside of tidy."),D.endScope(i),i}catch(i){throw D.endScope(null),i}};return Object.defineProperty(o,"name",{value:e,configurable:!0}),o}function rw(n,t){const e=S(n,"real","complex"),s=S(t,"imag","complex");gu(e.shape,s.shape,`real and imag shapes, ${e.shape} and ${s.shape}, must match in call to tf.complex().`);const o={real:e,imag:s};return D.runKernel(Nu,o)}const Gs=F({complex_:rw});function Ml(n,t,e,s){if(s==null)s=Lo(n);else if(s==="complex64")throw new Error("Cannot construct a complex64 tensor directly. Please use tf.complex(real, imag).");if(fm(n)||pm(n)){if(s!=="float32"&&s!=="int32")throw new Error(`Creating tensor from GPU data only supports 'float32'|'int32' dtype, while the dtype is ${s}.`);return D.backend.createTensorFromGPUData(n,t||e,s)}if(!rn(n)&&!Array.isArray(n)&&typeof n!="number"&&typeof n!="boolean"&&typeof n!="string")throw new Error("values passed to tensor(values) must be a number/boolean/string or an array of numbers/booleans/strings, or a TypedArray");if(t!=null){Jn(t);const o=W(t),r=W(e);$(o===r,()=>`Based on the provided shape, [${t}], the tensor should have ${o} values but has ${r}`);for(let i=0;i<e.length;++i){const a=e[i],l=i===e.length-1?a!==W(t.slice(i)):!0;$(e[i]===t[i]||!l,()=>`Error creating a new Tensor. Inferred shape (${e}) does not match the provided shape (${t}). `)}}return!rn(n)&&!Array.isArray(n)&&(n=[n]),t=t||e,n=s!=="string"?so(n,s):Us(n,[],!0),D.makeTensor(n,t,s)}function cr(n,t,e){const s=Ll(n,e);return Ml(n,t,s,e)}const ua={float32:4,float16:2,int32:4,uint16:2,uint8:1,bool:1,complex64:8};class Cs{static join(t){return new Cs(t).slice()}constructor(t){if(this.shards=[],this.previousShardIndex=0,t==null||(t instanceof Array||(t=[t]),t=t.map(s=>rn(s)?s.buffer:s),t.length===0))return;this.bufferUniformSize=t[0].byteLength;let e=0;for(let s=0;s<t.length;s++){const o=t[s];s!==t.length-1&&o.byteLength!==this.bufferUniformSize&&(this.bufferUniformSize=void 0);const r=e+o.byteLength;this.shards.push({buffer:o,start:e,end:r}),e=r}this.shards.length===0&&(this.byteLength=0),this.byteLength=this.shards[this.shards.length-1].end}slice(t=0,e=this.byteLength){if(this.shards.length===0)return new ArrayBuffer(0);if(t=isNaN(Number(t))?0:t,e=isNaN(Number(e))?0:e,t=Math.max(0,t),e=Math.min(this.byteLength,e),e<=t)return new ArrayBuffer(0);const s=this.findShardForByte(t);if(s===-1)throw new Error(`Could not find start shard for byte ${t}`);const o=e-t,r=new ArrayBuffer(o),i=new Uint8Array(r);let a=0;for(let l=s;l<this.shards.length;l++){const c=this.shards[l],h=t+a-c.start,d=a,f=Math.min(e,c.end)-c.start,m=new Uint8Array(c.buffer,h,f-h);if(i.set(m,d),a+=m.length,e<c.end)break}return r}findShardForByte(t){if(this.shards.length===0||t<0||t>=this.byteLength)return-1;if(this.bufferUniformSize!=null)return this.previousShardIndex=Math.floor(t/this.bufferUniformSize),this.previousShardIndex;function e(o){return t<o.start?-1:t>=o.end?1:0}if(e(this.shards[this.previousShardIndex])===0)return this.previousShardIndex;const s=iw(this.shards,e);return s===-1?-1:(this.previousShardIndex=s,this.previousShardIndex)}}function iw(n,t){let e=0,s=n.length;for(;e<=s;){const o=Math.floor((s-e)/2)+e,r=t(n[o]);if(r===0)return o;r<0?s=o:e=o+1}return-1}function kn(){return D}function lp(){return D.memory()}function _(n,t){return D.tidy(n,t)}function yt(n){mm(n).forEach(e=>e.dispose())}function Dn(n){return D.keep(n)}function yH(n){return D.setBackend(n)}function wH(){return D.ready()}function $m(n,t,e=1){return D.registerBackend(n,t,e)}function aw(){return D.backend}const No=4;async function cp(n,t){const e=[],s=[],o=Array.isArray(n)?n.map(i=>i.name):Object.keys(n);for(let i=0;i<o.length;++i){const a=o[i],l=Array.isArray(n)?n[i].tensor:n[a];if(l.dtype!=="float32"&&l.dtype!=="int32"&&l.dtype!=="bool"&&l.dtype!=="string"&&l.dtype!=="complex64")throw new Error(`Unsupported dtype in weight '${a}': ${l.dtype}`);const c={name:a,shape:l.shape,dtype:l.dtype};if(l.dtype==="string"){const u=new Promise(async h=>{const d=await l.bytes(),p=d.reduce((g,x)=>g+x.length,0)+No*d.length,f=new Uint8Array(p);let m=0;for(let g=0;g<d.length;g++){const x=d[g],b=new Uint8Array(new Uint32Array([x.length]).buffer);f.set(b,m),m+=No,f.set(x,m),m+=x.length}h(f)});s.push(u)}else s.push(l.data());t!=null&&(c.group=t),e.push(c)}const r=await Promise.all(s);return{data:hw(r),specs:e}}function lw(n,t){const e=new Cs(n),s={};let o=0;for(const r of t){const i=cw(r,(a,l)=>e.slice(o+a,o+l));s[r.name]=uw(r,e.slice(o,o+i)),o+=i}return s}function cw(n,t){const e=W(n.shape);let s;if("quantization"in n){const o=n.quantization;s=ua[o.dtype]}else if(n.dtype==="string"){let o=0;for(let r=0;r<e;r++)o+=No+new Uint32Array(t(o,o+No))[0];return o}else s=ua[n.dtype];return e*s}function uw(n,t){const e=n.name,s=n.dtype,o=n.shape,r=W(o);let i,a=0;if("quantization"in n){const l=n.quantization;if(l.dtype==="uint8"||l.dtype==="uint16"){if(!("min"in l&&"scale"in l))throw new Error(`Weight ${n.name} with quantization ${l.dtype} doesn't have corresponding metadata min and scale.`)}else if(l.dtype==="float16"){if(s!=="float32")throw new Error(`Weight ${n.name} is quantized with ${l.dtype} which only supports weights of type float32 not ${s}.`)}else throw new Error(`Weight ${n.name} has unknown quantization dtype ${l.dtype}. Supported quantization dtypes are: 'uint8', 'uint16', and 'float16'.`);const c=ua[l.dtype],u=l.dtype==="uint8"?new Uint8Array(t):new Uint16Array(t);if(s==="float32")if(l.dtype==="uint8"||l.dtype==="uint16"){i=new Float32Array(u.length);for(let h=0;h<u.length;h++){const d=u[h];i[h]=d*l.scale+l.min}}else if(l.dtype==="float16")i=Cw()(u);else throw new Error(`Unsupported quantization type ${l.dtype} for weight type float32.`);else if(s==="int32"){if(l.dtype!=="uint8"&&l.dtype!=="uint16")throw new Error(`Unsupported quantization type ${l.dtype} for weight type int32.`);i=new Int32Array(u.length);for(let h=0;h<u.length;h++){const d=u[h];i[h]=Math.round(d*l.scale+l.min)}}else throw new Error(`Unsupported dtype in weight '${e}': ${s}`);a+=r*c}else if(s==="string"){const l=W(n.shape);i=[];for(let c=0;c<l;c++){const u=new Uint32Array(t.slice(a,a+No))[0];a+=No;const h=new Uint8Array(t.slice(a,a+u));i.push(h),a+=u}}else{const l=ua[s];if(s==="float32")i=new Float32Array(t);else if(s==="int32")i=new Int32Array(t);else if(s==="bool")i=new Uint8Array(t);else if(s==="complex64"){i=new Float32Array(t);const c=new Float32Array(i.length/2),u=new Float32Array(i.length/2);for(let f=0;f<c.length;f++)c[f]=i[f*2],u[f]=i[f*2+1];const h=cr(c,o,"float32"),d=cr(u,o,"float32"),p=Gs(h,d);return h.dispose(),d.dispose(),p}else throw new Error(`Unsupported dtype in weight '${e}': ${s}`);a+=r*l}return cr(i,o,s)}function hw(n){if(n===null)throw new Error(`Invalid input value: ${JSON.stringify(n)}`);let t=0;const e=[];n.forEach(r=>{if(t+=r.byteLength,e.push(r.byteLength===r.buffer.byteLength?r:new r.constructor(r)),!(r instanceof Float32Array||r instanceof Int32Array||r instanceof Uint8Array))throw new Error(`Unsupported TypedArray subtype: ${r.constructor.name}`)});const s=new Uint8Array(t);let o=0;return e.forEach(r=>{s.set(new Uint8Array(r.buffer),o),o+=r.byteLength}),s.buffer}const ch=typeof Buffer<"u"&&(typeof Blob>"u"||typeof atob>"u"||typeof btoa>"u");function up(n){return ch?Buffer.byteLength(n,"utf8"):new Blob([n]).size}function dw(n){if(ch)return Buffer.from(n).toString("base64");const t=new Uint8Array(n);let e="";for(let s=0,o=t.length;s<o;s++)e+=String.fromCharCode(t[s]);return btoa(e)}function pw(n){if(ch){const s=Buffer.from(n,"base64");return s.buffer.slice(s.byteOffset,s.byteOffset+s.byteLength)}const t=atob(n),e=new Uint8Array(t.length);for(let s=0;s<t.length;++s)e.set([t.charCodeAt(s)],s);return e.buffer}function fw(n){return Cs.join(n)}function mw(n,t){const e={modelTopology:n.modelTopology,format:n.format,generatedBy:n.generatedBy,convertedBy:n.convertedBy,weightsManifest:t};return n.signature!=null&&(e.signature=n.signature),n.userDefinedMetadata!=null&&(e.userDefinedMetadata=n.userDefinedMetadata),n.modelInitializer!=null&&(e.modelInitializer=n.modelInitializer),n.initializerSignature!=null&&(e.initializerSignature=n.initializerSignature),n.trainingConfig!=null&&(e.trainingConfig=n.trainingConfig),e}function gw(n,t,e){const s={modelTopology:n.modelTopology,format:n.format,generatedBy:n.generatedBy,convertedBy:n.convertedBy};if(n.trainingConfig!=null&&(s.trainingConfig=n.trainingConfig),n.weightsManifest!=null){if(!t)throw new Error("modelJSON has weightsManifest but weightSpecs is null");if(!e)throw new Error("modelJSON has weightsManifest but weightData is null");s.weightSpecs=t,s.weightData=e}return n.signature!=null&&(s.signature=n.signature),n.userDefinedMetadata!=null&&(s.userDefinedMetadata=n.userDefinedMetadata),n.modelInitializer!=null&&(s.modelInitializer=n.modelInitializer),n.initializerSignature!=null&&(s.initializerSignature=n.initializerSignature),s}async function xw(n,t){let e,s;return n.weightsManifest!=null&&([e,s]=await t(n.weightsManifest)),gw(n,e,s)}function uh(n){if(n.modelTopology instanceof ArrayBuffer)throw new Error("Expected JSON model topology, received ArrayBuffer.");return{dateSaved:new Date,modelTopologyType:"JSON",modelTopologyBytes:n.modelTopology==null?0:up(JSON.stringify(n.modelTopology)),weightSpecsBytes:n.weightSpecs==null?0:up(JSON.stringify(n.weightSpecs)),weightDataBytes:n.weightData==null?0:new Cs(n.weightData).byteLength}}function hp(n){const t=[];for(const e of n)t.push(...e.weights);return t}function bw(){const n=e=>{let s=e<<13,o=0;for(;(s&8388608)===0;)o-=8388608,s<<=1;return s&=-8388609,o+=947912704,s|o},t=new Uint32Array(2048);t[0]=0;for(let e=1;e<1024;e++)t[e]=n(e);for(let e=1024;e<2048;e++)t[e]=939524096+(e-1024<<13);return t}function yw(){const n=new Uint32Array(64);n[0]=0,n[31]=1199570944,n[32]=2147483648,n[63]=3347054592;for(let t=1;t<31;t++)n[t]=t<<23;for(let t=33;t<63;t++)n[t]=2147483648+(t-32<<23);return n}function ww(){const n=new Uint32Array(64);for(let t=0;t<64;t++)n[t]=1024;return n[0]=n[32]=0,n}function Cw(){const n=bw(),t=yw(),e=ww();return s=>{const o=new ArrayBuffer(4*s.length),r=new Uint32Array(o);for(let i=0;i<s.length;i++){const a=s[i],l=n[e[a>>10]+(a&1023)]+t[a>>10];r[i]=l}return new Float32Array(o)}}class ue{constructor(){this.saveRouters=[],this.loadRouters=[]}static getInstance(){return ue.instance==null&&(ue.instance=new ue),ue.instance}static registerSaveRouter(t){ue.getInstance().saveRouters.push(t)}static registerLoadRouter(t){ue.getInstance().loadRouters.push(t)}static getSaveHandlers(t){return ue.getHandlers(t,"save")}static getLoadHandlers(t,e){return ue.getHandlers(t,"load",e)}static getHandlers(t,e,s){const o=[];return(e==="load"?ue.getInstance().loadRouters:ue.getInstance().saveRouters).forEach(i=>{const a=i(t,s);a!==null&&o.push(a)}),o}}const $w=n=>ue.getSaveHandlers(n),Iw=(n,t)=>ue.getLoadHandlers(n,t);const Uc="tensorflowjs",Gc=1,Ms="models_store",is="model_info_store";function Im(){if(!L().getBool("IS_BROWSER"))throw new Error("Failed to obtain IndexedDB factory because the current environmentis not a web browser.");const n=typeof window>"u"?self:window,t=n.indexedDB||n.mozIndexedDB||n.webkitIndexedDB||n.msIndexedDB||n.shimIndexedDB;if(t==null)throw new Error("The current browser does not appear to support IndexedDB.");return t}function Hc(n){const t=n.result;t.createObjectStore(Ms,{keyPath:"modelPath"}),t.createObjectStore(is,{keyPath:"modelPath"})}class Hs{constructor(t){if(this.indexedDB=Im(),t==null||!t)throw new Error("For IndexedDB, modelPath must not be null, undefined or empty.");this.modelPath=t}async save(t){if(t.modelTopology instanceof ArrayBuffer)throw new Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");return this.databaseAction(this.modelPath,t)}async load(){return this.databaseAction(this.modelPath)}databaseAction(t,e){return new Promise((s,o)=>{const r=this.indexedDB.open(Uc,Gc);r.onupgradeneeded=()=>Hc(r),r.onsuccess=()=>{const i=r.result;if(e==null){const a=i.transaction(Ms,"readonly"),c=a.objectStore(Ms).get(this.modelPath);c.onsuccess=()=>{if(c.result==null)return i.close(),o(new Error(`Cannot find model with path '${this.modelPath}' in IndexedDB.`));s(c.result.modelArtifacts)},c.onerror=u=>(i.close(),o(c.error)),a.oncomplete=()=>i.close()}else{e.weightData=Cs.join(e.weightData);const a=uh(e),l=i.transaction(is,"readwrite");let c=l.objectStore(is),u;try{u=c.put({modelPath:this.modelPath,modelArtifactsInfo:a})}catch(d){return o(d)}let h;u.onsuccess=()=>{h=i.transaction(Ms,"readwrite");const d=h.objectStore(Ms);let p;try{p=d.put({modelPath:this.modelPath,modelArtifacts:e,modelArtifactsInfo:a})}catch(f){return o(f)}p.onsuccess=()=>s({modelArtifactsInfo:a}),p.onerror=f=>{c=l.objectStore(is);const m=c.delete(this.modelPath);m.onsuccess=()=>(i.close(),o(p.error)),m.onerror=g=>(i.close(),o(p.error))}},u.onerror=d=>(i.close(),o(u.error)),l.oncomplete=()=>{h==null?i.close():h.oncomplete=()=>i.close()}}},r.onerror=i=>o(r.error)})}}Hs.URL_SCHEME="indexeddb://";const km=n=>L().getBool("IS_BROWSER")&&!Array.isArray(n)&&n.startsWith(Hs.URL_SCHEME)?kw(n.slice(Hs.URL_SCHEME.length)):null;ue.registerSaveRouter(km);ue.registerLoadRouter(km);function kw(n){return new Hs(n)}function vw(n){return n.startsWith(Hs.URL_SCHEME)?n.slice(Hs.URL_SCHEME.length):n}class Sw{constructor(){this.indexedDB=Im()}async listModels(){return new Promise((t,e)=>{const s=this.indexedDB.open(Uc,Gc);s.onupgradeneeded=()=>Hc(s),s.onsuccess=()=>{const o=s.result,r=o.transaction(is,"readonly"),a=r.objectStore(is).getAll();a.onsuccess=()=>{const l={};for(const c of a.result)l[c.modelPath]=c.modelArtifactsInfo;t(l)},a.onerror=l=>(o.close(),e(a.error)),r.oncomplete=()=>o.close()},s.onerror=o=>e(s.error)})}async removeModel(t){return t=vw(t),new Promise((e,s)=>{const o=this.indexedDB.open(Uc,Gc);o.onupgradeneeded=()=>Hc(o),o.onsuccess=()=>{const r=o.result,i=r.transaction(is,"readwrite"),a=i.objectStore(is),l=a.get(t);let c;l.onsuccess=()=>{if(l.result==null)return r.close(),s(new Error(`Cannot find model with path '${t}' in IndexedDB.`));{const u=a.delete(t),h=()=>{c=r.transaction(Ms,"readwrite");const p=c.objectStore(Ms).delete(t);p.onsuccess=()=>e(l.result.modelArtifactsInfo),p.onerror=f=>s(l.error)};u.onsuccess=h,u.onerror=d=>(h(),r.close(),s(l.error))}},l.onerror=u=>(r.close(),s(l.error)),i.oncomplete=()=>{c==null?r.close():c.oncomplete=()=>r.close()}},o.onerror=r=>s(o.error)})}}const Hn="/",yo="tensorflowjs_models",vm="info",Nw="model_topology",Tw="weight_specs",Ew="weight_data",Rw="model_metadata";function Sm(n){return{info:[yo,n,vm].join(Hn),topology:[yo,n,Nw].join(Hn),weightSpecs:[yo,n,Tw].join(Hn),weightData:[yo,n,Ew].join(Hn),modelMetadata:[yo,n,Rw].join(Hn)}}function Nm(n){for(const t of Object.values(n))window.localStorage.removeItem(t)}function Dw(n){const t=n.split(Hn);if(t.length<3)throw new Error(`Invalid key format: ${n}`);return t.slice(1,t.length-1).join(Hn)}function Aw(n){return n.startsWith(Ks.URL_SCHEME)?n.slice(Ks.URL_SCHEME.length):n}class Ks{constructor(t){if(!L().getBool("IS_BROWSER")||typeof window>"u"||typeof window.localStorage>"u")throw new Error("The current environment does not support local storage.");if(this.LS=window.localStorage,t==null||!t)throw new Error("For local storage, modelPath must not be null, undefined or empty.");this.modelPath=t,this.keys=Sm(this.modelPath)}async save(t){if(t.modelTopology instanceof ArrayBuffer)throw new Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");{const e=JSON.stringify(t.modelTopology),s=JSON.stringify(t.weightSpecs),o=uh(t),r=Cs.join(t.weightData);try{this.LS.setItem(this.keys.info,JSON.stringify(o)),this.LS.setItem(this.keys.topology,e),this.LS.setItem(this.keys.weightSpecs,s),this.LS.setItem(this.keys.weightData,dw(r));const i={format:t.format,generatedBy:t.generatedBy,convertedBy:t.convertedBy,signature:t.signature!=null?t.signature:void 0,userDefinedMetadata:t.userDefinedMetadata!=null?t.userDefinedMetadata:void 0,modelInitializer:t.modelInitializer!=null?t.modelInitializer:void 0,initializerSignature:t.initializerSignature!=null?t.initializerSignature:void 0,trainingConfig:t.trainingConfig!=null?t.trainingConfig:void 0};return this.LS.setItem(this.keys.modelMetadata,JSON.stringify(i)),{modelArtifactsInfo:o}}catch{throw Nm(this.keys),new Error(`Failed to save model '${this.modelPath}' to local storage: size quota being exceeded is a possible cause of this failure: modelTopologyBytes=${o.modelTopologyBytes}, weightSpecsBytes=${o.weightSpecsBytes}, weightDataBytes=${o.weightDataBytes}.`)}}}async load(){const t=JSON.parse(this.LS.getItem(this.keys.info));if(t==null)throw new Error(`In local storage, there is no model with name '${this.modelPath}'`);if(t.modelTopologyType!=="JSON")throw new Error("BrowserLocalStorage does not support loading non-JSON model topology yet.");const e={},s=JSON.parse(this.LS.getItem(this.keys.topology));if(s==null)throw new Error(`In local storage, the topology of model '${this.modelPath}' is missing.`);e.modelTopology=s;const o=JSON.parse(this.LS.getItem(this.keys.weightSpecs));if(o==null)throw new Error(`In local storage, the weight specs of model '${this.modelPath}' are missing.`);e.weightSpecs=o;const r=this.LS.getItem(this.keys.modelMetadata);if(r!=null){const a=JSON.parse(r);e.format=a.format,e.generatedBy=a.generatedBy,e.convertedBy=a.convertedBy,a.signature!=null&&(e.signature=a.signature),a.userDefinedMetadata!=null&&(e.userDefinedMetadata=a.userDefinedMetadata),a.modelInitializer!=null&&(e.modelInitializer=a.modelInitializer),a.initializerSignature!=null&&(e.initializerSignature=a.initializerSignature),a.trainingConfig!=null&&(e.trainingConfig=a.trainingConfig)}const i=this.LS.getItem(this.keys.weightData);if(i==null)throw new Error(`In local storage, the binary weight values of model '${this.modelPath}' are missing.`);return e.weightData=pw(i),e}}Ks.URL_SCHEME="localstorage://";const Tm=n=>L().getBool("IS_BROWSER")&&!Array.isArray(n)&&n.startsWith(Ks.URL_SCHEME)?Fw(n.slice(Ks.URL_SCHEME.length)):null;ue.registerSaveRouter(Tm);ue.registerLoadRouter(Tm);function Fw(n){return new Ks(n)}class Ow{constructor(){$(L().getBool("IS_BROWSER"),()=>"Current environment is not a web browser"),$(typeof window>"u"||typeof window.localStorage<"u",()=>"Current browser does not appear to support localStorage"),this.LS=window.localStorage}async listModels(){const t={},e=yo+Hn,s=Hn+vm;for(let o=0;o<this.LS.length;++o){const r=this.LS.key(o);if(r.startsWith(e)&&r.endsWith(s)){const i=Dw(r);t[i]=JSON.parse(this.LS.getItem(r))}}return t}async removeModel(t){t=Aw(t);const e=Sm(t);if(this.LS.getItem(e.info)==null)throw new Error(`Cannot find model at path '${t}'`);const s=JSON.parse(this.LS.getItem(e.info));return Nm(e),s}}const dp="://";class vn{constructor(){this.managers={}}static getInstance(){return vn.instance==null&&(vn.instance=new vn),vn.instance}static registerManager(t,e){$(t!=null,()=>"scheme must not be undefined or null."),t.endsWith(dp)&&(t=t.slice(0,t.indexOf(dp))),$(t.length>0,()=>"scheme must not be an empty string.");const s=vn.getInstance();$(s.managers[t]==null,()=>`A model store manager is already registered for scheme '${t}'.`),s.managers[t]=e}static getManager(t){const e=vn.getInstance().managers[t];if(e==null)throw new Error(`Cannot find model manager for scheme '${t}'`);return e}static getSchemes(){return Object.keys(vn.getInstance().managers)}}class _w{constructor(){this.messageName="setTimeoutCustom",this.functionRefs=[],this.handledMessageCount=0,this.hasEventListener=!1}fetch(t,e){return fetch(t,e)}now(){return performance.now()}encode(t,e){if(e!=="utf-8"&&e!=="utf8")throw new Error(`Browser's encoder only supports utf-8, but got ${e}`);return this.textEncoder==null&&(this.textEncoder=new TextEncoder),this.textEncoder.encode(t)}decode(t,e){return new TextDecoder(e).decode(t)}setTimeoutCustom(t,e){if(typeof window>"u"||!L().getBool("USE_SETTIMEOUTCUSTOM")){setTimeout(t,e);return}this.functionRefs.push(t),setTimeout(()=>{window.postMessage({name:this.messageName,index:this.functionRefs.length-1},"*")},e),this.hasEventListener||(this.hasEventListener=!0,window.addEventListener("message",s=>{if(s.source===window&&s.data.name===this.messageName){s.stopPropagation();const o=this.functionRefs[s.data.index];o(),this.handledMessageCount++,this.handledMessageCount===this.functionRefs.length&&(this.functionRefs=[],this.handledMessageCount=0)}},!0))}isTypedArray(t){return cm(t)}}if(L().get("IS_BROWSER")){L().setPlatform("browser",new _w);try{vn.registerManager(Ks.URL_SCHEME,new Ow)}catch{}try{vn.registerManager(Hs.URL_SCHEME,new Sw)}catch{}}const Lw={importFetch:()=>require("node-fetch")};let gc;class Mw{constructor(){this.util=require("util"),this.textEncoder=new this.util.TextEncoder}fetch(t,e){return L().global.fetch!=null?L().global.fetch(t,e):(gc==null&&(gc=Lw.importFetch()),gc(t,e))}now(){const t=process.hrtime();return t[0]*1e3+t[1]/1e6}encode(t,e){if(e!=="utf-8"&&e!=="utf8")throw new Error(`Node built-in encoder only supports utf-8, but got ${e}`);return this.textEncoder.encode(t)}decode(t,e){return t.length===0?"":new this.util.TextDecoder(e).decode(t)}isTypedArray(t){return this.util.types.isFloat32Array(t)||this.util.types.isInt32Array(t)||this.util.types.isUint8Array(t)||this.util.types.isUint8ClampedArray(t)}}L().get("IS_NODE")&&!L().get("IS_BROWSER")&&L().setPlatform("node",new Mw);function wt(n,t="float32",e){return t=t||"float32",Jn(n),new xe(n,t,e)}function Pw(n,t){const e=S(n,"x","cast");if(!$1(t))throw new Error(`Failed to cast to unknown dtype ${t}`);if(t==="string"&&e.dtype!=="string"||t!=="string"&&e.dtype==="string")throw new Error("Only strings can be casted to strings");const s={x:e},o={dtype:t};return D.runKernel(Fr,s,o)}const st=F({cast_:Pw});function zw(n){const e={x:S(n,"x","clone","string_or_numeric")};return D.runKernel(Kr,e)}const zs=F({clone_:zw});function Bw(n,t=!1){console.log(n.toString(t))}xm();const Vw={buffer:wt,cast:st,clone:zs,print:Bw};Z1(Vw);function Ww(n,t){let e=S(n,"a","add"),s=S(t,"b","add");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(Po,o)}const Y=F({add_:Ww});function Uw(n,t){let e=S(n,"a","floorDiv"),s=S(t,"b","floorDiv");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(Gr,o)}const Em=F({floorDiv_:Uw});function Gw(n,t){let e=S(n,"a","div"),s=S(t,"b","div");if([e,s]=Jt(e,s),e.dtype==="int32"&&s.dtype==="int32")return Em(e,s);const o={a:e,b:s},r={};return D.runKernel(Pr,o,r)}const ut=F({div_:Gw});function Hw(n,t){let e=S(n,"a","mul"),s=S(t,"b","mul");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(ei,o)}const R=F({mul_:Hw});function Kw(n){const t=S(n,"x","abs");if(t.dtype==="complex64"){const e={x:t};return D.runKernel(Wa,e)}else{const e={x:t};return D.runKernel(_a,e)}}const Ne=F({abs_:Kw});function jw(n){const e={x:S(n,"x","acos")};return D.runKernel(Sr,e)}const qw=F({acos_:jw});function Xw(n){const e={x:S(n,"x","acosh")};return D.runKernel(Nr,e)}const Yw=F({acosh_:Xw});function Jw(n,t=null,e=!1){const o={x:S(n,"x","all","bool")},r={axis:t,keepDims:e};return D.runKernel(Cu,o,r)}const Rm=F({all_:Jw});function Zw(n,t=null,e=!1){const o={x:S(n,"x","any","bool")},r={axis:t,keepDims:e};return D.runKernel($u,o,r)}const Kc=F({any_:Zw});function Qw(n,t=0){const s={x:S(n,"x","argMax")},o={axis:t};return D.runKernel(La,s,o)}const dr=F({argMax_:Qw});function tC(n,t=0){const s={x:S(n,"x","argMin")},o={axis:t};return D.runKernel(Ma,s,o)}const eC=F({argMin_:tC});function nC(n){const e={x:S(n,"x","asin")};return D.runKernel(Tr,e)}const sC=F({asin_:nC});function oC(n){const e={x:S(n,"x","asinh")};return D.runKernel(Er,e)}const rC=F({asinh_:oC});function iC(n){const e={x:S(n,"x","atan")};return D.runKernel(Rr,e)}const aC=F({atan_:iC});function lC(n,t){let e=S(n,"a","atan2"),s=S(t,"b","atan2");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(Ar,o)}const cC=F({atan2_:lC});function uC(n){const e={x:S(n,"x","atanh")};return D.runKernel(Dr,e)}const hC=F({atanh_:uC});function Ci(n,t,e,s,o="NHWC",r){const i=n[3],a=[...t,i],l=Qn(o);return be(n,a,e,r,s,null,null,l)}function ln(n,t,e,s,o,r,i="channelsLast"){const[a,l]=pr(t);let c;if(i==="channelsLast")c=[a,l,n[3],n[3]];else if(i==="channelsFirst")c=[a,l,n[1],n[1]];else throw new Error(`Unknown dataFormat ${i}`);return be(n,c,e,s,o,r,!1,i)}function Zn(n,t,e,s,o,r,i="NDHWC"){const[a,l,c]=jc(t);let u,h;if(i==="NDHWC")h="channelsLast",u=[a,l,c,n[4],n[4]];else if(i==="NCDHW")h="channelsFirst",u=[a,l,c,n[1],n[1]];else throw new Error(`Unknown dataFormat ${i}`);return $s(n,u,e,s,o,!1,h,r)}function be(n,t,e,s,o,r,i=!1,a="channelsLast"){let[l,c,u,h]=[-1,-1,-1,-1];if(a==="channelsLast")[l,c,u,h]=n;else if(a==="channelsFirst")[l,h,c,u]=n;else throw new Error(`Unknown dataFormat ${a}`);const[d,p,,f]=t,[m,g]=pr(e),[x,b]=pr(s),w=$o(d,x),y=$o(p,b),{padInfo:C,outHeight:I,outWidth:k}=fC(o,c,u,m,g,w,y,r,a),v=i?f*h:f;let N;return a==="channelsFirst"?N=[l,v,I,k]:a==="channelsLast"&&(N=[l,I,k,v]),{batchSize:l,dataFormat:a,inHeight:c,inWidth:u,inChannels:h,outHeight:I,outWidth:k,outChannels:v,padInfo:C,strideHeight:m,strideWidth:g,filterHeight:d,filterWidth:p,effectiveFilterHeight:w,effectiveFilterWidth:y,dilationHeight:x,dilationWidth:b,inShape:n,outShape:N,filterShape:t}}function $s(n,t,e,s,o,r=!1,i="channelsLast",a){let[l,c,u,h,d]=[-1,-1,-1,-1,-1];if(i==="channelsLast")[l,c,u,h,d]=n;else if(i==="channelsFirst")[l,d,c,u,h]=n;else throw new Error(`Unknown dataFormat ${i}`);const[p,f,m,,g]=t,[x,b,w]=jc(e),[y,C,I]=jc(s),k=$o(p,y),v=$o(f,C),N=$o(m,I),{padInfo:T,outDepth:O,outHeight:P,outWidth:z}=mC(o,c,u,h,x,b,w,k,v,N,a),B=r?g*d:g;let M;return i==="channelsFirst"?M=[l,B,O,P,z]:i==="channelsLast"&&(M=[l,O,P,z,B]),{batchSize:l,dataFormat:i,inDepth:c,inHeight:u,inWidth:h,inChannels:d,outDepth:O,outHeight:P,outWidth:z,outChannels:B,padInfo:T,strideDepth:x,strideHeight:b,strideWidth:w,filterDepth:p,filterHeight:f,filterWidth:m,effectiveFilterDepth:k,effectiveFilterHeight:v,effectiveFilterWidth:N,dilationDepth:y,dilationHeight:C,dilationWidth:I,inShape:n,outShape:M,filterShape:t}}function dC(n,t,e,s,o){s==null&&(s=hh(n,t,e));const r=n[0],i=n[1],a=fr((r-t+2*s)/e+1,o),l=fr((i-t+2*s)/e+1,o);return[a,l]}function pC(n,t,e,s,o,r){o==null&&(o=hh(n,t[0],s[0]));const i=[0,0,0,e];for(let a=0;a<3;a++)n[a]+2*o>=t[a]&&(i[a]=fr((n[a]-t[a]+2*o)/s[a]+1,r));return i}function hh(n,t,e,s=1){const o=$o(t,s);return Math.floor((n[0]*(e-1)-e+o)/2)}function pr(n){return typeof n=="number"?[n,n,n]:n.length===2?[n[0],n[1],1]:n}function jc(n){return typeof n=="number"?[n,n,n]:n}function $o(n,t){return t<=1?n:n+(n-1)*(t-1)}function fC(n,t,e,s,o,r,i,a,l){let c,u,h;if(typeof n=="number"){c={top:n,bottom:n,left:n,right:n,type:n===0?"VALID":"NUMBER"};const p=dC([t,e],r,s,n,a);u=p[0],h=p[1]}else if(n==="same"){u=Math.ceil(t/s),h=Math.ceil(e/o);const d=Math.max(0,(u-1)*s+r-t),p=Math.max(0,(h-1)*o+i-e),f=Math.floor(d/2),m=d-f,g=Math.floor(p/2),x=p-g;c={top:f,bottom:m,left:g,right:x,type:"SAME"}}else if(n==="valid")c={top:0,bottom:0,left:0,right:0,type:"VALID"},u=Math.ceil((t-r+1)/s),h=Math.ceil((e-i+1)/o);else if(typeof n=="object"){const d=l==="channelsLast"?n[1][0]:n[2][0],p=l==="channelsLast"?n[1][1]:n[2][1],f=l==="channelsLast"?n[2][0]:n[3][0],m=l==="channelsLast"?n[2][1]:n[3][1];c={top:d,bottom:p,left:f,right:m,type:d===0&&p===0&&f===0&&m===0?"VALID":"EXPLICIT"},u=fr((t-r+d+p)/s+1,a),h=fr((e-i+f+m)/o+1,a)}else throw Error(`Unknown padding parameter: ${n}`);return{padInfo:c,outHeight:u,outWidth:h}}function mC(n,t,e,s,o,r,i,a,l,c,u){let h,d,p,f;if(n==="valid"&&(n=0),typeof n=="number"){h={top:n,bottom:n,left:n,right:n,front:n,back:n,type:n===0?"VALID":"NUMBER"};const g=pC([t,e,s,1],[a,l,c],1,[o,r,i],n,u);d=g[0],p=g[1],f=g[2]}else if(n==="same"){d=Math.ceil(t/o),p=Math.ceil(e/r),f=Math.ceil(s/i);const m=(d-1)*o+a-t,g=(p-1)*r+l-e,x=(f-1)*i+c-s,b=Math.floor(m/2),w=m-b,y=Math.floor(g/2),C=g-y,I=Math.floor(x/2),k=x-I;h={top:y,bottom:C,left:I,right:k,front:b,back:w,type:"SAME"}}else throw Error(`Unknown padding parameter: ${n}`);return{padInfo:h,outDepth:d,outHeight:p,outWidth:f}}function fr(n,t){if(!t)return Math.trunc(n);switch(t){case"round":return Math.round(n);case"ceil":return Math.ceil(n);case"floor":return Math.floor(n);default:throw new Error(`Unknown roundingMode ${t}`)}}function js(n){const[t,e,s]=pr(n);return t===1&&e===1&&s===1}function ke(n,t){return js(n)||js(t)}function qs(n){return pr(n).every(t=>t>0)}function Qn(n){if(n==="NHWC")return"channelsLast";if(n==="NCHW")return"channelsFirst";throw new Error(`Unknown dataFormat ${n}`)}function ze(n,t,e){if(e!=null){if(typeof t=="string")throw Error(`Error in ${n}: pad must be an integer when using dimRoundingMode ${e} but got pad ${t}.`);if(typeof t=="number")$(vo(t),()=>`Error in ${n}: pad must be an integer when using dimRoundingMode ${e} but got pad ${t}.`);else if(typeof t=="object")t.forEach(s=>{s.forEach(o=>{$(vo(o),()=>`Error in ${n}: pad must be an integer when using dimRoundingMode ${e} but got pad ${o}.`)})});else throw Error(`Error in ${n}: Unknown padding parameter: ${t}`)}}function gC(n,t){const s={x:S(n,"x","reshape","string_or_numeric")},o={shape:t};return D.runKernel($l,s,o)}const A=F({reshape_:gC});function xC(n,t,e,s,o){const r=S(n,"x","avgPool","float32"),i=1;$(ke(e,i),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${e} and dilations '${i}'`);let a=r,l=!1;r.rank===3&&(l=!0,a=A(r,[1,r.shape[0],r.shape[1],r.shape[2]])),$(a.rank===4,()=>`Error in avgPool: x must be rank 4 but got rank ${a.rank}.`),ze("avgPool",s,o);const c={x:a},u={filterSize:t,strides:e,pad:s,dimRoundingMode:o};let h=D.runKernel(Pa,c,u);return h=st(h,r.dtype),l?A(h,[h.shape[1],h.shape[2],h.shape[3]]):h}const dh=F({avgPool_:xC});function bC(n,t,e,s,o,r="NDHWC"){const i=S(n,"x","avgPool3d","float32");let a=i,l=!1;i.rank===4&&(l=!0,a=A(i,[1,i.shape[0],i.shape[1],i.shape[2],i.shape[3]])),$(a.rank===5,()=>`Error in avgPool3d: x must be rank 5 but got rank ${a.rank}.`),$(r==="NDHWC",()=>`Error in avgPool3d: Only NDHWC is currently supported, but got dataFormat of ${r}`),$(typeof e=="number"&&e>0||Array.isArray(e)&&e[0]>0&&e[1]>0&&e[2]>0,()=>`Error in avgPool3d: Stride must be > 0, but got '${e}'`),ze("avgPool3d",s,o);const c={x:a},u={filterSize:t,strides:e,pad:s,dimRoundingMode:o,dataFormat:r};let h=D.runKernel(za,c,u);return h=st(h,a.dtype),l?A(h,[h.shape[1],h.shape[2],h.shape[3],h.shape[4]]):h}const yC=F({avgPool3d_:bC});function wC(n,t=0){$(n.length>=1,()=>"Pass at least one tensor to concat");const e=Cm(n,"tensors","concat","string_or_numeric");if(e[0].dtype==="complex64"&&e.forEach(r=>{if(r.dtype!=="complex64")throw new Error(`Cannot concatenate complex64 tensors with a tensor
          with dtype ${r.dtype}. `)}),e.length===1)return zs(e[0]);const s=e,o={axis:t};return D.runKernel(Ua,s,o)}const Le=F({concat_:wC});function CC(n,t,e=!1,s=!1){let o=S(n,"a","matMul"),r=S(t,"b","matMul");[o,r]=Jt(o,r);const i={a:o,b:r},a={transposeA:e,transposeB:s};return D.runKernel(Ba,i,a)}const Nt=F({matMul_:CC});function $C(n){const e={x:S(n,"x","sigmoid","float32")};return D.runKernel(di,e)}const zo=F({sigmoid_:$C});function IC(n,t,e){const s=S(n,"x","slice","string_or_numeric");if(s.rank===0)throw new Error("Slicing scalar is not possible");const o={x:s},r={begin:t,size:e};return D.runKernel(Nl,o,r)}const zt=F({slice_:IC});function kC(n){const e={x:S(n,"x","tanh","float32")};return D.runKernel(bi,e)}const Pl=F({tanh_:kC});function vC(n,t,e){const s=S(n,"x","batchToSpaceND"),o=t.reduce((a,l)=>a*l);$(s.rank>=1+t.length,()=>`input rank is ${s.rank} but should be > than blockShape.length ${t.length}`),$(e.length===t.length,()=>`crops.length is ${e.length} but should be equal to blockShape.length  ${t.length}`),$(s.shape[0]%o===0,()=>`input tensor batch is ${s.shape[0]} but is not divisible by the product of the elements of blockShape ${t.join(" * ")} === ${o}`);const r={x:s},i={blockShape:t,crops:e};return D.runKernel(Va,r,i)}const ph=F({batchToSpaceND_:vC});function SC(n){let t;return n.rank===0||n.rank===1?t=A(n,[1,1,1,n.size]):n.rank===2?t=A(n,[1,1,n.shape[0],n.shape[1]]):n.rank===3?t=A(n,[1,n.shape[0],n.shape[1],n.shape[2]]):t=n,t}function NC(n,t,e,s,o,r){r==null&&(r=.001);const i=S(n,"x","batchNorm"),a=S(t,"mean","batchNorm"),l=S(e,"variance","batchNorm");let c;o!=null&&(c=S(o,"scale","batchNorm"));let u;s!=null&&(u=S(s,"offset","batchNorm")),$(a.rank===l.rank,()=>"Batch normalization gradient requires mean and variance to have equal ranks."),$(u==null||a.rank===u.rank,()=>"Batch normalization gradient requires mean and offset to have equal ranks."),$(c==null||a.rank===c.rank,()=>"Batch normalization gradient requires mean and scale to have equal ranks.");const d={x:SC(i),scale:c,offset:u,mean:a,variance:l},p={varianceEpsilon:r},f=D.runKernel(Za,d,p);return A(f,i.shape)}const zl=F({batchNorm_:NC});function TC(n,t,e,s,o,r){const i=S(n,"x","batchNorm"),a=S(t,"mean","batchNorm"),l=S(e,"variance","batchNorm");let c;o!=null&&(c=S(o,"scale","batchNorm"));let u;return s!=null&&(u=S(s,"offset","batchNorm")),$(i.rank===2,()=>`Error in batchNorm2D: x must be rank 2 but got rank ${i.rank}.`),$(a.rank===2||a.rank===1,()=>`Error in batchNorm2D: mean must be rank 2 or rank 1 but got rank ${a.rank}.`),$(l.rank===2||l.rank===1,()=>`Error in batchNorm2D: variance must be rank 2 or rank 1 but got rank ${l.rank}.`),c!=null&&$(c.rank===2||c.rank===1,()=>`Error in batchNorm2D: scale must be rank 2 or rank 1 but got rank ${c.rank}.`),u!=null&&$(u.rank===2||u.rank===1,()=>`Error in batchNorm2D: offset must be rank 2 or rank 1 but got rank ${u.rank}.`),zl(i,a,l,u,c,r)}const EC=F({batchNorm2d_:TC});function RC(n,t,e,s,o,r){const i=S(n,"x","batchNorm"),a=S(t,"mean","batchNorm"),l=S(e,"variance","batchNorm");let c;o!=null&&(c=S(o,"scale","batchNorm"));let u;return s!=null&&(u=S(s,"offset","batchNorm")),$(i.rank===3,()=>`Error in batchNorm3D: x must be rank 3 but got rank ${i.rank}.`),$(a.rank===3||a.rank===1,()=>`Error in batchNorm3D: mean must be rank 3 or rank 1 but got rank ${a.rank}.`),$(l.rank===3||l.rank===1,()=>`Error in batchNorm3D: variance must be rank 3 or rank 1 but got rank ${l.rank}.`),c!=null&&$(c.rank===3||c.rank===1,()=>`Error in batchNorm3D: scale must be rank 3 or rank 1 but got rank ${c.rank}.`),u!=null&&$(u.rank===3||u.rank===1,()=>`Error in batchNorm3D: offset must be rank 3 or rank 1 but got rank ${u.rank}.`),zl(i,a,l,u,c,r)}const DC=F({batchNorm3d_:RC});function AC(n,t,e,s,o,r){const i=S(n,"x","batchNorm"),a=S(t,"mean","batchNorm"),l=S(e,"variance","batchNorm");let c;o!=null&&(c=S(o,"scale","batchNorm"));let u;return s!=null&&(u=S(s,"offset","batchNorm")),$(i.rank===4,()=>`Error in batchNorm4D: x must be rank 4 but got rank ${i.rank}.`),$(a.rank===4||a.rank===1,()=>`Error in batchNorm4D: mean must be rank 4 or rank 1 but got rank ${a.rank}.`),$(l.rank===4||l.rank===1,()=>`Error in batchNorm4D: variance must be rank 4 or rank 1 but got rank ${l.rank}.`),c!=null&&$(c.rank===4||c.rank===1,()=>`Error in batchNorm4D: scale must be rank 4 or rank 1 but got rank ${c.rank}.`),u!=null&&$(u.rank===4||u.rank===1,()=>`Error in batchNorm4D: offset must be rank 4 or rank 1 but got rank ${u.rank}.`),zl(i,a,l,u,c,r)}const FC=F({batchNorm4d_:AC});function OC(n,t,e){const s=S(n,"x","bincount"),o=S(t,"weights","bincount");$(s.dtype==="int32",()=>`Error in bincount: input dtype must be int32, but got ${s.dtype}`),$(e>=0,()=>`size must be non-negative, but got ${e}.`),$(o.size===s.size||o.size===0,()=>`Error in bincount: weights must have the same size as input or0-length, but got input shape: ${s.shape}, weights shape: ${o.shape}.`);const r={x:s,weights:o},i={size:e};return D.runKernel(vu,r,i)}const _C=F({bincount_:OC});function LC(n,t){let e=S(n,"broadcastTo","x");const s=e.shape;if(Jn(t),t.length<e.rank)throw new Error(`broadcastTo(): shape.length=${t.length} < input.rank=${e.rank}.`);if(t.length>e.rank){const c=e.shape.slice();for(;c.length<t.length;)c.unshift(1);e=A(e,c)}const o=e.shape,r=Array.from(t);for(let c=t.length-1;c>=0;c--)if(o[c]===t[c])r[c]=1;else if(e.shape[c]!==1)throw new Error(`broadcastTo(): [${s}] cannot be broadcast to [${t}].`);if(r.map((c,u)=>c>1?u:-1).filter(c=>c>=0).length===0)return zs(e);const a={x:e},l={reps:r};return D.runKernel(yi,a,l)}const ur=F({broadcastTo_:LC});function MC(n){const e={x:S(n,"x","ceil","float32")};return D.runKernel(Or,e)}const PC=F({ceil_:MC});function Bl(n,t,e){Jn(n),e=e||Lo(t);const s={shape:n,value:t,dtype:e};return D.runKernel(Bu,{},s)}function zC(n,t,e){const s=S(n,"x","clipByValue");if($(t<=e,()=>`Error in clip: min (${t}) must be less than or equal to max (${e}).`),t===e)return Bl(s.shape,t,s.dtype);const o={x:s},r={clipValueMin:t,clipValueMax:e};return D.runKernel(_r,o,r)}const Ye=F({clipByValue_:zC});function BC(n){return Le(n,0)}const VC=F({concat1d_:BC});function WC(n,t){return Le(n,t)}const UC=F({concat2d_:WC});function GC(n,t){return Le(n,t)}const HC=F({concat3d_:GC});function KC(n,t){return Le(n,t)}const jC=F({concat4d_:KC});function qC(n,t,e,s,o="NHWC",r=[1,1],i){const a=S(n,"x","conv2d","float32"),l=S(t,"filter","conv2d","float32");let c=a,u=!1;a.rank===3&&(u=!0,c=A(a,[1,a.shape[0],a.shape[1],a.shape[2]])),$(c.rank===4,()=>`Error in conv2d: input must be rank 4, but got rank ${c.rank}.`),$(l.rank===4,()=>`Error in conv2d: filter must be rank 4, but got rank ${l.rank}.`),ze("conv2d",s,i);const h=o==="NHWC"?c.shape[3]:c.shape[1];$(h===l.shape[2],()=>`Error in conv2d: depth of input (${h}) must match input depth for filter ${l.shape[2]}.`),$(ke(e,r),()=>`Error in conv2D: Either strides or dilations must be 1. Got strides ${e} and dilations '${r}'`),$(qs(r),()=>"Error in conv2D: Dilated rates should be larger than 0."),$(qs(e),()=>"Error in conv2D: Strides should be larger than 0.");const d={x:c,filter:l},p={strides:e,pad:s,dataFormat:o,dilations:r,dimRoundingMode:i},f=D.runKernel(Ga,d,p);return u?A(f,[f.shape[1],f.shape[2],f.shape[3]]):f}const Xs=F({conv2d_:qC});function XC(n,t,e,s,o="NWC",r=1,i){const a=S(n,"x","conv1d"),l=S(t,"filter","conv1d");let c=a,u=!1;a.rank===2&&(u=!0,c=A(a,[1,a.shape[0],a.shape[1]])),$(c.rank===3,()=>`Error in conv1d: input must be rank 3, but got rank ${c.rank}.`),$(l.rank===3,()=>`Error in conv1d: filter must be rank 3, but got rank ${l.rank}.`),ze("conv1d",s,i),$(c.shape[2]===l.shape[1],()=>`Error in conv1d: depth of input (${c.shape[2]}) must match input depth for filter ${l.shape[1]}.`),$(ke(e,r),()=>`Error in conv1D: Either stride or dilation must be 1. Got stride ${e} and dilation '${r}'`),$(qs(r),()=>"Error in conv1D: Dilated rates should be larger than 0."),$(qs(e),()=>"Error in conv1D: Stride should be larger than 0."),$(o==="NWC",()=>`Error in conv1d: got dataFormat of ${o} but only NWC is currently supported.`);const h=A(l,[1,l.shape[0],l.shape[1],l.shape[2]]),d=A(c,[c.shape[0],1,c.shape[1],c.shape[2]]),g=Xs(d,h,[1,e],s,"NHWC",[1,r],i);return u?A(g,[g.shape[2],g.shape[3]]):A(g,[g.shape[0],g.shape[2],g.shape[3]])}const Dm=F({conv1d_:XC});function YC(n,t,e,s,o,r="NHWC",i){$(n.length===t.rank,()=>`Length of inShape (${n.length}) and rank of dy (${t.rank}) must match`);let a=n,l=t,c=!1;t.rank===3&&(c=!0,l=A(t,[1,t.shape[0],t.shape[1],t.shape[2]]),a=[1,n[0],n[1],n[2]]),$(a.length===4,()=>`Error in conv2dDerInput: inShape must be length 4, but got length ${a.length}.`),$(l.rank===4,()=>`Error in conv2dDerInput: dy must be rank 4, but got rank ${l.rank}`),$(e.rank===4,()=>`Error in conv2dDerInput: filter must be rank 4, but got rank ${e.rank}`);const u=r==="NHWC"?a[3]:a[1],h=r==="NHWC"?l.shape[3]:l.shape[1];$(u===e.shape[2],()=>`Error in conv2dDerInput: depth of input (${u}) must match input depth for filter ${e.shape[2]}.`),$(h===e.shape[3],()=>`Error in conv2dDerInput: depth of output (${h}) must match output depth for filter ${e.shape[3]}.`),ze("conv2dDerInput",o,i);const d={dy:l,filter:e},p={strides:s,pad:o,dataFormat:r,dimRoundingMode:i,inputShape:a},f=D.runKernel(Ha,d,p);return c?A(f,[f.shape[1],f.shape[2],f.shape[3]]):f}const fh=F({conv2DBackpropInput_:YC});function JC(n,t,e,s,o,r){const i=S(n,"x","conv2dTranspose"),a=S(t,"filter","conv2dTranspose");return fh(e,i,a,s,o,"NHWC",r)}const Am=F({conv2dTranspose_:JC});function ZC(n,t,e,s,o="NDHWC",r=[1,1,1]){const i=S(n,"x","conv3d"),a=S(t,"filter","conv3d");let l=i,c=!1;i.rank===4&&(c=!0,l=A(i,[1,i.shape[0],i.shape[1],i.shape[2],i.shape[3]])),$(l.rank===5,()=>`Error in conv3d: input must be rank 5, but got rank ${l.rank}.`),$(a.rank===5,()=>`Error in conv3d: filter must be rank 5, but got rank ${a.rank}.`),$(l.shape[4]===a.shape[3],()=>`Error in conv3d: depth of input (${l.shape[4]}) must match input depth for filter ${a.shape[3]}.`),$(ke(e,r),()=>`Error in conv3D: Either strides or dilations must be 1. Got strides ${e} and dilations '${r}'`),$(o==="NDHWC",()=>`Error in conv3d: got dataFormat of ${o} but only NDHWC is currently supported.`),$(qs(r),()=>"Error in conv3D: Dilated rates should be larger than 0."),$(qs(e),()=>"Error in conv3D: Strides should be larger than 0.");const u={x:l,filter:a},h={strides:e,pad:s,dataFormat:o,dilations:r},d=D.runKernel(Ka,u,h);return c?A(d,[d.shape[1],d.shape[2],d.shape[3],d.shape[4]]):d}const QC=F({conv3d_:ZC});function t$(n,t,e,s,o){$(n.length===t.rank,()=>`Length of inShape (${n.length}) and rank of dy (${t.rank}) must match`);let r=n,i=t,a=!1;t.rank===4&&(a=!0,i=A(t,[1,t.shape[0],t.shape[1],t.shape[2],t.shape[3]]),r=[1,n[0],n[1],n[2],n[3]]);const l=r[4],c=i.shape[4];$(r.length===5,()=>`Error in conv3dDerInput: inShape must be length 5, but got length ${r.length}.`),$(i.rank===5,()=>`Error in conv3dDerInput: dy must be rank 5, but got rank ${i.rank}`),$(e.rank===5,()=>`Error in conv3dDerInput: filter must be rank 5, but got rank ${e.rank}`),$(l===e.shape[3],()=>`Error in conv3dDerInput: depth of input (${l}) must match input depth for filter ${e.shape[3]}.`),$(c===e.shape[4],()=>`Error in conv3dDerInput: depth of output (${c}) must match output depth for filter ${e.shape[4]}.`);const u={dy:i,filter:e},h={pad:o,strides:s,inputShape:r},d=D.runKernel(Ru,u,h);return a?A(d,[d.shape[1],d.shape[2],d.shape[3],d.shape[4]]):d}const Fm=F({conv3DBackpropInput_:t$});function e$(n,t,e,s,o){const r=S(n,"x","conv3dTranspose"),i=S(t,"filter","conv3dTranspose");return Fm(e,r,i,s,o)}const n$=F({conv3dTranspose_:e$});function s$(n){const e={x:S(n,"x","cos","float32")};return D.runKernel(Lr,e)}const mh=F({cos_:s$});function o$(n){const e={x:S(n,"x","cosh","float32")};return D.runKernel(Mr,e)}const Om=F({cosh_:o$});function r$(n,t=0,e=!1,s=!1){const r={x:S(n,"x","cumprod")},i={axis:t,exclusive:e,reverse:s};return D.runKernel(Du,r,i)}const qc=F({cumprod_:r$});function i$(n,t=0,e=!1,s=!1){const r={x:S(n,"x","cumsum")},i={axis:t,exclusive:e,reverse:s};return D.runKernel(ja,r,i)}const _m=F({cumsum_:i$});function a$(n,t,e,s=!1){const o=S(n,"x","denseBincount"),r=S(t,"weights","denseBincount");$(o.dtype==="int32",()=>`Error in denseBincount: input dtype must be int32, but got ${o.dtype}`),$(o.rank<=2,()=>`Error in denseBincount: input must be at most rank 2, but got rank ${o.rank}.`),$(e>=0,()=>`size must be non-negative, but got ${e}.`),$(r.size===o.size||r.size===0,()=>`Error in denseBincount: weights must have the same shape as x or 0-length, but got x shape: ${o.shape}, weights shape: ${r.shape}.`);const i={x:o,weights:r},a={size:e,binaryOutput:s};return D.runKernel(Fu,i,a)}const pp=F({denseBincount_:a$});function l$(n,t,e="NHWC"){const s=S(n,"x","depthToSpace","float32"),o=e==="NHWC"?s.shape[1]:s.shape[2],r=e==="NHWC"?s.shape[2]:s.shape[3],i=e==="NHWC"?s.shape[3]:s.shape[1];$(t>1,()=>`blockSize should be > 1 for depthToSpace, but was: ${t}`),$(o*t>=0,()=>`Negative dimension size caused by overflow when multiplying
    ${o} and ${t}  for depthToSpace with input shape
    ${s.shape}`),$(r*t>=0,()=>`Negative dimension size caused by overflow when multiplying
    ${r} and ${t} for depthToSpace with input shape
        ${s.shape}`),$(i%(t*t)===0,()=>`Dimension size must be evenly divisible by ${t*t} but is ${i} for depthToSpace with input shape ${s.shape}`);const a={x:s},l={blockSize:t,dataFormat:e};return D.runKernel(Ou,a,l)}const c$=F({depthToSpace_:l$});function u$(n,t,e,s,o="NHWC",r=[1,1],i){const a=S(n,"x","depthwiseConv2d","float32"),l=S(t,"filter","depthwiseConv2d","float32");let c=a,u=!1;a.rank===3&&(u=!0,c=A(a,[1,a.shape[0],a.shape[1],a.shape[2]])),$(c.rank===4,()=>`Error in depthwiseConv2d: input must be rank 4, but got rank ${c.rank}.`),$(l.rank===4,()=>`Error in depthwiseConv2d: filter must be rank 4, but got rank ${l.rank}.`);const h=o==="NHWC"?c.shape[3]:c.shape[1];$(h===l.shape[2],()=>`Error in depthwiseConv2d: number of input channels (${h}) must match the inChannels dimension in filter ${l.shape[2]}.`),ze("depthwiseConv2d",s,i);const d={x:c,filter:l},p={strides:e,pad:s,dataFormat:o,dilations:r,dimRoundingMode:i},f=D.runKernel(qa,d,p);return u?A(f,[f.shape[1],f.shape[2],f.shape[3]]):f}const gh=F({depthwiseConv2d_:u$});function h$(n,t,e,s,o=[1,1],r="NHWC"){const i=S(n,"x","dilation2d"),a=S(t,"filter","dilation2d");$(i.rank===3||i.rank===4,()=>`Error in dilation2d: input must be rank 3 or 4, but got rank ${i.rank}.`),$(a.rank===3,()=>`Error in dilation2d: filter must be rank 3, but got rank ${a.rank}.`),$(r==="NHWC",()=>`Error in dilation2d: Only NHWC is currently supported, but got dataFormat of ${r}`);let l=i,c=!1;i.rank===3&&(l=A(i,[1,i.shape[0],i.shape[1],i.shape[2]]),c=!0),$(l.shape[3]===a.shape[2],()=>`Error in dilation2d:  input and filter must have the same depth: ${l.shape[3]} vs ${a.shape[2]}`);const u={x:l,filter:a},h={strides:e,pad:s,dilations:o},d=D.runKernel(Xa,u,h);return c?A(d,[d.shape[1],d.shape[2],d.shape[3]]):d}const d$=F({dilation2d_:h$});function To(n,t){const e=n.length,s=[];for(let o=0;o<e;o++){const r=e-1-o,i=n[r]||1;(t[t.length-1-o]||1)>1&&i===1&&s.unshift(r)}return s}function le(n,t){const e=[];for(let s=0;s<t.length;s++){const o=n[n.length-s-1],r=t.length-s-1,i=t[r];(o==null||o===1&&i>1)&&e.unshift(r)}return e}function mt(n,t){const e=Math.max(n.length,t.length),s=new Array(e);for(let o=0;o<e;o++){let r=n[n.length-o-1];r==null&&(r=1);let i=t[t.length-o-1];if(i==null&&(i=1),r===1)s[e-o-1]=i;else if(i===1)s[e-o-1]=r;else if(r!==i){const a=`Operands could not be broadcast together with shapes ${n} and ${t}.`;throw Error(a)}else s[e-o-1]=r}return s}function p$(n,t){let e=S(n,"a","equal","string_or_numeric"),s=S(t,"b","equal","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(Ya,o)}const Ln=F({equal_:p$});function f$(n,t,e){const s=S(t,"a","where"),o=S(e,"b","where"),r=S(n,"condition","where","bool"),i=mt(mt(r.shape,s.shape),o.shape),a=ur(r,i),l=ur(s,i),c=ur(o,i),u={condition:a,t:l,e:c};return D.runKernel(Sl,u)}const Re=F({where_:f$});function m$(n){const e={x:S(n,"x","zerosLike")};return D.runKernel(Ol,e)}const kt=F({zerosLike_:m$});function g$(n,t){let e=S(n,"a","div"),s=S(t,"b","div");[e,s]=Jt(e,s);const o=ut(e,s),r=kt(o),i=Ln(s,r);return Re(i,r,o)}const x$=F({divNoNan_:g$});function b$(n,t){const e=S(n,"t1","dot"),s=S(t,"t2","dot");$((e.rank===1||e.rank===2)&&(s.rank===1||s.rank===2),()=>`Error in dot: inputs must all be rank 1 or 2, but got ranks ${e.rank} and ${s.rank}.`);const o=e.rank===1?e.size:e.shape[1],r=s.rank===1?s.size:s.shape[0];if($(o===r,()=>`Error in dot: inner dimensions of inputs must match, but got ${o} and ${r}.`),e.rank===1&&s.rank===1){const i=A(e,[1,-1]),a=A(s,[-1,1]),l=Nt(i,a);return A(l,[])}else if(e.rank===1&&s.rank===2){const i=A(e,[1,-1]),a=A(s,[s.shape[0],s.shape[1]]),l=Nt(i,a);return A(l,[l.size])}else if(e.rank===2&&s.rank===1){const i=A(s,[-1,1]),a=Nt(e,i);return A(a,[a.size])}else{const i=A(s,[s.shape[0],s.shape[1]]);return Nt(e,i)}}const y$=F({dot_:b$});function w$(n,...t){const e=t.map((o,r)=>S(o,`tensors${r}`,"einsum")),s={equation:n};return D.runKernel(Mu,e,s)}const tr=F({einsum_:w$});function C$(n){const e={x:S(n,"x","elu","float32")};return D.runKernel(zr,e)}const Vl=F({elu_:C$});function $$(n){let t=S(n,"x","erf");$(t.dtype==="int32"||t.dtype==="float32",()=>"Input dtype must be `int32` or `float32`."),t.dtype==="int32"&&(t=st(t,"float32"));const e={x:t};return D.runKernel(Br,e)}const Lm=F({erf_:$$});function xh(n,t){for(let e=0;e<n.length;++e)if(n[n.length-e-1]!==t-1-e)return!1;return!0}function Mm(n,t,e){const s=n.length+t.length,o=[];let r=0,i=0;for(let a=0;a<s;a++)e.indexOf(a)===-1?o.push(n[r++]):o.push(t[i++]);return o}function fe(n,t){const e=[],s=n.length;for(let r=0;r<s;r++)t.indexOf(r)===-1&&e.push(n[r]);const o=t.map(r=>n[r]);return[e,o]}function ne(n,t){const e=t.map(s=>1);return Mm(n,e,t)}function ye(n,t,e){$(xh(t,e),()=>`${n} supports only inner-most axes for now. Got axes ${t} and rank-${e} input.`)}function jt(n,t){if(xh(n,t))return null;const e=[];for(let s=0;s<t;++s)n.indexOf(s)===-1&&e.push(s);return n.forEach(s=>e.push(s)),e}function Is(n){return n.map((t,e)=>[e,t]).sort((t,e)=>t[1]-e[1]).map(t=>t[0])}function Zt(n,t){const e=[];for(let s=t-n;s<t;++s)e.push(s);return e}function I$(n,t=null,e=!1){const o={x:S(n,"x","max")},r={reductionIndices:t,keepDims:e};return D.runKernel(ll,o,r)}const bn=F({max_:I$});function k$(n,t=null,e=!1){const o={x:S(n,"x","min")},r={axis:t,keepDims:e};return D.runKernel(dl,o,r)}const ha=F({min_:k$});function v$(n,t){let e=S(n,"base","pow"),s=S(t,"exp","pow");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(ni,o)}const Ys=F({pow_:v$});function Tt(n,t){if((rn(n)&&t!=="string"||Array.isArray(n))&&t!=="complex64")throw new Error("Error creating a new Scalar: value must be a primitive (number|boolean|string)");if(t==="string"&&rn(n)&&!(n instanceof Uint8Array))throw new Error("When making a scalar from encoded string, the value must be `Uint8Array`.");return Ml(n,[],[],t)}function S$(n){const e={x:S(n,"x","sqrt","float32")};return D.runKernel(fi,e)}const Ie=F({sqrt_:S$});function N$(n){const t=S(n,"x","square"),e={};return D.runKernel("Square",{x:t},e)}const Vt=F({square_:N$});function T$(n,t=null,e=!1){let s=S(n,"x","sum");s.dtype==="bool"&&(s=st(s,"int32"));const o={x:s},r={axis:t,keepDims:e};return D.runKernel(Tl,o,r)}const ct=F({sum_:T$});function E$(n,t="euclidean",e=null,s=!1){n=S(n,"x","norm");const o=Pm(n,t,e);let r=o.shape;if(s){const i=Ct(e,n.shape);r=ne(o.shape,i)}return A(o,r)}function Pm(n,t,e=null){if(n.rank===0)return Ne(n);if(n.rank!==1&&e===null)return Pm(A(n,[-1]),t,e);if(n.rank===1||typeof e=="number"||Array.isArray(e)&&e.length===1){if(t===1)return ct(Ne(n),e);if(t===1/0)return bn(Ne(n),e);if(t===-1/0)return ha(Ne(n),e);if(t==="euclidean"||t===2)return Ie(ct(Ys(Ne(n),Tt(2,"int32")),e));throw new Error(`Error in norm: invalid ord value: ${t}`)}if(Array.isArray(e)&&e.length===2){if(t===1)return bn(ct(Ne(n),e[0]),e[1]-1);if(t===1/0)return bn(ct(Ne(n),e[1]),e[0]);if(t===-1/0)return ha(ct(Ne(n),e[1]),e[0]);if(t==="fro"||t==="euclidean")return Ie(ct(Vt(n),e));throw new Error(`Error in norm: invalid ord value: ${t}`)}throw new Error(`Error in norm: invalid axis: ${e}`)}const Wl=F({norm_:E$});function R$(n,t=null,e=!1){return Wl(n,"euclidean",t,e)}const D$=F({euclideanNorm_:R$});function A$(n){const e={x:S(n,"x","exp")};return D.runKernel(Vr,e)}const Mn=F({exp_:A$});function F$(n,t=0){const e=S(n,"x","expandDims","string_or_numeric");$(t<=e.rank,()=>"Axis must be <= rank of the tensor");const s={input:e},o={dim:t};return D.runKernel(Ja,s,o)}const Oe=F({expandDims_:F$});function O$(n){const e={x:S(n,"x","expm1")};return D.runKernel(Wr,e)}const _$=F({expm1_:O$});function L$(n,t){const e=S(n,"x","tile","string_or_numeric");$(e.rank===t.length,()=>`Error in transpose: rank of input ${e.rank} must match length of reps ${t}.`);const s={x:e},o={reps:t};return D.runKernel(yi,s,o)}const gn=F({tile_:L$});function M$(n,t,e,s="float32"){t==null&&(t=n);const o=wt([n,t],s),r=n<=t?n:t;for(let a=0;a<r;++a)o.set(1,a,a);const i=A(o.toTensor(),[n,t]);if(e==null)return i;if(e.length===1)return gn(Oe(i,0),[e[0],1,1]);if(e.length===2)return gn(Oe(Oe(i,0),0),[e[0],e[1],1,1]);if(e.length===3)return gn(Oe(Oe(Oe(i,0),0),0),[e[0],e[1],e[2],1,1]);throw new Error(`eye() currently supports only 1D and 2D batchShapes, but received ${e.length}D.`)}const zm=F({eye_:M$});function P$(n){const e={x:S(n,"x","floor","float32")};return D.runKernel(Ur,e)}const Ul=F({floor_:P$});function z$(n,t,e=0,s=0){const o=S(n,"x","gather"),r=S(t,"indices","gather","int32"),i={x:o,indices:r},a={axis:e,batchDims:s};return D.runKernel(Qa,i,a)}const bh=F({gather_:z$});function B$(n,t){let e=S(n,"a","greater","string_or_numeric"),s=S(t,"b","greater","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(tl,o)}const Je=F({greater_:B$});function V$(n,t){let e=S(n,"a","greaterEqual","string_or_numeric"),s=S(t,"b","greaterEqual","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(Hr,o)}const oo=F({greaterEqual_:V$});function W$(n){const e={input:S(n,"input","imag")};return D.runKernel(Uu,e)}const yh=F({imag_:W$});function U$(n){const e={x:S(n,"x","isFinite")};return D.runKernel(jr,e)}const G$=F({isFinite_:U$});function H$(n){const e={x:S(n,"x","isInf")};return D.runKernel(qr,e)}const K$=F({isInf_:H$});function j$(n){const e={x:S(n,"x","isNaN")};return D.runKernel(Xr,e)}const q$=F({isNaN_:j$});function X$(n,t=.2){const s={x:S(n,"x","leakyRelu")},o={alpha:t};return D.runKernel(el,s,o)}const wh=F({leakyRelu_:X$});function Y$(n,t){let e=S(n,"a","less","string_or_numeric"),s=S(t,"b","less","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(nl,o)}const da=F({less_:Y$});function J$(n,t){let e=S(n,"a","lessEqual","string_or_numeric"),s=S(t,"b","lessEqual","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(sl,o)}const Bo=F({lessEqual_:J$});function CH(n,t,e){const s={start:n,stop:t,num:e};return D.runKernel(Gu,{},s)}function Z$(n,t=5,e=1,s=1,o=.5){const r=S(n,"x","localResponseNormalization");$(r.rank===4||r.rank===3,()=>`Error in localResponseNormalization: x must be rank 3 or 4 but got
               rank ${r.rank}.`),$(vo(t),()=>`Error in localResponseNormalization: depthRadius must be an integer but got depthRadius ${t}.`);let i=r,a=!1;r.rank===3&&(a=!0,i=A(r,[1,r.shape[0],r.shape[1],r.shape[2]]));const l={x:i},c={depthRadius:t,bias:e,alpha:s,beta:o},u=D.runKernel(al,l,c);return a?A(u,[u.shape[1],u.shape[2],u.shape[3]]):u}const Q$=F({localResponseNormalization_:Z$});function tI(n){const e={x:S(n,"x","log","float32")};return D.runKernel(Yr,e)}const Pn=F({log_:tI});function eI(n){const e={x:S(n,"x","log1p")};return D.runKernel(Jr,e)}const Bm=F({log1p_:eI});function nI(n,t){$(Fc(n),()=>"The f passed in variableGrads(f) must be a function"),$(t==null||Array.isArray(t)&&t.every(c=>c instanceof ca),()=>"The varList passed in variableGrads(f, varList) must be an array of variables");const e=t!=null;if(!e){t=[];for(const c in D.registeredVariables)t.push(D.registeredVariables[c])}const s=e?t.filter(c=>!c.trainable):null,o=t.length;t=t.filter(c=>c.trainable),$(t.length>0,()=>`variableGrads() expects at least one of the input variables to be trainable, but none of the ${o} variables is trainable.`);const r=!0,{value:i,grads:a}=D.gradients(n,t,null,r);$(a.some(c=>c!=null),()=>"Cannot find a connection between any variable and the result of the loss function y=f(x). Please make sure the operations that use variables are inside the function f passed to minimize()."),$(i.rank===0,()=>`The f passed in variableGrads(f) must return a scalar, but it returned a rank-${i.rank} tensor`);const l={};return t.forEach((c,u)=>{a[u]!=null&&(l[c.name]=a[u])}),s?.forEach(c=>l[c.name]=null),{value:i,grads:l}}function Eo(n){return D.customGrad(n)}function sI(n){const e={x:S(n,"x","neg")};return D.runKernel(fl,e)}const Yt=F({neg_:sI});function oI(n){const e={x:S(n,"x","softplus")};return D.runKernel(pi,e)}const $i=F({softplus_:oI});function rI(n){const t=S(n,"x","logSigmoid");return Eo(s=>({value:Yt($i(Yt(s))),gradFunc:i=>R(i,zo(Yt(s)))}))(t)}const iI=F({logSigmoid_:rI});function aI(n,t){let e=S(n,"a","sub"),s=S(t,"b","sub");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(gi,o)}const pt=F({sub_:aI});function lI(n,t=-1){const e=S(n,"logits","logSoftmax");if(t===-1&&(t=e.rank-1),t!==e.rank-1)throw Error(`Log Softmax along a non-last dimension is not yet supported. Logits was rank ${e.rank} and axis was ${t}`);return Eo((o,r)=>{const a=bn(o,t,!0),l=pt(o,a),c=pt(st(l,"float32"),Pn(ct(Mn(l),t,!0)));return r([c]),{value:c,gradFunc:(h,d)=>{const[p]=d,f=!0,m=Mn(p);return pt(h,R(ct(h,t,f),m))}}})(e)}const Vm=F({logSoftmax_:lI});function cI(n,t=null,e=!1){const s=S(n,"x","logSumExp"),o=Ct(t,s.shape),r=bn(s,o,!0),i=pt(s,r),a=Mn(i),l=ct(a,o),c=Pn(l),u=Y(A(r,c.shape),c);if(e){const h=ne(u.shape,o);return A(u,h)}return u}const Wm=F({logSumExp_:cI});function uI(n,t){const e=S(n,"a","logicalAnd","bool"),s=S(t,"b","logicalAnd","bool");mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(ol,o)}const jn=F({logicalAnd_:uI});function hI(n){const e={x:S(n,"x","logicalNot","bool")};return D.runKernel(rl,e)}const Ch=F({logicalNot_:hI});function dI(n,t){const e=S(n,"a","logicalOr","bool"),s=S(t,"b","logicalOr","bool");mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(il,o)}const Um=F({logicalOr_:dI});function pI(n,t){const e=S(n,"a","logicalXor","bool"),s=S(t,"b","logicalXor","bool");return mt(e.shape,s.shape),jn(Um(n,t),Ch(jn(n,t)))}const fI=F({logicalXor_:pI});function mI(n,t,e,s,o){const r=S(n,"x","maxPool"),i=1;let a=r,l=!1;r.rank===3&&(l=!0,a=A(r,[1,r.shape[0],r.shape[1],r.shape[2]])),$(a.rank===4,()=>`Error in maxPool: input must be rank 4 but got rank ${a.rank}.`),$(ke(e,i),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${e} and dilations '${i}'`),ze("maxPool",s,o);const c={x:a},u={filterSize:t,strides:e,pad:s,dimRoundingMode:o},h=D.runKernel(cl,c,u);return l?A(h,[h.shape[1],h.shape[2],h.shape[3]]):h}const $h=F({maxPool_:mI});function gI(n,t=[1,1,1],e,s,o,r="NDHWC"){const i=S(n,"x","maxPool3d");let a=i,l=!1;i.rank===4&&(l=!0,a=A(i,[1,i.shape[0],i.shape[1],i.shape[2],i.shape[3]])),$(a.rank===5,()=>`Error in maxPool3d: x must be rank 5 but got rank ${a.rank}.`),$(r==="NDHWC",()=>`Error in maxPool3d: Only NDHWC is currently supported, but got dataFormat of ${r}`),ze("maxPool3d",s,o);const c={x:a},u={filterSize:t,strides:e,pad:s,dimRoundingMode:o,dataFormat:r},h=D.runKernel(ul,c,u);return l?A(h,[h.shape[1],h.shape[2],h.shape[3],h.shape[4]]):h}const xI=F({maxPool3d_:gI});function bI(n,t){let e=S(n,"a","maximum"),s=S(t,"b","maximum");[e,s]=Jt(e,s),e.dtype==="bool"&&(e=st(e,"int32"),s=st(s,"int32")),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(Zr,o)}const ks=F({maximum_:bI});function yI(n,t=null,e=!1){const o={x:S(n,"x","mean")},r={axis:t,keepDims:e};return D.runKernel(hl,o,r)}const ee=F({mean_:yI});function de(n,t="float32"){if(Jn(n),t==="complex64"){const s=de(n,"float32"),o=de(n,"float32");return Gs(s,o)}const e=$e(W(n),t);return D.makeTensor(e,n,t)}function vs(n,t="float32"){if(Jn(n),t==="complex64"){const s=vs(n,"float32"),o=de(n,"float32");return Gs(s,o)}const e=xu(W(n),t);return D.makeTensor(e,n,t)}function wI(n,t){let e=S(n,"a","minimum"),s=S(t,"b","minimum");[e,s]=Jt(e,s),e.dtype==="bool"&&(e=st(e,"int32"),s=st(s,"int32")),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(Qr,o)}const mr=F({minimum_:wI});function CI(n,t,e){$(e==="reflect"||e==="symmetric",()=>`Invalid mode. Mode must be either reflect or symmetric. Got ${e}.`);const s=S(n,"x","mirrorPad");if(s.rank===0)throw new Error("mirrorPad(scalar) is not defined. Pass non-scalar to mirrorPad");$(t.length===s.rank,()=>`Padding doesn't match input. Must be ${s.rank}. Got ${t.length}.`);const o=e==="reflect"?1:0;for(let a=0;a<s.rank;a++)$(t[a].length===2,()=>"Invalid number of paddings. Must be length of 2 each."),$(t[a][0]>=0&&t[a][0]<=s.shape[a]-o&&t[a][1]>=0&&t[a][1]<=s.shape[a]-o,()=>`Padding in dimension ${a} cannot be greater than or equal to ${s.shape[a]-o} or less than 0 for input of shape ${s.shape}`);const r={paddings:t,mode:e},i={x:s};return D.runKernel(pl,i,r)}const $I=F({mirrorPad_:CI});function II(n,t){let e=S(n,"a","mod"),s=S(t,"b","mod");[e,s]=Jt(e,s);const o={a:e,b:s};return D.runKernel(ti,o)}const kI=F({mod_:II});function vI(n,t=null,e=!1){n=S(n,"x","moments");const s=Ct(t,n.shape),o=ee(n,s,e);let r=o.shape;e||(r=ne(o.shape,s));const i=Vt(pt(st(n,"float32"),A(o,r))),a=ee(i,s,e);return{mean:o,variance:a}}const Ih=F({moments_:vI});function SI(n,t){let e=S(n,"a","notEqual","string_or_numeric"),s=S(t,"b","notEqual","string_or_numeric");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s};return D.runKernel(ml,o)}const pa=F({notEqual_:SI});function NI(n,t,e=1,s=0,o="int32"){if(t<2)throw new Error(`Error in oneHot: depth must be >=2, but it is ${t}`);const i={indices:S(n,"indices","oneHot","int32")},a={dtype:o,depth:t,onValue:e,offValue:s};return D.runKernel(xl,i,a)}const Gm=F({oneHot_:NI});function TI(n){const e={x:S(n,"x","onesLike")};return D.runKernel(gl,e)}const an=F({onesLike_:TI});function EI(n,t,e=0){const s=S(n,"x","pad");if(s.rank===0)throw new Error("pad(scalar) is not defined. Pass non-scalar to pad");const o={paddings:t,constantValue:e},r={x:s};return D.runKernel(yl,r,o)}const kh=F({pad_:EI});function RI(n,t,e){const s=S(n,"x","spaceToBatchND");$(s.rank>=1+t.length,()=>`input rank ${s.rank} should be > than [blockShape] ${t.length}`),$(e.length===t.length,()=>`paddings.shape[0] ${e.length} must be equal to [blockShape] ${t.length}`),$(s.shape.reduce((i,a,l)=>l>0&&l<=t.length?i&&(a+e[l-1][0]+e[l-1][1])%t[l-1]===0:i,!0),()=>`input spatial dimensions ${s.shape.slice(1)} with paddings ${e.toString()} must be divisible by blockShapes ${t.toString()}`);const o={x:s},r={blockShape:t,paddings:e};return D.runKernel(El,o,r)}const vh=F({spaceToBatchND_:RI});function DI(n,t,e,s,o,r,i){o==null&&(o=[1,1]),r==null&&(r=1),s===0&&(s="valid");const a=S(n,"x","maxPool");let l=a,c=!1;a.rank===3&&(c=!0,l=A(a,[1,a.shape[0],a.shape[1],a.shape[2]])),$(ke(r,o),()=>`Error in pool: Either strides or dilations must be 1. Got strides ${r} and dilations '${o}'`);const u=ln(l.shape,t,r,o,s),h=[u.dilationHeight,u.dilationWidth];let d;s==="same"?d=FI([u.filterHeight,u.filterWidth],h):d=[[0,0],[0,0]];const p=h[0]===1&&h[1]===1,[f,m]=AI([u.inHeight,u.inWidth],h,d),g=p?s:"valid",x=p?l:vh(l,h,f),w=(e==="avg"?()=>dh(x,t,r,g,i):()=>$h(x,t,r,g,i))(),y=p?w:ph(w,h,m);return c?A(y,[y.shape[1],y.shape[2],y.shape[3]]):y}function AI(n,t,e){const s=e.map(u=>u[0]),o=e.map(u=>u[1]),r=n.concat(s,o),i=t.map((u,h)=>(u-r[h]%u)%u),a=o.map((u,h)=>u+i[h]),l=t.map((u,h)=>[s[h],a[h]]),c=t.map((u,h)=>[0,i[h]]);return[l,c]}function FI(n,t){const s=n.map((i,a)=>i+(i-1)*(t[a]-1)).map(i=>i-1),o=s.map(i=>Math.floor(i/2)),r=s.map((i,a)=>i-o[a]);return s.map((i,a)=>[o[a],r[a]])}const OI=F({pool_:DI});function _I(n,t){const e=S(n,"x","prelu"),s=S(t,"alpha","prelu"),o={x:e,alpha:s};return D.runKernel(wl,o)}const Sh=F({prelu_:_I});function LI(n,t=null,e=!1){let s=S(n,"x","prod");s.dtype==="bool"&&(s=st(s,"int32"));const o={x:s},r={axis:t,keepDims:e};return D.runKernel(Cl,o,r)}const MI=F({prod_:LI});class Hm{constructor(t,e,s,o,r){this.mean=t,this.stdDev=e,this.dtype=s,this.nextVal=NaN,this.truncated=o,this.truncated&&(this.upper=this.mean+this.stdDev*2,this.lower=this.mean-this.stdDev*2);const i=r||Math.random();this.random=pu.alea(i.toString())}nextValue(){if(!isNaN(this.nextVal)){const o=this.nextVal;return this.nextVal=NaN,o}let t,e,s=!1;for(;!s;){let o,r,i;do o=2*this.random()-1,r=2*this.random()-1,i=o*o+r*r;while(i>=1||i===0);const a=Math.sqrt(-2*Math.log(i)/i);t=this.mean+this.stdDev*o*a,e=this.mean+this.stdDev*r*a,(!this.truncated||this.isValidTruncated(t))&&(s=!0)}return(!this.truncated||this.isValidTruncated(e))&&(this.nextVal=this.convertValue(e)),this.convertValue(t)}convertValue(t){return this.dtype==null||this.dtype==="float32"?t:Math.round(t)}isValidTruncated(t){return t<=this.upper&&t>=this.lower}}class PI{constructor(t=0,e=1,s,o){if(this.canReturnFloat=()=>this.dtype==null||this.dtype==="float32",this.min=t,this.range=e-t,this.dtype=s,o==null&&(o=Math.random()),typeof o=="number"&&(o=o.toString()),!this.canReturnFloat()&&this.range<=1)throw new Error(`The difference between ${t} - ${e} <= 1 and dtype is not float`);this.random=pu.alea(o)}convertValue(t){return this.canReturnFloat()?t:Math.round(t)}nextValue(){return this.convertValue(this.min+this.range*this.random())}}function zI(n,t=0,e=1,s,o){if(Jn(n),s!=null&&s==="bool")throw new Error(`Unsupported data type ${s}`);const r=new Hm(t,e,s,!1,o),i=wt(n,s);for(let a=0;a<i.values.length;a++)i.values[a]=r.nextValue();return i.toTensor()}const BI=F({randomNormal_:zI});function VI(n,t=0,e=1,s="float32",o){Jn(n);const r=wt(n,s),i=new PI(t,e,null,o);for(let a=0;a<r.values.length;a++)r.values[a]=i.nextValue();return r.toTensor()}const Ii=F({randomUniform_:VI});function gr(n,t,e=1,s="float32"){if(e===0)throw new Error("Cannot have a step of zero");const o={start:n,stop:t,step:e,dtype:s};return D.runKernel(Ju,{},o)}function WI(n){const e={input:S(n,"input","real")};return D.runKernel(Zu,e)}const fa=F({real_:WI});function UI(n){const e={x:S(n,"x","reciprocal")};return D.runKernel(si,e)}const GI=F({reciprocal_:UI});function HI(n){const e={x:S(n,"x","relu")};return D.runKernel(oi,e)}const ro=F({relu_:HI});function KI(n){const e={x:S(n,"x","relu6")};return D.runKernel(ri,e)}const Km=F({relu6_:KI});function jI(n,t){const s={x:S(n,"x","reverse")},o={dims:t};return D.runKernel(vl,s,o)}const Js=F({reverse_:jI});function qI(n){const e={x:S(n,"x","round")};return D.runKernel(ii,e)}const jm=F({round_:qI});function XI(n){const e={x:S(n,"x","rsqrt","float32")};return D.runKernel(ai,e)}const qm=F({rsqrt_:XI});function YI(n){const e={x:S(n,"x","selu")};return D.runKernel(li,e)}const Xm=F({selu_:YI});function JI(n,t,e,s,o,r=[1,1],i="NHWC"){const a=S(n,"x","separableConv2d"),l=S(t,"depthwiseFilter","separableConv2d"),c=S(e,"pointwiseFilter","separableConv2d");let u=a,h=!1;if(a.rank===3&&(h=!0,u=A(a,[1,a.shape[0],a.shape[1],a.shape[2]])),i==="NCHW")throw new Error("separableConv2d currently does not support dataFormat NCHW; only NHWC is supported");$(u.rank===4,()=>`Error in separableConv2d: input must be rank 4, but got rank ${u.rank}.`),$(l.rank===4,()=>`Error in separableConv2d: depthwise filter must be rank 4, but got rank ${l.rank}.`),$(c.rank===4,()=>`Error in separableConv2d: pointwise filter must be rank 4, but got rank ${l.rank}.`),$(c.shape[0]===1,()=>`Error in separableConv2d: the first dimension of pointwise filter  must be 1, but got ${c.shape[0]}.`),$(c.shape[1]===1,()=>`Error in separableConv2d: the second dimension of pointwise filter must be 1, but got ${c.shape[1]}.`);const d=l.shape[2],p=l.shape[3];$(c.shape[2]===d*p,()=>`Error in separableConv2d: the third dimension of pointwise filter must be ${d*p}, but got ${c.shape[2]}.`);const f=gh(u,l,s,o,i,r),g=Xs(f,c,1,"valid",i);return h?A(g,[g.shape[1],g.shape[2],g.shape[3]]):g}const Ym=F({separableConv2d_:JI});function ZI(n){const e={x:S(n,"x","sign")};return D.runKernel(hi,e)}const QI=F({sign_:ZI});function tk(n){const e={x:S(n,"x","sin","float32")};return D.runKernel(ci,e)}const Jm=F({sin_:tk});function ek(n){const e={x:S(n,"x","sinh")};return D.runKernel(ui,e)}const Zm=F({sinh_:ek});function nk(n,t,e){const s=S(n,"x","slice1d");return $(s.rank===1,()=>`slice1d expects a rank-1 tensor, but got a rank-${s.rank} tensor`),zt(s,[t],[e])}const Nh=F({slice1d_:nk});function sk(n,t,e){const s=S(n,"x","slice2d");return $(s.rank===2,()=>`slice2d expects a rank-2 tensor, but got a rank-${s.rank} tensor`),zt(s,t,e)}const Qm=F({slice2d_:sk});function ok(n,t,e){const s=S(n,"x","slice3d");return $(s.rank===3,()=>`slice3d expects a rank-3 tensor, but got a rank-${s.rank} tensor`),zt(s,t,e)}const Th=F({slice3d_:ok});function rk(n,t,e){const s=S(n,"x","slice4d");return $(s.rank===4,()=>`slice4d expects a rank-4 tensor, but got a rank-${s.rank} tensor`),zt(s,t,e)}const ma=F({slice4d_:rk});function ik(n,t=-1){const e=S(n,"logits","softmax","float32");if(t===-1&&(t=e.rank-1),t!==e.rank-1)throw Error(`Softmax along a non-last dimension is not yet supported. Logits was rank ${e.rank} and dim was ${t}`);const s={logits:e},o={dim:t};return D.runKernel(Dl,s,o)}const Eh=F({softmax_:ik});function ak(n){$(n.dtype==="complex64",()=>`The dtype for tf.spectral.fft() must be complex64 but got ${n.dtype}.`);const t={input:n};return D.runKernel(zu,t)}const tg=F({fft_:ak});function lk(n){$(n.dtype==="complex64",()=>`The dtype for tf.spectral.ifft() must be complex64 but got ${n.dtype}.`);const t={input:n};return D.runKernel(Wu,t)}const Xc=F({ifft_:lk});function ck(n){const t=n.shape[n.shape.length-1],e=n.size/t;let s;if(t<=2){const o=A(n,[e,t]);s=Xc(o)}else{const o=[e,2*(t-1)],r=A(fa(n),[e,t]),i=A(yh(n),[e,t]),a=Js(zt(r,[0,1],[e,t-2]),1),l=R(Js(zt(i,[0,1],[e,t-2]),1),Tt(-1)),c=Le([r,a],1),u=Le([i,l],1),h=A(Gs(c,u),[o[0],o[1]]);s=Xc(h)}if(s=fa(s),n.rank===3&&n.shape[0]!==0){const o=s,r=n.shape[0];s=A(s,[r,s.shape[0]/r,s.shape[1]]),o.dispose()}return s}const uk=F({irfft_:ck});function hk(n,t,e=0){const o={x:S(n,"x","split")},r={numOrSizeSplits:t,axis:e};return D.runKernel(Rl,o,r)}const Xe=F({split_:hk});function dk(n,t){$(n.dtype==="float32",()=>`The dtype for rfft() must be real value but got ${n.dtype}`);let e=n.shape[n.shape.length-1];const s=n.size/e;let o;if(t!=null&&t<e){const f=n.shape.map(g=>0),m=n.shape.map(g=>g);m[n.shape.length-1]=t,o=zt(n,f,m),e=t}else if(t!=null&&t>e){const f=n.shape.map(m=>m);f[n.shape.length-1]=t-e,o=Le([n,de(f)],n.shape.length-1),e=t}else o=n;const r=kt(o),i=A(Gs(o,r),[s,e]),a=tg(i),l=Math.floor(e/2)+1,c=fa(a),u=yh(a),h=Xe(c,[l,e-l],c.shape.length-1),d=Xe(u,[l,e-l],u.shape.length-1),p=o.shape.slice();return p[o.shape.length-1]=l,A(Gs(h[0],d[0]),p)}const pk=F({rfft_:dk});function fk(n,t){let e=S(n,"a","squaredDifference"),s=S(t,"b","squaredDifference");[e,s]=Jt(e,s),mt(e.shape,s.shape);const o={a:e,b:s},r={};return D.runKernel(mi,o,r)}const mk=F({squaredDifference_:fk});function gk(n,t){const e=S(n,"x","squeeze","string_or_numeric");return A(e,ys(e.shape,t).newShape)}const ki=F({squeeze_:gk});function xk(n,t=0){const e=Cm(n,"tensors","stack","string_or_numeric");$(e.length>=1,()=>"Pass at least one tensor to tf.stack"),e.length>0&&$(t<=e[0].rank,()=>"Axis must be <= rank of the tensor");const s=e,o={axis:t};return D.runKernel(bl,s,o)}const qn=F({stack_:xk});function bk(n,t=0){const s={x:S(n,"x","step")},o={alpha:t};return D.runKernel(wi,s,o)}const vi=F({step_:bk});function yk(n,t,e,s,o=0,r=0,i=0,a=0,l=0){const u={x:S(n,"x","stridedSlice","string_or_numeric")},h={begin:t,end:e,strides:s,beginMask:o,endMask:r,ellipsisMask:i,newAxisMask:a,shrinkAxisMask:l};return D.runKernel(sh,u,h)}const wk=F({stridedSlice_:yk});function Ck(n){const e={x:S(n,"x","tan","float32")};return D.runKernel(xi,e)}const $k=F({tan_:Ck});function We(n,t){Of(n);const e=Ll(n,t);if(e.length!==1)throw new Error("tensor1d() requires values to be a flat/TypedArray");return Ml(n,null,e,t)}function xc(n,t,e){if(Of(n),t!=null&&t.length!==2)throw new Error("tensor2d() requires shape to have two numbers");const s=Ll(n,e);if(s.length!==2&&s.length!==1)throw new Error("tensor2d() requires values to be number[][] or flat/TypedArray");if(s.length===1&&t==null)throw new Error("tensor2d() requires shape to be provided when `values` are a flat/TypedArray");return Ml(n,t,s,e)}function eg(n,t,e){const s=t.rank>1?t.shape[t.rank-1]:1,o=t.rank>1?t.rank-1:1,r=`Must have updates.shape = indices.shape[:batchDim] + shape[sliceDim:], got updates.shape: ${e.shape}, indices.shape: ${t.shape}, shape: ${n}, sliceDim: ${s}, and batchDim: ${o}.`;if(e.rank<o)throw new Error(r+` update.rank < ${o}. `);if(n.length<s+(e.rank-o))throw new Error(r+` Output shape length < ${s+(e.rank-o)}`);if(e.rank!==o+n.length-s)throw new Error(r+` update.rank != ${o+n.length-s}`);for(let i=0;i<o;++i)if(e.shape[i]!==t.shape[i])throw new Error(r+` updates.shape[${i}] (${e.shape[i]}) != indices.shape[${i}] (${t.shape[i]}).`);for(let i=0;i<e.rank-o;++i)if(e.shape[i+o]!==n[i+s])throw new Error(r+` updates.shape[${i+o}] (${e.shape[i+o]}) != shape[${i+o}] (${n[i+o]})`)}function Ik(n,t,e){if(t.rank<1)throw new Error(`tf.scatterND() expects the indices to be rank 1 or higher, but the rank was ${t.rank}.`);if(n.rank<1)throw new Error(`tf.scatterND() expects the updates to be rank 1 or higher, but the rank was ${n.rank}.`);if(t.dtype!=="int32")throw new Error(`The dtype of 'indices' should be int32, but got dtype: ${t.dtype}`);if(e.length<1)throw new Error(`Output rank must be greater or equal to 1, but got shape: ${e}`);if(e.length===0){if(t.size===0)throw new Error(`Indices specified for empty output. indices shape: ${t.shape}`);if(n.size===0)throw new Error(`Updates specified for empty output. updates shape: ${n.shape}`)}eg(e,t,n)}function io(n,t,e){const s=t.shape.length,o=s>1?t.shape[s-1]:1,r=e.length;let i=1;for(let h=o;h<r;++h)i*=e[h];const a=o<1?1:o,l=W(t.shape)/a,c=[...lt(e.slice(0,o)),1],u=W(e);return{sliceRank:o,numUpdates:l,sliceSize:i,strides:c,outputSize:u}}function kk(n,t=1,e=!0){const s=S(n,"x","topk");if(s.rank===0)throw new Error("topk() expects the input to be of rank 1 or higher");const o=s.shape[s.shape.length-1];if(t<0)throw new Error(`'k' passed to topk() must be >= 0 but got ${t}`);if(t>o)throw new Error(`'k' passed to topk() must be <= the last dimension (${o}) but got ${t}`);const r={x:s},i={k:t,sorted:e},[a,l]=D.runKernel(oh,r,i);return{values:a,indices:l}}const vk=F({topk_:kk});function Sk(n,t=0,e=1,s,o){if(Jn(n),s!=null&&s==="bool")throw new Error("Unsupported data type $ { dtype }");const r=new Hm(t,e,s,!0,o),i=wt(n,s);for(let a=0;a<i.values.length;a++)i.values[a]=r.nextValue();return i.toTensor()}const ng=F({truncatedNormal_:Sk});function Nk(n,t=0){const e=S(n,"x","unique","string_or_numeric");$(e.rank>0,()=>"The input tensor must be at least 1D");const s={x:e},o={axis:t},[r,i]=D.runKernel(ih,s,o);return{values:r,indices:i}}const Tk=F({unique_:Nk});function Ek(n,t,e){const s=S(n,"x","unsortedSegmentSum"),o=S(t,"segmentIds","unsortedSegmentSum","int32");$(vo(e),()=>"numSegments must be of dtype int");const r={x:s,segmentIds:o},i={numSegments:e};return D.runKernel(Fl,r,i)}const sg=F({unsortedSegmentSum_:Ek});function Rk(n,t=0){const e=S(n,"x","unstack","string_or_numeric");$(t>=-e.shape.length&&t<e.shape.length,()=>`Axis = ${t} is not in [-${e.shape.length}, ${e.shape.length})`);const s={value:e},o={axis:t};return D.runKernel(Al,s,o)}const Zs=F({unstack_:Rk});function Dk(n,t=!0,e,s){return D.makeVariable(n,t,e,s)}function og(n,t){const e=[];for(let r=0;r<t.length;r++)t[r]&&e.push(r);const s=wt(n,"int32"),o=wt([e.length,n.length],"int32");for(let r=0;r<e.length;r++){const i=s.indexToLoc(e[r]),a=r*n.length;o.values.set(i,a)}return o.toTensor()}function Ak(n,t,e){const s=S(n,"x","transpose");if(t==null&&(t=s.shape.map((i,a)=>a).reverse()),$(s.rank===t.length,()=>`Error in transpose: rank of input ${s.rank} must match length of perm ${t}.`),t.forEach(i=>{$(i>=0&&i<s.rank,()=>`All entries in 'perm' must be between 0 and ${s.rank-1} but got ${t}`)}),s.rank<=1)return s.clone();const o={x:s},r={perm:t};return s.dtype==="complex64"?_(()=>{let i=fa(s),a=yh(s);return i=D.runKernel(Co,{x:i},r),a=D.runKernel(Co,{x:a},r),e&&(a=Yt(a)),Gs(i,a)}):D.runKernel(Co,o,r)}const It=F({transpose_:Ak});function Fk(n,t){if(t==null)return n.shape.slice();if(Et(n.shape,t))return t;if(n.shape.length===t.length){const e=[];for(let s=0;s<n.shape.length;s++)t[s]==null&&n.shape[s]!=null?e.push(n.shape[s]):e.push(t[s]);return e}return t}function Ok(n,t,e,s){const o=S(n,"x","dropout");if($(o.dtype==="float32",()=>`x has to be a floating point tensor since it's going to be scaled, but got a ${o.dtype} tensor instead.`),$(t>=0&&t<1,()=>`rate must be a float in the range [0, 1), but got ${t}.`),t===0)return n instanceof se?o.clone():o;const r=Fk(o,e),i=1-t,a=ut(Ul(Y(Ii(r,0,1,"float32",s),i)),i);return R(o,a)}const _k=F({dropout_:Ok});function Lk(n,t,e,s,o,r="NHWC",i){let a=n;n.rank===3&&(a=A(n,[1,n.shape[0],n.shape[1],n.shape[2]]));let l=t;l.rank===3&&(l=A(t,[1,t.shape[0],t.shape[1],t.shape[2]])),$(a.rank===4,()=>`Error in conv2dDerFilter: input must be rank 4, but got shape ${a.shape}.`),$(l.rank===4,()=>`Error in conv2dDerFilter: dy must be rank 4, but got shape ${l.shape}.`),$(e.length===4,()=>`Error in conv2dDerFilter: filterShape must be length 4, but got ${e}.`);const c=r==="NHWC"?a.shape[3]:a.shape[1],u=r==="NHWC"?l.shape[3]:l.shape[1];$(c===e[2],()=>`Error in conv2dDerFilter: depth of input ${c}) must match input depth in filter (${e[2]}.`),$(u===e[3],()=>`Error in conv2dDerFilter: depth of dy (${u}) must match output depth for filter (${e[3]}).`),ze("conv2dDerFilter",o,i);const h={x:a,dy:l},d={strides:s,pad:o,dataFormat:r,dimRoundingMode:i,filterShape:e};return D.runKernel(Tu,h,d)}const Rh=F({conv2DBackpropFilter_:Lk});function Dh(n,t,e){if(e==null||e==="linear")return n;if(e==="relu")return R(n,vi(t));throw new Error(`Cannot compute gradient for fused activation ${e}.`)}function Ah(n,t){let e=t;const s=le(n.shape,t.shape);return s.length>0&&(e=ct(e,s)),A(e,n.shape)}function Fh(n,t,e,s){if(t==="linear")return n;if(t==="relu")return ro(n);if(t==="elu")return Vl(n);if(t==="relu6")return Km(n);if(t==="prelu")return Sh(n,e);if(t==="leakyrelu")return wh(n,s);if(t==="sigmoid")return zo(n);throw new Error(`Unknown fused activation ${t}.`)}const Oh=(n,t)=>!(n>0)||t==="linear";function Mk({x:n,filter:t,strides:e,pad:s,dataFormat:o="NHWC",dilations:r=[1,1],dimRoundingMode:i,bias:a,activation:l="linear",preluActivationWeights:c,leakyreluAlpha:u}){if(l=l||"linear",Oh(D.state.gradientDepth,l)===!1){$(o==="NHWC",()=>`Error in fused conv2d: got dataFormat of ${o} but only NHWC is currently supported for the case of gradient depth is 0 and the activation is not linear.`);let I=Xs(n,t,e,s,o,r,i);return a!=null&&(I=Y(I,a)),Fh(I,l,c,u)}const h=S(n,"x","conv2d","float32"),d=S(t,"filter","conv2d","float32");let p=h,f=!1;h.rank===3&&(f=!0,p=A(h,[1,h.shape[0],h.shape[1],h.shape[2]])),$(p.rank===4,()=>`Error in fused conv2d: input must be rank 4, but got rank ${p.rank}.`),$(d.rank===4,()=>`Error in fused conv2d: filter must be rank 4, but got rank ${d.rank}.`),ze("fused conv2d",s,i);const m=o==="NHWC"?p.shape[3]:p.shape[1];$(d.shape[2]===m,()=>`Error in conv2d: depth of input (${m}) must match input depth for filter ${d.shape[2]}.`),$(ke(e,r),()=>`Error in conv2D: Either strides or dilations must be 1. Got strides ${e} and dilations '${r}'`);const g=be(p.shape,d.shape,e,r,s,i);let x;a!=null&&(x=S(a,"bias","fused conv2d"),[x]=Jt(x,h),o==="NHWC"?mt(g.outShape,x.shape):($(x.shape.length<=1,()=>`Error in fused conv2d: only supports scalar or 1-D Tensor bias for NCHW format but got the bias of rank-${x.shape.length}.`),$(x.shape.length===0||x.shape[0]===g.outChannels||x.shape[0]===1,()=>`Error in fused conv2d: bias shape (${x.shape}) is not compatible with the number of output channels (${g.outChannels})`)));let b;if(c!=null){const I=c.shape;if($(I.length<=1||I.length===3,()=>`Error in fused conv2d: only supports scalar, 1-D Tensor or 3-D Tensor PReLU activation weights but got a tensor of rank-${I.length}.`),I.length===1)$(I[0]===1||I[0]===g.outChannels,()=>`Error in fused conv2d: PReLU activation weights (${I}) is not compatible with the number of output channels (${g.outChannels}).`);else if(I.length===3)try{mt(I,g.outShape)}catch{const v=`Error in fused conv2d: PReLU activation weights (${I}) is not compatible with the output shape of the conv2d (${g.outShape}).`;throw Error(v)}b=S(c,"prelu weights","fused conv2d")}const w=(I,k)=>{$(o==="NHWC",()=>`Error in gradient of fused conv2D: got dataFormat of ${o} but only NHWC is currently supported.`);const[v,N,T,O]=k,P=Dh(I,T,l);$(js(r),()=>`Error in gradient of fused conv2D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${r}'`);const z=fh(N.shape,P,v,e,s),B=Rh(N,P,v.shape,e,s),M=[z,B];if(O!=null){const G=Ah(O,P);M.push(G)}return M},y={x:p,filter:d,bias:x,preluActivationWeights:b},C={strides:e,pad:s,dataFormat:o,dilations:r,dimRoundingMode:i,activation:l,leakyreluAlpha:u};return a==null?Eo((k,v,N)=>{let T=D.runKernel(aa,y,C);return N([v,k,T]),f&&(T=A(T,[T.shape[1],T.shape[2],T.shape[3]])),{value:T,gradFunc:w}})(p,d):Eo((k,v,N,T)=>{let O=D.runKernel(aa,y,C);return T([v,k,O,N]),f&&(O=A(O,[O.shape[1],O.shape[2],O.shape[3]])),{value:O,gradFunc:w}})(p,d,x)}const Pk=F({fusedConv2d_:Mk});function zk(n,t,e,s,o,r=[1,1],i){let a=n;n.rank===3&&(a=A(n,[1,n.shape[0],n.shape[1],n.shape[2]]));let l=t;l.rank===3&&(l=A(t,[1,t.shape[0],t.shape[1],t.shape[2]]));const c={x:a,dy:l},u={strides:s,pad:o,dimRoundingMode:i,dilations:r,filterShape:e};return D.runKernel(_u,c,u)}const Bk=F({depthwiseConv2dNativeBackpropFilter_:zk});function Vk(n,t,e,s,o,r=[1,1],i){let a=t,l=!1;t.rank===3&&(l=!0,a=A(t,[1,t.shape[0],t.shape[1],t.shape[2]]));const c={dy:a,filter:e},u={strides:s,pad:o,dimRoundingMode:i,dilations:r,inputShape:n},h=D.runKernel(Lu,c,u);return l?A(h,[h.shape[1],h.shape[2],h.shape[3]]):h}const Wk=F({depthwiseConv2dNativeBackpropInput_:Vk});function Uk({a:n,b:t,transposeA:e=!1,transposeB:s=!1,bias:o,activation:r="linear",preluActivationWeights:i,leakyreluAlpha:a=.2}){if(Oh(D.state.gradientDepth,r)===!1){let O=Nt(n,t,e,s);return o!=null&&(O=Y(O,o)),Fh(O,r,i,a)}let l=S(n,"a","fused matMul"),c=S(t,"b","fused matMul");[l,c]=Jt(l,c);const u=e?l.shape[l.rank-2]:l.shape[l.rank-1],h=s?c.shape[c.rank-1]:c.shape[c.rank-2],d=e?l.shape[l.rank-1]:l.shape[l.rank-2],p=s?c.shape[c.rank-2]:c.shape[c.rank-1],f=l.shape.slice(0,-2),m=c.shape.slice(0,-2),g=W(f),x=W(m);$(u===h,()=>`Error in fused matMul: inner shapes (${u}) and (${h}) of Tensors with shapes ${l.shape} and ${c.shape} and transposeA=${e} and transposeB=${s} must match.`);const w=mt(l.shape.slice(0,-2),c.shape.slice(0,-2)).concat([d,p]),y=e?A(l,[g,u,d]):A(l,[g,d,u]),C=s?A(c,[x,p,h]):A(c,[x,h,p]);let I;o!=null&&(I=S(o,"bias","fused matMul"),[I]=Jt(I,l),mt(w,I.shape));let k;i!=null&&(k=S(i,"prelu weights","fused matMul"));const v=(O,P)=>{const[z,B,M,G]=P,H=Dh(A(O,M.shape),M,r);let U,K;if(!e&&!s?(U=Nt(H,B,!1,!0),K=Nt(z,H,!0,!1)):!e&&s?(U=Nt(H,B,!1,!1),K=Nt(H,z,!0,!1)):e&&!s?(U=Nt(B,H,!1,!0),K=Nt(z,H,!1,!1)):(U=Nt(B,H,!0,!0),K=Nt(H,z,!0,!0)),o!=null){const q=Ah(G,H);return[U,K,q]}else return[U,K]},N={a:y,b:C,bias:I,preluActivationWeights:k},T={transposeA:e,transposeB:s,activation:r,leakyreluAlpha:a};return o==null?Eo((P,z,B)=>{const M=D.runKernel(ia,N,T);return B([P,z,M]),{value:A(M,w),gradFunc:v}})(y,C):Eo((P,z,B,M)=>{const G=D.runKernel(ia,N,T);return M([P,z,G,B]),{value:A(G,w),gradFunc:v}})(y,C,I)}const fp=F({fusedMatMul_:Uk});function Gk(n,t,e,s,o="bilinear",r=0){const i=S(n,"image","cropAndResize"),a=S(t,"boxes","cropAndResize","float32"),l=S(e,"boxInd","cropAndResize","int32"),c=a.shape[0];$(i.rank===4,()=>`Error in cropAndResize: image must be rank 4,but got rank ${i.rank}.`),$(a.rank===2&&a.shape[1]===4,()=>`Error in cropAndResize: boxes must be have size [${c},4] but had shape ${a.shape}.`),$(l.rank===1&&l.shape[0]===c,()=>`Error in cropAndResize: boxInd must be have size [${c}] but had shape ${a.shape}.`),$(s.length===2,()=>`Error in cropAndResize: cropSize must be of length 2, but got length ${s.length}.`),$(s[0]>=1&&s[1]>=1,()=>`cropSize must be atleast [1,1], but was ${s}`),$(o==="bilinear"||o==="nearest",()=>`method must be bilinear or nearest, but was ${o}`);const u={image:i,boxes:a,boxInd:l},h={method:o,extrapolationValue:r,cropSize:s};return D.runKernel(Au,u,h)}const Hk=F({cropAndResize_:Gk});function Kk(n){const t=S(n,"image","flipLeftRight","float32");$(t.rank===4,()=>`Error in flipLeftRight: image must be rank 4,but got rank ${t.rank}.`);const e={image:t};return D.runKernel(Vu,e,{})}const jk=F({flipLeftRight_:Kk});function qk(n){const t=S(n,"image","grayscaleToRGB"),e=t.rank-1,s=t.shape[e];$(t.rank>=2,()=>`Error in grayscaleToRGB: images must be at least rank 2, but got rank ${t.rank}.`),$(s===1,()=>`Error in grayscaleToRGB: last dimension of a grayscale image should be size 1, but got size ${s}.`);const o=new Array(t.rank);return o.fill(1,0,e),o[e]=3,gn(t,o)}const Xk=F({grayscaleToRGB_:qk});function Yk(n){const t=S(n,"image","RGBToGrayscale"),e=t.rank-1,s=t.shape[e];$(t.rank>=2,()=>`Error in RGBToGrayscale: images must be at least rank 2, but got rank ${t.rank}.`),$(s===3,()=>`Error in RGBToGrayscale: last dimension of an RGB image should be size 3, but got size ${s}.`);const o=t.dtype,r=st(t,"float32"),i=We([.2989,.587,.114]);let a;switch(t.rank){case 2:a=tr("ij,j->i",r,i);break;case 3:a=tr("ijk,k->ij",r,i);break;case 4:a=tr("ijkl,l->ijk",r,i);break;case 5:a=tr("ijklm,m->ijkl",r,i);break;case 6:a=tr("ijklmn,n->ijklm",r,i);break;default:throw new Error("Not a valid tensor rank.")}return a=Oe(a,-1),st(a,o)}const Jk=F({rgbToGrayscale_:Yk});function Zk(n,t,e=0,s=.5){const o=S(n,"image","rotateWithOffset","float32");$(o.rank===4,()=>`Error in rotateWithOffset: image must be rank 4,but got rank ${o.rank}.`);const r={image:o},i={radians:t,fillValue:e,center:s};return D.runKernel(ah,r,i)}const Qk=F({rotateWithOffset_:Zk});function Vo(n,t,e,s,o,r){s==null&&(s=.5),o==null&&(o=Number.NEGATIVE_INFINITY),r==null&&(r=0);const i=n.shape[0];return e=Math.min(e,i),$(0<=s&&s<=1,()=>`iouThreshold must be in [0, 1], but was '${s}'`),$(n.rank===2,()=>`boxes must be a 2D tensor, but was of rank '${n.rank}'`),$(n.shape[1]===4,()=>`boxes must have 4 columns, but 2nd dimension was ${n.shape[1]}`),$(t.rank===1,()=>"scores must be a 1D tensor"),$(t.shape[0]===i,()=>`scores has incompatible shape with boxes. Expected ${i}, but was ${t.shape[0]}`),$(0<=r&&r<=1,()=>`softNmsSigma must be in [0, 1], but was '${r}'`),{maxOutputSize:e,iouThreshold:s,scoreThreshold:o,softNmsSigma:r}}function tv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY){const r=S(n,"boxes","nonMaxSuppression","float32"),i=S(t,"scores","nonMaxSuppression","float32"),a=Vo(r,i,e,s,o);e=a.maxOutputSize,s=a.iouThreshold,o=a.scoreThreshold;const l={maxOutputSize:e,iouThreshold:s,scoreThreshold:o};return D.runKernel(qu,{boxes:r,scores:i},l)}const ev=F({nonMaxSuppression_:tv});function nv(n,t,e){const s=sv(n,t,e),o=s<0?-(s+1):s;n.splice(o,0,t)}function sv(n,t,e){return rv(n,t,e||ov)}function ov(n,t){return n>t?1:n<t?-1:0}function rv(n,t,e){let s=0,o=n.length,r=0,i=!1;for(;s<o;){r=s+(o-s>>>1);const a=e(t,n[r]);a>0?s=r+1:(o=r,i=!a)}return i?s:-s-1}function _h(n,t,e,s,o){return Ph(n,t,e,s,o,0)}function Lh(n,t,e,s,o,r){return Ph(n,t,e,s,o,0,!1,r,!0)}function Mh(n,t,e,s,o,r){return Ph(n,t,e,s,o,r,!0)}function Ph(n,t,e,s,o,r,i=!1,a=!1,l=!1){const c=[];for(let g=0;g<t.length;g++)t[g]>o&&c.push({score:t[g],boxIndex:g,suppressBeginIndex:0});c.sort(mp);const u=r>0?-.5/r:0,h=[],d=[];for(;h.length<e&&c.length>0;){const g=c.pop(),{score:x,boxIndex:b,suppressBeginIndex:w}=g;if(x<o)break;let y=!1;for(let C=h.length-1;C>=w;--C){const I=iv(n,b,h[C]);if(I>=s){y=!0;break}if(g.score=g.score*av(s,u,I),g.score<=o)break}g.suppressBeginIndex=h.length,y||(g.score===x?(h.push(b),d.push(g.score)):g.score>o&&nv(c,g,mp))}const p=h.length,f=e-p;a&&f>0&&(h.push(...new Array(f).fill(0)),d.push(...new Array(f).fill(0)));const m={selectedIndices:h};return i&&(m.selectedScores=d),l&&(m.validOutputs=p),m}function iv(n,t,e){const s=n.subarray(t*4,t*4+4),o=n.subarray(e*4,e*4+4),r=Math.min(s[0],s[2]),i=Math.min(s[1],s[3]),a=Math.max(s[0],s[2]),l=Math.max(s[1],s[3]),c=Math.min(o[0],o[2]),u=Math.min(o[1],o[3]),h=Math.max(o[0],o[2]),d=Math.max(o[1],o[3]),p=(a-r)*(l-i),f=(h-c)*(d-u);if(p<=0||f<=0)return 0;const m=Math.max(r,c),g=Math.max(i,u),x=Math.min(a,h),b=Math.min(l,d),w=Math.max(x-m,0)*Math.max(b-g,0);return w/(p+f-w)}function av(n,t,e){const s=Math.exp(t*e*e);return e<=n?s:0}function mp(n,t){return n.score-t.score||n.score===t.score&&t.boxIndex-n.boxIndex}async function lv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY){const r=S(n,"boxes","nonMaxSuppressionAsync"),i=S(t,"scores","nonMaxSuppressionAsync"),a=Vo(r,i,e,s,o);e=a.maxOutputSize,s=a.iouThreshold,o=a.scoreThreshold;const l=await Promise.all([r.data(),i.data()]),c=l[0],u=l[1],{selectedIndices:h}=_h(c,u,e,s,o);return r!==n&&r.dispose(),i!==t&&i.dispose(),We(h,"int32")}const cv=lv;function uv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY,r=0){const i=S(n,"boxes","nonMaxSuppression"),a=S(t,"scores","nonMaxSuppression"),l=Vo(i,a,e,s,o,r);e=l.maxOutputSize,s=l.iouThreshold,o=l.scoreThreshold,r=l.softNmsSigma;const c={boxes:i,scores:a},u={maxOutputSize:e,iouThreshold:s,scoreThreshold:o,softNmsSigma:r},h=D.runKernel(Yu,c,u);return{selectedIndices:h[0],selectedScores:h[1]}}const hv=F({nonMaxSuppressionWithScore_:uv});async function dv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY,r=0){const i=S(n,"boxes","nonMaxSuppressionAsync"),a=S(t,"scores","nonMaxSuppressionAsync"),l=Vo(i,a,e,s,o,r);e=l.maxOutputSize,s=l.iouThreshold,o=l.scoreThreshold,r=l.softNmsSigma;const c=await Promise.all([i.data(),a.data()]),u=c[0],h=c[1],{selectedIndices:d,selectedScores:p}=Mh(u,h,e,s,o,r);return i!==n&&i.dispose(),a!==t&&a.dispose(),{selectedIndices:We(d,"int32"),selectedScores:We(p)}}const pv=dv;function fv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY,r=!1){const i=S(n,"boxes","nonMaxSuppression"),a=S(t,"scores","nonMaxSuppression"),l=Vo(i,a,e,s,o,null),c=l.maxOutputSize,u=l.iouThreshold,h=l.scoreThreshold,d={boxes:i,scores:a},p={maxOutputSize:c,iouThreshold:u,scoreThreshold:h,padToMaxOutputSize:r},f=D.runKernel(Xu,d,p);return{selectedIndices:f[0],validOutputs:f[1]}}const mv=F({nonMaxSuppressionPadded_:fv});async function gv(n,t,e,s=.5,o=Number.NEGATIVE_INFINITY,r=!1){const i=S(n,"boxes","nonMaxSuppressionAsync"),a=S(t,"scores","nonMaxSuppressionAsync"),l=Vo(i,a,e,s,o,null),c=l.maxOutputSize,u=l.iouThreshold,h=l.scoreThreshold,[d,p]=await Promise.all([i.data(),a.data()]),{selectedIndices:f,validOutputs:m}=Lh(d,p,c,u,h,r);return i!==n&&i.dispose(),a!==t&&a.dispose(),{selectedIndices:We(f,"int32"),validOutputs:Tt(m,"int32")}}const xv=gv;function bv(n,t,e=!1,s=!1){const o=S(n,"images","resizeBilinear");$(o.rank===3||o.rank===4,()=>`Error in resizeBilinear: x must be rank 3 or 4, but got rank ${o.rank}.`),$(t.length===2,()=>`Error in resizeBilinear: new shape must 2D, but got shape ${t}.`),$(s===!1||e===!1,()=>"Error in resizeBilinear: If halfPixelCenters is true, alignCorners must be false.");let r=o,i=!1;o.rank===3&&(i=!0,r=A(o,[1,o.shape[0],o.shape[1],o.shape[2]]));const a={images:r},l={alignCorners:e,halfPixelCenters:s,size:t},c=D.runKernel(kl,a,l);return i?A(c,[c.shape[1],c.shape[2],c.shape[3]]):c}const rg=F({resizeBilinear_:bv});function yv(n,t,e=!1,s=!1){const o=S(n,"images","resizeNearestNeighbor");$(o.rank===3||o.rank===4,()=>`Error in resizeNearestNeighbor: x must be rank 3 or 4, but got rank ${o.rank}.`),$(t.length===2,()=>`Error in resizeNearestNeighbor: new shape must 2D, but got shape ${t}.`),$(o.dtype==="float32"||o.dtype==="int32",()=>"`images` must have `int32` or `float32` as dtype"),$(s===!1||e===!1,()=>"Error in resizeNearestNeighbor: If halfPixelCenters is true, alignCorners must be false.");let r=o,i=!1;o.rank===3&&(i=!0,r=A(o,[1,o.shape[0],o.shape[1],o.shape[2]]));const a={images:r},l={alignCorners:e,halfPixelCenters:s,size:t},c=D.runKernel(Il,a,l);return i?A(c,[c.shape[1],c.shape[2],c.shape[3]]):c}const ig=F({resizeNearestNeighbor_:yv});function wv(n,t="binary",e=!1,s=.5){const o=S(n,"image","threshold"),r=.2989,i=.587,a=.114,l=o.shape[0]*o.shape[1];let c=R(We([s]),255),u,h,d,p;if($(o.rank===3,()=>`Error in threshold: image must be rank 3,but got rank ${o.rank}.`),$(o.shape[2]===3||o.shape[2]===1,()=>`Error in threshold: image color channel must be equal to 3 or 1but got ${o.shape[2]}.`),$(o.dtype==="int32"||o.dtype==="float32",()=>`Error in dtype: image dtype must be int32 or float32,but got dtype ${o.dtype}.`),$(t==="otsu"||t==="binary",()=>`Method must be binary or otsu, but was ${t}`),o.shape[2]===3){[u,h,d]=Xe(o,[1,1,1],-1);const g=R(u,r),x=R(h,i),b=R(d,a);p=Y(Y(g,x),b)}else p=n;if(t==="otsu"){const g=_C(st(jm(p),"int32"),cr([]),256);c=Cv(g,l)}const f=e?Bo(p,c):Je(p,c);return st(R(f,255),"int32")}function Cv(n,t){let e=We([-1]),s=We([0]),o=We([0]),r,i,a,l,c,u;for(let h=0;h<n.size-1;h++){r=zt(n,0,h+1),i=zt(n,h+1),c=ut(ct(r),t),u=ut(ct(i),t);const d=ct(R(r,gr(0,r.size)));a=ut(d,ct(r));const p=Bl(i.shape,r.size),f=Y(gr(0,i.size),p),m=R(i,f);l=ut(ct(m),ct(i));const g=pt(a,l),x=pt(a,l),b=R(c,u);o=R(R(b,g),x);const w=Je(o,s);s=Re(w,o,s),e=Re(w,We([h]),e)}return e}const $v=F({threshold_:wv});function Iv(n,t,e="nearest",s="constant",o=0,r){const i=S(n,"image","transform","float32"),a=S(t,"transforms","transform","float32");$(i.rank===4,()=>`Error in transform: image must be rank 4,but got rank ${i.rank}.`),$(a.rank===2&&(a.shape[0]===i.shape[0]||a.shape[0]===1)&&a.shape[1]===8,()=>"Error in transform: Input transform should be batch x 8 or 1 x 8"),$(r==null||r.length===2,()=>`Error in transform: outputShape must be [height, width] or null, but got ${r}.`);const l={image:i,transforms:a},c={interpolation:e,fillMode:s,fillValue:o,outputShape:r};return D.runKernel(rh,l,c)}const kv=F({transform_:Iv});function vv(n,t,e){const s=S(n,"a","bandPart");$(s.rank>=2,()=>`bandPart(): Rank must be at least 2, got ${s.rank}.`);const o=s.shape,[r,i]=s.shape.slice(-2);let a,l;typeof t=="number"?($(t%1===0,()=>`bandPart(): numLower must be an integer, got ${t}.`),$(t<=r,()=>`bandPart(): numLower (${t}) must not be greater than the number of rows (${r}).`),a=S(t<0?r:t,"numLower","bandPart")):($(t.dtype==="int32",()=>"bandPart(): numLower's dtype must be an int32."),a=Re(da(t,0),r,mr(t,r))),typeof e=="number"?($(e%1===0,()=>`bandPart(): numUpper must be an integer, got ${e}.`),$(e<=i,()=>`bandPart(): numUpper (${e}) must not be greater than the number of columns (${i}).`),l=S(e<0?i:e,"numUpper","bandPart")):($(e.dtype==="int32",()=>"bandPart(): numUpper's dtype must be an int32."),l=Re(da(e,0),i,mr(e,i)));const c=A(gr(0,r,1,"int32"),[-1,1]),u=gr(0,i,1,"int32"),h=pt(c,u),d=jn(Bo(h,a),oo(h,Yt(l))),p=de([r,i],s.dtype);return A(qn(Zs(A(s,[-1,r,i])).map(f=>Re(d,f,p))),o)}const Sv=F({bandPart_:vv});function Nv(n){let t;if(Array.isArray(n)){t=!1,$(n!=null&&n.length>0,()=>"Gram-Schmidt process: input must not be null, undefined, or empty");const o=n[0].shape[0];for(let r=1;r<n.length;++r)$(n[r].shape[0]===o,()=>`Gram-Schmidt: Non-unique lengths found in the input vectors: (${n[r].shape[0]} vs. ${o})`)}else t=!0,n=Xe(n,n.shape[0],0).map(o=>ki(o,[0]));$(n.length<=n[0].shape[0],()=>`Gram-Schmidt: Number of vectors (${n.length}) exceeds number of dimensions (${n[0].shape[0]}).`);const e=[],s=n;for(let o=0;o<n.length;++o)e.push(D.tidy(()=>{let r=s[o];if(o>0)for(let i=0;i<o;++i){const a=R(ct(R(e[i],r)),e[i]);r=pt(r,a)}return ut(r,Wl(r,"euclidean"))}));return t?qn(e,0):e}const Tv=F({gramSchmidt_:Nv});function Ev(n,t=!1){if($(n.rank>=2,()=>`qr() requires input tensor to have a rank >= 2, but got rank ${n.rank}`),n.rank===2)return gp(n,t);{const e=n.shape.slice(0,n.shape.length-2).reduce((l,c)=>l*c),s=Zs(A(n,[e,n.shape[n.shape.length-2],n.shape[n.shape.length-1]]),0),o=[],r=[];s.forEach(l=>{const[c,u]=gp(l,t);o.push(c),r.push(u)});const i=A(qn(o,0),n.shape),a=A(qn(r,0),n.shape);return[i,a]}}function gp(n,t=!1){return D.tidy(()=>{$(n.shape.length===2,()=>`qr2d() requires a 2D Tensor, but got a ${n.shape.length}D Tensor.`);const e=n.shape[0],s=n.shape[1];let o=zm(e),r=zs(n);const i=xc([[1]],[1,1]);let a=zs(i);const l=e>=s?s:e;for(let c=0;c<l;++c){const u=r,h=a,d=o;[a,r,o]=D.tidy(()=>{const p=zt(r,[c,c],[e-c,1]),f=Wl(p),m=zt(r,[c,c],[1,1]),g=Re(Je(m,0),xc([[-1]]),xc([[1]])),x=pt(m,R(g,f)),b=ut(p,x);b.shape[0]===1?a=zs(i):a=Le([i,zt(b,[1,0],[b.shape[0]-1,b.shape[1]])],0);const w=Yt(ut(Nt(g,x),f)),y=zt(r,[c,0],[e-c,s]),C=R(w,a),I=It(a);if(c===0)r=pt(y,Nt(C,Nt(I,y)));else{const N=pt(y,Nt(C,Nt(I,y)));r=Le([zt(r,[0,0],[c,s]),N],0)}const k=It(C),v=zt(o,[0,c],[e,o.shape[1]-c]);if(c===0)o=pt(v,Nt(Nt(v,a),k));else{const N=pt(v,Nt(Nt(v,a),k));o=Le([zt(o,[0,0],[e,c]),N],1)}return[a,r,o]}),yt([u,h,d])}return!t&&e>s&&(o=zt(o,[0,0],[e,s]),r=zt(r,[0,0],[s,s])),[o,r]})}const Rv=F({qr_:Ev});const Kn={flipLeftRight:jk,grayscaleToRGB:Xk,resizeNearestNeighbor:ig,resizeBilinear:rg,rgbToGrayscale:Jk,rotateWithOffset:Qk,cropAndResize:Hk,nonMaxSuppression:ev,nonMaxSuppressionAsync:cv,nonMaxSuppressionWithScore:hv,nonMaxSuppressionWithScoreAsync:pv,nonMaxSuppressionPadded:mv,nonMaxSuppressionPaddedAsync:xv,threshold:$v,transform:kv},Dv={bandPart:Sv,gramSchmidt:Tv,qr:Rv};const Av=new Map,Fv=new Map;class Wo{getClassName(){return this.constructor.className}static fromConfig(t,e){return new t(e)}}class nn{constructor(){this.classNameMap={}}static getMap(){return nn.instance==null&&(nn.instance=new nn),nn.instance}static register(t){nn.getMap().classNameMap[t.className]=[t,t.fromConfig]}}function j(n,t,e){$(n.className!=null,()=>"Class being registered does not have the static className property defined."),$(typeof n.className=="string",()=>"className is required to be a string, but got type "+typeof n.className),$(n.className.length>0,()=>"Class being registered has an empty-string as its className, which is disallowed."),typeof t>"u"&&(t="Custom"),typeof e>"u"&&(e=n.className);const s=e,o=t+">"+s;return nn.register(n),Av.set(o,n),Fv.set(n,o),n}class Ss extends Wo{minimize(t,e=!1,s){const{value:o,grads:r}=this.computeGradients(t,s);if(s!=null){const i=s.map(a=>({name:a.name,tensor:r[a.name]}));this.applyGradients(i)}else this.applyGradients(r);return yt(r),e?o:(o.dispose(),null)}get iterations(){return this.iterations_==null&&(this.iterations_=0),this.iterations_}incrementIterations(){this.iterations_=this.iterations+1}computeGradients(t,e){return nI(t,e)}dispose(){this.iterations_!=null&&yt(this.iterations_)}async saveIterations(){return this.iterations_==null&&(this.iterations_=0),{name:"iter",tensor:Tt(this.iterations_,"int32")}}async getWeights(){throw new Error("getWeights() is not implemented for this optimizer yet.")}async setWeights(t){throw new Error(`setWeights() is not implemented for this optimizer class ${this.getClassName()}`)}async extractIterations(t){return this.iterations_=(await t[0].tensor.data())[0],t.slice(1)}}Object.defineProperty(Ss,Symbol.hasInstance,{value:n=>n.minimize!=null&&n.computeGradients!=null&&n.applyGradients!=null});class ag extends Ss{static get className(){return"Adadelta"}constructor(t,e,s=null){super(),this.learningRate=t,this.rho=e,this.epsilon=s,this.accumulatedGrads=[],this.accumulatedUpdates=[],s==null&&(this.epsilon=D.backend.epsilon())}applyGradients(t){(Array.isArray(t)?t.map(s=>s.name):Object.keys(t)).forEach((s,o)=>{const r=D.registeredVariables[s],i=!1;this.accumulatedGrads[o]==null&&(this.accumulatedGrads[o]={originalName:`${s}/accum_grad`,variable:_(()=>kt(r).variable(i))}),this.accumulatedUpdates[o]==null&&(this.accumulatedUpdates[o]={originalName:`${s}/accum_var`,variable:_(()=>kt(r).variable(i))});const a=Array.isArray(t)?t[o].tensor:t[s];if(a==null)return;const l=this.accumulatedGrads[o].variable,c=this.accumulatedUpdates[o].variable;_(()=>{const u=Y(R(l,this.rho),R(Vt(a),1-this.rho)),h=R(ut(Ie(Y(c,this.epsilon)),Ie(Y(l,this.epsilon))),a),d=Y(R(c,this.rho),R(Vt(h),1-this.rho));l.assign(u),c.assign(d);const p=Y(R(h,-this.learningRate),r);r.assign(p)})}),this.incrementIterations()}dispose(){this.accumulatedUpdates!=null&&(yt(this.accumulatedGrads.map(t=>t.variable)),yt(this.accumulatedUpdates.map(t=>t.variable)))}async getWeights(){const t=[...this.accumulatedGrads,...this.accumulatedUpdates];return[await this.saveIterations()].concat(t.map(e=>({name:e.originalName,tensor:e.variable})))}async setWeights(t){t=await this.extractIterations(t);const e=t.length/2,s=!1;this.accumulatedGrads=t.slice(0,e).map(o=>({originalName:o.name,variable:o.tensor.variable(s)})),this.accumulatedUpdates=t.slice(e,e*2).map(o=>({originalName:o.name,variable:o.tensor.variable(s)}))}getConfig(){return{learningRate:this.learningRate,rho:this.rho,epsilon:this.epsilon}}static fromConfig(t,e){return new t(e.learningRate,e.rho,e.epsilon)}}class lg extends Ss{static get className(){return"Adagrad"}constructor(t,e=.1){super(),this.learningRate=t,this.initialAccumulatorValue=e,this.accumulatedGrads=[]}applyGradients(t){(Array.isArray(t)?t.map(s=>s.name):Object.keys(t)).forEach((s,o)=>{const r=D.registeredVariables[s];this.accumulatedGrads[o]==null&&(this.accumulatedGrads[o]={originalName:`${s}/accumulator`,variable:_(()=>Bl(r.shape,this.initialAccumulatorValue).variable(!1))});const i=Array.isArray(t)?t[o].tensor:t[s];if(i==null)return;const a=this.accumulatedGrads[o].variable;_(()=>{const l=Y(a,Vt(i));a.assign(l);const c=Y(R(ut(i,Ie(Y(l,D.backend.epsilon()))),-this.learningRate),r);r.assign(c)})}),this.incrementIterations()}dispose(){this.accumulatedGrads!=null&&yt(this.accumulatedGrads.map(t=>t.variable))}async getWeights(){return[await this.saveIterations()].concat(this.accumulatedGrads.map(t=>({name:t.originalName,tensor:t.variable})))}async setWeights(t){t=await this.extractIterations(t);const e=!1;this.accumulatedGrads=t.map(s=>({originalName:s.name,variable:s.tensor.variable(e)}))}getConfig(){return{learningRate:this.learningRate,initialAccumulatorValue:this.initialAccumulatorValue}}static fromConfig(t,e){return new t(e.learningRate,e.initialAccumulatorValue)}}class cg extends Ss{static get className(){return"Adam"}constructor(t,e,s,o=null){super(),this.learningRate=t,this.beta1=e,this.beta2=s,this.epsilon=o,this.accumulatedFirstMoment=[],this.accumulatedSecondMoment=[],_(()=>{this.accBeta1=Tt(e).variable(),this.accBeta2=Tt(s).variable()}),o==null&&(this.epsilon=D.backend.epsilon())}applyGradients(t){const e=Array.isArray(t)?t.map(s=>s.name):Object.keys(t);_(()=>{const s=pt(1,this.accBeta1),o=pt(1,this.accBeta2);e.forEach((r,i)=>{const a=D.registeredVariables[r],l=!1;this.accumulatedFirstMoment[i]==null&&(this.accumulatedFirstMoment[i]={originalName:`${r}/m`,variable:_(()=>kt(a).variable(l))}),this.accumulatedSecondMoment[i]==null&&(this.accumulatedSecondMoment[i]={originalName:`${r}/v`,variable:_(()=>kt(a).variable(l))});const c=Array.isArray(t)?t[i].tensor:t[r];if(c==null)return;const u=this.accumulatedFirstMoment[i].variable,h=this.accumulatedSecondMoment[i].variable,d=Y(R(u,this.beta1),R(c,1-this.beta1)),p=Y(R(h,this.beta2),R(Vt(c),1-this.beta2)),f=ut(d,s),m=ut(p,o);u.assign(d),h.assign(p);const g=Y(R(ut(f,Y(Ie(m),this.epsilon)),-this.learningRate),a);a.assign(g)}),this.accBeta1.assign(R(this.accBeta1,this.beta1)),this.accBeta2.assign(R(this.accBeta2,this.beta2))}),this.incrementIterations()}dispose(){this.accBeta1.dispose(),this.accBeta2.dispose(),this.accumulatedFirstMoment!=null&&yt(this.accumulatedFirstMoment.map(t=>t.variable)),this.accumulatedSecondMoment!=null&&yt(this.accumulatedSecondMoment.map(t=>t.variable))}async getWeights(){const t=[...this.accumulatedFirstMoment,...this.accumulatedSecondMoment];return[await this.saveIterations()].concat(t.map(e=>({name:e.originalName,tensor:e.variable})))}async setWeights(t){t=await this.extractIterations(t),_(()=>{this.accBeta1.assign(Ys(this.beta1,this.iterations_+1)),this.accBeta2.assign(Ys(this.beta2,this.iterations_+1))});const e=t.length/2,s=!1;this.accumulatedFirstMoment=t.slice(0,e).map(o=>({originalName:o.name,variable:o.tensor.variable(s)})),this.accumulatedSecondMoment=t.slice(e,e*2).map(o=>({originalName:o.name,variable:o.tensor.variable(s)}))}getConfig(){return{learningRate:this.learningRate,beta1:this.beta1,beta2:this.beta2,epsilon:this.epsilon}}static fromConfig(t,e){return new t(e.learningRate,e.beta1,e.beta2,e.epsilon)}}class ug extends Ss{static get className(){return"Adamax"}constructor(t,e,s,o=null,r=0){super(),this.learningRate=t,this.beta1=e,this.beta2=s,this.epsilon=o,this.decay=r,this.accumulatedFirstMoment=[],this.accumulatedWeightedInfNorm=[],_(()=>{this.iteration=Tt(0).variable(),this.accBeta1=Tt(e).variable()}),o==null&&(this.epsilon=D.backend.epsilon())}applyGradients(t){const e=Array.isArray(t)?t.map(s=>s.name):Object.keys(t);_(()=>{const s=pt(1,this.accBeta1),o=ut(-this.learningRate,Y(R(this.iteration,this.decay),1));e.forEach((r,i)=>{const a=D.registeredVariables[r],l=!1;this.accumulatedFirstMoment[i]==null&&(this.accumulatedFirstMoment[i]={originalName:`${r}/m`,variable:kt(a).variable(l)}),this.accumulatedWeightedInfNorm[i]==null&&(this.accumulatedWeightedInfNorm[i]={originalName:`${r}/v`,variable:kt(a).variable(l)});const c=Array.isArray(t)?t[i].tensor:t[r];if(c==null)return;const u=this.accumulatedFirstMoment[i].variable,h=this.accumulatedWeightedInfNorm[i].variable,d=Y(R(u,this.beta1),R(c,1-this.beta1)),p=R(h,this.beta2),f=Ne(c),m=ks(p,f);u.assign(d),h.assign(m);const g=Y(R(ut(o,s),ut(d,Y(m,this.epsilon))),a);a.assign(g)}),this.iteration.assign(Y(this.iteration,1)),this.accBeta1.assign(R(this.accBeta1,this.beta1))}),this.incrementIterations()}dispose(){this.accBeta1.dispose(),this.iteration.dispose(),this.accumulatedFirstMoment!=null&&yt(this.accumulatedFirstMoment.map(t=>t.variable)),this.accumulatedWeightedInfNorm!=null&&yt(this.accumulatedWeightedInfNorm.map(t=>t.variable))}async getWeights(){throw new Error("getWeights() is not implemented for Adamax yet.")}async setWeights(t){throw new Error("setWeights() is not implemented for Adamax yet.")}getConfig(){return{learningRate:this.learningRate,beta1:this.beta1,beta2:this.beta2,epsilon:this.epsilon,decay:this.decay}}static fromConfig(t,e){return new t(e.learningRate,e.beta1,e.beta2,e.epsilon,e.decay)}}class zh extends Ss{static get className(){return"SGD"}constructor(t){super(),this.learningRate=t,this.setLearningRate(t)}applyGradients(t){(Array.isArray(t)?t.map(s=>s.name):Object.keys(t)).forEach((s,o)=>{const r=Array.isArray(t)?t[o].tensor:t[s];if(r==null)return;const i=D.registeredVariables[s];_(()=>{const a=Y(R(this.c,r),i);i.assign(a)})}),this.incrementIterations()}setLearningRate(t){this.learningRate=t,this.c!=null&&this.c.dispose(),this.c=Dn(Tt(-t))}dispose(){this.c.dispose()}async getWeights(){return[await this.saveIterations()]}async setWeights(t){if(t=await this.extractIterations(t),t.length!==0)throw new Error("SGD optimizer does not have settable weights.")}getConfig(){return{learningRate:this.learningRate}}static fromConfig(t,e){return new t(e.learningRate)}}class hg extends zh{static get className(){return"Momentum"}constructor(t,e,s=!1){super(t),this.learningRate=t,this.momentum=e,this.useNesterov=s,this.accumulations=[],this.m=Tt(this.momentum)}applyGradients(t){(Array.isArray(t)?t.map(s=>s.name):Object.keys(t)).forEach((s,o)=>{const r=D.registeredVariables[s];this.accumulations[o]==null&&(this.accumulations[o]={originalName:`${s}/momentum`,variable:_(()=>kt(r).variable(!1))});const i=this.accumulations[o].variable,a=Array.isArray(t)?t[o].tensor:t[s];a!=null&&_(()=>{let l;const c=Y(R(this.m,i),a);this.useNesterov?l=Y(R(this.c,Y(a,R(c,this.m))),r):l=Y(R(this.c,c),r),i.assign(c),r.assign(l)})}),this.incrementIterations()}dispose(){this.m.dispose(),this.accumulations!=null&&yt(this.accumulations.map(t=>t.variable))}setMomentum(t){this.momentum=t}async getWeights(){return[await this.saveIterations()].concat(this.accumulations.map(t=>({name:t.originalName,tensor:t.variable})))}async setWeights(t){t=await this.extractIterations(t);const e=!1;this.accumulations=t.map(s=>({originalName:s.name,variable:s.tensor.variable(e)}))}getConfig(){return{learningRate:this.learningRate,momentum:this.momentum,useNesterov:this.useNesterov}}static fromConfig(t,e){return new t(e.learningRate,e.momentum,e.useNesterov)}}class dg extends Ss{static get className(){return"RMSProp"}constructor(t,e=.9,s=0,o=null,r=!1){if(super(),this.learningRate=t,this.decay=e,this.momentum=s,this.epsilon=o,this.accumulatedMeanSquares=[],this.accumulatedMoments=[],this.accumulatedMeanGrads=[],this.centered=r,o==null&&(this.epsilon=D.backend.epsilon()),t==null)throw new Error("learningRate for RMSPropOptimizer must be defined.")}applyGradients(t){(Array.isArray(t)?t.map(s=>s.name):Object.keys(t)).forEach((s,o)=>{const r=D.registeredVariables[s],i=!1;this.accumulatedMeanSquares[o]==null&&(this.accumulatedMeanSquares[o]={originalName:`${s}/rms`,variable:_(()=>kt(r).variable(i))}),this.accumulatedMoments[o]==null&&(this.accumulatedMoments[o]={originalName:`${s}/momentum`,variable:_(()=>kt(r).variable(i))}),this.accumulatedMeanGrads[o]==null&&this.centered&&(this.accumulatedMeanGrads[o]={originalName:`${s}/mg`,variable:_(()=>kt(r).variable(i))});const a=Array.isArray(t)?t[o].tensor:t[s];if(a==null)return;const l=this.accumulatedMeanSquares[o].variable,c=this.accumulatedMoments[o].variable;_(()=>{const u=Y(R(l,this.decay),R(Vt(a),1-this.decay));if(this.centered){const h=this.accumulatedMeanGrads[o].variable,d=Y(R(h,this.decay),R(a,1-this.decay)),p=ut(R(a,this.learningRate),Ie(pt(u,Y(Vt(d),this.epsilon)))),f=Y(R(c,this.momentum),p);l.assign(u),h.assign(d),c.assign(f);const m=pt(r,f);r.assign(m)}else{const h=Y(R(l,this.decay),R(Vt(a),1-this.decay)),d=Y(R(c,this.momentum),ut(R(a,this.learningRate),Ie(Y(h,this.epsilon))));l.assign(h),c.assign(d);const p=pt(r,d);r.assign(p)}})}),this.incrementIterations()}dispose(){this.accumulatedMeanSquares!=null&&yt(this.accumulatedMeanSquares.map(t=>t.variable)),this.accumulatedMeanGrads!=null&&this.centered&&yt(this.accumulatedMeanGrads.map(t=>t.variable)),this.accumulatedMoments!=null&&yt(this.accumulatedMoments.map(t=>t.variable))}async getWeights(){const t=[...this.accumulatedMeanSquares,...this.accumulatedMoments];return this.centered&&t.push(...this.accumulatedMeanGrads),[await this.saveIterations()].concat(t.map(e=>({name:e.originalName,tensor:e.variable})))}async setWeights(t){t=await this.extractIterations(t);const e=this.centered?t.length/3:t.length/2,s=!1;this.accumulatedMeanSquares=t.slice(0,e).map(o=>({originalName:o.name,variable:o.tensor.variable(s)})),this.accumulatedMoments=t.slice(e,e*2).map(o=>({originalName:o.name,variable:o.tensor.variable(s)})),this.centered&&(this.accumulatedMeanGrads=t.slice(e*2,e*3).map(o=>({originalName:o.name,variable:o.tensor.variable(s)})))}getConfig(){return{learningRate:this.learningRate,decay:this.decay,momentum:this.momentum,epsilon:this.epsilon,centered:this.centered}}static fromConfig(t,e){return new t(e.learningRate,e.decay,e.momentum,e.epsilon,e.centered)}}const Ov=[ag,lg,cg,ug,hg,dg,zh];function _v(){for(const n of Ov)j(n)}function xp(n,t,e,s){i(n),e=e??0,s=s??1,a(e,s);let o=0;const r=l=>(l.then(c=>{const u=e+ ++o/n.length*(s-e);return t(u),c}),l);function i(l){$(l!=null&&Array.isArray(l)&&l.length>0,()=>"promises must be a none empty array")}function a(l,c){$(l>=0&&l<=1,()=>`Progress fraction must be in range [0, 1], but got startFraction ${l}`),$(c>=0&&c<=1,()=>`Progress fraction must be in range [0, 1], but got endFraction ${c}`),$(c>=l,()=>`startFraction must be no more than endFraction, but got startFraction ${l} and endFraction ${c}`)}return Promise.all(n.map(r))}async function Lv(n,t){t==null&&(t={});const e=t.fetchFunc==null?L().platform.fetch:t.fetchFunc,s=n.map(h=>e(h,t.requestInit,{isBinary:!0})),a=(t.onProgress==null?await Promise.all(s):await xp(s,t.onProgress,0,.5)).map(h=>h.arrayBuffer());return t.onProgress==null?await Promise.all(a):await xp(a,t.onProgress,.5,1)}function Mv(n,t){var e;const s=t.fetchFunc==null?L().platform.fetch:t.fetchFunc;let o=0,r;return(e=t.onProgress)===null||e===void 0||e.call(t,0),new ReadableStream({pull:async i=>{for(var a;o<n.length;){r||(r=(await s(n[o],t.requestInit,{isBinary:!0})).body.getReader());const{done:l,value:c}=await r.read();if(l){o++,r=void 0,(a=t.onProgress)===null||a===void 0||a.call(t,o/n.length);continue}i.enqueue(c);return}i.close()}})}const Pv="application/octet-stream",zv="application/json";class Bh{constructor(t,e){if(this.DEFAULT_METHOD="POST",e==null&&(e={}),this.weightPathPrefix=e.weightPathPrefix,this.weightUrlConverter=e.weightUrlConverter,e.fetchFunc!=null?($(typeof e.fetchFunc=="function",()=>"Must pass a function that matches the signature of `fetch` (see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)"),this.fetch=e.fetchFunc):this.fetch=L().platform.fetch,$(t!=null&&t.length>0,()=>"URL path for http must not be null, undefined or empty."),Array.isArray(t)&&$(t.length===2,()=>`URL paths for http must have a length of 2, (actual length is ${t.length}).`),this.path=t,e.requestInit!=null&&e.requestInit.body!=null)throw new Error("requestInit is expected to have no pre-existing body, but has one.");this.requestInit=e.requestInit||{},this.loadOptions=e}async save(t){if(t.modelTopology instanceof ArrayBuffer)throw new Error("BrowserHTTPRequest.save() does not support saving model topology in binary formats yet.");const e=Object.assign({method:this.DEFAULT_METHOD},this.requestInit);e.body=new FormData;const s=[{paths:["./model.weights.bin"],weights:t.weightSpecs}],o=mw(t,s);if(e.body.append("model.json",new Blob([JSON.stringify(o)],{type:zv}),"model.json"),t.weightData!=null){const i=Cs.join(t.weightData);e.body.append("model.weights.bin",new Blob([i],{type:Pv}),"model.weights.bin")}const r=await this.fetch(this.path,e);if(r.ok)return{modelArtifactsInfo:uh(t),responses:[r]};throw new Error(`BrowserHTTPRequest.save() failed due to HTTP response status ${r.status}.`)}async loadModelJSON(){const t=await this.fetch(this.path,this.requestInit);if(!t.ok)throw new Error(`Request to ${this.path} failed with status code ${t.status}. Please verify this URL points to the model JSON of the model to load.`);let e;try{e=await t.json()}catch{let i=`Failed to parse model JSON of response from ${this.path}.`;throw this.path.endsWith(".pb")?i+=" Your path contains a .pb file extension. Support for .pb models have been removed in TensorFlow.js 1.0 in favor of .json models. You can re-convert your Python TensorFlow model using the TensorFlow.js 1.0 conversion scripts or you can convert your.pb models with the 'pb2json'NPM script in the tensorflow/tfjs-converter repository.":i+=" Please make sure the server is serving valid JSON for this request.",new Error(i)}const s=e.modelTopology,o=e.weightsManifest;if(s==null&&o==null)throw new Error(`The JSON from HTTP path ${this.path} contains neither model topology or manifest for weights.`);return e}async load(){if(this.loadOptions.streamWeights)return this.loadStream();const t=await this.loadModelJSON();return xw(t,e=>this.loadWeights(e))}async loadStream(){const t=await this.loadModelJSON(),e=await this.getWeightUrls(t.weightsManifest),s=hp(t.weightsManifest),o=()=>Mv(e,this.loadOptions);return Object.assign(Object.assign({},t),{weightSpecs:s,getWeightStream:o})}async getWeightUrls(t){const e=Array.isArray(this.path)?this.path[1]:this.path,[s,o]=Bv(e),r=this.weightPathPrefix||s,i=[],a=[];for(const l of t)for(const c of l.paths)this.weightUrlConverter!=null?a.push(this.weightUrlConverter(c)):i.push(r+c+o);return this.weightUrlConverter&&i.push(...await Promise.all(a)),i}async loadWeights(t){const e=await this.getWeightUrls(t),s=hp(t),o=await Lv(e,this.loadOptions);return[s,o]}}Bh.URL_SCHEME_REGEX=/^https?:\/\//;function Bv(n){const t=n.lastIndexOf("/"),e=n.lastIndexOf("?"),s=n.substring(0,t),o=e>t?n.substring(e):"";return[s+"/",o]}function bp(n){return n.match(Bh.URL_SCHEME_REGEX)!=null}const pg=(n,t)=>{if(typeof fetch>"u"&&(t==null||t.fetchFunc==null))return null;{let e=!0;if(Array.isArray(n)?e=n.every(s=>bp(s)):e=bp(n),e)return fg(n,t)}return null};ue.registerSaveRouter(pg);ue.registerLoadRouter(pg);function fg(n,t){return new Bh(n,t)}function Vv(n,t){return fg(n,t)}function Vh(n,t){const e=n.shape.length,s=t.shape.length;if(e<1)throw new Error(`tf.gatherND() expects the input to be rank 1 or higher, but the rank was ${e}.`);if(s<1)throw new Error(`tf.gatherND() expects the indices to be rank 1 or higher, but the rank was ${s}.`);if(t.dtype!=="int32")throw new Error(`tf.gatherND() expects the indices to be int32 type, but the dtype was ${t.dtype}.`);if(t.shape[s-1]>e)throw new Error(`index innermost dimension length must be <= tensor rank; saw: ${t.shape[s-1]} vs. ${e}`);if(W(n.shape)===0)throw new Error(`Requested more than 0 entries, but input is empty. Input shape: ${n.shape}.`);const o=t.shape,r=o[o.length-1];let i=1;for(let h=0;h<o.length-1;++h)i*=o[h];const a=n.shape,l=o.slice();l.pop();let c=1;for(let h=r;h<e;++h)c*=a[h],l.push(a[h]);const u=[...lt(n.shape).map(h=>h/c),1].slice(0,r);return[l,i,c,u]}const Yc=-2,Wv=-1;function Wh(n,t,e){const s=n.shape.length;$(s===t.length,()=>`Error in slice${s}D: Length of begin ${t} must match the rank of the array (${s}).`),$(s===e.length,()=>`Error in slice${s}D: Length of size ${e} must match the rank of the array (${s}).`);for(let o=0;o<s;++o)$(t[o]+e[o]<=n.shape[o],()=>`Error in slice${s}D: begin[${o}] + size[${o}] (${t[o]+e[o]}) would overflow input.shape[${o}] (${n.shape[o]})`)}function Uv(n){const t=[];let e=0;for(;n>0;)n&1&&t.push(e),n/=2,e++;return t}function Uh(n,t,e){const s=[];for(let o=0;o<n.length;o++)s[o]=Math.ceil((t[o]-n[o])/e[o]);return s}function mg(n,t,e,s){const o=[...n];for(let r=o.length;r<s.length;r++)o.push(1);for(let r=0;r<e;r++)r===0?o[t]=1:(o.splice(t,0,1),o.pop());return o}function gg(n,t,e){return e<=n?e:e-(t-1)}function xg(n,t){const e=[];for(let s=0;s<n;s++)e.push(t+s);return e}function Gv(n,t,e,s,o,r,i,a,l){const c=n.length;let u=new Array(c),h=new Array(c),d=new Array(c);if(t.length&&e>0){const p=t[0],f=e+1;u=bg(i,p,f,s,n),h=yg(a,p,f,o,n),d=mg(r,p,f,n)}else for(let p=0;p<c;p++)u[p]=Cg(i,s,r,n,p,l),h[p]=$g(a,o,r,n,p,l),d[p]=wg(r,p,l);return{begin:u,end:h,strides:d}}function bg(n,t,e,s,o){const r=[...o],i=xg(e,t);for(let a=0;a<r.length;a++)if(i.indexOf(a)>-1)r[a]=0;else{const l=gg(t,e,a);let c=s[l];n&1<<l&&(c=0),r[a]=c}return r}function yg(n,t,e,s,o){const r=[...o],i=xg(e,t);for(let a=0;a<r.length;a++)if(i.indexOf(a)>-1)r[a]=Number.MAX_SAFE_INTEGER;else{const l=gg(t,e,a);let c=s[l];n&1<<l&&(c=Number.MAX_SAFE_INTEGER),r[a]=c}for(let a=0;a<r.length;a++){const l=o[a];r[a]<0&&(r[a]+=l),r[a]=Ws(0,r[a],o[a])}return r}function wg(n,t,e){let s=n[t];return(e&1<<t||s==null)&&(s=1),s}function Cg(n,t,e,s,o,r){let i=t[o];const a=e[o]||1;(n&1<<o||r&1<<o||i==null)&&(a>0?i=Number.MIN_SAFE_INTEGER:i=Number.MAX_SAFE_INTEGER);const l=s[o];return i<0&&(i+=l),i=Ws(0,i,l-1),i}function $g(n,t,e,s,o,r){let i=t[o];const a=e[o]||1;(n&1<<o||r&1<<o||i==null)&&(a>0?i=Number.MAX_SAFE_INTEGER:i=Number.MIN_SAFE_INTEGER);const l=s[o];return i<0&&(i+=l),a>0?i=Ws(0,i,l):i=Ws(-1,i,l-1),i}function Gh(n,t,e){let s=e.length;for(let o=0;o<e.length;o++)if(e[o]>1){s=o;break}for(let o=s+1;o<e.length;o++)if(t[o]>0||e[o]!==n[o])return!1;return!0}function Hh(n,t){let e=n.length>0?n[n.length-1]:1;for(let s=0;s<n.length-1;s++)e+=n[s]*t[s];return e}function Gl(n,t,e){let s;const o=n.shape.length;typeof t=="number"?s=[t,...new Array(o-1).fill(0)]:t.length<o?s=t.concat(new Array(o-t.length).fill(0)):s=t.slice(),s.forEach(i=>{$(i!==-1,()=>"slice() does not support negative begin indexing.")});let r;return e==null?r=new Array(o).fill(-1):typeof e=="number"?r=[e,...new Array(o-1).fill(-1)]:e.length<o?r=e.concat(new Array(o-e.length).fill(-1)):r=e,r=r.map((i,a)=>i>=0?i:($(i===-1,()=>`Negative size values should be exactly -1 but got ${i} for the slice() size at index ${a}.`),n.shape[a]-s[a])),[s,r]}function Kh(n,t,e,s,o,r,i,a,l){let c;if(s==null?(c=new Array(t.length),c.fill(1)):c=s,i!=null&&(i&i-1)!==0)throw new Error("Multiple ellipses in slice is not allowed.");let u=!1;const h={dims:c.length,numAddAxisAfterEllipsis:0,begin:t.slice(),end:e.slice(),strides:c.slice(),beginMask:o,endMask:r,ellipsisMask:i,newAxisMask:a,shrinkAxisMask:l};for(let w=0;w<h.dims;w++)u&&(1<<w&a)!==0&&h.numAddAxisAfterEllipsis++,1<<w&i&&(u=!0);u||(h.ellipsisMask|=1<<h.dims,h.dims++);const d={dims:n.length,beginMask:0,endMask:0,beginValid:!1,endValid:!1};Hv(h,d);let p=!0,f=!0,m=!0;const g=[],x=[];for(let w=0;w<n.length;++w){if(d.strides[w]===0)throw Error(`strides[${w}] must be non-zero`);const y=!!(d.shrinkAxisMask&1<<w),C=n[w];if(C===-1){g.push(y?1:-1);continue}const I=[d.beginMask&1<<w,d.endMask&1<<w],k=[d.strides[w]>0?0:-1,d.strides[w]>0?C:C-1];if(y&&d.strides[w]<=0)throw Error("only stride 1 allowed on non-range indexing.");m=m&&d.strides[w]===1;const v=!!(d.beginMask&1<<w&&d.endMask&1<<w);if(d.beginValid&&d.endValid){if(y){const P=d.begin[w]<0?C+d.begin[w]:d.begin[w];if(d.begin[w]=P,d.end[w]=d.begin[w]+1,P<0||P>=C)throw Error(`slice index ${d.begin[w]} of dimension ${w} out of bounds.`)}else d.begin[w]=yp(d.begin[w],0,d.strides[w],C,I,k),d.end[w]=yp(d.end[w],1,d.strides[w],C,I,k);const O=d.strides[w]===1&&d.begin[w]===0&&d.end[w]===C;p=p&&O,f=f&&(w===0&&d.strides[w]===1||O)}else p=p&&d.strides[w]===1&&v,f=f&&(w===0&&d.strides[w]===1||v);let N,T=!1;if(d.beginValid&&d.endValid?(N=d.end[w]-d.begin[w],T=!0):y?(N=1,T=!0):v&&C>=0&&(d.strides[w]<0?N=-C:N=C,T=!0),T){let O;N===0||N<0!=d.strides[w]<0?O=0:O=Math.trunc(N/d.strides[w])+(N%d.strides[w]!==0?1:0),g.push(O)}else g.push(-1)}for(let w=0;w<d.finalShapeGatherIndices.length;++w){const y=d.finalShapeGatherIndices[w];y>=0?x.push(g[y]):y===Yc&&x.push(1)}return{finalShapeSparse:x.filter((w,y)=>d.finalShapeGatherIndices[y]!==Yc),finalShape:x,isIdentity:p,sliceDim0:f,isSimpleSlice:m,begin:d.begin,end:d.end,strides:d.strides}}function Hv(n,t){t.beginMask=0,t.endMask=0,t.shrinkAxisMask=0;let e=0;t.beginValid=n.begin!=null,t.endValid=n.end!=null,t.begin=new Array(t.dims),t.end=new Array(t.dims),t.strides=new Array(t.dims),t.finalShapeGatherIndices=[],t.finalShapeGatherIndicesSparse=[],t.inputShapeGatherIndicesSparse=new Array(t.dims);for(let s=0;s<n.dims;s++)if(1<<s&n.ellipsisMask){const o=Math.min(t.dims-(n.dims-s)+1+n.numAddAxisAfterEllipsis,t.dims);for(;e<o;e++)t.begin[e]=0,t.end[e]=0,t.strides[e]=1,t.beginMask|=1<<e,t.endMask|=1<<e,t.finalShapeGatherIndices.push(e),t.finalShapeGatherIndicesSparse.push(-1),t.inputShapeGatherIndicesSparse[e]=s}else if(1<<s&n.newAxisMask)t.finalShapeGatherIndices.push(Yc),t.finalShapeGatherIndicesSparse.push(-1);else{if(e===t.begin.length)throw Error(`Index out of range using input dim ${e}; input has only ${t.dims} dims, ${t.begin.length}.`);n.begin!=null&&(t.begin[e]=n.begin[s]),n.end!=null&&(t.end[e]=n.end[s]),t.strides[e]=n.strides[s],n.beginMask&1<<s&&(t.beginMask|=1<<e),n.endMask&1<<s&&(t.endMask|=1<<e),n.shrinkAxisMask&1<<s?(t.finalShapeGatherIndices.push(Wv),t.finalShapeGatherIndicesSparse.push(-1),t.shrinkAxisMask|=1<<e):(t.finalShapeGatherIndices.push(e),t.finalShapeGatherIndicesSparse.push(s)),t.inputShapeGatherIndicesSparse[e]=s,e++}}function yp(n,t,e,s,o,r){if(o[t])return e>0?r[t]:r[t+1&1];{const i=n<0?s+n:n;return i<r[0]?r[0]:i>r[1]?r[1]:i}}const Kv=Object.freeze(Object.defineProperty({__proto__:null,assertParamsValid:Wh,computeFlatOffset:Hh,computeOutShape:Uh,getNormalizedAxes:Gv,isSliceContinous:Gh,maskToAxes:Uv,parseSliceParams:Gl,sliceInfo:Kh,startForAxis:Cg,startIndicesWithElidedDims:bg,stopForAxis:$g,stopIndicesWithElidedDims:yg,stridesForAxis:wg,stridesWithElidedDims:mg},Symbol.toStringTag,{value:"Module"}));class jv{static sgd(t){return new zh(t)}static momentum(t,e,s=!1){return new hg(t,e,s)}static rmsprop(t,e=.9,s=0,o=null,r=!1){return new dg(t,e,s,o,r)}static adam(t=.001,e=.9,s=.999,o=null){return new cg(t,e,s,o)}static adadelta(t=.001,e=.95,s=null){return new ag(t,e,s)}static adamax(t=.002,e=.9,s=.999,o=null,r=0){return new ug(t,e,s,o,r)}static adagrad(t,e=.1){return new lg(t,e)}}const fo=jv;const qv=typeof requestAnimationFrame<"u"?requestAnimationFrame:typeof setImmediate<"u"?setImmediate:n=>n();function Ig(){return new Promise(n=>qv(()=>n()))}function jh(n,t){const e=n[0].length;n.forEach((o,r)=>{$(o.length===e,()=>`Error in concat${e}D: rank of tensors[${r}] must be the same as the rank of the rest (${e})`)}),$(t>=0&&t<e,()=>`Error in concat${e}D: axis must be between 0 and ${e-1}.`);const s=n[0];n.forEach((o,r)=>{for(let i=0;i<e;i++)$(i===t||o[i]===s[i],()=>`Error in concat${e}D: Shape of tensors[${r}] (${o}) does not match the shape of the rest (${s}) along the non-concatenated axis ${r}.`)})}function An(n,t){const e=n[0].slice();for(let s=1;s<n.length;s++)e[t]+=n[s][t];return e}var mn;(function(n){n[n.FIRST_DIM_SIZE=0]="FIRST_DIM_SIZE",n[n.VALUE_ROWIDS=1]="VALUE_ROWIDS",n[n.ROW_LENGTHS=2]="ROW_LENGTHS",n[n.ROW_SPLITS=3]="ROW_SPLITS",n[n.ROW_LIMITS=4]="ROW_LIMITS",n[n.ROW_STARTS=5]="ROW_STARTS"})(mn||(mn={}));function kg(n,t,e){let s=new Array;if(e==null&&t==null)return s;if(t==null)for(;s.length<n+e.length;)s.push(-1);else s=t.slice();if(e==null)return s;if(n+e.length!==s.length)throw new Error(`rt input.shape and shape=${t} are incompatible: rt input.rank = ${n+e.length}, but shape.rank = ${s.length}`);for(let o=1;o<e.length;++o){const r=e[o],i=s[s.length-e.length+o],a=s[i];if(r>=0)if(a>=0){if(a!==r)throw new Error(`rt input.shape and shape=${t} are incompatible: rt input.shape[${o+n}] = ${r} but shape[${o+n}] = ${a}`)}else s[i]=r}return s}function vg(n){const t={FIRST_DIM_SIZE:mn.FIRST_DIM_SIZE,VALUE_ROWIDS:mn.VALUE_ROWIDS,ROW_LENGTHS:mn.ROW_LENGTHS,ROW_SPLITS:mn.ROW_SPLITS,ROW_LIMITS:mn.ROW_LIMITS,ROW_STARTS:mn.ROW_STARTS},e=[];for(const s of n)if(s in t)e.push(t[s]);else break;return e}function Sg(n){return n.length===0?0:n[0]===mn.FIRST_DIM_SIZE?n.length-1:n.length}function Ng(n,t){if(n==null||t==null)return;const e=n.length,s=t.length;if(e>=s)throw new Error(`defaultValue.shape=${n} and ragged tensor flatValues.shape=${t}, are incompatible: defaultValue.rank = ${e} must be less than ragged tensor input flatValues.rank = ${s})`);for(let o=0;o<Math.min(e,s-1);++o){const r=n[o],i=t[o+1];if(r>=0&&i>=0&&r!==1&&r!==i)throw new Error(`defaultValue.shape=${n}, and ragged tensor input flatValues.shape=${t} are incompatible: defaultValue.shape[${o-n.length}] = ${r} but ragged tensor input.flatValues.shape[${o-n.length}] = ${i}`)}}const qh=30;function Hl(n){return n<=qh?n:Oc(n,Math.floor(Math.sqrt(n)))}function Xh(n,t,e){const s=e*(typeof n=="number"?n:n[0]),o=t*(typeof n=="number"?n:n[1]);return[s,o]}function Si(n,t,e,s=!0){let o=[];if(s)o=o.concat(t.slice(0)),o.push(n[0]/e),o=o.concat(n.slice(1));else{o=o.concat(n[0]);const r=t.length;for(let i=0;i<r;++i)o=o.concat([n[i+1]/t[i],t[i]]);o=o.concat(n.slice(r+1))}return o}function Ni(n,t,e=!0){const s=[];if(e){s.push(t);for(let o=t+1;o<n;++o)o<=2*t?(s.push(o),s.push(o-(t+1))):s.push(o)}else{const o=[],r=[];for(let i=1;i<n;++i)i>=t*2+1||i%2===1?r.push(i):o.push(i);s.push(...o),s.push(0),s.push(...r)}return s}function Ti(n,t,e,s=!0){const o=[];s?o.push(n[0]/e):o.push(n[0]*e);for(let r=1;r<n.length;++r)r<=t.length?s?o.push(t[r-1]*n[r]):o.push(n[r]/t[r-1]):o.push(n[r]);return o}function Yh(n,t){const e=[0];for(let s=0;s<t;++s)e.push(n[s][0]);return e}function Jh(n,t,e){const s=n.slice(0,1);for(let o=0;o<e;++o)s.push(n[o+1]-t[o][0]-t[o][1]);return s}const Kl=1.7580993408473768,jl=1.0507009873554805;const Zh=.3275911,Qh=.254829592,td=-.284496736,ed=1.421413741,nd=-1.453152027,sd=1.061405429;function Xn(n,t){if(n.length!==t.length)throw new Error(`Cannot merge real and imag arrays of different lengths. real:${n.length}, imag: ${t.length}.`);const e=new Float32Array(n.length*2);for(let s=0;s<e.length;s+=2)e[s]=n[s/2],e[s+1]=t[s/2];return e}function Tg(n){const t=new Float32Array(n.length/2),e=new Float32Array(n.length/2);for(let s=0;s<n.length;s+=2)t[s/2]=n[s],e[s/2]=n[s+1];return{real:t,imag:e}}function Eg(n){const t=Math.ceil(n.length/4),e=new Float32Array(t),s=new Float32Array(t);for(let o=0;o<n.length;o+=4)e[Math.floor(o/4)]=n[o],s[Math.floor(o/4)]=n[o+1];return{real:e,imag:s}}function Rg(n){const t=Math.floor(n.length/4),e=new Float32Array(t),s=new Float32Array(t);for(let o=2;o<n.length;o+=4)e[Math.floor(o/4)]=n[o],s[Math.floor(o/4)]=n[o+1];return{real:e,imag:s}}function od(n,t){const e=n[t*2],s=n[t*2+1];return{real:e,imag:s}}function Dg(n,t,e,s){n[s*2]=t,n[s*2+1]=e}function Ag(n,t){const e=new Float32Array(n/2),s=new Float32Array(n/2);for(let o=0;o<Math.ceil(n/2);o++){const r=(t?2:-2)*Math.PI*(o/n);e[o]=Math.cos(r),s[o]=Math.sin(r)}return{real:e,imag:s}}function Fg(n,t,e){const s=(e?2:-2)*Math.PI*(n/t),o=Math.cos(s),r=Math.sin(s);return{real:o,imag:r}}const bc="->",Xv=/->/g,wp=",",Cp="...";function rd(n,t){n=n.replace(/\s/g,"");const e=(n.length-n.replace(Xv,"").length)/bc.length;if(e<1)throw new Error("Equations without an arrow are not supported.");if(e>1)throw new Error(`Equation must contain exactly one arrow ("${bc}").`);const[s,o]=n.split(bc);$(s.indexOf(Cp)===-1,()=>`The ellipsis notation ("${Cp}") is not supported yet.`);const r=s.split(wp),i=r.length;if(t!==i)throw new Error(`Expected ${i} input tensors, received ${t}`);if(i>2)throw new Error("Support for more than 2 input tensors is not implemented yet.");const a=[];for(let d=0;d<o.length;++d){const p=o[d];if(!r.some(f=>f.indexOf(p)!==-1))throw new Error(`Output subscripts contain the label ${p} not present in the input subscripts.`);a.indexOf(p)===-1&&a.push(p)}for(let d=0;d<s.length;++d){const p=s[d];a.indexOf(p)===-1&&p!==wp&&a.push(p)}const l=new Array(r.length);for(let d=0;d<i;++d){if(new Set(r[d].split("")).size!==r[d].length)throw new Error(`Found duplicate axes in input component ${r[d]}. Support for duplicate axes in input is not implemented yet.`);l[d]=[];for(let p=0;p<r[d].length;++p)l[d].push(a.indexOf(r[d][p]))}const c=a.length,u=o.length,h=[];for(let d=u;d<c;++d)h.push(d);return{allDims:a,summedDims:h,idDims:l}}function id(n,t){let e=new Array(n);e.fill(-1);for(let o=0;o<t.length;++o)e[t[o]]=o;const s=[];for(let o=0;o<n;++o)e[o]===-1&&s.push(o);return e=e.filter(o=>o!==-1),{permutationIndices:e,expandDims:s}}function ad(n,t,e){const s=new Array(n);for(let o=0;o<e.length;++o){const r=e[o].shape;for(let i=0;i<t[o].length;++i)s[t[o][i]]===void 0?s[t[o][i]]=r[i]:$(s[t[o][i]]===r[i],()=>`Expected dimension ${s[t[o][i]]} at axis ${i} of input shaped ${JSON.stringify(r)}, but got dimension ${r[i]}`)}}function ld(n,t){const e=n,s=[];let o=0;n.length===0&&e.push(-1),o=n.length+1;for(let i=0;i<o;++i)s.push([]);const r=[];for(let i=0;i<e.length;++i){const a=e[i],l=Yv(t,a);for(const c of l)r.indexOf(c)===-1&&(s[i].push(c),r.push(c))}return{path:e,steps:s}}function cd(n){return n.every((t,e)=>t===e)}function Yv(n,t){const e=[];for(let s=0;s<n.length;++s)(n[s].length===0||n[s].indexOf(t)!==-1||t===-1)&&e.push(s);return e}function ud(n,t,e=0){let s=[];if(typeof t=="number")$(n.shape[e]%t===0,()=>"Number of splits must evenly divide the axis."),s=new Array(t).fill(n.shape[e]/t);else{const o=t.reduce((i,a)=>(a===-1&&(i+=1),i),0);$(o<=1,()=>"There should be only one negative value in split array.");const r=t.indexOf(-1);if(r!==-1){const i=t.reduce((a,l)=>l>0?a+l:a);t[r]=n.shape[e]-i}$(n.shape[e]===t.reduce((i,a)=>i+a),()=>"The sum of sizes must match the size of the axis dimension."),s=t}return s}function Og(n){return`Received SparseTensor with denseShape[0] = 0 but
  indices.shape[0] = ${n}`}function _g(n,t){return`indices(${n}, 0) is invalid: ${t} < 0`}function Lg(n,t,e){return`indices(${n}, 0) is invalid: ${t} >= ${e}`}function Mg(n,t){return`only one output dimension may be -1, not both ${n} and ${t}`}function Pg(n,t){return`size ${n} must be non-negative, not ${t}`}function zg(){return"reshape cannot infer the missing input size for an empty tensor unless all specified input sizes are non-zero"}function Bg(n,t){const e=W(n),s=W(t);return`Input to reshape is a SparseTensor with ${e}
  dense values, but the requested shape requires a multiple of ${s}. inputShape=${n} outputShape= ${t}`}function Vg(n,t){const e=W(n),s=W(t);return`Input to reshape is a tensor with ${e} dense values, but the requested shape has ${s}. inputShape=${n} outputShape=${t}`}function Jc(){return"segment ids must be >= 0"}function Wg(){return"segment ids are not increasing"}function Ug(n,t){return`Segment id ${n} out of range [0, ${t}), possibly because segmentIds input is not sorted.`}function Gg(n,t,e){return`Bad: indices[${n}] == ${t} out of range [0, ${e})`}function Hg(n,t){let e=!1,s;for(n<=qh?(s=n,e=!0):s=Oc(n,Math.floor(Math.sqrt(n)));!e;)s>t||s===n?e=!0:s=Oc(n,s+1);return s}function Kg(n,t,e){const s=[],o=n.length;for(let r=0;r<o;r++)r!==t?s.push(n[r]):s.push(e);return s}function hd(n,t,e,s){const o=t.shape.length,r=n.shape.length;if(s!==0&&(s<-o||s>o))throw new Error(`Expect batchDims in the range of [-${o}, ${o}], but got ${s}`);if(s<0&&(s+=o),s>r)throw new Error(`batchDims (${s}) must be less than rank(x) (
    ${r}).`);if(e<s)throw new Error(`batchDims (${s}) must be less than or equal to axis (${e}).`);for(let h=0;h<s;++h)if(n.shape[h]!==t.shape[h])throw new Error(`x.shape[${h}]: ${n.shape[h]} should be equal to indices.shape[${h}]: ${t.shape[h]}.`);const i=n.shape[e],a=[];let l=1,c=1,u=1;for(let h=0;h<s;++h)a.push(n.shape[h]),l*=n.shape[h];for(let h=s;h<e;h++)a.push(n.shape[h]),c*=n.shape[h];for(let h=s;h<o;h++)a.push(t.shape[h]);for(let h=e+1;h<r;h++)a.push(n.shape[h]),u*=n.shape[h];return{batchSize:l,sliceSize:u,outerSize:c,dimSize:i,outputShape:a}}const Jv=Object.freeze(Object.defineProperty({__proto__:null,collectGatherOpShapeInfo:hd,computeOutShape:Kg,segOpComputeOptimalWindowSize:Hg},Symbol.toStringTag,{value:"Module"}));function Yn(n){try{return n.map(t=>ps(t))}catch(t){throw new Error(`Failed to decode encoded string bytes into utf-8, error: ${t}`)}}function jg(n){return n.map(t=>us(t))}const Zv=Object.freeze(Object.defineProperty({__proto__:null,ERF_A1:Qh,ERF_A2:td,ERF_A3:ed,ERF_A4:nd,ERF_A5:sd,ERF_P:Zh,PARALLELIZE_THRESHOLD:qh,get RowPartitionType(){return mn},SELU_SCALE:jl,SELU_SCALEALPHA:Kl,applyActivation:Fh,assertAndGetBroadcastShape:mt,assertAxesAreInnerMostDims:ye,assertParamsConsistent:jh,assignToTypedArray:Dg,axesAreInnerMostDims:xh,calculateShapes:io,checkEinsumDimSizes:ad,checkPadOnDimRoundingMode:ze,combineLocations:Mm,combineRaggedTensorToTensorShapes:kg,complexWithEvenIndex:Eg,complexWithOddIndex:Rg,computeConv2DInfo:be,computeConv3DInfo:$s,computeDefaultPad:hh,computeDilation2DInfo:Ci,computeOptimalWindowSize:Hl,computeOutAndReduceShapes:fe,computeOutShape:An,computePool2DInfo:ln,computePool3DInfo:Zn,convertConv2DDataFormat:Qn,decodeEinsumEquation:rd,eitherStridesOrDilationsAreOne:ke,expandShapeToKeepDim:ne,exponent:Fg,exponents:Ag,fromStringArrayToUint8:jg,fromUint8ToStringArray:Yn,getAxesPermutation:jt,getBroadcastDims:To,getComplexWithIndex:od,getEinsumComputePath:ld,getEinsumPermutation:id,getFusedBiasGradient:Ah,getFusedDyActivation:Dh,getImageCenter:Xh,getInnerMostAxes:Zt,getPermuted:Ni,getRaggedRank:Sg,getReductionAxes:le,getReshaped:Si,getReshapedPermuted:Ti,getRowPartitionTypesHelper:vg,getSliceBeginCoords:Yh,getSliceSize:Jh,getSparseFillEmptyRowsIndicesDenseShapeMismatch:Og,getSparseFillEmptyRowsNegativeIndexErrorMessage:_g,getSparseFillEmptyRowsOutOfRangeIndexErrorMessage:Lg,getSparseReshapeEmptyTensorZeroOutputDimErrorMessage:zg,getSparseReshapeInputOutputMismatchErrorMessage:Vg,getSparseReshapeInputOutputMultipleErrorMessage:Bg,getSparseReshapeMultipleNegativeOneOutputDimErrorMessage:Mg,getSparseReshapeNegativeOutputDimErrorMessage:Pg,getSparseSegmentReductionIndicesOutOfRangeErrorMessage:Gg,getSparseSegmentReductionNegativeSegmentIdsErrorMessage:Jc,getSparseSegmentReductionNonIncreasingSegmentIdsErrorMessage:Wg,getSparseSegmentReductionSegmentIdOutOfRangeErrorMessage:Ug,getUndoAxesPermutation:Is,isIdentityPermutation:cd,log:L1,mergeRealAndImagArrays:Xn,prepareAndValidate:Vh,prepareSplitSize:ud,segment_util:Jv,shouldFuse:Oh,slice_util:Kv,splitRealAndImagArrays:Tg,stridesOrDilationsArePositive:qs,tupleValuesAreOne:js,upcastType:Ue,validateDefaultValueShape:Ng,validateInput:Ik,validateUpdateShape:eg,warn:je},Symbol.toStringTag,{value:"Module"}));_v();const qg={kernelName:_a,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,vi(st(e,"float32"),-1))}}};const Qv={kernelName:Sr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>{const s=Vt(st(e,"float32")),o=Ie(pt(Tt(1),s));return Yt(ut(n,o))}}}};const tS={kernelName:Nr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>{const s=Ie(pt(Vt(st(e,"float32")),1));return ut(n,s)}}}};const eS={kernelName:Po,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{let a=n;const l=le(e.shape,o);return l.length>0&&(a=ct(a,l)),A(a,e.shape)},b:()=>{let a=n;const l=le(s.shape,o);return l.length>0&&(a=ct(a,l)),A(a,s.shape)}}}};const nS={kernelName:wu,saveAllInputs:!0,gradFunc:(n,t)=>{const e={};return t.forEach((s,o)=>{e[o]=()=>n.clone()}),e}};const sS={kernelName:La,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>kt(e)}}};const oS={kernelName:Ma,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>kt(e)}}};const rS={kernelName:Tr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,Ie(pt(Tt(1),Vt(st(e,"float32")))))}}};const iS={kernelName:Er,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>{const s=Ie(Y(Tt(1),Vt(st(e,"float32"))));return ut(n,s)}}}};const aS={kernelName:Ar,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{const a=Y(Vt(e),Vt(s));let l=R(n,ut(s,a));const c=le(e.shape,o);return c.length>0&&(l=ct(l,c)),A(l,e.shape)},b:()=>{const a=Y(Vt(e),Vt(s));let l=Yt(R(n,ut(e,a)));const c=le(s.shape,o);return c.length>0&&(l=ct(l,c)),A(l,s.shape)}}}};const lS={kernelName:Rr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,Y(Vt(st(e,"float32")),1))}}};const cS={kernelName:Dr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,pt(Tt(1),Vt(st(e,"float32"))))}}};function uS(n,t,e,s,o,r){const i=S(n,"dy","avgPool3dGrad"),a=S(t,"input","avgPool3dGrad");let l=i,c=a,u=!1;a.rank===4&&(u=!0,l=A(i,[1,i.shape[0],i.shape[1],i.shape[2],i.shape[3]]),c=A(a,[1,a.shape[0],a.shape[1],a.shape[2],a.shape[3]])),$(l.rank===5,()=>`Error in avgPool3dGrad: dy must be rank 5 but got rank ${l.rank}.`),$(c.rank===5,()=>`Error in avgPool3dGrad: input must be rank 5 but got rank ${c.rank}.`),ze("avgPool3dGrad",o,r);const h={dy:l,input:c},d={filterSize:e,strides:s,pad:o,dimRoundingMode:r},p=D.runKernel(ku,h,d);return u?A(p,[p.shape[1],p.shape[2],p.shape[3],p.shape[4]]):p}const hS=F({avgPool3dGrad_:uS});const dS={kernelName:za,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{filterSize:o,strides:r,pad:i,dimRoundingMode:a}=e;return{x:()=>hS(n,s,o,r,i,a)}}};function pS(n,t,e,s,o){const r=S(n,"dy","avgPoolGrad"),i=S(t,"input","avgPoolGrad");$(i.rank===r.rank,()=>`Rank of input (${i.rank}) does not match rank of dy (${r.rank})`);let a=i,l=r,c=!1;i.rank===3&&(c=!0,a=A(i,[1,i.shape[0],i.shape[1],i.shape[2]]),l=A(r,[1,r.shape[0],r.shape[1],r.shape[2]])),$(l.rank===4,()=>`Error in avgPoolGrad: dy must be rank 4 but got rank ${l.rank}.`),$(a.rank===4,()=>`Error in avgPoolGrad: input must be rank 4 but got rank ${a.rank}.`);const u={dy:l,input:a},h={filterSize:e,strides:s,pad:o},d=D.runKernel(Iu,u,h);return c?A(d,[d.shape[1],d.shape[2],d.shape[3]]):d}const fS=F({avgPoolGrad_:pS});const mS={kernelName:Pa,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{filterSize:o,strides:r,pad:i}=e;return{x:()=>fS(n,s,o,r,i)}}};const gS={kernelName:Ba,inputsToSave:["a","b"],gradFunc:(n,t,e)=>{const[s,o]=t,{transposeA:r,transposeB:i}=e;return!r&&!i?{a:()=>Nt(n,o,!1,!0),b:()=>Nt(s,n,!0,!1)}:!r&&i?{a:()=>Nt(n,o,!1,!1),b:()=>Nt(n,s,!0,!1)}:r&&!i?{a:()=>Nt(o,n,!1,!0),b:()=>Nt(s,n,!1,!1)}:{a:()=>Nt(o,n,!0,!0),b:()=>Nt(n,s,!0,!0)}}};const xS={kernelName:Va,gradFunc:(n,t,e)=>{const{blockShape:s,crops:o}=e;return{x:()=>vh(n,s,o)}}};const bS={kernelName:A1,gradFunc:(n,t,e)=>{const s=e,o=s.inputShape,r=s.shape,i=Array.from(r);for(let l=o.length-1;l>=0;l--)if(o[l]===r[l])i[l]=1;else if(o[l]!==1)throw new Error(`broadcastTo(): [${o}] cannot be broadcast to [${r}].`);const a=[];for(let l=0;l<i.length;l++)i[l]>1&&a.push(l);return{x:()=>ct(n,a,!0)}}};const yS={kernelName:Fr,gradFunc:n=>({x:()=>n.clone()})};const wS={kernelName:Or,gradFunc:n=>({x:()=>kt(n)})};const CS={kernelName:_r,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{clipValueMin:o,clipValueMax:r}=e;return{x:()=>Re(jn(oo(s,o),Bo(s,r)),n,kt(n))}}};const $S={kernelName:Wa,inputsToSave:["x"],gradFunc:qg.gradFunc};const IS={kernelName:Ua,saveAllInputs:!0,gradFunc:(n,t,e)=>{const s=t.map(l=>l.shape),{axis:o}=e,r=Ct(o,t[0].shape)[0],i=s.map(l=>l[r]);return Xe(n,i,r).map(l=>()=>l)}};const kS={kernelName:Ga,inputsToSave:["x","filter"],gradFunc:(n,t,e)=>{const[s,o]=t,{dilations:r,strides:i,pad:a,dataFormat:l}=e;return $(js(r),()=>`Error in gradient of conv2D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${r}'`),{x:()=>fh(s.shape,n,o,i,a,l),filter:()=>Rh(s,n,o.shape,i,a,l)}}};const vS={kernelName:Ha,inputsToSave:["dy","filter"],gradFunc:(n,t,e)=>{const[s,o]=t,{strides:r,pad:i,dataFormat:a,dimRoundingMode:l}=e;return{dy:()=>Xs(n,o,r,i,a,1,l),filter:()=>Rh(n,s,o.shape,r,i,a,l)}}};function SS(n,t,e,s,o){let r=n;n.rank===4&&(r=A(n,[1,n.shape[0],n.shape[1],n.shape[2],n.shape[3]]));let i=t;i.rank===4&&(i=A(t,[1,t.shape[0],t.shape[1],t.shape[2],t.shape[3]])),$(r.rank===5,()=>`Error in conv3dDerFilter: input must be rank 5, but got shape ${r.shape}.`),$(i.rank===5,()=>`Error in conv3dDerFilter: dy must be rank 5, but got shape ${i.shape}.`),$(e.length===5,()=>`Error in conv3dDerFilter: filterShape must be length 5, but got ${e}.`),$(r.shape[4]===e[3],()=>`Error in conv3dDerFilter: depth of input ${r.shape[4]}) must match input depth in filter (${e[3]}.`),$(i.shape[4]===e[4],()=>`Error in conv3dDerFilter: depth of dy (${i.shape[4]}) must match output depth for filter (${e[4]}).`);const a={x:r,dy:i},l={strides:s,pad:o,filterShape:e};return D.runKernel(Eu,a,l)}const NS=F({conv3DBackpropFilter_:SS});const TS={kernelName:Ka,inputsToSave:["x","filter"],gradFunc:(n,t,e)=>{const{dilations:s,strides:o,pad:r}=e;$(js(s),()=>`Error in gradient of conv3D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${s}'`);const[i,a]=t;return{x:()=>Fm(i.shape,n,a,o,r),filter:()=>NS(i,n,a.shape,o,r)}}};const ES={kernelName:Lr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(Yt(Jm(st(e,"float32"))),n)}}};const RS={kernelName:Mr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(Zm(st(e,"float32")),n)}}};const DS={kernelName:ja,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{axis:o,exclusive:r,reverse:i}=e;return{x:()=>{const a=jt([o],s.rank);let l=_m(n,o,r,!i);return a!=null&&(l=It(l,a)),l}}}};const AS={kernelName:qa,inputsToSave:["x","filter"],gradFunc:(n,t,e)=>{const{dilations:s,strides:o,pad:r,dimRoundingMode:i}=e,a=s??[1,1];$(js(a),()=>`Error in gradient of depthwiseConv2dNative: dilation rates greater than 1 are not yet supported. Got dilations '${a}'`);const[l,c]=t;return $(l.rank===4,()=>`Error in gradient of depthwiseConv2dNative: input must be rank 4, but got rank ${l.rank}.`),$(c.rank===4,()=>`Error in gradient of depthwiseConv2dNative: filter must be rank 4, but got rank ${c.rank}.`),$(l.shape[3]===c.shape[2],()=>`Error in gradient of depthwiseConv2d: number of input channels (${l.shape[3]}) must match the inChannels dimension in filter ${c.shape[2]}.`),$(ke(o,a),()=>`Error in gradient of depthwiseConv2d: Either strides or dilations must be  1. Got strides ${o} and dilations '${a}'.`),ze("depthwiseConv2d",r,i),{x:()=>Wk(l.shape,n,c,o,r,a,i),filter:()=>Bk(l,n,c.shape,o,r,a,i)}}};const FS={kernelName:Xa,inputsToSave:["x","filter"],gradFunc:(n,t,e)=>{const[s,o]=t,r={x:s,filter:o,dy:n},i={x:s,filter:o,dy:n};return{x:()=>D.runKernel(_c,r,e),filter:()=>D.runKernel(Lc,i,e)}}};const OS={kernelName:zr,outputsToSave:[!0],gradFunc:(n,t)=>{const[e]=t,s={dy:n,y:e};return{x:()=>D.runKernel(Pu,s)}}};const _S={kernelName:Br,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t,s=R(Mn(Yt(Vt(e))),2/Math.sqrt(Math.PI));return{x:()=>R(n,s)}}};const LS={kernelName:Vr,outputsToSave:[!0],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,e)}}};const MS={kernelName:Ja,inputsToSave:["input"],gradFunc:(n,t)=>{const[e]=t;return{input:()=>A(n,e.shape)}}};const PS={kernelName:Wr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,Mn(e))}}};const zS={kernelName:Ur,gradFunc:n=>({x:()=>kt(n)})};const BS={kernelName:Gr,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{const a=ut(n,st(s,"float32")),l=le(e.shape,o);return l.length>0?A(ct(a,l),e.shape):a},b:()=>{let a=R(n,st(e,"float32"));const l=le(s.shape,o);l.length>0&&(a=A(ct(a,l),s.shape));const c=Vt(s);return Yt(ut(a,st(c,"float32")))}}}};const VS={kernelName:Za,inputsToSave:["x","mean","variance","scale"],gradFunc:(n,t,e)=>{const{varianceEpsilon:s}=e,[o,r,i,a]=t,l=a??Tt(1),c=le(r.shape,o.shape),u=[];if(r.rank===1){for(let y=0;y<o.shape.length-1;++y)u.push(o.shape[y]);u.push(1)}const h=pt(o,r),d=R(n,l),p=qm(Y(i,Tt(s))),f=R(R(R(p,p),p),Tt(-.5));return{x:()=>r.rank===1?A(R(R(n,gn(A(p,[1,1,1,r.shape[0]]),u)),l),o.shape):A(R(R(n,p),l),o.shape),mean:()=>{let y=R(R(p,Tt(-1)),d);return r.rank===1&&(y=ct(y,c)),A(y,r.shape)},variance:()=>{let y=R(R(f,h),d);return r.rank===1&&(y=ct(y,c)),A(y,r.shape)},scale:()=>{const y=R(h,p);let C=R(n,y);return r.rank===1&&(C=ct(C,c)),A(C,r.shape)},offset:()=>{let y=n;return r.rank===1&&(y=ct(y,c)),A(y,r.shape)}}}};const WS={kernelName:Qa,inputsToSave:["x","indices"],gradFunc:(n,t,e)=>{const[s,o]=t,{axis:r,batchDims:i}=e,a=Ct(r,s.shape)[0],l=(c,u,h)=>()=>{const d=c.shape,p=u.size,f=d.slice(0,a),m=f.length,g=d.slice(r,d.length).slice(1),x=g.length,b=$p(0,m),w=$p(m+1,m+1+x),y=Ip([f,[p],g]),C=A(h,y),I=A(u,[p]),k=Ip([[m],b,w]),v=It(C,k);let N=sg(v,I,c.shape[a]);const T=Is(k);return N=It(N,T),N};if(i===1){const c=s.shape[0],u=s.split(c,0);return{x:()=>qn(u.map((p,f)=>l(p,o.slice(f,1),n.slice(f,1))())).reshape(s.shape),indices:()=>o}}else return{x:l(s,o,n),indices:()=>o}}};function $p(n,t){const e=[];for(let s=n;s<t;++s)e.push(s);return e}function Ip(n){const t=[];for(let e=0;e<n.length;++e)for(let s=0;s<n[e].length;++s)t.push(n[e][s]);return t}const US={kernelName:Hr,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t;return{a:()=>kt(e),b:()=>kt(s)}}};const GS={kernelName:Kr,gradFunc:n=>({x:()=>st(n,"float32")})};const HS={kernelName:jr,gradFunc:n=>({x:()=>kt(n)})};const KS={kernelName:qr,gradFunc:n=>({x:()=>kt(n)})};const jS={kernelName:Xr,gradFunc:n=>({x:()=>kt(n)})};const qS={kernelName:el,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{alpha:o}=e,r=Je(s,0);return{x:()=>Re(r,n,R(n,o))}}};const XS={kernelName:Jr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,Y(e,1))}}};const YS={kernelName:Yr,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,st(e,"float32"))}}};const JS={kernelName:O1,inputsToSave:[],outputsToSave:[!0],gradFunc:(n,t,e)=>{const[s]=t,{axis:o}=e;return{logits:()=>{const i=Mn(s);return pt(n,R(ct(n,o,!0),i))}}}};function ZS(n,t,e,s=5,o=1,r=1,i=.5){const a={x:n,y:t,dy:e},l={depthRadius:s,bias:o,alpha:r,beta:i};return D.runKernel(Hu,a,l)}const QS=F({localResponseNormalizationBackprop_:ZS});const tN={kernelName:al,inputsToSave:["x"],outputsToSave:[!0],gradFunc:(n,t,e)=>{const[s,o]=t,{depthRadius:r,bias:i,alpha:a,beta:l}=e;return{x:()=>QS(s,o,n,r,i,a,l)}}};function Xg(n,t,e,s){return t.rank<e.rank&&(t=A(t,ne(t.shape,s))),n.rank<e.rank&&(n=A(n,ne(n.shape,s))),{x:()=>R(n,st(Ln(e,t),n.dtype))}}const kp={kernelName:ll,inputsToSave:["x"],outputsToSave:[!0],gradFunc:(n,t,e)=>{const s=e,{reductionIndices:o}=s,r=t[0],i=t[1],a=Ct(o,r.shape),l=Xg(n,i,r,a);return{x:()=>l.x()}}};const eN={kernelName:Zr,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t;return{a:()=>R(n,st(oo(e,s),"float32")),b:()=>R(n,st(da(e,s),"float32"))}}};function nN(n,t,e,s,o,r,i){const a=S(n,"dy","maxPool3dGrad"),l=S(t,"input","maxPool3dGrad"),c=S(e,"output","maxPool3dGrad");let u=a,h=l,d=c,p=!1;l.rank===4&&(p=!0,u=A(a,[1,a.shape[0],a.shape[1],a.shape[2],a.shape[3]]),h=A(l,[1,l.shape[0],l.shape[1],l.shape[2],l.shape[3]]),d=A(c,[1,c.shape[0],c.shape[1],c.shape[2],c.shape[3]])),$(u.rank===5,()=>`Error in maxPool3dGrad: dy must be rank 5 but got rank ${u.rank}.`),$(h.rank===5,()=>`Error in maxPool3dGrad: input must be rank 5 but got rank ${h.rank}.`),$(d.rank===5,()=>`Error in maxPool3dGrad: output must be rank 5 but got rank ${d.rank}.`),ze("maxPool3dGrad",r,i);const f={dy:u,input:h,output:d},m={filterSize:s,strides:o,pad:r,dimRoundingMode:i},g=D.runKernel(ju,f,m);return p?A(g,[g.shape[1],g.shape[2],g.shape[3],g.shape[4]]):g}const sN=F({maxPool3dGrad_:nN});const oN={kernelName:ul,inputsToSave:["x"],outputsToSave:[!0],gradFunc:(n,t,e)=>{const[s,o]=t,{filterSize:r,strides:i,pad:a,dimRoundingMode:l}=e;return{x:()=>sN(n,s,o,r,i,a,l)}}};function rN(n,t,e,s,o,r,i){const a=S(n,"dy","maxPoolGrad"),l=S(t,"input","maxPoolGrad"),c=S(e,"output","maxPoolGrad");$(l.rank===a.rank,()=>`Rank of input (${l.rank}) does not match rank of dy (${a.rank})`),$(a.rank===4,()=>`Error in maxPoolGrad: dy must be rank 4 but got rank ${a.rank}.`),$(l.rank===4,()=>`Error in maxPoolGrad: input must be rank 4 but got rank ${l.rank}.`),ze("maxPoolGrad",r,i);const u={dy:a,input:l,output:c},h={filterSize:s,strides:o,pad:r,dimRoundingMode:i};return D.runKernel(Ku,u,h)}const iN=F({maxPoolGrad_:rN});const aN={kernelName:cl,inputsToSave:["x"],outputsToSave:[!0],gradFunc:(n,t,e)=>{const[s,o]=t,{filterSize:r,strides:i,pad:a}=e;return{x:()=>iN(n,s,o,r,i,a)}}};const lN={kernelName:hl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{axis:o}=e,r=Ct(o,s.shape),a=fe(s.shape,r)[1],l=W(a);return{x:()=>{const u=s.shape.slice();r.forEach(p=>{u[p]=1});const h=A(n,u);return ut(R(h,vs(s.shape,"float32")),l)}}}};const cN={kernelName:dl,inputsToSave:["x"],outputsToSave:[!0],gradFunc:(n,t,e)=>{const s=e,{axis:o}=s,[r,i]=t,a=Ct(o,r.shape),l=Xg(n,i,r,a);return{x:()=>l.x()}}};const uN={kernelName:Qr,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t;return{a:()=>R(n,st(Bo(e,s),"float32")),b:()=>R(n,st(Je(e,s),"float32"))}}};const hN={kernelName:pl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const s=t[0],{paddings:o}=e,r=o.map(i=>i[0]);return{x:()=>zt(n,r,s.shape)}}};const dN={kernelName:ti,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{const a=le(e.shape,o);return a.length>0?A(ct(n,a),e.shape):n},b:()=>{const a=R(n,Yt(Ul(ut(e,s)))),l=le(s.shape,o);return l.length>0?A(ct(a,l),s.shape):a}}}};const pN={kernelName:ei,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{const a=R(n,st(s,"float32")),l=le(e.shape,o);return l.length>0?A(ct(a,l),e.shape):a},b:()=>{const a=R(n,st(e,"float32")),l=le(s.shape,o);return l.length>0?A(ct(a,l),s.shape):a}}}};const fN={kernelName:fl,gradFunc:n=>({x:()=>Yt(n)})};const mN={kernelName:xl,inputsToSave:["indices"],gradFunc:(n,t)=>{const e=t[0];return{indices:()=>de(e.shape,"float32")}}};const gN={kernelName:gl,gradFunc:n=>({x:()=>kt(n)})};const xN={kernelName:bl,saveAllInputs:!0,gradFunc:(n,t,e)=>{const{axis:s}=e;return Zs(n,s).map(r=>()=>r)}};const vp={kernelName:yl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const s=t[0],{paddings:o}=e,r=o.map(i=>i[0]);return{x:()=>zt(n,r,s.shape)}}};const bN={kernelName:ni,inputsToSave:["a","b"],outputsToSave:[!0],gradFunc:(n,t)=>{const[e,s,o]=t,r=e,i=s,a=mt(r.shape,i.shape);return{a:()=>{const u=st(i,"float32");let h=R(n,R(u,Ys(r,pt(u,Tt(1)))));const d=le(r.shape,a);return d.length>0&&(h=ct(h,d)),A(h,r.shape)},b:()=>{const u=Je(r,0),h=Re(u,Pn(r),kt(r));let d=R(n,R(o,h));const p=le(i.shape,a);return p.length>0&&(d=ct(d,p)),A(d,i.shape)}}}};const yN={kernelName:wl,inputsToSave:["x","alpha"],gradFunc:(n,t)=>{const[e,s]=t,o=Je(e,0);return{x:()=>Re(o,n,R(n,s)),alpha:()=>{let r=Re(o,kt(n),R(n,e));const i=le(s.shape,n.shape);return i.length>0&&(r=ct(r,i)),A(r,s.shape)}}}};function wN(n,t,e){const s=n.shape.slice();s[e]=1;const o=A(t,s),r=qc(n,e,!0,!1),i=qc(n,e,!0,!0),a=R(r,i);return R(o,a)}function CN(n,t,e){const s=n.shape.length,o=s-e.length,r=jt(e,s);let i=n;r!=null&&(i=It(n,r));const a=i.shape.slice(),c=a.splice(s-e.length,e.length).reduce((d,p)=>d*p,1);a.push(c);const u=i.reshape(a);let h=wN(u,t,o);if(h=h.reshape(i.shape),r!=null){const d=Is(r);h=It(h,d)}return h}const $N={kernelName:Cl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{axis:o}=e;let r=[];return o==null?r=s.shape.map((i,a)=>a):typeof o=="number"?r=[o]:r=o,{x:()=>CN(s,n,r)}}};const IN={kernelName:Pr,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{const a=ut(n,st(s,"float32")),l=le(e.shape,o);return l.length>0?A(ct(a,l),e.shape):a},b:()=>{let a=R(n,st(e,"float32"));const l=le(s.shape,o);l.length>0&&(a=A(ct(a,l),s.shape));const c=Vt(s);return Yt(ut(a,st(c,"float32")))}}}};const kN={kernelName:si,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,Yt(Vt(e)))}}};const vN={kernelName:ri,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t,s=R(Bo(e,6),vi(e));return{x:()=>R(n,st(s,"float32"))}}};const SN={kernelName:oi,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,st(vi(e),"float32"))}}};const NN={kernelName:$l,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>A(n,e.shape)}}};const TN={kernelName:kl,inputsToSave:["images"],gradFunc:(n,t,e)=>{const[s]=t,o={dy:n,images:s};return{images:()=>D.runKernel(th,o,e)}}};const EN={kernelName:Il,inputsToSave:["images"],gradFunc:(n,t,e)=>{const[s]=t,o={dy:n,images:s};return{images:()=>D.runKernel(Qu,o,e)}}};const RN={kernelName:vl,gradFunc:(n,t,e)=>{const{dims:s}=e,o=Ct(s,n.shape);return{x:()=>Js(n,o)}}};const DN={kernelName:ii,gradFunc:n=>({x:()=>kt(n)})};const AN={kernelName:ai,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>Yt(ut(n,R(Ys(e,1.5),2)))}}};const FN={kernelName:Sl,inputsToSave:["condition"],gradFunc:(n,t)=>{const[e]=t;return{condition:()=>st(kt(e),"float32"),t:()=>R(n,st(e,n.dtype)),e:()=>R(n,st(Ch(e),n.dtype))}}};const ON={kernelName:li,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>{const s=Je(e,Tt(0)),o=Tt(Kl),r=Tt(jl),i=R(n,r),a=R(R(n,o),Mn(st(e,"float32")));return Re(s,i,a)}}}};const _N={kernelName:di,outputsToSave:[!0],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,R(e,pt(Tt(1),e)))}}};const LN={kernelName:hi,gradFunc:n=>({x:()=>kt(n)})};const MN={kernelName:ci,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(mh(st(e,"float32")),n)}}};const PN={kernelName:ui,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(Om(st(e,"float32")),n)}}};const zN={kernelName:Nl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{begin:o,size:r}=e,i=s.shape,[a,l]=Gl(s,o,r),c=[];for(let u=0;u<n.rank;u++)c.push([a[u],i[u]-a[u]-l[u]]);return{x:()=>kh(n,c)}}};const BN={kernelName:Dl,outputsToSave:[!0],gradFunc:(n,t,e)=>{const[s]=t,{dim:o}=e,r=!0,i=R(n,s);return{logits:()=>pt(i,R(ct(i,[o],r),s))}}};const VN={kernelName:pi,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,zo(e))}}};const Sp={kernelName:El,gradFunc:(n,t,e)=>{const{blockShape:s,paddings:o}=e;return{x:()=>ph(n,s,o)}}};const Np={kernelName:Rl,gradFunc:(n,t,e)=>{const{axis:s}=e;return{x:()=>Le(n,s)}}};const WN={kernelName:fi,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,R(Ie(st(e,"float32")),2))}}};const UN={kernelName:eh,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(n,R(st(e,"float32"),2))}}};const GN={kernelName:mi,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=Tt(2);return{a:()=>R(n,R(o,pt(e,s))),b:()=>R(n,R(o,pt(s,e)))}}};const HN={kernelName:wi,gradFunc:n=>({x:()=>kt(n)})};const KN={kernelName:gi,inputsToSave:["a","b"],gradFunc:(n,t)=>{const[e,s]=t,o=mt(e.shape,s.shape);return{a:()=>{let a=n;const l=le(e.shape,o);return l.length>0&&(a=ct(a,l)),A(a,e.shape)},b:()=>{let a=n;const l=le(s.shape,o);return l.length>0&&(a=ct(a,l)),A(Yt(a),s.shape)}}}};const jN={kernelName:Tl,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,o=s.shape.slice(),{axis:r}=e;Ct(r,s.shape).forEach(c=>{o[c]=1});const a=A(n,o),l=R(a,vs(s.shape,"float32"));return{x:()=>l}}};const qN={kernelName:xi,inputsToSave:["x"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>ut(n,Vt(mh(e)))}}};const XN={kernelName:bi,outputsToSave:[!0],gradFunc:(n,t)=>{const[e]=t;return{x:()=>R(pt(Tt(1),Vt(e)),n)}}};const YN={kernelName:yi,inputsToSave:["x"],gradFunc:(n,t,e)=>{const[s]=t,{reps:o}=e;return{x:()=>{let i=kt(s);if(s.rank===1)for(let a=0;a<o[0];++a)i=Y(i,zt(n,[a*s.shape[0]],[s.shape[0]]));else if(s.rank===2)for(let a=0;a<o[0];++a)for(let l=0;l<o[1];++l)i=Y(i,zt(n,[a*s.shape[0],l*s.shape[1]],[s.shape[0],s.shape[1]]));else if(s.rank===3)for(let a=0;a<o[0];++a)for(let l=0;l<o[1];++l)for(let c=0;c<o[2];++c)i=Y(i,zt(n,[a*s.shape[0],l*s.shape[1],c*s.shape[2]],[s.shape[0],s.shape[1],s.shape[2]]));else if(s.rank===4)for(let a=0;a<o[0];++a)for(let l=0;l<o[1];++l)for(let c=0;c<o[2];++c)for(let u=0;u<o[3];++u)i=Y(i,zt(n,[a*s.shape[0],l*s.shape[1],c*s.shape[2],u*s.shape[3]],[s.shape[0],s.shape[1],s.shape[2],s.shape[3]]));else throw new Error(`Gradient for tile operation is not implemented for rank-${s.rank} tensors yet.`);return i}}}};const JN={kernelName:Co,gradFunc:(n,t,e)=>{const s=e,{perm:o}=s,r=Is(o);return{x:()=>It(n,r)}}};const ZN={kernelName:Al,gradFunc:(n,t,e)=>{const s=e,{axis:o}=s;return{value:()=>qn(n,o)}}};const QN={kernelName:Fl,inputsToSave:["segmentIds"],gradFunc:(n,t)=>{const[e]=t;return{x:()=>t2(n,e)}}};function t2(n,t){const e=ks(t,kt(t)),s=bh(n,e);let o=oo(t,Tt(0,"int32"));const r=s.rank-o.rank;for(let a=0;a<r;++a)o=Oe(o,a+1);o=jn(o,vs(s.shape,"bool"));const i=kt(s);return Re(o,s,i)}const e2={kernelName:Ol,gradFunc:n=>({x:()=>kt(n)})};const n2=[qg,Qv,tS,eS,nS,sS,oS,rS,iS,aS,lS,cS,dS,mS,gS,xS,bS,yS,wS,CS,$S,IS,vS,kS,TS,ES,RS,DS,AS,FS,IN,OS,_S,LS,MS,PS,BS,zS,VS,WS,US,GS,HS,KS,jS,qS,XS,YS,JS,tN,kp,kp,eN,oN,aN,lN,cN,uN,hN,dN,pN,fN,mN,gN,xN,vp,vp,bN,yN,$N,kN,vN,SN,NN,TN,EN,RN,DN,AN,FN,ON,_N,LN,MN,PN,zN,BN,VN,Sp,Sp,Np,Np,WN,GN,UN,HN,KN,jN,qN,XN,YN,JN,ZN,QN,e2];for(const n of n2)M1(n);V().prototype.abs=function(){return this.throwIfDisposed(),Ne(this)};V().prototype.acos=function(){return this.throwIfDisposed(),qw(this)};V().prototype.acosh=function(){return this.throwIfDisposed(),Yw(this)};V().prototype.add=function(n){return this.throwIfDisposed(),Y(this,n)};V().prototype.all=function(n,t){return this.throwIfDisposed(),Rm(this,n,t)};V().prototype.any=function(n,t){return this.throwIfDisposed(),Kc(this,n,t)};V().prototype.argMax=function(n){return this.throwIfDisposed(),dr(this,n)};V().prototype.argMin=function(n){return this.throwIfDisposed(),eC(this,n)};V().prototype.asScalar=function(){return this.throwIfDisposed(),$(this.size===1,()=>"The array must have only 1 element."),A(this,[])};V().prototype.asType=function(n){return this.throwIfDisposed(),st(this,n)};V().prototype.as1D=function(){return this.throwIfDisposed(),A(this,[this.size])};V().prototype.as2D=function(n,t){return this.throwIfDisposed(),A(this,[n,t])};V().prototype.as3D=function(n,t,e){return this.throwIfDisposed(),A(this,[n,t,e])};V().prototype.as4D=function(n,t,e,s){return this.throwIfDisposed(),A(this,[n,t,e,s])};V().prototype.as5D=function(n,t,e,s,o){return this.throwIfDisposed(),A(this,[n,t,e,s,o])};V().prototype.asin=function(){return this.throwIfDisposed(),sC(this)};V().prototype.asinh=function(){return this.throwIfDisposed(),rC(this)};V().prototype.atan=function(){return this.throwIfDisposed(),aC(this)};V().prototype.atan2=function(n){return this.throwIfDisposed(),cC(this,n)};V().prototype.atanh=function(){return this.throwIfDisposed(),hC(this)};V().prototype.avgPool=function(n,t,e,s){return this.throwIfDisposed(),dh(this,n,t,e,s)};V().prototype.batchToSpaceND=function(n,t){return this.throwIfDisposed(),ph(this,n,t)};V().prototype.batchNorm=function(n,t,e,s,o){return this.throwIfDisposed(),zl(this,n,t,e,s,o)};V().prototype.broadcastTo=function(n){return this.throwIfDisposed(),ur(this,n)};V().prototype.cast=function(n){return this.throwIfDisposed(),st(this,n)};V().prototype.ceil=function(){return this.throwIfDisposed(),PC(this)};V().prototype.clipByValue=function(n,t){return this.throwIfDisposed(),Ye(this,n,t)};V().prototype.concat=function(n,t){return this.throwIfDisposed(),n instanceof se&&(n=[n]),Le([this,...n],t)};V().prototype.conv1d=function(n,t,e,s,o,r){return this.throwIfDisposed(),Dm(this,n,t,e,s,o,r)};V().prototype.conv2dTranspose=function(n,t,e,s,o){return this.throwIfDisposed(),Am(this,n,t,e,s,o)};V().prototype.conv2d=function(n,t,e,s,o,r){return this.throwIfDisposed(),Xs(this,n,t,e,s,o,r)};V().prototype.cos=function(){return this.throwIfDisposed(),mh(this)};V().prototype.cosh=function(){return this.throwIfDisposed(),Om(this)};V().prototype.cumprod=function(n,t,e){return this.throwIfDisposed(),qc(this,n,t,e)};V().prototype.cumsum=function(n,t,e){return this.throwIfDisposed(),_m(this,n,t,e)};V().prototype.depthToSpace=function(n,t){return this.throwIfDisposed(),c$(this,n,t)};V().prototype.depthwiseConv2d=function(n,t,e,s,o,r){return this.throwIfDisposed(),gh(this,n,t,e,s,o,r)};V().prototype.dilation2d=function(n,t,e,s,o){return this.throwIfDisposed(),d$(this,n,t,e,s,o)};V().prototype.divNoNan=function(n){return this.throwIfDisposed(),x$(this,n)};V().prototype.div=function(n){return this.throwIfDisposed(),ut(this,n)};V().prototype.dot=function(n){return this.throwIfDisposed(),y$(this,n)};V().prototype.elu=function(){return this.throwIfDisposed(),Vl(this)};V().prototype.equal=function(n){return this.throwIfDisposed(),Ln(this,n)};V().prototype.erf=function(){return this.throwIfDisposed(),Lm(this)};V().prototype.euclideanNorm=function(n,t){return this.throwIfDisposed(),D$(this,n,t)};V().prototype.exp=function(){return this.throwIfDisposed(),Mn(this)};V().prototype.expandDims=function(n){return this.throwIfDisposed(),Oe(this,n)};V().prototype.expm1=function(){return this.throwIfDisposed(),_$(this)};V().prototype.fft=function(){return this.throwIfDisposed(),tg(this)};V().prototype.flatten=function(){return this.throwIfDisposed(),A(this,[this.size])};V().prototype.floor=function(){return this.throwIfDisposed(),Ul(this)};V().prototype.floorDiv=function(n){return this.throwIfDisposed(),Em(this,n)};V().prototype.gather=function(n,t,e){return this.throwIfDisposed(),bh(this,n,t,e)};V().prototype.greaterEqual=function(n){return this.throwIfDisposed(),oo(this,n)};V().prototype.greater=function(n){return this.throwIfDisposed(),Je(this,n)};V().prototype.ifft=function(){return this.throwIfDisposed(),Xc(this)};V().prototype.irfft=function(){return this.throwIfDisposed(),uk(this)};V().prototype.isFinite=function(){return this.throwIfDisposed(),G$(this)};V().prototype.isInf=function(){return this.throwIfDisposed(),K$(this)};V().prototype.isNaN=function(){return this.throwIfDisposed(),q$(this)};V().prototype.leakyRelu=function(n){return this.throwIfDisposed(),wh(this,n)};V().prototype.lessEqual=function(n){return this.throwIfDisposed(),Bo(this,n)};V().prototype.less=function(n){return this.throwIfDisposed(),da(this,n)};V().prototype.localResponseNormalization=function(n,t,e,s){return this.throwIfDisposed(),Q$(this,n,t,e,s)};V().prototype.logSigmoid=function(){return this.throwIfDisposed(),iI(this)};V().prototype.logSoftmax=function(n){return this.throwIfDisposed(),Vm(this,n)};V().prototype.logSumExp=function(n,t){return this.throwIfDisposed(),Wm(this,n,t)};V().prototype.log=function(){return this.throwIfDisposed(),Pn(this)};V().prototype.log1p=function(){return this.throwIfDisposed(),Bm(this)};V().prototype.logicalAnd=function(n){return this.throwIfDisposed(),jn(this,n)};V().prototype.logicalNot=function(){return this.throwIfDisposed(),Ch(this)};V().prototype.logicalOr=function(n){return this.throwIfDisposed(),Um(this,n)};V().prototype.logicalXor=function(n){return this.throwIfDisposed(),fI(this,n)};V().prototype.matMul=function(n,t,e){return this.throwIfDisposed(),Nt(this,n,t,e)};V().prototype.maxPool=function(n,t,e,s){return this.throwIfDisposed(),$h(this,n,t,e,s)};V().prototype.max=function(n,t){return this.throwIfDisposed(),bn(this,n,t)};V().prototype.maximum=function(n){return this.throwIfDisposed(),ks(this,n)};V().prototype.mean=function(n,t){return this.throwIfDisposed(),ee(this,n,t)};V().prototype.min=function(n,t){return this.throwIfDisposed(),ha(this,n,t)};V().prototype.minimum=function(n){return this.throwIfDisposed(),mr(this,n)};V().prototype.mirrorPad=function(n,t){return this.throwIfDisposed(),$I(this,n,t)};V().prototype.mod=function(n){return this.throwIfDisposed(),kI(this,n)};V().prototype.mul=function(n){return this.throwIfDisposed(),R(this,n)};V().prototype.neg=function(){return this.throwIfDisposed(),Yt(this)};V().prototype.norm=function(n,t,e){return this.throwIfDisposed(),Wl(this,n,t,e)};V().prototype.notEqual=function(n){return this.throwIfDisposed(),pa(this,n)};V().prototype.oneHot=function(n,t=1,e=0){return this.throwIfDisposed(),Gm(this,n,t,e)};V().prototype.onesLike=function(){return this.throwIfDisposed(),an(this)};V().prototype.pad=function(n,t){return this.throwIfDisposed(),kh(this,n,t)};V().prototype.pool=function(n,t,e,s,o,r){return this.throwIfDisposed(),OI(this,n,t,e,s,o,r)};V().prototype.pow=function(n){return this.throwIfDisposed(),Ys(this,n)};V().prototype.prelu=function(n){return this.throwIfDisposed(),Sh(this,n)};V().prototype.prod=function(n,t){return this.throwIfDisposed(),MI(this,n,t)};V().prototype.reciprocal=function(){return this.throwIfDisposed(),GI(this)};V().prototype.relu=function(){return this.throwIfDisposed(),ro(this)};V().prototype.relu6=function(){return this.throwIfDisposed(),Km(this)};V().prototype.reshapeAs=function(n){return this.throwIfDisposed(),A(this,n.shape)};V().prototype.reshape=function(n){return this.throwIfDisposed(),A(this,n)};V().prototype.resizeBilinear=function(n,t,e){return this.throwIfDisposed(),rg(this,n,t,e)};V().prototype.resizeNearestNeighbor=function(n,t,e){return this.throwIfDisposed(),ig(this,n,t,e)};V().prototype.reverse=function(n){return this.throwIfDisposed(),Js(this,n)};V().prototype.rfft=function(){return this.throwIfDisposed(),pk(this)};V().prototype.round=function(){return this.throwIfDisposed(),jm(this)};V().prototype.rsqrt=function(){return this.throwIfDisposed(),qm(this)};V().prototype.selu=function(){return this.throwIfDisposed(),Xm(this)};V().prototype.separableConv2d=function(n,t,e,s,o,r){return this.throwIfDisposed(),Ym(this,n,t,e,s,o,r)};V().prototype.sigmoid=function(){return this.throwIfDisposed(),zo(this)};V().prototype.sign=function(){return this.throwIfDisposed(),QI(this)};V().prototype.sin=function(){return this.throwIfDisposed(),Jm(this)};V().prototype.sinh=function(){return this.throwIfDisposed(),Zm(this)};V().prototype.slice=function(n,t){return this.throwIfDisposed(),zt(this,n,t)};V().prototype.softmax=function(n){return this.throwIfDisposed(),Eh(this,n)};V().prototype.softplus=function(){return this.throwIfDisposed(),$i(this)};V().prototype.spaceToBatchND=function(n,t){return this.throwIfDisposed(),vh(this,n,t)};V().prototype.split=function(n,t){return this.throwIfDisposed(),Xe(this,n,t)};V().prototype.sqrt=function(){return this.throwIfDisposed(),Ie(this)};V().prototype.square=function(){return this.throwIfDisposed(),Vt(this)};V().prototype.squaredDifference=function(n){return this.throwIfDisposed(),mk(this,n)};V().prototype.squeeze=function(n){return this.throwIfDisposed(),ki(this,n)};V().prototype.stack=function(n,t){this.throwIfDisposed();const e=n instanceof se?[this,n]:[this,...n];return qn(e,t)};V().prototype.step=function(n){return this.throwIfDisposed(),vi(this,n)};V().prototype.stridedSlice=function(n,t,e,s,o,r,i,a){return this.throwIfDisposed(),wk(this,n,t,e,s,o,r,i,a)};V().prototype.sub=function(n){return this.throwIfDisposed(),pt(this,n)};V().prototype.sum=function(n,t){return this.throwIfDisposed(),ct(this,n,t)};V().prototype.tan=function(){return this.throwIfDisposed(),$k(this)};V().prototype.tanh=function(){return this.throwIfDisposed(),Pl(this)};V().prototype.tile=function(n){return this.throwIfDisposed(),gn(this,n)};V().prototype.toBool=function(){return this.throwIfDisposed(),st(this,"bool")};V().prototype.toFloat=function(){return this.throwIfDisposed(),st(this,"float32")};V().prototype.toInt=function(){return this.throwIfDisposed(),st(this,"int32")};V().prototype.topk=function(n,t){return this.throwIfDisposed(),vk(this,n,t)};V().prototype.transpose=function(n){return this.throwIfDisposed(),It(this,n)};V().prototype.unique=function(n){return this.throwIfDisposed(),Tk(this,n)};V().prototype.unsortedSegmentSum=function(n,t){return this.throwIfDisposed(),sg(this,n,t)};V().prototype.unstack=function(n){return this.throwIfDisposed(),Zs(this,n)};V().prototype.where=function(n,t){return this.throwIfDisposed(),Re(n,this,t)};V().prototype.zerosLike=function(){return this.throwIfDisposed(),kt(this)};class Sn extends Error{constructor(t){super(t),Object.setPrototypeOf(this,Sn.prototype)}}class sn extends Error{constructor(t){super(t),Object.setPrototypeOf(this,sn.prototype)}}class E extends Error{constructor(t){super(t),Object.setPrototypeOf(this,E.prototype)}}class xt extends Error{constructor(t){super(t),Object.setPrototypeOf(this,xt.prototype)}}class dd extends Error{constructor(t){super(t),Object.setPrototypeOf(this,dd.prototype)}}class Yg{constructor(t){this.maxEntries=t||100,this.cache=new Map}get(t){let e;return this.cache.has(t)&&(e=this.cache.get(t),this.cache.delete(t),this.cache.set(t,e)),e}put(t,e){if(this.cache.has(t))this.cache.delete(t);else if(this.cache.size>=this.maxEntries){const s=this.cache.keys().next().value;this.cache.delete(s)}this.cache.set(t,e)}getMaxEntries(){return this.maxEntries}setMaxEntries(t){if(t<0)throw new Error(`The maxEntries of LRU caches must be at least 0, but got ${t}.`);if(this.maxEntries>t)for(let e=0;e<this.maxEntries-t;e++){const s=this.cache.keys().next().value;this.cache.delete(s)}this.maxEntries=t}}function Qs(n,t){if(Array.isArray(n)){let e=[];for(let s=0;s<t;s++)e=e.concat(n);return e}else{const e=new Array(t);return e.fill(n),e}}function Nn(n,t){if(!n)throw new dd(t)}function Tp(n,t){let e=0;for(const s of n)s===t&&e++;return e}function _e(n){return n.length===1?n[0]:n}function Dt(n){return Array.isArray(n)?n:[n]}function Gn(n){const e=n.replace(/(.)([A-Z][a-z0-9]+)/g,"$1_$2").replace(/([a-z])([A-Z])/g,"$1_$2").toLowerCase();return e[0]!=="_"?e:"private"+e}function _s(n){return n.length<=1||n.indexOf("_")===-1?n:n.replace(/[_]+(\w|$)/g,(t,e)=>e.toUpperCase())}let Qe={};function pd(n){if(n==null)return null;const t={};return t.className=n.getClassName(),t.config=n.getConfig(),t}function Zc(n){if(!(n==null||typeof n!="object"))if(Array.isArray(n))n.forEach(t=>Zc(t));else{const t=Object.keys(n);for(const e of t){const s=n[e];s!=null&&typeof s=="object"&&(!Array.isArray(s)&&s.type==="ndarray"&&typeof s.value=="number"?n[e]=s.value:Zc(s))}}}function Ei(n,t={},e={},s="object",o=!1){if(typeof n=="string"){const r=n;let i;if(r in e)i=e[r];else if(r in Qe)i=Qe[r];else if(i=t[r],i==null)throw new E(`Unknown ${s}: ${n}. This may be due to one of the following reasons:
1. The ${s} is defined in Python, in which case it needs to be ported to TensorFlow.js or your JavaScript code.
2. The custom ${s} is defined in JavaScript, but is not registered properly with tf.serialization.registerClass().`);return i}else{const r=n;if(r.className==null||r.config==null)throw new E(`${s}: Improper config format: ${JSON.stringify(r)}.
'className' and 'config' must set.`);const i=r.className;let a,l;if(i in e?[a,l]=e[i]:i in Qe?[a,l]=Qe.className:i in t&&([a,l]=t[i]),a==null)throw new E(`Unknown ${s}: ${i}. This may be due to one of the following reasons:
1. The ${s} is defined in Python, in which case it needs to be ported to TensorFlow.js or your JavaScript code.
2. The custom ${s} is defined in JavaScript, but is not registered properly with tf.serialization.registerClass().`);if(l!=null){const c={};for(const p of Object.keys(Qe))c[p]=Qe[p];for(const p of Object.keys(e))c[p]=e[p];const u=r.config;u.customObjects=c;const h=Object.assign({},Qe);for(const p of Object.keys(e))Qe[p]=e[p];Zc(r.config);const d=l(a,r.config,e,o);return Qe=Object.assign({},h),d}else{const c=Object.assign({},Qe);for(const h of Object.keys(e))Qe[h]=e[h];const u=new a(r.config);return Qe=Object.assign({},c),u}}}function s2(n,t){return n<t?-1:n>t?1:0}function Hi(n,t){return-1*s2(n,t)}function hs(n){if(n==null)return n;const t=[];for(const e of n)t.indexOf(e)===-1&&t.push(e);return t}function o2(n){if(n==null)throw new E(`Invalid value in obj: ${JSON.stringify(n)}`);for(const t in n)if(n.hasOwnProperty(t))return!1;return!0}function ao(n,t,e){if(e!=null&&n.indexOf(e)<0)throw new E(`${e} is not a valid ${t}.  Valid values are ${n} or null/undefined.`)}function fd(n,t,e=0,s=1/0){return Nn(e>=0),Nn(s>=e),Array.isArray(n)&&n.length>=e&&n.length<=s&&n.every(o=>typeof o===t)}function pe(n,t){Array.isArray(n)?($(n.length>0,()=>`${t} is unexpectedly an empty array.`),n.forEach((e,s)=>pe(e,`element ${s+1} of ${t}`))):$(Number.isInteger(n)&&n>0,()=>`Expected ${t} to be a positive integer, but got ${Jg(n)}.`)}function Jg(n){return n===null?"null":Array.isArray(n)?"["+n.map(t=>Jg(t)).join(",")+"]":typeof n=="string"?`"${n}"`:`${n}`}function r2(n,t,e){let s=e!=null?e():Fe(),o;return(...i)=>{const a=e!=null?e():Fe();return a-s<t||(s=a,o=n(...i)),o}}function Zg(n){return n==="relu"?"relu":n==="linear"?"linear":n==="elu"?"elu":null}let i2=0;function Qg(){return i2++}const Ki={};function ql(n=""){return n in Ki||(Ki[n]=0),Ki[n]+=1,n+Ki[n].toString()}const a2=["channelsFirst","channelsLast"],l2=["nearest","bilinear"],c2=["valid","same","causal"],u2=["max","avg"],h2=["sum","mul","concat","ave"];const mo=new Map;function Qt(n){ao(a2,"DataFormat",n)}function d2(n){ao(l2,"InterpolationFormat",n)}function Ze(n){ao(c2,"PaddingMode",n)}function tx(n){ao(u2,"PoolMode",n)}const hr=[],Ep="/";function Bs(n,t){hr.push(n);try{const e=t();return hr.pop(),e}catch(e){throw hr.pop(),e}}function p2(){return hr.length===0?"":hr.join(Ep)+Ep}function ex(n){if(!sx(n))throw new Error("Not a valid tensor name: '"+n+"'");return p2()+n}function nx(n){if(!sx(n))throw new Error("Not a valid tensor name: '"+n+"'");mo.has(n)||mo.set(n,0);const t=mo.get(n);if(mo.set(n,mo.get(n)+1),t>0){const e=`${n}_${t}`;return mo.set(e,1),e}else return n}const f2=new RegExp(/^[A-Za-z0-9][-A-Za-z0-9\._\/]*$/);function sx(n){return!!n.match(f2)}function m2(n){return n===parseInt(n.toString(),10)}function ds(n,t,e){t==null&&(t=0),e==null&&(e=n.length);let s=1;for(let o=t;o<e;++o)s*=n[o];return s}function Ro(n){if(n.length===0)return Number.NaN;let t=Number.POSITIVE_INFINITY;for(let e=0;e<n.length;e++){const s=n[e];s<t&&(t=s)}return t}function fs(n){if(n.length===0)return Number.NaN;let t=Number.NEGATIVE_INFINITY;for(let e=0;e<n.length;e++){const s=n[e];s>t&&(t=s)}return t}function wn(n,t){if(t<n)throw new E(`end (${t}) < begin (${n}) is forbidden.`);const e=[];for(let s=n;s<t;++s)e.push(s);return e}let yc;function oe(){return yc==null&&(yc=aw().epsilon()),yc}function Cn(){return"channelsLast"}function Fn(n,t){return st(n,t)}function Ri(n,t=-1){const e=n.shape.slice();return t<0&&(t=e.length+t+1),e.splice(t,0,1),A(n,e)}function g2(n,t){return _(()=>{if(n.shape.length!==2)throw new E(`repeat() expects a rank-2 tensor, but received a rank-${n.shape.length} tensor.`);const e=Ri(n,1);return Qc(e,[1,t,1])})}function x2(n){const t=[ds(n.shape)];return A(n,t)}function b2(n){if(n.rank<=1)throw new E(`batchFlatten requires a minimum rank of 2. Got rank: ${n.rank}.`);const t=[n.shape[0],ds(n.shape,1)];return A(n,t)}function Vs(n,t,e){return _(()=>{switch(n.rank){case 1:return Nh(n,t,e);case 2:return Qm(n,[t,0],[e,n.shape[1]]);case 3:return Th(n,[t,0,0],[e,n.shape[1],n.shape[2]]);case 4:return ma(n,[t,0,0,0],[e,n.shape[1],n.shape[2],n.shape[3]]);case 5:return zt(n,[t,0,0,0,0],[e,n.shape[1],n.shape[2],n.shape[3],n.shape[4]]);case 6:return zt(n,[t,0,0,0,0,0],[e,n.shape[1],n.shape[2],n.shape[3],n.shape[4],n.shape[5]]);default:throw new E(`sliceAlongFirstAxis() received an unsupported tensor rank: ${n.rank}`)}})}function wc(n,t,e){return _(()=>{switch(n.rank){case 1:return Nh(n,t,e);case 2:return Qm(n,[0,t],[n.shape[0],e]);case 3:return Th(n,[0,0,t],[n.shape[0],n.shape[1],e]);case 4:return ma(n,[0,0,0,t],[n.shape[0],n.shape[1],n.shape[2],e]);default:throw new E(`sliceAlongLastAxis() received an unsupported tensor rank: ${n.rank}`)}})}function ji(n,t,e,s){return _(()=>{switch(n.rank){case 1:return Nh(n,t,e);case 2:switch(s){case 1:return Vs(n,t,e);case 2:return wc(n,t,e);default:throw new E(`The axis is not within the rank of the tensor ${s}`)}case 3:switch(s){case 1:return Vs(n,t,e);case 2:return Th(n,[0,t,0],[n.shape[0],e,n.shape[2]]);case 3:return wc(n,t,e);default:throw new E(`The axis is not within the rank of the tensor ${s}`)}case 4:switch(s){case 1:return Vs(n,t,e);case 2:return ma(n,[0,t,0,0],[n.shape[0],e,n.shape[2],n.shape[3]]);case 3:return ma(n,[0,0,t,0],[n.shape[0],n.shape[1],e,n.shape[3]]);case 4:return wc(n,t,e);default:throw new E(`The axis is not within the rank of the tensor ${s}`)}default:throw new E(`sliceAlongLastAxis() received an unsupported tensor rank: ${n.rank}`)}})}function md(n,t=-1){let e;return t<0&&(e=n[0].rank,e!==0?t=e:t=0),t===n[0].rank&&(t=-1),Le(n,t)}function Rp(n,t){switch(n.rank){case 1:return VC([n,t]);case 2:return UC([n,t],0);case 3:return HC([n,t],0);case 4:return jC([n,t],0);default:throw new E(`concatAlongFirstAxis() received an unsupported tensor rank: ${n.rank}`)}}function Qc(n,t){if(Array.isArray(t)||(t=[t]),n.rank!==t.length)throw new E(`The length of input n (${t.length}) does not match the number of dimensions in input x (${n.rank})`);return gn(n,t)}function Xl(n,t=0,e=1,s,o){return BI(n,t,e,s,o)}function On(n,t,e,s){if(n.rank<2||t.rank<2)throw new xt(`dot requires both inputs to be rank >= 2 but got x shape = ${n.shape} and y shape = ${t.shape}`);if(t.rank>=3){const o=n.shape.slice(-1)[0],r=t.shape.slice(-2)[0];if(o!==r)throw new xt(`If rank y >= 3, then the second last dim of y must equal the last dim of x but got x shape = ${n.shape} and  y shape = ${t.shape}`)}if(n.rank===2&&t.rank===2)return fp({a:n,b:t,transposeA:!1,transposeB:!1,bias:s?tu(n.rank,s,Cn()):null,activation:e});{const o=n.shape.slice(),r=o.pop();n=A(n,[-1,r]);const i=t.shape.slice(),a=i.pop(),l=i.pop(),c=[...i,a],u=Array.from({length:t.rank},(f,m)=>m===0?t.rank-2:m<=t.rank-2?m-1:m);t=A(It(t,u),[l,-1]);const h=[...o,...c];return A(fp({a:n,b:t,transposeA:!1,transposeB:!1,bias:s?tu(n.rank,s,Cn()):null,activation:e}),h)}}function ox(n,t,e){return _(()=>(Array.isArray(t)?t=We(t,"int32"):t=st(t,"int32"),bh(n,t,e)))}function Di(n){return R(n,n)}function tu(n,t,e){const s=t.shape;if(t.rank!==1&&t.rank!==n)throw new E(`Unexpected bias dimensions: ${t.rank}; expected it to be 1 or ${n}`);if(n===5){if(e==="channelsFirst")return s.length===1?A(t,[1,s[0],1,1,1]):A(t,[1,s[3],s[0],s[1],s[2]]);if(e==="channelsLast")return s.length===1?A(t,[1,1,1,1,s[0]]):A(t,[1].concat(s))}else if(n===4){if(e==="channelsFirst")return s.length===1?A(t,[1,s[0],1,1]):A(t,[1,s[2],s[0],s[1]]);if(e==="channelsLast")return s.length===1?A(t,[1,1,1,s[0]]):A(t,[1].concat(s))}else if(n===3){if(e==="channelsFirst")return s.length===1?A(t,[1,s[0],1]):A(t,[1,s[1],s[0]]);if(e==="channelsLast")return s.length===1?A(t,[1,1,s[0]]):A(t,[1].concat(s))}else if(n<3)return t;throw new E(`Unsupported input rank by biasAdd: ${t.rank}`)}function In(n,t,e){return _(()=>(e==null&&(e=Cn()),Qt(e),Y(n,tu(n.rank,t,e))))}function y2(n,t=1){if(t!==1)throw new xt(`Support for alpha values other than 1 (${t}) is not implemented yet.`);return Vl(n)}function w2(n){return _(()=>ut(n,Y(Ne(n),1)))}function rx(n,t,e,s){return _(()=>_k(n,t,e,s))}function C2(n){return _(()=>{const t=Y(.5,R(.2,n));return Ye(t,0,1)})}function Ai(n,t,e=!1){return e?n():t()}const $2=["fanIn","fanOut","fanAvg"],I2=["normal","uniform","truncatedNormal"];function k2(n){ao($2,"FanMode",n)}function v2(n){ao(I2,"Distribution",n)}class cn extends Wo{fromConfigUsesCustomObjects(){return!1}getConfig(){return{}}}class ix extends cn{apply(t,e){return de(t,e)}}ix.className="Zeros";j(ix);class gd extends cn{apply(t,e){return vs(t,e)}}gd.className="Ones";j(gd);class ax extends cn{constructor(t){if(super(),typeof t!="object")throw new E(`Expected argument of type ConstantConfig but got ${t}`);if(t.value===void 0)throw new E(`config must have value set but got ${t}`);this.value=t.value}apply(t,e){return _(()=>R(Tt(this.value),vs(t,e)))}getConfig(){return{value:this.value}}}ax.className="Constant";j(ax);class lx extends cn{constructor(t){super(),this.DEFAULT_MINVAL=-.05,this.DEFAULT_MAXVAL=.05,this.minval=t.minval||this.DEFAULT_MINVAL,this.maxval=t.maxval||this.DEFAULT_MAXVAL,this.seed=t.seed}apply(t,e){return Ii(t,this.minval,this.maxval,e,this.seed)}getConfig(){return{minval:this.minval,maxval:this.maxval,seed:this.seed}}}lx.className="RandomUniform";j(lx);class cx extends cn{constructor(t){super(),this.DEFAULT_MEAN=0,this.DEFAULT_STDDEV=.05,this.mean=t.mean||this.DEFAULT_MEAN,this.stddev=t.stddev||this.DEFAULT_STDDEV,this.seed=t.seed}apply(t,e){if(e=e||"float32",e!=="float32"&&e!=="int32")throw new xt(`randomNormal does not support dType ${e}.`);return Xl(t,this.mean,this.stddev,e,this.seed)}getConfig(){return{mean:this.mean,stddev:this.stddev,seed:this.seed}}}cx.className="RandomNormal";j(cx);class ux extends cn{constructor(t){super(),this.DEFAULT_MEAN=0,this.DEFAULT_STDDEV=.05,this.mean=t.mean||this.DEFAULT_MEAN,this.stddev=t.stddev||this.DEFAULT_STDDEV,this.seed=t.seed}apply(t,e){if(e=e||"float32",e!=="float32"&&e!=="int32")throw new xt(`truncatedNormal does not support dType ${e}.`);return ng(t,this.mean,this.stddev,e,this.seed)}getConfig(){return{mean:this.mean,stddev:this.stddev,seed:this.seed}}}ux.className="TruncatedNormal";j(ux);class hx extends cn{constructor(t){super(),this.gain=t.gain!=null?t.gain:1}apply(t,e){return _(()=>{if(t.length!==2||t[0]!==t[1])throw new E("Identity matrix initializer can only be used for 2D square matrices.");return R(this.gain,zm(t[0]))})}getConfig(){return{gain:this.gain}}}hx.className="Identity";j(hx);function S2(n,t="channelsLast"){let e,s;if(Qt(t),n.length===2)e=n[0],s=n[1];else if([3,4,5].indexOf(n.length)!==-1){if(t==="channelsFirst"){const o=ds(n,2);e=n[1]*o,s=n[0]*o}else if(t==="channelsLast"){const o=ds(n,0,n.length-2);e=n[n.length-2]*o,s=n[n.length-1]*o}}else{const o=ds(n);e=Math.sqrt(o),s=Math.sqrt(o)}return[e,s]}class Ge extends cn{constructor(t){if(super(),t.scale<0)throw new E(`scale must be a positive float. Got: ${t.scale}`);this.scale=t.scale==null?1:t.scale,this.mode=t.mode==null?"fanIn":t.mode,k2(this.mode),this.distribution=t.distribution==null?"normal":t.distribution,v2(this.distribution),this.seed=t.seed}apply(t,e){const s=S2(t),o=s[0],r=s[1];let i=this.scale;if(this.mode==="fanIn"?i/=Math.max(1,o):this.mode==="fanOut"?i/=Math.max(1,r):i/=Math.max(1,(o+r)/2),this.distribution==="normal"){const a=Math.sqrt(i);if(e=e||"float32",e!=="float32"&&e!=="int32")throw new xt(`${this.getClassName()} does not support dType ${e}.`);return ng(t,0,a,e,this.seed)}else{const a=Math.sqrt(3*i);return Ii(t,-a,a,e,this.seed)}}getConfig(){return{scale:this.scale,mode:this.mode,distribution:this.distribution,seed:this.seed}}}Ge.className="VarianceScaling";j(Ge);class xd extends Ge{constructor(t){super({scale:1,mode:"fanAvg",distribution:"uniform",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}xd.className="GlorotUniform";j(xd);class bd extends Ge{constructor(t){super({scale:1,mode:"fanAvg",distribution:"normal",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}bd.className="GlorotNormal";j(bd);class yd extends Ge{constructor(t){super({scale:2,mode:"fanIn",distribution:"normal",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}yd.className="HeNormal";j(yd);class wd extends Ge{constructor(t){super({scale:2,mode:"fanIn",distribution:"uniform",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}wd.className="HeUniform";j(wd);class Cd extends Ge{constructor(t){super({scale:1,mode:"fanIn",distribution:"normal",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}Cd.className="LeCunNormal";j(Cd);class $d extends Ge{constructor(t){super({scale:1,mode:"fanIn",distribution:"uniform",seed:t==null?null:t.seed})}getClassName(){return Ge.className}}$d.className="LeCunUniform";j($d);class dx extends cn{constructor(t){super(),this.DEFAULT_GAIN=1,this.ELEMENTS_WARN_SLOW=2e3,this.gain=t.gain==null?this.DEFAULT_GAIN:t.gain,this.seed=t.seed}apply(t,e){return _(()=>{if(t.length<2)throw new xt("Shape must be at least 2D.");if(e!=="int32"&&e!=="float32"&&e!==void 0)throw new TypeError(`Unsupported data type ${e}.`);e=e;const s=W(t.slice(0,-1)),o=t[t.length-1],r=s*o;r>this.ELEMENTS_WARN_SLOW&&console.warn(`Orthogonal initializer is being called on a matrix with more than ${this.ELEMENTS_WARN_SLOW} (${r}) elements: Slowness may result.`);const i=[Math.max(o,s),Math.min(o,s)],a=Xl(i,0,1,e,this.seed),l=Dv.qr(a,!1);let c=l[0];const h=l[1].flatten().stridedSlice([0],[Math.min(o,s)*Math.min(o,s)],[Math.min(o,s)+1]);return c=R(c,h.sign()),s<o&&(c=c.transpose()),R(Tt(this.gain),c.reshape(t))})}getConfig(){return{gain:this.gain,seed:this.seed}}}dx.className="Orthogonal";j(dx);const Dp={constant:"Constant",glorotNormal:"GlorotNormal",glorotUniform:"GlorotUniform",heNormal:"HeNormal",heUniform:"HeUniform",identity:"Identity",leCunNormal:"LeCunNormal",leCunUniform:"LeCunUniform",ones:"Ones",orthogonal:"Orthogonal",randomNormal:"RandomNormal",randomUniform:"RandomUniform",truncatedNormal:"TruncatedNormal",varianceScaling:"VarianceScaling",zeros:"Zeros"};function Ap(n,t={}){return Ei(n,nn.getMap().classNameMap,t,"initializer")}function Kt(n){return pd(n)}function Ut(n){if(typeof n=="string"){const t=n in Dp?Dp[n]:n;if(t==="GlorotNormal")return new bd;if(t==="GlorotUniform")return new xd;if(t==="HeNormal")return new yd;if(t==="HeUniform")return new wd;if(t==="LeCunNormal")return new Cd;if(t==="LeCunUniform")return new $d;{const e={};return e.className=t,e.config={},Ap(e)}}else return n instanceof cn?n:Ap(n)}function eu(n){return Array.isArray(n)&&Array.isArray(n[0])}function ga(n){return n.length===0?[]:Array.isArray(n[0])?n:[n]}function ft(n){let t;if(Array.isArray(n)){if(n.length!==1)throw new E(`Expected Tensor length to be 1; got ${n.length}`);t=n[0]}else t=n;return t}function St(n){if(Array.isArray(n)&&Array.isArray(n[0])){if(n.length===1)return n=n,n[0];throw new E(`Expected exactly 1 Shape; got ${n.length}`)}else return n}function xa(n){let t=0;for(const e of n)e.shape.length===0?t+=1:t+=e.shape.reduce((s,o)=>s*o);return t}const Fp="Variable";class N2{constructor(t,e="float32",s=Fp,o=!0,r=null){this.dtype=e??"float32",this.shape=t.shape,this.id=Qg(),s=s??Fp,this.originalName=ex(s),this.name=nx(this.originalName),this.trainable_=o,this.constraint=r,this.val=Dk(t,this.trainable_,this.name,this.dtype)}read(){return this.assertNotDisposed(),this.val}write(t){return this.assertNotDisposed(),T2(this.val,t),this.val.id!==t.id&&(this.val.assign(t),this.constraint!=null&&this.val.assign(this.constraint.apply(this.val))),this}dispose(){this.assertNotDisposed(),this.val.dispose()}assertNotDisposed(){if(this.val.isDisposed)throw new Error(`LayersVariable ${this.name} is already disposed.`)}get trainable(){return this.trainable_}set trainable(t){this.trainable_=t,this.val.trainable=t}}function T2(n,t){if(n.shape.toString()!==t.shape.toString())throw new Error("Shape mismatch: "+JSON.stringify(n.shape)+" vs. "+JSON.stringify(t.shape))}function nu(n){return n.map(t=>t.read())}function Id(n){n.forEach(t=>{t[0].write(t[1])})}class re{constructor(t){this.dtype=t.dtype,this.shape=t.shape,t.shape!=null?this.ndim=t.shape.length:this.ndim=t.ndim,this.maxNDim=t.maxNDim,this.minNDim=t.minNDim,this.axes=t.axes||{}}}class zn{constructor(t,e,s,o,r,i,a){this.dtype=t,this.shape=e,this.sourceLayer=s,this.inputs=o,this.callArgs=r,this.outputTensorIndex=a,this.id=Qg(),i!=null&&(this.originalName=ex(i),this.name=nx(this.originalName)),this.rank=e.length}}let E2=0;class Yl{constructor(t,e){this.callArgs=e,this.id=E2++,this.outboundLayer=t.outboundLayer,this.inboundLayers=t.inboundLayers,this.nodeIndices=t.nodeIndices,this.tensorIndices=t.tensorIndices,this.inputTensors=t.inputTensors,this.outputTensors=t.outputTensors,this.inputMasks=t.inputMasks,this.outputMasks=t.outputMasks,this.inputShapes=t.inputShapes,this.outputShapes=t.outputShapes;for(const s of t.inboundLayers)s?.outboundNodes.push(this);t.outboundLayer.inboundNodes.push(this)}getConfig(){const t=[];for(const e of this.inboundLayers)e!=null?t.push(e.name):t.push(null);return{outboundLayer:this.outboundLayer?this.outboundLayer.name:null,inboundLayers:t,nodeIndices:this.nodeIndices,tensorIndices:this.tensorIndices}}}let R2=0;class $t extends Wo{constructor(t={}){super(),this._callHook=null,this._addedWeightNames=[],this._stateful=!1,this.id=R2++,this.activityRegularizer=null,this.inputSpec=null,this.supportsMasking=!1,this._trainableWeights=[],this._nonTrainableWeights=[],this._losses=[],this._updates=[],this._built=!1,this.inboundNodes=[],this.outboundNodes=[];let e=t.name;if(!e){const s=this.getClassName();e=Gn(s)+"_"+ql(s)}if(this.name=e,this.trainable_=t.trainable==null?!0:t.trainable,t.inputShape!=null||t.batchInputShape!=null){let s;if(t.batchInputShape!=null)s=t.batchInputShape;else if(t.inputShape!=null){let r=null;t.batchSize!=null&&(r=t.batchSize),s=[r].concat(t.inputShape)}this.batchInputShape=s;let o=t.dtype;o==null&&(o=t.inputDType),o==null&&(o="float32"),this.dtype=o}t.weights!=null?this.initialWeights=t.weights:this.initialWeights=null,this._refCount=null,this.fastWeightInitDuringBuild=!1}static nodeKey(t,e){return t.name+"_ib-"+e.toString()}getNodeAtIndex(t,e){if(this.inboundNodes.length===0)throw new sn(`The layer has never been called and thus has no defined ${e}.`);if(this.inboundNodes.length<=t)throw new E(`Asked to get ${e} at node ${t}, but the layer has only ${this.inboundNodes.length} inbound nodes.`);return this.inboundNodes[t]}getInputAt(t){return _e(this.getNodeAtIndex(t,"input").inputTensors)}getOutputAt(t){return _e(this.getNodeAtIndex(t,"output").outputTensors)}get input(){if(this.inboundNodes.length>1)throw new Sn(`Layer ${this.name} has multiple inbound nodes, hence the notion of "layer input" is ill-defined. Use \`getInputAt(nodeIndex)\` instead.`);if(this.inboundNodes.length===0)throw new Sn(`Layer ${this.name} is not connected, no input to return.`);return _e(this.getNodeAtIndex(0,"input").inputTensors)}get output(){if(this.inboundNodes.length===0)throw new Sn(`Layer ${this.name} has no inbound nodes.`);if(this.inboundNodes.length>1)throw new Sn(`Layer ${this.name} has multiple inbound nodes, hence the notion of "layer output" is ill-defined. Use \`getOutputAt(nodeIndex)\` instead.`);return _e(this.getNodeAtIndex(0,"output").outputTensors)}get losses(){return this._losses}calculateLosses(){return this.losses.map(t=>t())}get updates(){return this._updates}get built(){return this._built}set built(t){this._built=t}get trainable(){return this.trainable_}set trainable(t){this._trainableWeights.forEach(e=>e.trainable=t),this.trainable_=t}get trainableWeights(){return this.trainable_?this._trainableWeights.filter(t=>t.trainable):[]}set trainableWeights(t){this._trainableWeights=t}get nonTrainableWeights(){return this.trainable?this._trainableWeights.filter(t=>!t.trainable).concat(this._nonTrainableWeights):this._trainableWeights.concat(this._nonTrainableWeights)}set nonTrainableWeights(t){this._nonTrainableWeights=t}get weights(){return this.trainableWeights.concat(this.nonTrainableWeights)}get stateful(){return this._stateful}resetStates(){if(!this.stateful)throw new Error("Cannot call the resetStates() method of a non-stateful Layer object.")}assertInputCompatibility(t){const e=Dt(t);if(this.inputSpec==null||this.inputSpec.length===0)return;const s=Dt(this.inputSpec);if(e.length!==s.length)throw new E(`Layer ${this.name} expects ${s.length} inputs, but it received ${e.length} input tensors. Input received: ${t}`);for(let o=0;o<e.length;o++){const r=e[o],i=s[o];if(i==null)continue;const a=r.rank;if(i.ndim!=null&&a!==i.ndim)throw new E(`Input ${o} is incompatible with layer ${this.name}: expected ndim=${i.ndim}, found ndim=${a}`);if(i.maxNDim!=null&&a>i.maxNDim)throw new E(`Input ${o} is incompatible with layer ${this.name}: expected max_ndim=${i.maxNDim}, found ndim=${a}`);if(i.minNDim!=null&&a<i.minNDim)throw new E(`Input ${o} is incompatible with layer ${this.name}: expected min_ndim=${i.minNDim}, found ndim=${a}.`);if(i.dtype!=null&&r.dtype!==i.dtype)throw new E(`Input ${o} is incompatible with layer ${this.name} : expected dtype=${i.dtype}, found dtype=${r.dtype}.`);if(i.axes){const l=r.shape;for(const c in i.axes){const u=Number(c),h=i.axes[c],d=u>=0?l[u]:l[l.length+u];if(h!=null&&[h,null].indexOf(d)===-1)throw new E(`Input ${o} is incompatible with layer ${this.name}: expected axis ${u} of input shape to have value ${h} but got shape ${l}.`)}}if(i.shape!=null)for(let l=0;l<i.shape.length;++l){const c=i.shape[l],u=r.shape[l];if(c!=null&&u!=null&&c!==u)throw new E(`Input ${o} is incompatible with layer ${this.name}: expected shape=${i.shape}, found shape=${r.shape}.`)}}}call(t,e){return t}invokeCallHook(t,e){this._callHook!=null&&this._callHook(t,e)}setCallHook(t){this._callHook=t}clearCallHook(){this._callHook=null}apply(t,e){e=e||{},this.assertNotDisposed();const s=Dt(t),o=F2(t),r=O2(t);if(o===r)throw new E("Arguments to apply() must be all SymbolicTensors or all Tensors");return Bs(this.name,()=>{if(!this.built){this.assertInputCompatibility(t);const i=[];for(const a of Dt(t))i.push(a.shape);this.build(_e(i)),this.built=!0,this.initialWeights&&this.setWeights(this.initialWeights),this._refCount===null&&r&&(this._refCount=1)}if(this.assertInputCompatibility(t),r){let i=this.call(t,e);this.supportsMasking&&this.setMaskMetadata(t,i);const a=Dt(i),l=[];for(let c of a)s.indexOf(c)!==-1&&(c=c.clone()),l.push(c);if(i=_e(l),this.activityRegularizer!=null)throw new xt("Layer invocation in the presence of activity regularizer(s) is not supported yet.");return i}else{const i=D2(t),a=this.computeOutputShape(i);let l;const c=A2(t);if(this.warnOnIncompatibleInputShape(Array.isArray(t)?i[0]:i),a!=null&&a.length>0&&Array.isArray(a[0])?l=a.map((u,h)=>new zn(c,u,this,Dt(t),e,this.name,h)):l=new zn(c,a,this,Dt(t),e,this.name),this.addInboundNode(t,l,null,null,i,a,e),this._refCount++,this.activityRegularizer!=null)throw new xt("Layer invocation in the presence of activity regularizer(s) is not supported yet.");return l}})}warnOnIncompatibleInputShape(t){if(this.batchInputShape!=null)if(t.length!==this.batchInputShape.length)console.warn(`The rank of the input tensor provided (shape: ${JSON.stringify(t)}) does not match that of the batchInputShape (${JSON.stringify(this.batchInputShape)}) of the layer ${this.name}`);else{let e=!1;this.batchInputShape.forEach((s,o)=>{s!=null&&t[o]!=null&&t[o]!==s&&(e=!0)}),e&&console.warn(`The shape of the input tensor (${JSON.stringify(t)}) does not match the expectation of layer ${this.name}: ${JSON.stringify(this.batchInputShape)}`)}}get outputShape(){if(this.inboundNodes==null||this.inboundNodes.length===0)throw new Sn(`The layer ${this.name} has never been called and thus has no defined output shape.`);const t=[];for(const e of this.inboundNodes){const s=JSON.stringify(e.outputShapes);t.indexOf(s)===-1&&t.push(s)}if(t.length===1){const e=this.inboundNodes[0].outputShapes;return Array.isArray(e)&&Array.isArray(e[0])&&e.length===1?e[0]:e}else throw new Sn(`The layer ${this.name} has multiple inbound nodes with different output shapes. Hence the notion of "output shape" is ill-defined for the layer.`)}countParams(){if(!this.built)throw new sn(`You tried to call countParams() on ${this.name}, but the layer is not built yet. Build it first by calling build(batchInputShape).`);return xa(this.weights)}build(t){this.built=!0}getWeights(t=!1){return nu(t?this.trainableWeights:this.weights)}setWeights(t){_(()=>{const e=this.weights;if(e.length!==t.length)throw new E(`You called setWeights(weights) on layer "${this.name}" with a weight list of length ${t.length}, but the layer was expecting ${e.length} weights. Provided weights: ${t}...`);if(e.length===0)return;const s=[],o=nu(e);for(let r=0;r<o.length;++r){const i=o[r],a=e[r],l=t[r];if(!Et(i.shape,l.shape))throw new E(`Layer weight shape ${i.shape} not compatible with provided weight shape ${l.shape}`);s.push([a,l])}Id(s)})}addWeight(t,e,s,o,r,i,a,l){if(this._addedWeightNames.indexOf(t)!==-1)throw new E(`Duplicate weight name ${t} for layer ${this.name}`);this._addedWeightNames.push(t),s==null&&(s="float32"),this.fastWeightInitDuringBuild&&(o=l!=null?l():Ut("zeros"));const c=o.apply(e,s),u=new N2(c,s,t,i,a);return c.dispose(),r!=null&&this.addLoss(()=>r.apply(u.read())),i==null&&(i=!0),i?this._trainableWeights.push(u):this._nonTrainableWeights.push(u),u}setFastWeightInitDuringBuild(t){this.fastWeightInitDuringBuild=t}addLoss(t){t==null||Array.isArray(t)&&t.length===0||(t=Dt(t),this._losses!==void 0&&this._losses!==null&&this.losses.push(...t))}computeOutputShape(t){return t}computeMask(t,e){if(!this.supportsMasking){if(e!=null)if(Array.isArray(e))e.forEach(s=>{if(s!=null)throw new TypeError(`Layer ${this.name} does not support masking, but was passed an inputMask.`)});else throw new TypeError(`Layer ${this.name} does not support masking, but was passed an inputMask.`);return null}return e}setMaskMetadata(t,e,s){if(!this.supportsMasking)return;const o=this.computeMask(t,s),r=Dt(e),i=Dt(o);if(r.length!==i.length)throw new Error(`${this.name} outputs ${r.length} tensors but ${r.length} masks for those tensors`);for(let a=0;a<r.length;a++)r[a].kerasMask=i[a]}addInboundNode(t,e,s,o,r,i,a=null){const l=Dt(t);e=Dt(e),s=Dt(s),o=Dt(o),r=ga(r),i=ga(i);const c=[],u=[],h=[];for(const d of l)c.push(d.sourceLayer),u.push(d.nodeIndex),h.push(d.tensorIndex);new Yl({outboundLayer:this,inboundLayers:c,nodeIndices:u,tensorIndices:h,inputTensors:l,outputTensors:e,inputMasks:s,outputMasks:o,inputShapes:r,outputShapes:i},a);for(let d=0;d<e.length;d++)e[d].sourceLayer=this,e[d].nodeIndex=this.inboundNodes.length-1,e[d].tensorIndex=d}getConfig(){const t={name:this.name,trainable:this.trainable};return this.batchInputShape!=null&&(t.batchInputShape=this.batchInputShape),this.dtype!=null&&(t.dtype=this.dtype),t}disposeWeights(){return this.weights.forEach(t=>t.dispose()),this.weights.length}assertNotDisposed(){if(this._refCount===0)throw new Error(`Layer '${this.name}' is already disposed.`)}dispose(){if(!this.built)throw new Error(`Cannot dispose Layer ${this.name} because it has not been built yet.`);if(this._refCount===null)throw new Error(`Cannot dispose Layer ${this.name} because it has not been used yet.`);this.assertNotDisposed();let t=0;return--this._refCount===0&&(t=this.disposeWeights()),{refCountAfterDispose:this._refCount,numDisposedVariables:t}}}function D2(n){n=Dt(n);const t=[];for(const e of n)t.push(e.shape);return _e(t)}function A2(n){return"float32"}function px(n,t,e){if((t==null||e!=null&&e>0)&&(t=n.sourceLayer,e=n.nodeIndex),t.inboundNodes.length===0)return[n];{const s=t.inboundNodes[e];if(s.inboundLayers.length===0)return s.inputTensors;{const o=[];for(let r=0;r<s.inboundLayers.length;r++){const i=s.inputTensors[r],a=s.inboundLayers[r],l=s.nodeIndices[r],c=px(i,a,l);for(const u of c)o.indexOf(u)===-1&&o.push(u)}return o}}}function F2(n){let t=!0;for(const e of Dt(n))if(!(e instanceof zn)){t=!1;break}return t}function O2(n){let t=!0;for(const e of Dt(n))if(e instanceof zn){t=!1;break}return t}class Fi extends $t{constructor(t){if(super({dtype:t.dtype,name:t.name!=null?t.name:ql("input").toString()}),t.batchSize==null&&(t.batchSize=null),t.sparse==null&&(t.sparse=!1),this.trainable=!1,this.built=!0,this.sparse=t.sparse,t.inputShape!=null&&t.batchInputShape!=null)throw new E("Only provide the inputShape OR batchInputShape argument to inputLayer, not both at the same time.");let e=t.batchInputShape;if(e==null){if(t.inputShape==null)throw new E("An InputLayer should be passed either a `batchInputShape` or an `inputShape`.");e=[t.batchSize].concat(t.inputShape)}else if(t.batchSize!=null)throw new E("Cannot specify batchSize if batchInputShape is specified when creating an InputLayer.");const s=t.dtype||"float32";this.batchInputShape=e,this.dtype=s,this.inputSpec=[{shape:e}];const o=new zn(this.dtype,this.batchInputShape,this,[],{},this.name);o.nodeIndex=0,o.tensorIndex=0,new Yl({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:[o],outputTensors:[o],inputMasks:[null],outputMasks:[null],inputShapes:[e],outputShapes:[e]})}apply(t,e){throw new E(`Cannot pass any input to an InputLayer's apply() method. InputLayer name: ${this.name}`)}dispose(){return{refCountAfterDispose:this._refCount,numDisposedVariables:0}}getConfig(){return{batchInputShape:this.batchInputShape,dtype:this.dtype,sparse:this.sparse,name:this.name}}}Fi.className="InputLayer";j(Fi);function _2(n){if(n.batchShape==null&&n.shape==null)throw new Error("Please provide to Input either a `shape` or a `batchShape` argument. Note that `shape` does not include the batch dimension.");if(n.batchShape!=null&&n.shape!=null)throw new E("Please provide either a `shape` or `batchShape` argument to Input, but not both.");let t=n.batchShape;n.shape!=null&&t==null&&(t=[null].concat(n.shape));let e=n.dtype;return e==null&&(e="float32"),new Fi({batchInputShape:t,name:n.name,dtype:e,sparse:n.sparse}).inboundNodes[0].outputTensors[0]}function L2(n,t){if(n.dtype==null||n.dtype===t.dtype)return t;try{return st(t,n.dtype)}catch{throw new E(`The dtype of the feed (${t.dtype}) can not be cast to the dtype of the key '${n.name}' (${n.dtype}).`)}}class as{constructor(t){if(this.id2Value={},this.id2Mask={},this.name2Id={},t instanceof as)for(const e in t.id2Value)this.id2Value[e]=t.id2Value[e],e in t.id2Mask&&(this.id2Mask[e]=t.id2Mask[e]);else{if(t==null)return;for(const e of t)this.add(e.key,e.value)}}add(t,e,s){if(this.id2Value[t.id]==null)this.id2Value[t.id]=L2(t,e),this.name2Id[t.name]=t.id,s!=null&&(this.id2Mask[t.id]=s);else throw new E(`Duplicate key: name=${t.name}, id=${t.id}`);return this}addFeed(t){this.add(t.key,t.value)}hasKey(t){return this.id2Value[t.id]!=null}names(){return Object.keys(this.name2Id)}getValue(t){if(t instanceof zn){if(this.id2Value[t.id]==null)throw new E(`Nonexistent key: ${t.name}`);return this.id2Value[t.id]}else{const e=this.name2Id[t];if(e==null)throw new E(`Feed dict has no SymbolicTensor name: ${t}`);return this.id2Value[e]}}getMask(t){if(t instanceof zn){if(this.id2Value[t.id]==null)throw new E(`Nonexistent key: ${t.name}`);return this.id2Mask[t.id]}else{const e=this.name2Id[t];if(e==null)throw new E(`Feed dict has no SymbolicTensor name: ${t}`);return this.id2Mask[e]}}disposeMasks(){this.id2Mask!=null&&yt(this.id2Mask)}}const ba=new Yg,ya=new Yg;function M2(n){ba?.setMaxEntries(n),ya?.setMaxEntries(n)}function rr(n,t,e,s){const o=e==null?!1:e.training,r=Array.isArray(n),i=r?n:[n],a=i.map(f=>f.name),l=[],c=t.names();for(const f of a)c.indexOf(f)!==-1?l.push(t.getValue(f)):l.push(null);const u=a.join(",")+"|"+t.names().sort().join(",");let h=ba.get(u),d;if(h==null){const f=P2(i,t);h=f.sorted,d=f.recipientCounts,ba.put(u,h),ya.put(u,d)}d={},o||Object.assign(d,ya.get(u));const p=new as(t);for(let f=0;f<h.length;++f){const m=h[f],g=m.sourceLayer;if(g instanceof Fi)continue;const x=[],b=[],w=[];let y=!1;for(const N of m.inputs){const T=p.getValue(N),O=p.getMask(N);x.push(T),b.push(O),O!=null&&(y=!0),o||(d[N.name]--,d[N.name]===0&&!t.hasKey(N)&&a.indexOf(N.name)===-1&&!T.isDisposed&&N.sourceLayer.stateful!==!0&&w.push(T))}y&&(e=e||{},e.mask=b[0]);const C=Dt(g.apply(x,e));let I=null;g.supportsMasking&&(I=g.computeMask(x,b));const k=B2(m),v=Array.isArray(k)?k:[k];for(let N=0;N<v.length;++N){p.hasKey(v[N])||p.add(v[N],C[N],Array.isArray(I)?I[0]:I);const T=a.indexOf(v[N].name);T!==-1&&(l[T]=C[N])}o||yt(w)}return p.disposeMasks(),r?l:l[0]}function P2(n,t){$(n!=null&&n.length>0,()=>"Expected at least one fetch, got none");let e=[],s={};if(n.length===1){const o=Op(n[0],t);e=o.sorted,s=o.recipientMap}else{const o=new Set;for(const r of n){const{sorted:i,recipientMap:a}=Op(r,t);for(const l of i)o.has(l.name)||(e.push(l),o.add(l.name));for(const l in a)s[l]==null&&(s[l]=new Set),a[l].forEach(c=>s[l].add(c))}}return{sorted:e,recipientCounts:z2(s)}}function z2(n){const t={};for(const e in n)t[e]=n[e].size;return t}function Op(n,t){const e=new Set,s=[],o={};for(const a of t.names())e.add(a);const r=[],i=[];for(r.push(n);r.length>0;){const a=r[r.length-1];if(e.has(a.name)){r.pop();continue}const l=i[i.length-1]===r.length-1;if(a.inputs.length===0||l)r.pop(),s.push(a),e.add(a.name),l&&i.pop();else{i.push(r.length-1);for(const c of a.inputs)o[c.name]==null&&(o[c.name]=new Set),o[c.name].add(a.name),!e.has(c.name)&&r.push(c)}}return{sorted:s,recipientMap:o}}function B2(n){let t;if(n.sourceLayer.inboundNodes.length===1)t=n.sourceLayer.output;else{let e=null;for(let s=0;s<n.sourceLayer.inboundNodes.length;++s)for(const o of n.sourceLayer.inboundNodes[s].outputTensors)if(o.id===n.id){e=s;break}t=n.sourceLayer.getOutputAt(e)}return t}const V2=L();V2.registerFlag("TOPOLOGICAL_SORT_CACHE_MAX_ENTRIES",()=>100,M2);function kd(n,t){return _(()=>Ie(ct(R(n,n),t,!0)))}class Oi extends Wo{getConfig(){return{}}}class fx extends Oi{constructor(t){super(),this.defaultMaxValue=2,this.defaultAxis=0,this.maxValue=t.maxValue!=null?t.maxValue:this.defaultMaxValue,this.axis=t.axis!=null?t.axis:this.defaultAxis}apply(t){return _(()=>{const e=kd(t,this.axis),s=Ye(e,0,this.maxValue);return R(t,ut(s,Y(oe(),e)))})}getConfig(){return{maxValue:this.maxValue,axis:this.axis}}}fx.className="MaxNorm";j(fx);class mx extends Oi{constructor(t){super(),this.defaultAxis=0,this.axis=t.axis!=null?t.axis:this.defaultAxis}apply(t){return _(()=>ut(t,Y(oe(),kd(t,this.axis))))}getConfig(){return{axis:this.axis}}}mx.className="UnitNorm";j(mx);class gx extends Oi{apply(t){return ro(t)}}gx.className="NonNeg";j(gx);class xx extends Oi{constructor(t){super(),this.defaultMinValue=0,this.defaultMaxValue=1,this.defaultRate=1,this.defaultAxis=0,this.minValue=t.minValue!=null?t.minValue:this.defaultMinValue,this.maxValue=t.maxValue!=null?t.maxValue:this.defaultMaxValue,this.rate=t.rate!=null?t.rate:this.defaultRate,this.axis=t.axis!=null?t.axis:this.defaultAxis}apply(t){return _(()=>{const e=kd(t,this.axis),s=Y(R(this.rate,Ye(e,this.minValue,this.maxValue)),R(1-this.rate,e));return R(t,ut(s,Y(oe(),e)))})}getConfig(){return{minValue:this.minValue,maxValue:this.maxValue,rate:this.rate,axis:this.axis}}}xx.className="MinMaxNorm";j(xx);const _p={maxNorm:"MaxNorm",minMaxNorm:"MinMaxNorm",nonNeg:"NonNeg",unitNorm:"UnitNorm"};function ie(n){return pd(n)}function Lp(n,t={}){return Ei(n,nn.getMap().classNameMap,t,"constraint")}function ae(n){if(n==null)return null;if(typeof n=="string"){const e={className:n in _p?_p[n]:n,config:{}};return Lp(e)}else return n instanceof Oi?n:Lp(n)}async function Ds(n){if(n==null)return;const t=[],e=[],s=[];for(const o in n){const r=n[o];if(typeof r!="number"){const i=r;t.push(i.data()),e.push(o),s.push(i)}}if(t.length>0){const o=await Promise.all(t);for(let r=0;r<o.length;++r)n[e[r]]=o[r][0];yt(s)}}function bx(n){if(n!=null)for(const t in n){const e=n[t];typeof e!="number"&&e.dispose()}}var Mp;(function(n){n[n.SILENT=0]="SILENT",n[n.VERBOSE=1]="VERBOSE"})(Mp||(Mp={}));const W2=125;class xr{constructor(){this.validationData=null}setParams(t){this.params=t}async onEpochBegin(t,e){}async onEpochEnd(t,e){}async onBatchBegin(t,e){}async onBatchEnd(t,e){}async onTrainBegin(t){}async onTrainEnd(t){}setModel(t){}}class U2{constructor(t,e=10){t==null&&(t=[]),this.callbacks=t,this.queueLength=e}append(t){this.callbacks.push(t)}setParams(t){for(const e of this.callbacks)e.setParams(t)}setModel(t){for(const e of this.callbacks)e.setModel(t)}async onEpochBegin(t,e){e==null&&(e={});for(const s of this.callbacks)await s.onEpochBegin(t,e)}async onEpochEnd(t,e){e==null&&(e={});for(const s of this.callbacks)await s.onEpochEnd(t,e)}async onBatchBegin(t,e){e==null&&(e={});for(const s of this.callbacks)await s.onBatchBegin(t,e)}async onBatchEnd(t,e){e==null&&(e={});for(const s of this.callbacks)await s.onBatchEnd(t,e)}async onTrainBegin(t){t==null&&(t={});for(const e of this.callbacks)await e.onTrainBegin(t)}async onTrainEnd(t){t==null&&(t={});for(const e of this.callbacks)await e.onTrainEnd(t)}}class G2 extends xr{constructor(){super()}async onEpochBegin(t){this.seen=0,this.totals={}}async onBatchEnd(t,e){e==null&&(e={});const s=e.size==null?0:e.size;this.seen+=s;for(const o in e){const r=e[o];if(typeof r=="number")this.totals.hasOwnProperty(o)||(this.totals[o]=0),this.totals[o]=this.totals[o]+r*s;else{let i;o in this.totals?i=this.totals[o]:this.totals[o]=0;const a=_(()=>Y(this.totals[o],R(r,s)));this.totals[o]=a,i?.dispose()}}}async onEpochEnd(t,e){if(e!=null)for(const s of this.params.metrics)this.totals[s]!=null&&(typeof this.totals[s]=="number"?e[s]=this.totals[s]/this.seen:_(()=>{const o=R(ut(1,this.seen),this.totals[s]);e[s]=o,this.totals[s].dispose(),Dn(e[s])}))}}class H2 extends xr{async onTrainBegin(t){this.epoch=[],this.history={}}async onEpochEnd(t,e){e==null&&(e={}),this.epoch.push(t);for(const s in e)this.history[s]==null&&(this.history[s]=[]),this.history[s].push(e[s])}async syncData(){const t=[],e=[],s=[];for(const r in this.history){const i=this.history[r];for(let a=0;a<i.length;++a)if(typeof i[a]!="number"){const l=i[a];t.push(l.data()),e.push(r),s.push(a)}}const o=await Promise.all(t);for(let r=0;r<o.length;++r)this.history[e[r]][s[r]].dispose(),this.history[e[r]][s[r]]=o[r][0]}}class K2 extends xr{constructor(t,e){if(super(),this.currentEpoch=0,this.nowFunc=t.nowFunc,this.nextFrameFunc=t.nextFrameFunc||Ig,this.yieldEvery=e||"auto",this.yieldEvery==="auto"&&(this.yieldEvery=W2),this.yieldEvery==="never"&&t.onYield!=null)throw new Error("yieldEvery is `never` but you provided an `onYield` callback. Either change `yieldEvery` or remove the callback");Ac(this.yieldEvery)&&(this.maybeWait=r2(this.maybeWait.bind(this),this.yieldEvery,this.nowFunc)),this.trainBegin=t.onTrainBegin,this.trainEnd=t.onTrainEnd,this.epochBegin=t.onEpochBegin,this.epochEnd=t.onEpochEnd,this.batchBegin=t.onBatchBegin,this.batchEnd=t.onBatchEnd,this.yield=t.onYield}async maybeWait(t,e,s){const o=[];this.yield!=null&&(await Ds(s),o.push(this.yield(t,e,s))),o.push(this.nextFrameFunc()),await Promise.all(o)}async onEpochBegin(t,e){this.currentEpoch=t,this.epochBegin!=null&&(await Ds(e),await this.epochBegin(t,e))}async onEpochEnd(t,e){const s=[];this.epochEnd!=null&&(await Ds(e),s.push(this.epochEnd(t,e))),this.yieldEvery==="epoch"&&s.push(this.nextFrameFunc()),await Promise.all(s)}async onBatchBegin(t,e){this.batchBegin!=null&&(await Ds(e),await this.batchBegin(t,e))}async onBatchEnd(t,e){const s=[];this.batchEnd!=null&&(await Ds(e),s.push(this.batchEnd(t,e))),this.yieldEvery==="batch"?s.push(this.nextFrameFunc()):Ac(this.yieldEvery)&&s.push(this.maybeWait(this.currentEpoch,t,e)),await Promise.all(s)}async onTrainBegin(t){this.trainBegin!=null&&(await Ds(t),await this.trainBegin(t))}async onTrainEnd(t){this.trainEnd!=null&&(await Ds(t),await this.trainEnd(t))}}function yx(n,t){return n==null&&(n={}),n instanceof xr?[n]:Array.isArray(n)&&n[0]instanceof xr?n:Dt(n).map(s=>new K2(s,t))}class en{constructor(){}static registerCallbackConstructor(t,e){$(t>=0&&Number.isInteger(t),()=>`Verbosity level is expected to be an integer >= 0, but got ${t}`),en.checkForDuplicate(e),en.constructors[t]==null&&(en.constructors[t]=[]),en.constructors[t].push(e)}static checkForDuplicate(t){for(const e in en.constructors)en.constructors[+e].forEach(o=>{if(o===t)throw new E("Duplicate callback constructor.")})}static clear(){en.constructors={}}static createCallbacks(t){const e=[];for(const s in en.constructors){const o=+s;t>=o&&e.push(...en.constructors[o])}return e.map(s=>new s)}}en.constructors={};function wx(n,t,e,s,o,r,i,a,l){const c=new H2,u=[new G2,...en.createCallbacks(t)];n!=null&&u.push(...n),u.push(c);const h=new U2(u);return h.setParams({epochs:e,initialEpoch:s,samples:o,steps:r,batchSize:i,verbose:t,doValidation:a,metrics:l}),{callbackList:h,history:c}}function _n(n,t={},e=!1){return Ei(n,nn.getMap().classNameMap,t,"layer",e)}function wa(n,t){return _(()=>{n.dtype!=="float32"&&(n=st(n,"float32"));const e=ct(Di(n),t,!0),s=Bl(e.shape,oe()),o=Ie(ks(e,s));return ut(n,o)})}function Jl(n,t){return _(()=>ee(Di(pt(t,n)),-1))}function vd(n,t){return _(()=>ee(Ne(pt(t,n)),-1))}function Sd(n,t){return _(()=>{const e=pt(n,t),s=Ye(Ne(n),oe(),Number.MAX_VALUE),o=Ne(ut(e,s));return R(100,ee(o,-1))})}function j2(n,t){return _(()=>{const e=Ye(t,oe(),Number.MAX_VALUE),s=Pn(Y(1,e)),o=Ye(n,oe(),Number.MAX_VALUE),r=Pn(Y(1,o));return ee(Di(pt(s,r)),-1)})}function q2(n,t){return _(()=>{const e=ks(0,pt(1,R(n,t)));return ee(Di(e),-1)})}function X2(n,t){return _(()=>{const e=ks(0,pt(1,R(n,t)));return ee(e,-1)})}function Y2(n,t){return _(()=>{const e=ct(R(n,t),-1),s=bn(R(pt(1,n),t),-1);return ks(0,Y(1,pt(s,e)))})}function J2(n,t){return _(()=>{const e=Math.log(2),s=pt(t,n),o=pt(Y(s,$i(R(-2,s))),e);return ee(o,-1)})}function br(n,t,e=!1){return _(()=>{if(e)t=Eh(t);else{const s=ct(t,t.shape.length-1,!0);t=ut(t,s)}return t=Ye(t,oe(),1-oe()),Yt(ct(R(st(n,"float32"),Pn(t)),t.shape.length-1))})}function Ca(n,t,e=!1){return _(()=>{const s=st(Ul(x2(n)),"int32");t=Ye(t,oe(),1-oe());const o=t.shape,r=A(Gm(s,o[o.length-1]),o);return br(r,t,e)})}function Z2(n,t){if(!Et(n.shape,t.shape))throw new E(`logits and labels must have the same shape, but got shapes ${JSON.stringify(n.shape)} and ${JSON.stringify(t.shape)}`);return _(()=>{const e=ro(t),s=Yt(Ne(t));return Y(pt(e,R(t,n)),Bm(Mn(s)))})}function Zl(n,t){return _(()=>{let e;return e=Ye(t,oe(),1-oe()),e=Pn(ut(e,pt(1,e))),ee(Z2(n,e),-1)})}function Q2(n,t){return _(()=>{const e=Ye(n,oe(),1),s=Ye(t,oe(),1);return ct(R(n,Pn(ut(e,s))),-1)})}function tT(n,t){return _(()=>{const e=Pn(Y(oe(),t));return ee(pt(t,R(n,e)),-1)})}function Cx(n,t){return _(()=>{const e=wa(n,-1),s=wa(t,-1),o=R(e,s);return Yt(ct(o,-1))})}const $a={meanSquaredError:Jl,meanAbsoluteError:vd,meanAbsolutePercentageError:Sd,meanSquaredLogarithmicError:j2,squaredHinge:q2,hinge:X2,categoricalHinge:Y2,logcosh:J2,categoricalCrossentropy:br,sparseCategoricalCrossentropy:Ca,binaryCrossentropy:Zl,kullbackLeiblerDivergence:Q2,poisson:tT,cosineProximity:Cx};function Cc(n){if(typeof n=="string"){if(n in $a)return $a[n];let t=`Unknown loss ${n}`;throw n.toLowerCase().includes("softmaxcrossentropy")&&(t=`Unknown loss ${n}. Use "categoricalCrossentropy" as the string name for tf.losses.softmaxCrossEntropy`),new E(t)}else return n}function $x(n,t){return _(()=>{const e=R(.5,an(t)),s=Fn(Je(t,e),n.dtype);return ee(Ln(n,s),-1)})}function Ix(n,t){return _(()=>Fn(Ln(dr(n,-1),dr(t,-1)),"float32"))}function eT(n,t){return _(()=>st(ct(jn(Ln(n,1),Ln(t,1))),"float32"))}function nT(n,t){return _(()=>st(ct(jn(Ln(n,0),Ln(t,1))),"float32"))}function sT(n,t){return _(()=>{const e=eT(n,t),s=nT(n,t),o=Y(e,s);return st(Re(Je(o,0),ut(e,o),0),"float32")})}function oT(n,t){return Zl(n,t)}function rT(n,t){return n.rank===t.rank&&(n=ki(n,[n.rank-1])),t=dr(t,-1),t.dtype!==n.dtype&&(t=st(t,n.dtype)),st(Ln(n,t),"float32")}const iT=Jl,aT=Jl,lT=vd,cT=vd,uT=Sd,hT=Sd,kx=br,dT=Cx,vx=Ca,Ia={binaryAccuracy:$x,categoricalAccuracy:Ix,precision:sT,categoricalCrossentropy:kx,sparseCategoricalCrossentropy:vx,mse:iT,MSE:aT,mae:lT,MAE:cT,mape:uT,MAPE:hT,cosine:dT};function pT(n){if(typeof n=="string"&&n in Ia)return Ia[n];if(typeof n!="string"&&n!=null)return n;throw new E(`Unknown metric ${n}`)}function qi(n){if(Nn(n!==null,`Unknown LossOrMetricFn ${n}`),typeof n=="string")return n;{let t;for(const e of Object.keys($a))if($a[e]===n){t=e;break}if(t!==void 0)return t;for(const e of Object.keys(Ia))if(Ia[e]===n){t=e;break}return t!==void 0?t:n.name}}function fT(n){const t={Adagrad:()=>fo.adagrad(.01),Adadelta:()=>fo.adadelta(1,.95,oe()),Adam:()=>fo.adam(.001,.9,.999,oe()),Adamax:()=>fo.adamax(.002,.9,.999,oe(),0),RMSProp:()=>fo.rmsprop(.001,.9,0,oe()),SGD:()=>fo.sgd(.01)};if(t.adagrad=t.Adagrad,t.adadelta=t.Adadelta,t.adam=t.Adam,t.adamax=t.Adamax,t.rmsprop=t.RMSProp,t.sgd=t.SGD,n in t)return t[n]();throw new E(`Unknown Optimizer ${n}`)}const Pp=1*1024*1024;function zp(n,t,e=!1){if(n==null||typeof n!="object"||Object.getPrototypeOf(n)!==Object.prototype||!su(n))throw new Error("User-defined metadata is expected to be a JSON object, but is not.");if(e){const s=JSON.stringify(n);s.length>Pp&&console.warn(`User-defined metadata of model "${t}" is too large in size (length=${s.length} when serialized). It is not recommended to store such large objects in user-defined metadata. Please make sure its serialized length is <= ${Pp}.`)}}function su(n){if(n===null)return!0;if(typeof n=="object")if(Object.getPrototypeOf(n)===Object.prototype){const t=Object.keys(n);for(const e of t)if(typeof e!="string"||!su(n[e]))return!1;return!0}else if(Array.isArray(n)){for(const t of n)if(!su(t))return!1;return!0}else return!1;else{const t=typeof n;return t==="string"||t==="number"||t==="boolean"}}function mT(n,t,e,s=console.log){const o=xT(n),r=["Layer (type)","Input Shape","Output shape","Param #"];o?(t=t||90,e=e||[.32,.61,.89,1]):(t=t||115,e=e||[.24,.48,.7,.8,1]),e[e.length-1]<=1&&(e=e.map(u=>Math.floor(t*u)));let i;if(!o){r.push("Receives inputs"),i=[];for(const u in n.nodesByDepth)i.push(...n.nodesByDepth[u])}s("_".repeat(t)),ka(r,e,s),s("=".repeat(t));const a=n.layers;for(let u=0;u<a.length;++u)o?bT(a[u],e,s):yT(a[u],e,i,s),s((u===a.length-1?"=":"_").repeat(t));n.checkTrainableWeightsConsistency();const l=gT(n),c=xa(n.nonTrainableWeights);s(`Total params: ${l+c}`),s(`Trainable params: ${l}`),s(`Non-trainable params: ${c}`),s("_".repeat(t))}function gT(n){let t;return n.collectedTrainableWeights!=null?t=xa(n.collectedTrainableWeights):t=xa(n.trainableWeights),t}function xT(n){let t=!0;const e=[],s=[];for(const o in n.nodesByDepth)e.push(n.nodesByDepth[o]);for(const o of e){if(o.length>1||o.length===1&&o[0].inboundLayers.length>1){t=!1;break}s.push(...o)}if(t)for(const o of n.layers){let r=!1;for(const i of o.inboundNodes)if(s.indexOf(i)!==-1)if(r){t=!1;break}else r=!0;if(!t)break}return t}function ka(n,t,e=console.log){let s="";for(let o=0;o<n.length;++o)o>0&&(s=s.slice(0,s.length-1)+" "),s+=n[o],s=s.slice(0,t[o]),s+=" ".repeat(t[o]-s.length);e(s)}function bT(n,t,e){let s,o;try{o=n.inboundNodes.map(l=>JSON.stringify(l.inputShapes)).join(",")}catch{o="multiple"}try{s=JSON.stringify(n.outputShape)}catch{s="multiple"}const r=n.name,i=n.getClassName(),a=[`${r} (${i})`,o,s,n.countParams().toString()];ka(a,t,e)}function yT(n,t,e,s){let o,r;try{r=n.inboundNodes.map(h=>JSON.stringify(h.inputShapes)).join(",")}catch{r="multiple"}try{o=JSON.stringify(n.outputShape)}catch{o="multiple"}const i=[];for(const h of n.inboundNodes)if(!(e!=null&&e.length>0&&e.indexOf(h)===-1))for(let d=0;d<h.inboundLayers.length;++d){const p=h.inboundLayers[d].name,f=h.nodeIndices[d],m=h.tensorIndices[d];i.push(`${p}[${f}][${m}]`)}const a=n.name,l=n.getClassName(),c=i.length===0?"":i[0],u=[`${a} (${l})`,r,o,n.countParams().toString(),c];ka(u,t,s);for(let h=1;h<i.length;++h)ka(["","","","",i[h]],t,s)}function Sx(n,t,e){return(n==="inboundNodes"||n==="outputLayers"||n==="inputLayers")&&t===0&&typeof e=="string"}function va(n,t){if(n===null)return null;if(typeof n=="string")return _s(n);if(typeof n=="number"||typeof n=="boolean")return n;if(n instanceof Array){const e=[],s=n.length;for(let o=0;o<s;++o){const r=n[o];Sx(t,o,r)?e.push(r):e.push(va(r,t))}return e}else{const e={};for(const s of Object.keys(n)){const o=n[s];if(s==="name"&&typeof o=="string")e[s]=o;else{const r=_s(s);e[r]=va(o,r)}}return e}}function ou(n,t){if(n==null)return null;if(typeof n=="string")return Gn(n);if(typeof n=="number"||typeof n=="boolean")return n;if(n instanceof Array){const e=[],s=n.length;for(let o=0;o<s;++o){const r=n[o];Sx(t,o,r)?e.push(r):e.push(ou(r,t))}return e}else{const e={};for(const s of Object.keys(n)){const o=n[s],r=Gn(s);(s==="name"||s==="className")&&typeof o=="string"?e[r]=o:e[r]=ou(o,s)}return e}}const Nx="4.22.0";const wT=n=>{const t=Object.keys(n);if(t.length===0)return!1;const e=t[0].split("/");return!isNaN(parseInt(e[e.length-1],10))};class pn extends $t{constructor(t){if(super({}),this.containerNodes=new Set,this.name=t.name,this.name==null){const b=this.getClassName().toLowerCase();this.name=ql(b)}if(this.supportsMasking=!1,this.trainable_=!0,Array.isArray(t.inputs)?this.inputs=t.inputs.slice():this.inputs=[t.inputs],Array.isArray(t.outputs)?this.outputs=t.outputs.slice():this.outputs=[t.outputs],hs(this.inputs).length!==this.inputs.length)throw new E(`The list of inputs passed to the model is redundant. All inputs should only appear once. Found: ${this.inputs.map(b=>b.name)}`);hs(this.outputs).length!==this.outputs.length&&console.warn(`The list of outputs passed to the model is redundant. All outputs should only appear once. Found: ${this.outputs.map(b=>b.name)}`),this.inputLayers=[],this.inputLayersNodeIndices=[],this.inputLayersTensorIndices=[],this.outputLayers=[],this.outputLayersNodeIndices=[],this.outputLayersTensorIndices=[],this.layers=[],this.internalContainerRefs=[];for(const b of this.outputs){const w=b.sourceLayer,y=b.nodeIndex,C=b.tensorIndex;this.outputLayers.push(w),this.outputLayersNodeIndices.push(y),this.outputLayersTensorIndices.push(C)}for(const b of this.inputs){const w=b.sourceLayer,y=b.nodeIndex,C=b.tensorIndex;Nn(y===0,"input layer has >1 nodes"),Nn(C===0,"input layer has >1 tensors"),this.inputLayers.push(w),this.inputLayersNodeIndices.push(y),this.inputLayersTensorIndices.push(C)}this.inputNames=[],this.outputNames=[],this.feedInputShapes=[],this.feedInputNames=[],this.feedOutputNames=[];for(let b=0;b<this.inputLayers.length;b++){const w=this.inputLayers[b];if(!(w instanceof Fi))throw new TypeError(`Input layers to a LayersModel must be InputLayer objects. Received inputs: ${t.inputs}. Input ${b} (0-based) originates from layer type ${w.getClassName()}.`);this.inputNames.push(w.name),this.feedInputShapes.push(w.batchInputShape),this.feedInputNames.push(w.name)}for(const b of this.outputLayers)this.outputNames.push(b.name);this.internalInputShapes=this.inputs.map(b=>b.shape),this.internalOutputShapes=this.outputs.map(b=>b.shape);const e={},s={},o={},r={},i={},a=[],l=(b,w,y,C,I,k)=>{(C==null||I==null||k==null)&&(C=b.sourceLayer,I=b.nodeIndex,k=b.tensorIndex);const v=C.inboundNodes[I];if(y.indexOf(v)!==-1)throw new sn(`The tensor ${b.name} at layer "${C.name}" is part of a cycle.`);if(w.indexOf(v)!==-1)return;this.containerNodes.add(pn.nodeKey(C,I)),C.id in i||(i[C.id]=Object.keys(i).length),y.indexOf(v)===-1&&y.push(v);const N=v.inboundLayers.length;for(let T=0;T<N;T++){const O=v.inputTensors[T],P=v.inboundLayers[T],z=v.nodeIndices[T],B=v.tensorIndices[T];l(O,w,y,P,z,B)}for(w.push(v);y.indexOf(v)>=0;)y.splice(y.indexOf(v),1);a.push(v)},c=[],u=[];for(const b of this.outputs)l(b,c,u);const h=a.slice().reverse();for(const b of h){s[b.id]=b,b.id in e||(e[b.id]=0);let w=e[b.id];const y=o[b.outboundLayer.id]==null?0:o[b.outboundLayer.id];w=Math.max(w,y),o[b.outboundLayer.id]=w,r[b.outboundLayer.id]=b.outboundLayer,e[b.id]=w;for(let C=0;C<b.inboundLayers.length;C++){const I=b.inboundLayers[C],k=b.nodeIndices[C],v=I.inboundNodes[k],N=e[v.id]==null?0:e[v.id];e[v.id]=Math.max(w+1,N),s[v.id]=v}}const d={};for(const b in e){const w=e[b];w in d||(d[w]=[]),d[w].push(s[b])}const p={};for(const b in o){const w=o[b];w in p||(p[w]=[]),p[w].push(r[b])}let f=Object.keys(p).map(b=>parseInt(b,10)).sort(Hi);this.layers=[];for(const b of f){const w=p[b];w.sort((y,C)=>{const I=i[y.id],k=i[C.id];return I<k?-1:I>k?1:0});for(const y of w)y instanceof pn&&this.internalContainerRefs.push(y),this.layers.push(y)}this.layersByDepth=p,f=Object.keys(d).map(b=>parseInt(b,10)).sort(Hi);const m=this.inputs.slice(),g=[];for(const b of f)for(const w of d[b]){const y=w.outboundLayer;if(y!=null){for(const C of w.inputTensors)if(m.indexOf(C)===-1)throw new sn(`Graph disconnected: cannot obtain value for tensor ${C} at layer "${y.name}". The following previous layers were accessed without issue: ${g}`);for(const C of w.outputTensors)m.push(C);g.push(y.name)}}this.nodesByDepth=d;const x=this.layers.map(b=>b.name);for(const b of x){const w=x.filter(y=>y===b).length;if(w!==1)throw new sn(`The name "${b}" is used ${w} times in the model. All layer names should be unique. Layer names: `+JSON.stringify(x))}this.outboundNodes=[],this.inboundNodes=[],new Yl({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:this.inputs,outputTensors:this.outputs,inputMasks:this.inputs.map(b=>null),outputMasks:this.outputs.map(b=>null),inputShapes:this.inputs.map(b=>b.shape),outputShapes:this.outputs.map(b=>b.shape)}),this.built=!0,this._refCount=1}assertNotDisposed(){if(this._refCount===0)throw new Error(`Container '${this.name}' is already disposed.`)}dispose(){this.assertNotDisposed();const t={refCountAfterDispose:null,numDisposedVariables:0};if(--this._refCount===0){for(const e of this.layers)t.numDisposedVariables+=e.dispose().numDisposedVariables;for(const e of this.internalContainerRefs)t.numDisposedVariables+=e.dispose().numDisposedVariables}return t.refCountAfterDispose=this._refCount,t}get trainable(){return this.trainable_}set trainable(t){this.layers.forEach(e=>{e._trainableWeights.forEach(s=>s.trainable=t)}),this.trainable_=t}get trainableWeights(){if(this._trainableWeights.length>0)throw new E("Container instance unexpectedly contains _trainableWeights.The trainable weights of a Container are a union of the trainable weights of its consituent Layers. Its own _trainableWeights must remain an empty Array.");if(!this.trainable)return[];let t=[];for(const e of this.layers)t=t.concat(e.trainableWeights);return t}get nonTrainableWeights(){const t=[];for(const e of this.layers)t.push(...e.nonTrainableWeights);if(!this.trainable){const e=[];for(const s of this.layers)e.push(...s.trainableWeights);return e.concat(t)}return t}get weights(){return this.trainableWeights.concat(this.nonTrainableWeights)}loadWeights(t,e=!0){const s={};let o=0;const r=wT(t);r&&this.parseWeights(t);for(const a of this.layers)for(const[l,c]of a.weights.entries()){const u=r?`${c.name.split("/").slice(0,-1).join("/")+"/"}${l}`:c.originalName;if(s[u]!=null)throw new E(`Duplicate weight name: ${u}`);s[u]=c,o++}const i=[];for(const a in t){let l=a;if(s[a]==null){const c=a.split("/");l=c.slice(0,-2).concat([c[c.length-1]]).join("/")}if(s[l]!=null)i.push([s[l],t[a]]);else if(e)throw new E(`Provided weight data has no target variable: ${a}`);delete s[l]}if(e){const a=[];for(const l in s)a.push(l);if(a.length>0)throw new E(`${a.length} of ${o} weights are not set: ${a}`)}Id(i)}parseWeights(t){for(const e in Object.keys(t)){const s=e.split("/"),o=["vars","layer_checkpoint_dependencies"],r=s.map(i=>i.startsWith("_")?i.slice(1):i).filter(i=>!o.includes(i)).join("/");r!==e&&(t[r]=t[e],delete t[e])}}updatedConfig(){const t=this.getConfig(),e={};return e.className=this.getClassName(),e.config=t,e.kerasVersion=`tfjs-layers ${Nx}`,e.backend="TensorFlow.js",e}toJSON(t,e=!0){const s=ou(this.updatedConfig());return e?JSON.stringify(s):s}call(t,e){return _(()=>{t=Dt(t);const s=new as;for(let o=0;o<this.inputs.length;++o)s.add(this.inputs[o],t[o]);return rr(this.outputs,s,e)})}computeMask(t,e){return _(()=>{t=Dt(t);let s;return e==null?s=Qs(null,t.length):s=Dt(e),this.runInternalGraph(t,s)[1]})}computeOutputShape(t){const e=ga(t);if(e.length!==this.inputLayers.length)throw new E(`Invalid inputShape argument ${t}: model has ${this.inputLayers.length} tensor inputs.`);const s={};for(let a=0;a<e.length;a++){const l=this.inputLayers[a],c=e[a],u=l.name+"_0_0";s[u]=c}const o=Object.keys(this.nodesByDepth).map(a=>parseInt(a,10)).sort(Hi);if(o.length>1)for(const a of o){const l=this.nodesByDepth[a];for(const c of l){const u=c.outboundLayer;if(this.inputLayers.map(m=>m.id).indexOf(u.id)!==-1)continue;const h=[];for(let m=0;m<c.inboundLayers.length;m++){const g=c.inboundLayers[m],x=c.nodeIndices[m],b=c.tensorIndices[m],w=`${g.name}_${x}_${b}`,y=s[w];h.push(y)}const d=u.computeOutputShape(_e(h)),p=ga(d),f=u.inboundNodes.indexOf(c);for(let m=0;m<p.length;m++){const g=`${u.name}_${f}_${m}`;s[g]=p[m]}}}const r=[],i=[];for(let a=0;a<this.outputLayers.length;a++){const l=this.outputLayers[a],c=this.outputLayersNodeIndices[a],u=this.outputLayersTensorIndices[a],h=`${l.name}_${c}_${u}`;i.push(h)}for(let a=0;a<i.length;a++){const l=i[a];Nn(l in s),r.push(s[l])}return _e(r)}runInternalGraph(t,e){e==null&&(e=Qs(null,t.length));const s={};for(let l=0;l<this.inputs.length;++l){const c=this.inputs[l],u=t[l],h=e[l];s[c.id]=[u,h]}const o=Object.keys(this.nodesByDepth).map(l=>parseInt(l,10)).sort(Hi);for(const l of o){const c=this.nodesByDepth[l];for(const u of c){const h=u.outboundLayer,d=u.inputTensors,p=u.outputTensors,f=new Array;for(const m of d)m.id in s&&f.push(s[m.id]);if(f.length===d.length){let m={},g,x,b,w;if(u.callArgs!=null&&(m=u.callArgs),f.length===1){const[y,C]=f[0];m.mask==null&&(m.mask=C),b=Dt(h.call(y,m)),w=Dt(h.computeMask(y,C)),g=[y],x=[C]}else g=f.map(y=>y[0]),x=f.map(y=>y[1]),m.mask==null&&(m.mask=x),b=Dt(h.call(g,m)),w=Dt(h.computeMask(g,x));if(h.activityRegularizer)throw new xt("LayersModel invocation with concrete Tensor value(s) in the presence of activity regularizer(s) is not supported yet.");for(let y=0;y<p.length;++y){const C=p[y],I=b[y],k=w[y];s[C.id]=[I,k]}}}}const r=[],i=[],a=[];for(const l of this.outputs){Nn(l.id in s,`Could not compute output ${l.name} : ${l.id}`);const[c,u]=s[l.id];a.push(c.shape),r.push(c),i.push(u)}return[r,i,a]}buildNodeConversionMap(t){const e={};let s;for(const o of this.layers){s=o instanceof pn?1:0;for(let r=0;r<o.inboundNodes.length;r++){const i=pn.nodeKey(o,r);this.containerNodes.has(i)&&(e[i]=s,s+=1)}}return e}getLayer(t,e){if(e!=null)return this.findLayer(e);if(t==null)throw new E("Provide either a layer name or layer index");if(typeof t=="number")return this.findLayer(t);for(const s of this.layers)if(s.name===t)return s;throw new E(`No such layer: ${t}`)}findLayer(t){if(this.layers.length<=t)throw new E(`Was asked to retrieve layer at index ${t}, but model only has ${this.layers.length} layer(s).`);return this.layers[t]}calculateLosses(){return _(()=>{const t=[];for(const e of this.layers)for(let s=0;s<e.inboundNodes.length;++s){const o=pn.nodeKey(e,s);this.containerNodes.has(o)&&t.push(...e.calculateLosses())}return t})}getConfig(){const t={name:this.name},e=this.buildNodeConversionMap(this.layers),s=[];for(const i of this.layers){const a=i.getClassName(),l=i.getConfig(),c=[];for(let h=0;h<i.inboundNodes.length;h++){const d=i.inboundNodes[h],p=pn.nodeKey(i,h);let f={};if(this.containerNodes.has(p)){if(d.callArgs)try{JSON.stringify(d.callArgs),f=d.callArgs}catch{console.warn(`Layer ${i.name} was passed non-serializable keyword arguments: ${d.callArgs}. They will not be included in the serialized model (and thus will be missing at deserialization time).`),f={}}if(d.inboundLayers.length>0){const m=[];for(let g=0;g<d.inboundLayers.length;g++){const x=d.inboundLayers[g],b=d.nodeIndices[g],w=d.tensorIndices[g],y=pn.nodeKey(x,b);let C=e[y];C==null&&(C=0),m.push([x.name,C,w,f])}c.push(m)}}}const u={};u.name=i.name,u.className=a,u.config=l,u.inboundNodes=c,s.push(u)}t.layers=s;const o=[];for(let i=0;i<this.inputLayers.length;i++){const a=this.inputLayers[i],l=this.inputLayersNodeIndices[i],c=pn.nodeKey(a,l);if(!this.containerNodes.has(c))continue;let u=e[c];u==null&&(u=0);const h=this.inputLayersTensorIndices[i];o.push([a.name,u,h])}t.inputLayers=o;const r=[];for(let i=0;i<this.outputLayers.length;i++){const a=this.outputLayers[i],l=this.outputLayersNodeIndices[i],c=pn.nodeKey(a,l);if(!this.containerNodes.has(c))continue;let u=e[c];u==null&&(u=0);const h=this.outputLayersTensorIndices[i];r.push([a.name,u,h])}return t.outputLayers=r,t}static fromConfig(t,e,s={},o=!1){const r={},i={};function a(g,x){g.name in i?i[g.name].push(x):i[g.name]=[x]}function l(g,x){const b=[];let w;for(const y of x){const C=y[0],I=y[1],k=y[2];if(w=y[3]==null?{}:y[3],!(C in r)){a(g,x);return}const v=r[C];if(v.inboundNodes.length<=I){a(g,x);return}const N=v.inboundNodes[I];b.push(N.outputTensors[k])}b.length>0&&g.apply(_e(b),w)}function c(g){const x=g.name,b=_n(g,e.customObjects!=null?e.customObjects:{});b.setFastWeightInitDuringBuild(o),r[x]=b,g.inboundNodes.forEach(y=>{if(!(y instanceof Array))throw new E(`Corrupted configuration, expected array for nodeData: ${y}`);a(b,y)})}const u=e.name,h=e.layers;for(const g of h)c(g);for(;!o2(i);)for(const g of h){const x=r[g.name];if(x.name in i){const b=i[x.name];delete i[x.name];for(const w of b)l(x,w)}}const d=[],p=[],f=e.inputLayers;for(const g of f){const x=g[0],b=g[1],w=g[2];Nn(x in r);const C=r[x].inboundNodes[b].outputTensors;d.push(C[w])}const m=e.outputLayers;for(const g of m){const x=g[0],b=g[1],w=g[2];Nn(x in r);const C=r[x].inboundNodes[b].outputTensors;p.push(C[w])}return new t({inputs:d,outputs:p,name:u})}get stateful(){if(this._stateful)throw new E("Container instance unexpectedly has _stateful = true. The statefulness of a Container is determined by the Layers it contains. Its _stateful property must remain the default false.");for(const t of this.layers)if(t.stateful)return!0;return!1}resetStates(){_(()=>{this.layers.forEach(t=>{t.stateful&&t.resetStates()})})}}function CT(n,t,e){const s=t.length;if(n==null||Array.isArray(n)&&n.length===0)return t.map(o=>null);if(s===1)return Array.isArray(n)&&n.length===1?n:typeof n=="object"&&t[0]in n?[n[t[0]]]:[n];if(Array.isArray(n)){if(n.length!==s)throw new Error(`Provided ${e} is an array of ${n.length} element(s), but the model has ${s} outputs. Make sure a set of weights is provided for each model output.`);return n}else if(typeof n=="object"&&Object.keys(n).length>0&&typeof n[Object.keys(n)[0]]=="object"){const o=[];return t.forEach(r=>{r in n?o.push(n[r]):o.push(null)}),o}else throw new Error(`The model has multiple (${s}) outputs, so ${e} must be either an array with ${s} elements or an object with ${t} keys. Provided ${e} not understood: ${JSON.stringify(n)}`)}function Tx(n,t){return CT(n,t,"classWeight")}async function Ex(n,t,e,s){if(e!=null){const o=_(()=>{if(n.shape.length===1)return zs(n);if(n.shape.length===2){if(n.shape[1]>1)return dr(n,1);if(n.shape[1]===1)return A(n,[n.shape[0]]);throw new Error(`Encountered unexpected last-dimension size (${n.shape[1]}) during handling of class weights. The size is expected to be >= 1.`)}else throw new Error(`Unexpected rank of target (y) tensor (${n.rank}) during handling of class weights. The rank is expected to be 1 or 2.`)}),r=Array.from(await o.data());yt(o);const i=[];return r.forEach(a=>{if(e[a]==null)throw new Error(`classWeight must contain all classes in the training data. The class ${a} exists in the data but not in classWeight`);i.push(e[a])}),We(i,"float32")}else return null}function $T(n,t){return R(n,t)}const IT=32;function Rx(n,t){let e,s;const o=t;e=o.xs,s=o.ys,$(e!=null&&s!=null,()=>`A Dataset iterator for fitDataset() is expected to generate objects of the form \`{xs: xVal, ys: yVal}\`, where the two values may be \`tf.Tensor\`, an array of Tensors, or a map of string to Tensor.  The provided Dataset instead generates ${t}`);const r=Bp("input",n.inputNames,e),i=Bp("output",n.outputNames,s),a=r[0].shape[0];$(r.length===n.inputs.length,()=>`LayersModel has ${n.inputs.length} inputs, but the dataset provides ${r.length} inputs.  (Expected input keys: ${JSON.stringify(n.inputNames)})`),$(i.length===n.outputs.length,()=>`LayersModel has ${n.outputs.length} outputs, but the dataset provides ${i.length} outputs.  (Expected output keys: ${JSON.stringify(n.outputNames)})`);for(let l=0;l<r.length;l++)$(r[l].shape[0]===a,()=>`Batch size mismatch: input ${n.inputNames[l]} has ${r[l].shape[0]}; expected  ${a} based on input ${n.inputNames[0]}.`);for(let l=0;l<i.length;l++)$(i[l].shape[0]===a,()=>`Batch size mismatch: output ${n.outputNames[l]} has ${i[l].shape[0]}; expected  ${a} based on input ${n.inputNames[0]}.`);return{xs:r,ys:i}}function Bp(n,t,e){if(e instanceof se)return[e];if(Array.isArray(e))return $(e.length===t.length,()=>`Received an array of ${e.length} Tensors, but expected ${t.length} to match the ${n} keys ${t}.`),e;{const s=[];for(const o of t){if(e[o]==null)throw new E(`The feature data generated by the dataset lacks the required ${n} key '${o}'.`);s.push(e[o])}return s}}function kT(n){if(n.length===3)throw new xt("Validation with sample weights is not implemented yet.");return{xs:n[0],ys:n[1]}}async function vT(n,t,e){const s=e.batchesPerEpoch!=null;if($(n.optimizer!=null,()=>"You must compile a model before training/testing. Use LayersModel.compile(modelCompileConfig)."),$(e!=null,()=>"For fitDataset(), the 2nd argument (config) is required, but it is not provided in this call."),$(e.epochs!=null&&e.epochs>0&&Number.isInteger(e.epochs),()=>`For fitDataset(), config.epochs is expected to be a positive integer, but got ${e.epochs}`),$(!s||e.batchesPerEpoch>0&&Number.isInteger(e.batchesPerEpoch),()=>`For fitDataset(), config.batchesPerEpoch is expected to be a positive integer if specified, but got ${e.batchesPerEpoch}`),$(e.validationSplit==null,()=>"`validationSplit` is not supported by `fitDataset()`. Use validationData instead."),n.isTraining)throw new Error("Cannot start training because another fit() call is ongoing.");n.isTraining=!0;try{const o=e.validationData!=null;let r,i;if(o)if(Vp(e.validationData))$(e.validationBatches==null||e.validationBatches>0&&Number.isInteger(e.validationBatches),()=>`For fitDataset() with dataset-based validation, config.validationBatches is expected not to be provided, or to be a positive integer, but got ${e.validationBatches}`);else{const g=kT(e.validationData);r=g.xs,i=g.ys}const a=n.makeTrainFunction(),l=n.getDedupedMetricsNames();let c;o?c=l.slice().concat(l.map(g=>"val_"+g)):c=l.slice();const u=yx(e.callbacks,e.yieldEvery),h=e.verbose==null?1:e.verbose,{callbackList:d,history:p}=wx(u,h,e.epochs,null,null,ST(t,e),null,o,c);d.setModel(n),n.history=p,await d.onTrainBegin(),n.stopTraining_=!1;let f=e.initialEpoch==null?0:e.initialEpoch,m=await t.iterator();for(;f<e.epochs;){const g={};await d.onEpochBegin(f);let x=0,b=0;for(s||(m=await t.iterator());!s||x<e.batchesPerEpoch;){const w=await m.next();if(s&&w.done){console.warn(`You provided \`batchesPerEpoch\` as ${e.batchesPerEpoch}, but your dataset iterator ran out of data after ${x} batches; interrupting training. Make sure that your dataset can generate at least \`batchesPerEpoch * epochs\` batches (in this case, ${e.batchesPerEpoch*e.epochs} batches). You may need to use the repeat() function when building your dataset.`);break}if(w.value!=null){const{xs:y,ys:C}=Rx(n,w.value),I={};I.batch=b,I.size=y[0].shape[0],await d.onBatchBegin(b,I);const k=[];if(e.classWeight!=null){const T=Tx(e.classWeight,n.outputNames);for(let O=0;O<T.length;++O)k.push(await Ex(C[O],null,T[O]))}const v=y.concat(C).concat(k),N=a(v);yt(v);for(let T=0;T<l.length;++T){const O=l[T],P=N[T];I[O]=P,Dn(P)}await d.onBatchEnd(b,I),bx(I),b++,x++}if(s?x>=e.batchesPerEpoch:w.done){if(o){let y;Vp(e.validationData)?y=Dt(await n.evaluateDataset(e.validationData,{batches:e.validationBatches})):y=Dt(n.evaluate(r,i,{batchSize:e.validationBatchSize==null?IT:e.validationBatchSize,verbose:0}));for(let C=0;C<n.metricsNames.length;++C)g[`val_${n.metricsNames[C]}`]=y[C]}break}if(n.stopTraining_)break}if(await d.onEpochEnd(f,g),f++,n.stopTraining_)break}return await d.onTrainEnd(),await n.history.syncData(),n.history}finally{n.isTraining=!1}}function ST(n,t){let e=null;return t.batchesPerEpoch!=null?e=t.batchesPerEpoch:Number.isFinite(n.size)&&(e=n.size),e}function Vp(n){return typeof n.iterator=="function"}function NT(n){return typeof n.next=="function"}async function TT(n,t,e){e=e||{};const s=e.batches!=null,o=n.testFunction;let r=[];if(e.verbose>0)throw new xt("Verbose mode is not implemented yet.");$(!s||e.batches>0&&Number.isInteger(e.batches),()=>`Test loop expects \`batches\` to be a positive integer, but received ${JSON.stringify(e.batches)}`);const i=NT(t)?t:await t.iterator();let a=0,l=0;for(;!s||l<e.batches;){const c=await i.next();if(r=_(()=>{if(c.value){const{xs:u,ys:h}=Rx(n,c.value),d=u.concat(h),p=_(()=>o(d));if(yt(d),l===0)for(let m=0;m<p.length;++m)r.push(Tt(0));const f=d[0].shape[0];for(let m=0;m<p.length;++m){const g=p[m],x=r[m];r[m]=_(()=>Y(r[m],R(f,g))),l>0&&yt(x)}yt(p),a+=f,++l}return r}),c.done){s&&console.warn(`Your dataset iterator ran out of data during evaluateDataset(). Interrupting evalution. Make sure that your dataset can generate at least \`batches\` batches (in this case, ${e.batches} batches). You may need to use the repeat() function when building your dataset.`);break}}for(let c=0;c<r.length;++c){const u=r[c];r[c]=ut(r[c],a),yt(u)}return _e(r)}function $c(n){$(n>0&&Number.isInteger(n),()=>`batchSize is required to be a positive integer, but got ${n}`)}function er(n,t,e){return n==null?[null]:Array.isArray(n)?n.map(s=>Vs(s,t,e-t)):Vs(n,t,e-t)}function ru(n,t){return _(()=>n==null?null:Array.isArray(n)?n.map(e=>ru(e,t)):ox(n,t.dtype==="int32"?t:st(t,"int32")))}function Ic(n,t){const e=[];let s=0,o=null;for(;s<n;)o=s+t,o>=n&&(o=n),e.push([s,o]),s=o;return e}function Dx(n){const t=[];n instanceof se&&(n=[n]);for(let e=0;e<n.length;++e){const s=n[e];if(s.rank===1)t.push(Ri(s,1));else{if(s.rank===0)throw new Error("Expected tensor to be at least 1D, but received a 0D tensor (scalar).");t.push(s)}}return t}function dn(n,t){if(n==null)return;const e=[];if(t instanceof se)e.push(t.id);else if(Array.isArray(t))t.forEach(o=>e.push(o.id));else if(t!=null)for(const o in t){const r=t[o];e.push(r.id)}const s=[];if(n instanceof se)e.indexOf(n.id)===-1&&s.push(n);else if(Array.isArray(n))n.forEach(o=>{e.indexOf(o.id)===-1&&s.push(o)});else if(n!=null)for(const o in n){const r=n[o];e.indexOf(r.id)===-1&&s.push(r)}s.forEach(o=>{o.isDisposed||o.dispose()})}function ET(n){return n instanceof se}function iu(n){return Array.isArray(n)}function Wp(n){return!ET(n)&&!iu(n)}function Up(n,t,e,s=!0,o=""){if(t==null||t.length===0){if(n!=null){let i=!1;if(iu(n)&&n.length>0)i=!0;else if(Wp(n)){for(const a in n)if(n.hasOwnProperty(a)){i=!0;break}}else i=!0;if(i)throw new E(`Error when checking model ${o} expected no data, but got ${n}`)}return[]}if(n==null)return t.map(i=>null);let r;if(Wp(n)){n=n,r=[];for(const i of t){if(n[i]==null)throw new E(`No data provided for "${i}". Need data for each key in: ${t}`);r.push(n[i])}}else if(iu(n)){if(n=n,n.length!==t.length)throw new E(`Error when checking model ${o}: the Array of Tensors that you are passing to your model is not the size the model expected. Expected to see ${t.length} Tensor(s), but instead got the following list of Tensor(s): ${n}`);r=n}else{if(n=n,t.length>1)throw new E(`The model ${o} expects ${t.length} Tensor(s), but only received one Tensor. Found: Tensor with shape ${n.shape}`);r=[n]}if(r=Dx(r),e!=null)for(let i=0;i<t.length;++i){if(e[i]==null)continue;const a=r[i];if(a.shape.length!==e[i].length)throw new E(`Error when checking ${o}: expected ${t[i]} to have ${e[i].length} dimension(s). but got array with shape ${a.shape}`);for(let l=0;l<e[i].length;++l){if(l===0&&!s)continue;const c=a.shape[l],u=e[i][l];if(u!=null&&u>=0&&c!==u)throw new E(`${o} expected a batch of elements where each example has shape [${e[i].slice(1,e[i].length)}] (i.e.,tensor shape [*,${e[i].slice(1,e[i].length)}]) but the ${o} received an input with ${a.shape[0]} examples, each with shape [${a.shape.slice(1,a.shape.length)}] (tensor shape [${a.shape}])`)}}return r}function RT(n,t,e){const s=hs(n.map(r=>r.shape[0]));s.sort();const o=hs(t.map(r=>r.shape[0]));if(o.sort(),s.length>1)throw new E(`All input Tensors (x) should have the same number of samples. Got array shapes: ${JSON.stringify(n.map(r=>r.shape))}`);if(o.length>1)throw new E(`All target Tensors (y) should have the same number of samples. Got array shapes: ${JSON.stringify(t.map(r=>r.shape))}`);if(s.length>0&&o.length>0&&!Et(s,o))throw new E(`Input Tensors should have the same number of samples as target Tensors. Found ${s[0]} input sample(s) and ${o[0]} target sample(s).`)}function DT(n,t,e){const s=[Jl,Zl,br];for(let o=0;o<n.length;++o){const r=n[o],i=t[o],a=e[o];if(i!=null){if(i===br&&r.shape[r.shape.length-1]===1)throw new E(`You are passing a target array of shape ${r.shape} while using a loss 'categorical_crossentropy'. 'categorical_crossentropy'expects targets to be binary matrices (1s and 0s) of shape [samples, classes].`);if(s.indexOf(i)!==-1){const l=r.shape.slice(1),c=a.slice(1);for(let u=0;u<l.length;++u){const h=l[u],d=c[u];if(d!=null&&h!==d)throw new E(`A target Tensor with shape ${r.shape} was passed for an output of shape ${a}, while using a loss function that expects targets to have the same shape as the output.`)}}}}}function Gp(n,t,e,s=!0,o=""){let r;if(Array.isArray(n)){if(n.length!==t.length)throw new E(`Error when checking model ${o}: the Array of Tensors that you are passing to your model is not the size the the model expected. Expected to see ${t.length} Tensor(s), but instead got ${n.length} Tensors(s).`);r=n}else{if(t.length>1)throw new E(`The model expects ${t.length} ${o} Tensors, but only received one Tensor. Found: array with shape ${JSON.stringify(n.shape)}.`);r=[n]}if(e!=null)for(let i=0;i<t.length;++i){if(e[i]==null)continue;const a=r[i];if(a.shape.length!==e[i].length)throw new E(`Error when checking ${o}: expected ${t[i]} to have ${e[i].length} dimension(s), but got array with shape ${JSON.stringify(a.shape)}`);for(let l=0;l<e[i].length;++l){if(l===0&&!s)continue;const c=a.shape[l],u=e[i][l];if(u!=null&&u!==c)throw new E(`Error when checking ${o}: expected ${t[i]} to have shape ${JSON.stringify(e[i])} but got array with shape ${JSON.stringify(a.shape)}.`)}}}function AT(n,t){if(n==null||Array.isArray(n)&&n.length===0)return t.map(s=>[]);let e;if(typeof n=="string"||typeof n=="function")e=[n];else if(Array.isArray(n)||typeof n=="object")e=n;else throw new TypeError(`Type of metrics argument not understood. Expected an string,function, Array, or Object, found: ${n}`);if(Array.isArray(e))return t.map(s=>e);{const s=[];for(const o of t){let r=e.hasOwnProperty(o)?e[o]:[];Array.isArray(r)||(r=[r]),s.push(r)}return s}}const FT="layers-model";class Io extends pn{constructor(t){super(t),this.isTraining=!1}summary(t,e,s=console.log){if(!this.built)throw new E("This model has never been called, thus its weights have not been created yet. So no summary can be displayed. Build the model first (e.g., by calling it on some test data).");mT(this,t,e,s)}compile(t){if(t.loss==null&&(t.loss=[]),this.loss=t.loss,typeof t.optimizer=="string")this.optimizer_=fT(t.optimizer),this.isOptimizerOwned=!0;else{if(!(t.optimizer instanceof Ss))throw new E("User-defined optimizer must be an instance of tf.Optimizer.");this.optimizer_=t.optimizer,this.isOptimizerOwned=!1}let e=[];if(!Array.isArray(t.loss)&&typeof t.loss!="string"&&typeof t.loss!="function"){t.loss=t.loss;for(const i in t.loss)if(this.outputNames.indexOf(i)===-1)throw new E(`Unknown entry in loss dictionary: "${i}". Only expected the following keys: ${this.outputNames}`);for(const i of this.outputNames)t.loss[i]==null&&console.warn(`Output "${i}" is missing from loss dictionary. We assume this was done on purpose, and we will not be expecting data to be passed to ${i} during training`),e.push(Cc(t.loss[i]))}else if(Array.isArray(t.loss)){if(t.loss.length!==this.outputs.length)throw new E(`When passing an Array as loss, it should have one entry per model output. The model has ${this.outputs.length} output(s), but you passed loss=${t.loss}.`);e=t.loss.map(a=>Cc(a))}else{const i=Cc(t.loss);this.outputs.forEach(a=>{e.push(i)})}this.lossFunctions=e,this.feedOutputNames=[],this.feedOutputShapes=[],this.feedLossFns=[];for(let i=0;i<this.outputs.length;++i){const a=this.internalOutputShapes[i],l=this.outputNames[i];this.feedOutputNames.push(l),this.feedOutputShapes.push(a),this.feedLossFns.push(this.lossFunctions[i])}const s=[];this.metrics=t.metrics,this.metricsNames=["loss"],this.metricsTensors=[],Bs("loss",()=>{for(let i=0;i<this.outputs.length;++i){if(s.indexOf(i)!==-1)continue;const a=this.lossFunctions[i];this.outputs.length>1&&(this.metricsTensors.push([a,i]),this.metricsNames.push(this.outputNames[i]+"_loss"))}});const o=AT(t.metrics,this.outputNames),r=(i,a,l)=>{this.outputNames.length>1&&(a=this.outputNames[i]+"_"+a),this.metricsNames.push(a),this.metricsTensors.push([l,i])};Bs("metric",()=>{for(let i=0;i<this.outputs.length;++i){if(s.indexOf(i)!==-1)continue;const a=o[i];(c=>{let h,d,p;for(const f of c){if(typeof f=="string"&&["accuracy","acc","crossentropy","ce"].indexOf(f)!==-1){const g=this.internalOutputShapes[i];g[g.length-1]===1||this.lossFunctions[i]===Zl?["accuracy","acc"].indexOf(f)!==-1?d=$x:["crossentropy","ce"].indexOf(f)!==-1&&(d=oT):this.lossFunctions[i]===Ca?["accuracy","acc"].indexOf(f)!==-1?d=rT:["crossentropy","ce"].indexOf(f)!==-1&&(d=vx):["accuracy","acc"].indexOf(f)!==-1?d=Ix:["crossentropy","ce"].indexOf(f)!==-1&&(d=kx);let x;["accuracy","acc"].indexOf(f)!==-1?x="acc":["crossentropy","ce"].indexOf(f)!==-1&&(x="ce"),p=d,h=""+x}else p=pT(f),h=""+qi(f);let m;Bs(h,()=>{m=p}),r(i,h,m)}})(a)}}),this.collectedTrainableWeights=this.trainableWeights}checkTrainableWeightsConsistency(){this.collectedTrainableWeights!=null&&this.trainableWeights.length!==this.collectedTrainableWeights.length&&console.warn("Discrepancy between trainableweights and collected trainable weights. Did you set `model.trainable` without calling `model.compile()` afterwards?")}evaluate(t,e,s={}){const o=s.batchSize==null?32:s.batchSize;$c(o);const i=this.standardizeUserDataXY(t,e,!0,o);try{const a=i[0].concat(i[1]);this.makeTestFunction();const l=this.testFunction,c=this.testLoop(l,a,o,s.verbose,s.steps);return _e(c)}finally{dn(i[0],t),dn(i[1],e)}}async evaluateDataset(t,e){return this.makeTestFunction(),TT(this,t,e)}checkNumSamples(t,e,s,o="steps"){let r;if(s!=null){if(r=null,e!=null)throw new E(`If ${o} is set, batchSize must be null or undefined.Got batchSize = ${e}`)}else if(t!=null)Array.isArray(t)?r=t[0].shape[0]:r=t.shape[0];else throw new E(`Either the input data should have a defined shape, or ${o} shoud be specified.`);return r}execute(t,e){if(Array.isArray(e)&&e.length===0)throw new E("`outputs` is an empty Array, which is not allowed.");const s=Array.isArray(e),o=s?e:[e],r=this.retrieveSymbolicTensors(o),i=new as;if(t instanceof se&&(t=[t]),Array.isArray(t)){if(t.length!==this.inputs.length)throw new E(`The number of inputs provided (${t.length}) does not match the number of inputs of this model (${this.inputs.length}).`);for(let l=0;l<this.inputs.length;++l)i.add(this.inputs[l],t[l])}else for(const l of this.inputs){const c=t[l.name];if(c==null)throw new E(`No value is provided for the model's input ${l.name}`);i.add(l,c)}const a=rr(r,i);return s?a:a[0]}retrieveSymbolicTensors(t){const e=Qs(null,t.length);let s=t.length;for(const o of this.layers){const r=Array.isArray(o.output)?o.output:[o.output],i=r.map(a=>a.name);for(let a=0;a<t.length;++a){const l=i.indexOf(t[a]);if(l!==-1&&(e[a]=r[l],s--),s===0)break}if(s===0)break}if(s>0){const o=[];throw e.forEach((r,i)=>{r==null&&o.push(t[i])}),new E(`Cannot find SymbolicTensors for output name(s): ${JSON.stringify(o)}`)}return e}predictLoop(t,e=32,s=!1){return _(()=>{const o=this.checkNumSamples(t);if(s)throw new xt("Verbose predictLoop() is not implemented yet.");const r=Ic(o,e),i=this.outputs.map(a=>[]);for(let a=0;a<r.length;++a)_(()=>{const c=r[a][0],u=r[a][1],h=er(t,c,u),d=[];if(Array.isArray(h))for(let f=0;f<h.length;++f)d.push({key:this.inputs[f],value:h[f]});else d.push({key:this.inputs[0],value:h});const p=new as(d);return rr(this.outputs,p)}).forEach((c,u)=>i[u].push(c));return _e(i.map(a=>Le(a,0)))})}predict(t,e={}){const s=Dx(t);Gp(s,this.inputNames,this.feedInputShapes,!1);try{const o=e.batchSize==null?32:e.batchSize;return $c(o),this.predictLoop(s,o)}finally{dn(s,t)}}predictOnBatch(t){Gp(t,this.inputNames,this.feedInputShapes,!0);const e=(Array.isArray(t)?t[0]:t).shape[0];return this.predictLoop(t,e)}standardizeUserDataXY(t,e,s=!0,o){if(this.optimizer_==null)throw new sn("You must compile a model before training/testing. Use LayersModel.compile(modelCompileArgs).");const r=[];for(let i=0;i<this.feedOutputShapes.length;++i){const a=this.feedOutputShapes[i];this.feedLossFns[i]===Ca?r.push(a.slice(0,a.length-1).concat([1])):r.push(a)}if(t=Up(t,this.feedInputNames,this.feedInputShapes,!1,"input"),e=Up(e,this.feedOutputNames,r,!1,"target"),RT(t,e),DT(e,this.feedLossFns,this.feedOutputShapes),this.stateful&&o!=null&&o>0&&t[0].shape[0]%o!==0)throw new E(`In a stateful network, you should only pass inputs with a number of samples that is divisible by the batch size ${o}. Found: ${t[0].shape[0]} sample(s).`);return[t,e]}async standardizeUserData(t,e,s,o,r=!0,i){const[a,l]=this.standardizeUserDataXY(t,e,r,i);if(s!=null)throw new Error("sample weight is not supported yet.");let c=null;if(o!=null){const u=Tx(o,this.outputNames);c=[];for(let h=0;h<u.length;++h)c.push(await Ex(l[h],null,u[h]))}return[a,l,c]}testLoop(t,e,s,o=0,r){return _(()=>{const i=this.checkNumSamples(e,s,r,"steps"),a=[];if(o>0)throw new xt("Verbose mode is not implemented yet.");if(r!=null)throw new xt("steps mode in testLoop() is not implemented yet");{const l=Ic(i,s),c=We(wn(0,i));for(let u=0;u<l.length;++u){const h=l[u][0],d=l[u][1],p=Vs(c,h,d-h),f=ru(e,p),m=t(f);if(u===0)for(let g=0;g<m.length;++g)a.push(Tt(0));for(let g=0;g<m.length;++g){const x=m[g];a[g]=Y(a[g],R(d-h,x))}}for(let u=0;u<a.length;++u)a[u]=ut(a[u],i)}return a})}getDedupedMetricsNames(){const t=this.metricsNames,e=[];for(let s=0;s<t.length;++s){const o=t[s];let r=o;if(Tp(t,o)>1){const i=Tp(t.slice(0,s),o);r+=`_${i}`}e.push(r)}return e}makeTrainFunction(){return t=>{const e=[],s=t.slice(0,this.inputs.length),o=t.slice(this.inputs.length,this.inputs.length+this.outputs.length),r=t.slice(this.inputs.length+this.outputs.length,this.inputs.length+this.outputs.length*2),i=[],a=()=>{const h=[];for(let m=0;m<this.inputs.length;++m)h.push({key:this.inputs[m],value:s[m]});const d=new as(h),p=rr(this.outputs,d,{training:!0});let f;for(let m=0;m<this.lossFunctions.length;++m){const g=this.lossFunctions[m];let x=g(o[m],p[m]);r[m]!=null&&(x=$T(x,r[m]));const b=ee(x);e.push(b),m===0?f=x:f=Y(f,x)}for(let m=0;m<this.metricsTensors.length;++m){let g;if(this.outputs.length>1&&m<this.outputs.length)g=e[m];else{const x=this.metricsTensors[m][0],b=this.metricsTensors[m][1];g=ee(x(o[b],p[b]))}Dn(g),i.push(g)}return f=ee(f),this.calculateLosses().forEach(m=>{f=Y(f,m)}),f},l=this.collectedTrainableWeights.map(h=>h.read());return[this.optimizer_.minimize(a,!0,l)].concat(i)}}makeTestFunction(){this.testFunction=t=>_(()=>{const e=[];let s;const o=t.slice(0,this.inputs.length),r=t.slice(this.inputs.length,this.inputs.length+this.outputs.length),i=[];for(let c=0;c<this.inputs.length;++c)i.push({key:this.inputs[c],value:o[c]});const a=new as(i),l=rr(this.outputs,a);for(let c=0;c<this.lossFunctions.length;++c){const u=this.lossFunctions[c],h=ee(u(r[c],l[c]));c===0?s=h:s=Y(s,h),e.push(s)}for(let c=0;c<this.metricsTensors.length;++c){const u=this.metricsTensors[c][0],h=this.metricsTensors[c][1],d=ee(u(r[h],l[h]));e.push(d)}return e})}async fit(t,e,s={}){if(this.isTraining)throw new Error("Cannot start training because another fit() call is ongoing.");this.isTraining=!0;let o,r,i,a,l,c,u,h,d;try{const p=s.batchSize==null?32:s.batchSize;$c(p);const m=await this.standardizeUserData(t,e,s.sampleWeight,s.classWeight,!1,p);o=m[0],r=m[1],d=m[2];let g=!1,x;if(s.validationData!=null&&s.validationData.length>0){if(g=!0,s.validationData.length===2)l=s.validationData[0],c=s.validationData[1];else throw s.validationData.length===3?new xt("validationData including sample weights is not supported yet."):new E(`When passing validation data, it must contain 2 (valX, valY) or 3 (valX, valY, valSampleWeight) items; ${s.validationData} is invalid.`);const T=await this.standardizeUserData(l,c,null,null,!0,p);u=T[0],h=T[1],x=u.concat(h)}else if(s.validationSplit!=null&&s.validationSplit>0&&s.validationSplit<1){g=!0;const N=Math.floor(o[0].shape[0]*(1-s.validationSplit)),T=o[0].shape[0];u=er(o,N,T),i=o,o=er(o,0,N),h=er(r,N,T),a=r,r=er(r,0,N),x=u.concat(h)}else s.validationSteps!=null&&(g=!0);const b=o.concat(r).concat(d);this.checkTrainableWeightsConsistency();const w=this.makeTrainFunction(),y=this.getDedupedMetricsNames();let C,I;g?(this.makeTestFunction(),C=this.testFunction,I=y.slice().concat(y.map(N=>"val_"+N))):(C=null,x=[],I=y.slice());const k=yx(s.callbacks,s.yieldEvery);return await this.fitLoop(w,b,y,p,s.epochs,s.verbose,k,C,x,s.shuffle,I,s.initialEpoch,null,null)}finally{this.isTraining=!1,dn(o,t),dn(r,e),dn(i,t),dn(a,e),dn(u,l),dn(h,c),d!=null&&yt(d)}}async fitLoop(t,e,s,o,r,i,a,l,c,u,h,d,p,f){o==null&&(o=32),r==null&&(r=1),u==null&&(u=!0),d==null&&(d=0);let m=!1;if(l!=null&&c!=null&&(m=!0),f!=null&&(m=!0,p==null))throw new E("Can only use `validationSteps` when doing step-wise training, i.e., `stepsPerEpoch` must be set.");const g=this.checkNumSamples(e,o,p,"steps_per_epoch");let x;g!=null&&(x=wn(0,g)),i==null&&(i=1);const{callbackList:b,history:w}=wx(a,i,r,d,g,p,o,m,h);b.setModel(this),this.history=w,await b.onTrainBegin(),this.stopTraining_=!1;for(let y=d;y<r;++y){await b.onEpochBegin(y);const C={};if(p!=null)throw new xt("stepsPerEpoch mode is not implemented yet.");{if(u==="batch")throw new xt("batch shuffling is not implemneted yet");u&&y1(x);const I=We(x),k=Ic(g,o);for(let v=0;v<k.length;++v){const N={};if(await b.onBatchBegin(v,N),_(()=>{const T=k[v][0],O=k[v][1],P=Vs(I,T,O-T);N.batch=v,N.size=O-T;const z=ru(e,P),B=t(z);for(let M=0;M<s.length;++M){const G=s[M],H=B[M];N[G]=H,Dn(H)}if(v===k.length-1&&m){const M=this.testLoop(l,c,o);for(let G=0;G<s.length;++G){const H=s[G],U=M[G];Dn(U),C["val_"+H]=U}}}),await b.onBatchEnd(v,N),bx(N),this.stopTraining_)break}I.dispose()}if(await b.onEpochEnd(y,C),this.stopTraining_)break}return await b.onTrainEnd(),await this.history.syncData(),this.history}async fitDataset(t,e){return vT(this,t,e)}async trainOnBatch(t,e){const s=await this.standardizeUserData(t,e),o=s[0],r=s[1],a=this.makeTrainFunction()(o.concat(r)),l=[];for(const c of a){const u=await c.data();l.push(u[0])}return yt(a),dn(s[0],t),dn(s[1],e),_e(l)}getNamedWeights(t){const e=[],s=t!=null&&t.trainableOnly,o=s?this.trainableWeights:this.weights,r=this.getWeights(s);for(let i=0;i<o.length;++i)s&&!o[i].trainable||e.push({name:o[i].originalName,tensor:r[i]});return e}set stopTraining(t){this.stopTraining_=t}get stopTraining(){return this.stopTraining_}get optimizer(){return this.optimizer_}set optimizer(t){this.optimizer_!==t&&(this.optimizer_=t,this.isOptimizerOwned=!1)}dispose(){const t=super.dispose();if(t.refCountAfterDispose===0&&this.optimizer!=null&&this.isOptimizerOwned){const e=lp().numTensors;this.optimizer_.dispose(),t.numDisposedVariables+=e-lp().numTensors}return t}getLossIdentifiers(){let t;if(typeof this.loss=="string")t=Gn(this.loss);else if(Array.isArray(this.loss)){for(const e of this.loss)if(typeof e!="string")throw new Error("Serialization of non-string loss is not supported.");t=this.loss.map(e=>Gn(e))}else{const e=Object.keys(this.loss);t={};const s=this.loss;for(const o of e)if(typeof s[o]=="string")t[o]=Gn(s[o]);else throw new Error("Serialization of non-string loss is not supported.")}return t}getMetricIdentifiers(){if(typeof this.metrics=="string"||typeof this.metrics=="function")return[Gn(qi(this.metrics))];if(Array.isArray(this.metrics))return this.metrics.map(t=>Gn(qi(t)));{const t={};for(const e in this.metrics)t[e]=Gn(qi(this.metrics[e]));return t}}getTrainingConfig(){return{loss:this.getLossIdentifiers(),metrics:this.getMetricIdentifiers(),optimizer_config:{class_name:this.optimizer.getClassName(),config:this.optimizer.getConfig()}}}loadTrainingConfig(t){if(t.weighted_metrics!=null)throw new Error("Loading weight_metrics is not supported yet.");if(t.loss_weights!=null)throw new Error("Loading loss_weights is not supported yet.");if(t.sample_weight_mode!=null)throw new Error("Loading sample_weight_mode is not supported yet.");const e=va(t.optimizer_config),s=_n(e);let o;if(typeof t.loss=="string")o=_s(t.loss);else if(Array.isArray(t.loss))o=t.loss.map(i=>_s(i));else if(t.loss!=null){o={};for(const i in t.loss)o[i]=_s(t.loss[i])}let r;if(Array.isArray(t.metrics))r=t.metrics.map(i=>_s(i));else if(t.metrics!=null){r={};for(const i in t.metrics)r[i]=_s(t.metrics[i])}this.compile({loss:o,metrics:r,optimizer:s})}async save(t,e){if(typeof t=="string"){const c=$w(t);if(c.length===0)throw new E(`Cannot find any save handlers for URL '${t}'`);if(c.length>1)throw new E(`Found more than one (${c.length}) save handlers for URL '${t}'`);t=c[0]}if(t.save==null)throw new E("LayersModel.save() cannot proceed because the IOHandler provided does not have the `save` attribute defined.");const s=await cp(this.getNamedWeights(e)),a={modelTopology:this.toJSON(null,!1),format:FT,generatedBy:`TensorFlow.js tfjs-layers v${Nx}`,convertedBy:null};if((e==null?!1:e.includeOptimizer)&&this.optimizer!=null){a.trainingConfig=this.getTrainingConfig();const c="optimizer",{data:u,specs:h}=await cp(await this.optimizer.getWeights(),c);s.specs.push(...h),s.data=fw([s.data,u])}return this.userDefinedMetadata!=null&&(zp(this.userDefinedMetadata,this.name,!0),a.userDefinedMetadata=this.userDefinedMetadata),a.weightData=s.data,a.weightSpecs=s.specs,t.save(a)}setUserDefinedMetadata(t){zp(t,this.name),this.userDefinedMetadata=t}getUserDefinedMetadata(){return this.userDefinedMetadata}}Io.className="Model";j(Io);class Ax extends Io{}Ax.className="Functional";j(Ax);async function $H(n,t){if(t==null&&(t={}),typeof n=="string"){const e=Iw(n,t);if(e.length===0)e.push(Vv(n,t));else if(e.length>1)throw new E(`Found more than one (${e.length}) load handlers for URL '${n}'`);n=e[0]}return OT(n,void 0,t)}async function OT(n,t,e){if(e==null&&(e={}),n.load==null)throw new E("Cannot proceed with model loading because the IOHandler provided does not have the `load` method implemented.");const s=await n.load();let o=s.modelTopology;o.model_config!=null&&(o=o.model_config);const r=e.strict==null?!0:e.strict,i=s.weightData!=null&&s.weightSpecs!=null&&r,a=_n(va(o),t,i),l=s.trainingConfig;if(l!=null&&a.loadTrainingConfig(l),s.userDefinedMetadata!=null&&a.setUserDefinedMetadata(s.userDefinedMetadata),s.weightData!=null){if(s.weightSpecs==null)throw new E("LayersModel artifacts contains weight data, but not weight specs. Therefore loading of weights cannot proceed.");const{modelWeights:c,optimizerWeights:u}=_T(s.weightData,s.weightSpecs);a.loadWeights(c,r),a.optimizer!=null&&u.length>0&&await a.optimizer.setWeights(u),yt(c),yt(u.map(h=>h.tensor))}return a}function _T(n,t){const e=lw(n,t),s={},o=[];return t.forEach(r=>{r.group==="optimizer"?o.push({name:r.name,tensor:e[r.name]}):s[r.name]=e[r.name]}),{modelWeights:s,optimizerWeights:o}}class yr extends Io{constructor(t){if(super({inputs:[],outputs:[]}),t=t||{},this.trainable=!0,this.built=!1,this.name=t.name!=null?t.name:ql("sequential_"),t.layers!=null)for(const e of t.layers)this.add(e)}checkShape(t){if(t.inboundNodes[0].outputTensors[0].shape.some(s=>s<0))throw new E(`Negative dimension size caused by adding layer ${t.name} with input shape [${t.inboundNodes[0].inputTensors[0].shape}]`)}add(t){const e=t instanceof yr||t instanceof Io;let s;if(e){if(s=t,s.outputs.length!==1)throw new E("All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.");if(s.inputs.length!==1)throw new E("All layers in a Sequential model should have a single input tensor. For multi-input layers, use the functional API.")}if(this.outputs.length===0){if(t.inboundNodes.length===0){if(t.batchInputShape==null)throw new E("The first layer in a Sequential model must get an `inputShape` or `batchInputShape` argument.");const o=_2({batchShape:t.batchInputShape,dtype:t.dtype,name:t.name+"_input"});t.apply(o)}if(e)this.outputs=s.outputs,this.inputs=s.inputs;else{if(t.inboundNodes.length!==1)throw new E(`A layer added to a Sequential model must not already be connected somewhere else. LayersModel received layer ${t.name} which has ${t.inboundNodes.length} pre-existing inbound connections.`);if(t.inboundNodes[0].outputTensors.length!==1)throw new E("All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.");this.checkShape(t),this.outputs=[t.inboundNodes[0].outputTensors[0]],this.inputs=px(this.outputs[0])}this.inboundNodes=[],new Yl({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:this.inputs,outputTensors:this.outputs,inputMasks:Qs(null,this.inputs.length),outputMasks:[null],inputShapes:this.inputs.map(o=>o.shape),outputShapes:this.outputs[0].shape})}else{const o=t.apply(this.outputs[0]);if(Array.isArray(o))throw new TypeError("All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.");this.checkShape(t),this.outputs=[o],this.inboundNodes[0].outputTensors=this.outputs,this.inboundNodes[0].outputShapes=[this.outputs[0].shape]}this.layers.push(t),this.built=!1}pop(){if(this.layers.length===0)throw new TypeError("There are no layers in the model.");if(this.layers.pop(),this.layers.length===0)this.outputs=[],this.inboundNodes=[],this.outboundNodes=[];else{const t=this.layers.length-1;this.layers[t].outboundNodes=[],this.outputs=[this.layers[t].output],this.inboundNodes[0].outputTensors=this.outputs,this.inboundNodes[0].outputShapes=[this.outputs[0].shape]}}call(t,e){return this.model==null&&this.build(),this.model.call(t,e)}build(t){if(St(t),this.inputs.length===0||this.outputs.length===0)throw new TypeError("Sequential model cannot be built: model is empty. Add some layers first.");this.model=new Io({inputs:this.inputs,outputs:this.outputs[0],name:this.name+"_model"}),this.model.trainable=this.trainable,this.supportsMasking=this.model.supportsMasking,this.inputLayers=this.model.inputLayers,this.inputLayersNodeIndices=this.model.inputLayersNodeIndices,this.inputLayersTensorIndices=this.model.inputLayersTensorIndices,this.outputLayers=this.model.outputLayers,this.outputLayersNodeIndices=this.model.outputLayersNodeIndices,this.outputLayersTensorIndices=this.model.outputLayersTensorIndices,this.nodesByDepth=this.model.nodesByDepth,this.containerNodes=this.model.containerNodes,this.outputNames=this.model.outputNames,this.inputNames=this.model.inputNames,this.built=!0}countParams(){return this.built||this.build(),super.countParams()}summary(t,e,s=console.log){this.built||this.build(),super.summary(t,e,s)}setWeights(t){this.model==null&&this.build(),this.model.setWeights(t)}evaluate(t,e,s={}){if(!this.built)throw new sn("The model needs to be compiled before being used.");return this.model.evaluate(t,e,s)}async evaluateDataset(t,e){if(!this.built)throw new sn("The model needs to be compiled before being used.");return this.model.evaluateDataset(t,e)}predict(t,e={}){return this.model==null&&this.build(),this.model.predict(t,e)}predictOnBatch(t){return this.model==null&&this.build(),this.model.predictOnBatch(t)}compile(t){this.build(),this.model.compile(t),this.optimizer_=this.model.optimizer,this.isOptimizerOwned=this.model.isOptimizerOwned,this.loss=this.model.loss,this.metrics=this.model.metrics,this.metricsTensors=this.model.metricsTensors,this.metricsNames=this.model.metricsNames}get optimizer(){return this.model==null?void 0:this.model.optimizer}set optimizer(t){this.model.optimizer=t}async fit(t,e,s={}){if(!this.built)throw new sn("The model needs to be compiled before being used.");return this.model.fit(t,e,s)}async fitDataset(t,e){if(!this.built)throw new sn("The model needs to be compiled before being used.");return this.model.fitDataset(t,e)}async trainOnBatch(t,e){return this.model.trainOnBatch(t,e)}static fromConfig(t,e,s={},o=!1){let r,i={};if(e instanceof Array){if(e[0].className==null||e[0].className==="Merge")throw new E("Legacy serialization format not supported yet.");r=e}else $(e.layers!=null,()=>"When the config data for a Sequential model is not an Array, it must be an Object that contains the 'layers' field."),r=e.layers,delete e.layers,i=e;const a=new t(i);if(!(a instanceof yr))throw new xt(`Sequential.fromConfig called on non-Sequential input: ${a}`);for(const l of r){const u=_n(l,void 0,o);o&&u.setFastWeightInitDuringBuild(!0),a.add(u)}return a}set stopTraining(t){if(this.model==null)throw new E("Cannot set the stopTraining property of a sequential model before it is compiled.");this.model.stopTraining=t}get stopTraining(){if(this.model==null)throw new E("Cannot get the stopTraining property of a sequential model before it is compiled.");return this.model.stopTraining}getConfig(){const t=[];for(const e of this.layers){const s={};s.className=e.getClassName(),s.config=e.getConfig(),t.push(s)}return{name:this.name,layers:t}}}yr.className="Sequential";j(yr);let ve=class extends Wo{getConfig(){return{}}};class Fx extends ve{apply(t,e=1){return y2(t,e)}}Fx.className="elu";j(Fx);class Ox extends ve{apply(t){return Xm(t)}}Ox.className="selu";j(Ox);class _x extends ve{apply(t){return ro(t)}}_x.className="relu";j(_x);class Lx extends ve{apply(t){return _(()=>mr(6,ro(t)))}}Lx.className="relu6";j(Lx);class Mx extends ve{apply(t){return t}}Mx.className="linear";j(Mx);class Px extends ve{apply(t){return zo(t)}}Px.className="sigmoid";j(Px);class zx extends ve{apply(t){return C2(t)}}zx.className="hardSigmoid";j(zx);class Bx extends ve{apply(t){return $i(t)}}Bx.className="softplus";j(Bx);class Vx extends ve{apply(t){return w2(t)}}Vx.className="softsign";j(Vx);class Wx extends ve{apply(t){return Pl(t)}}Wx.className="tanh";j(Wx);let Nd=class extends ve{apply(t,e=-1){return Eh(t,e)}};Nd.className="softmax";j(Nd);class Ux extends ve{apply(t,e=-1){return Vm(t,e)}}Ux.className="logSoftmax";j(Ux);class Gx extends ve{apply(t){return _(()=>_(()=>{const e=Math.sqrt(2),s=R(.5,Y(1,Lm(ut(t,e))));return R(t,s)}))}}Gx.className="gelu";j(Gx);class Hx extends ve{apply(t){return _(()=>R(.5,R(t,Y(1,Pl(R(Ie(ut(2,Math.PI)),Y(t,R(.044715,Ys(t,3)))))))))}}Hx.className="gelu_new";j(Hx);class Kx extends ve{apply(t){return _(()=>R(t,Pl($i(t))))}}Kx.className="mish";j(Kx);class jx extends ve{apply(t,e=1){return _(()=>R(zo(R(t,e)),t))}}jx.className="swish";j(jx);function ms(n){return n.getClassName()}function kc(n,t={}){return Ei(n,nn.getMap().classNameMap,t,"activation")}function gs(n){if(n==null){const t={};return t.className="linear",t.config={},kc(t)}if(typeof n=="string"){const t={};return t.className=n,t.config={},kc(t)}else return n instanceof ve?n:kc(n)}function LT(n){if(n!=null&&typeof n!="object")throw new Error(`Argument to L1L2 regularizer's constructor is expected to be an object, but received: ${n}`)}class qx extends Wo{}class Xx extends qx{constructor(t){super(),LT(t),this.l1=t==null||t.l1==null?.01:t.l1,this.l2=t==null||t.l2==null?.01:t.l2,this.hasL1=this.l1!==0,this.hasL2=this.l2!==0}apply(t){return _(()=>{let e=de([1]);return this.hasL1&&(e=Y(e,ct(R(this.l1,Ne(t))))),this.hasL2&&(e=Y(e,ct(R(this.l2,Di(t))))),A(e,[])})}getConfig(){return{l1:this.l1,l2:this.l2}}static fromConfig(t,e){return new t({l1:e.l1,l2:e.l2})}}Xx.className="L1L2";j(Xx);const Hp={l1l2:"L1L2"};function _t(n){return pd(n)}function Kp(n,t={}){return Ei(n,nn.getMap().classNameMap,t,"regularizer")}function Gt(n){if(n==null)return null;if(typeof n=="string"){const e={className:n in Hp?Hp[n]:n,config:{}};return Kp(e)}else return n instanceof qx?n:Kp(n)}class Yx extends $t{constructor(t){super(t??{}),this.supportsMasking=!0,t!=null&&(this.maxValue=t.maxValue)}call(t,e){t=ft(t);let s=ro(t);return this.maxValue!=null&&(s=Ye(s,0,this.maxValue)),s}computeOutputShape(t){return t}getConfig(){const t={maxValue:this.maxValue},e=super.getConfig();return Object.assign(t,e),t}}Yx.className="ReLU";j(Yx);class Jx extends $t{constructor(t){super(t??{}),this.DEFAULT_ALPHA=.3,t==null&&(t={}),this.alpha=t.alpha==null?this.DEFAULT_ALPHA:t.alpha}call(t,e){const s=ft(t);return wh(s,this.alpha)}computeOutputShape(t){return t}getConfig(){const t={alpha:this.alpha},e=super.getConfig();return Object.assign(t,e),t}}Jx.className="LeakyReLU";j(Jx);class Zx extends $t{constructor(t){if(super(t??{}),this.DEFAULT_ALPHA_INITIALIZER="zeros",t==null&&(t={}),this.supportsMasking=!0,this.alphaInitializer=Ut(t.alphaInitializer||this.DEFAULT_ALPHA_INITIALIZER),this.alphaRegularizer=Gt(t.alphaRegularizer),this.alphaConstraint=ae(t.alphaConstraint),t.sharedAxes==null)this.sharedAxes=null;else if(Array.isArray(t.sharedAxes))this.sharedAxes=t.sharedAxes;else if(typeof t.sharedAxes=="number")this.sharedAxes=[t.sharedAxes];else throw new E(`Expected sharedAxes to be a number or an array of numbers, but got ${t.sharedAxes}`)}build(t){t=St(t);const e=t.slice(1);if(this.sharedAxes!=null)for(const o of this.sharedAxes)e[o-1]=1;this.alpha=this.addWeight("alpha",e,"float32",this.alphaInitializer,this.alphaRegularizer,!0,this.alphaConstraint);const s={};if(this.sharedAxes!=null)for(let o=1;o<t.length;++o)s[o]=t[o];this.inputSpec=[new re({ndim:t.length,axes:s})],this.built=!0}call(t,e){return t=ft(t),Sh(t,this.alpha.read())}getConfig(){const t={alphaInitializer:Kt(this.alphaInitializer),alphaRegularizer:_t(this.alphaRegularizer),alphaConstraint:ie(this.alphaConstraint),sharedAxes:this.sharedAxes},e=super.getConfig();return Object.assign(t,e),t}}Zx.className="PReLU";j(Zx);let Qx=class extends $t{constructor(t){if(super(t??{}),this.DEFAULT_ALPHA=1,t==null&&(t={}),t.alpha!=null&&t.alpha!==this.DEFAULT_ALPHA)throw new xt(`Non-default alpha value (${t.alpha}) is not supported by the ELU layer yet.`);this.alpha=t.alpha==null?this.DEFAULT_ALPHA:t.alpha}call(t,e){const s=ft(t);return Vl(s)}computeOutputShape(t){return t}getConfig(){const t={alpha:this.alpha},e=super.getConfig();return Object.assign(t,e),t}};Qx.className="ELU";j(Qx);class tb extends $t{constructor(t){super(t??{}),this.DEFAULT_THETA=1,t==null&&(t={}),this.theta=t.theta==null?this.DEFAULT_THETA:t.theta}call(t,e){const s=ft(t);return R(s,st(Je(s,this.theta),"float32"))}computeOutputShape(t){return t}getConfig(){const t={theta:this.theta},e=super.getConfig();return Object.assign(t,e),t}}tb.className="ThresholdedReLU";j(tb);class eb extends $t{constructor(t){super(t??{}),this.DEFAULT_AXIS=1,t==null&&(t={}),this.softmax=new Nd().apply,this.axis=t.axis==null?this.DEFAULT_AXIS:t.axis}call(t,e){return _(()=>{let s=ft(t);const o=e.mask;if(o!=null){const r=R(pt(vs(s.shape),st(o,s.dtype)),Tt(-1e9));s=Y(s,r)}return this.axis instanceof Array?this.axis.length>1?Mn(pt(s,Wm(s,this.axis,!0))):this.softmax(s,this.axis[0]):this.softmax(s,this.axis)})}computeOutputShape(t){return t}getConfig(){const t={axis:this.axis},e=super.getConfig();return Object.assign(t,e),t}}eb.className="Softmax";j(eb);function ko(n,t,e){if(typeof n=="number")return Qs(n,t);if(n.length!==t)throw new E(`The ${e} argument must be an integer or tuple of ${t} integers. Received: ${n.length} elements.`);for(let s=0;s<t;++s){const o=n[s];if(!m2(o))throw new E(`The ${e} argument must be an integer or tuple of ${t} integers. Received: ${JSON.stringify(n)} including a non-integer number ${o}`)}return n}function yn(n,t,e,s,o=1){if(n==null)return n;const r=t+(t-1)*(o-1);let i;return e==="same"?i=n:i=n-r+1,Math.floor((i+s-1)/s)}function Tn(n,t,e,s){if(n==null)return null;if(s==="valid")n=n*t+fs([e-t,0]);else if(s==="same")n=n*t;else throw new E(`Unsupport padding mode: ${s}.`);return n}function Td(n,t){return _(()=>(Qt(t),t==="channelsFirst"?It(n,[0,2,3,1]):n))}function nb(n,t){return _(()=>(Qt(t),t==="channelsFirst"?It(n,[0,2,3,4,1]):n))}function MT(n,t,e,s=1,o="valid",r,i=1){return _(()=>{if(r==null&&(r=Cn()),Qt(r),n.shape.length!==3)throw new E(`The input of a conv1dWithBias operation should be 3, but is ${n.shape.length} instead.`);if(t.shape.length!==3)throw new E(`The kernel for a conv1dWithBias operation should be 3, but is ${t.shape.length} instead`);if(e!=null&&e.shape.length!==1)throw new E(`The bias for a conv1dWithBias operation should be 1, but is ${e.shape.length} instead`);if(r==="channelsFirst"&&(n=It(n,[0,2,1])),o==="causal")throw new xt("The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.");let a=Dm(n,t,s,o==="same"?"same":"valid","NWC",i);return e!=null&&(a=In(a,e)),a})}function jp(n,t,e,s=[1,1],o="valid",r,i,a=null){return _(()=>{if(r==null&&(r=Cn()),Qt(r),n.rank!==3&&n.rank!==4)throw new E(`conv2dWithBiasActivation expects input to be of rank 3 or 4, but received ${n.rank}.`);if(t.rank!==3&&t.rank!==4)throw new E(`conv2dWithBiasActivation expects kernel to be of rank 3 or 4, but received ${n.rank}.`);let l=Td(n,r);if(o==="causal")throw new xt("The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.");return l=Pk({x:l,filter:t,strides:s,pad:o==="same"?"same":"valid",dilations:i,dataFormat:"NHWC",bias:e,activation:a}),r==="channelsFirst"&&(l=It(l,[0,3,1,2])),l})}function PT(n,t,e,s=[1,1,1],o="valid",r,i){return _(()=>{if(r==null&&(r=Cn()),Qt(r),n.rank!==4&&n.rank!==5)throw new E(`conv3dWithBias expects input to be of rank 4 or 5, but received ${n.rank}.`);if(t.rank!==4&&t.rank!==5)throw new E(`conv3dWithBias expects kernel to be of rank 4 or 5, but received ${n.rank}.`);let a=nb(n,r);if(o==="causal")throw new xt("The support for CAUSAL padding mode in conv3dWithBias is not implemented yet.");return a=QC(a,t,s,o==="same"?"same":"valid","NDHWC",i),e!=null&&(a=In(a,e)),r==="channelsFirst"&&(a=It(a,[0,4,1,2,3])),a})}class Ql extends $t{constructor(t,e){if(super(e),this.bias=null,this.DEFAULT_KERNEL_INITIALIZER="glorotNormal",this.DEFAULT_BIAS_INITIALIZER="zeros",Ql.verifyArgs(e),this.rank=t,pe(this.rank,"rank"),this.rank!==1&&this.rank!==2&&this.rank!==3)throw new xt(`Convolution layer for rank other than 1, 2, or 3 (${this.rank}) is not implemented yet.`);if(this.kernelSize=ko(e.kernelSize,t,"kernelSize"),this.strides=ko(e.strides==null?1:e.strides,t,"strides"),this.padding=e.padding==null?"valid":e.padding,Ze(this.padding),this.dataFormat=e.dataFormat==null?"channelsLast":e.dataFormat,Qt(this.dataFormat),this.activation=gs(e.activation),this.useBias=e.useBias==null?!0:e.useBias,this.biasInitializer=Ut(e.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.biasConstraint=ae(e.biasConstraint),this.biasRegularizer=Gt(e.biasRegularizer),this.activityRegularizer=Gt(e.activityRegularizer),this.dilationRate=ko(e.dilationRate==null?1:e.dilationRate,t,"dilationRate"),this.rank===1&&Array.isArray(this.dilationRate)&&this.dilationRate.length!==1)throw new E(`dilationRate must be a number or an array of a single number for 1D convolution, but received ${JSON.stringify(this.dilationRate)}`);if(this.rank===2){if(typeof this.dilationRate=="number")this.dilationRate=[this.dilationRate,this.dilationRate];else if(this.dilationRate.length!==2)throw new E(`dilationRate must be a number or array of two numbers for 2D convolution, but received ${JSON.stringify(this.dilationRate)}`)}else if(this.rank===3){if(typeof this.dilationRate=="number")this.dilationRate=[this.dilationRate,this.dilationRate,this.dilationRate];else if(this.dilationRate.length!==3)throw new E(`dilationRate must be a number or array of three numbers for 3D convolution, but received ${JSON.stringify(this.dilationRate)}`)}}static verifyArgs(t){if(Nn("kernelSize"in t,"required key 'kernelSize' not in config"),typeof t.kernelSize!="number"&&!fd(t.kernelSize,"number",1,3))throw new E(`BaseConv expects config.kernelSize to be number or number[] with length 1, 2, or 3, but received ${JSON.stringify(t.kernelSize)}.`)}getConfig(){const t={kernelSize:this.kernelSize,strides:this.strides,padding:this.padding,dataFormat:this.dataFormat,dilationRate:this.dilationRate,activation:ms(this.activation),useBias:this.useBias,biasInitializer:Kt(this.biasInitializer),biasRegularizer:_t(this.biasRegularizer),activityRegularizer:_t(this.activityRegularizer),biasConstraint:ie(this.biasConstraint)},e=super.getConfig();return Object.assign(t,e),t}}class Uo extends Ql{constructor(t,e){super(t,e),this.kernel=null,Uo.verifyArgs(e),this.filters=e.filters,pe(this.filters,"filters"),this.kernelInitializer=Ut(e.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.kernelConstraint=ae(e.kernelConstraint),this.kernelRegularizer=Gt(e.kernelRegularizer)}build(t){t=St(t);const e=this.dataFormat==="channelsFirst"?1:t.length-1;if(t[e]==null)throw new E(`The channel dimension of the input should be defined. Found ${t[e]}`);const s=t[e],o=this.kernelSize.concat([s,this.filters]);this.kernel=this.addWeight("kernel",o,null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight("bias",[this.filters],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[{ndim:this.rank+2,axes:{[e]:s}}],this.built=!0}call(t,e){return _(()=>{t=ft(t);let s;const o=this.bias==null?null:this.bias.read(),r=Zg(this.activation.getClassName());if(r!=null&&this.rank===2)s=jp(t,this.kernel.read(),o,this.strides,this.padding,this.dataFormat,this.dilationRate,r);else{if(this.rank===1)s=MT(t,this.kernel.read(),o,this.strides[0],this.padding,this.dataFormat,this.dilationRate[0]);else if(this.rank===2)s=jp(t,this.kernel.read(),o,this.strides,this.padding,this.dataFormat,this.dilationRate);else if(this.rank===3)s=PT(t,this.kernel.read(),o,this.strides,this.padding,this.dataFormat,this.dilationRate);else throw new xt("convolutions greater than 3D are not implemented yet.");this.activation!=null&&(s=this.activation.apply(s))}return s})}computeOutputShape(t){t=St(t);const e=[],s=this.dataFormat==="channelsLast"?t.slice(1,t.length-1):t.slice(2);for(let r=0;r<s.length;++r){const i=yn(s[r],this.kernelSize[r],this.padding,this.strides[r],typeof this.dilationRate=="number"?this.dilationRate:this.dilationRate[r]);e.push(i)}let o=[t[0]];return this.dataFormat==="channelsLast"?(o=o.concat(e),o.push(this.filters)):(o.push(this.filters),o=o.concat(e)),o}getConfig(){const t={filters:this.filters,kernelInitializer:Kt(this.kernelInitializer),kernelRegularizer:_t(this.kernelRegularizer),kernelConstraint:ie(this.kernelConstraint)},e=super.getConfig();return Object.assign(t,e),t}static verifyArgs(t){if(!("filters"in t)||typeof t.filters!="number"||t.filters<1)throw new E(`Convolution layer expected config.filters to be a 'number' > 0 but got ${JSON.stringify(t.filters)}`)}}class _i extends Uo{constructor(t){super(2,t),_i.verifyArgs(t)}getConfig(){const t=super.getConfig();return delete t.rank,t}static verifyArgs(t){if(typeof t.kernelSize!="number"&&!fd(t.kernelSize,"number",1,2))throw new E(`Conv2D expects config.kernelSize to be number or number[] with length 1 or 2, but received ${JSON.stringify(t.kernelSize)}.`)}}_i.className="Conv2D";j(_i);class Li extends Uo{constructor(t){super(3,t),Li.verifyArgs(t)}getConfig(){const t=super.getConfig();return delete t.rank,t}static verifyArgs(t){if(typeof t.kernelSize!="number"&&!(Array.isArray(t.kernelSize)&&(t.kernelSize.length===1||t.kernelSize.length===3)))throw new E(`Conv3D expects config.kernelSize to be number or [number, number, number], but received ${JSON.stringify(t.kernelSize)}.`)}}Li.className="Conv3D";j(Li);class sb extends _i{constructor(t){if(super(t),this.inputSpec=[new re({ndim:4})],this.padding!=="same"&&this.padding!=="valid")throw new E(`Conv2DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)}build(t){if(t=St(t),t.length!==4)throw new E("Input should have rank 4; Received input shape: "+JSON.stringify(t));const e=this.dataFormat==="channelsFirst"?1:t.length-1;if(t[e]==null)throw new E("The channel dimension of the inputs should be defined. Found `None`.");const s=t[e],o=this.kernelSize.concat([this.filters,s]);this.kernel=this.addWeight("kernel",o,"float32",this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight("bias",[this.filters],"float32",this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[new re({ndim:4,axes:{[e]:s}})],this.built=!0}call(t,e){return _(()=>{let s=ft(t);if(s.shape.length!==4)throw new E(`Conv2DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${s.shape.length}`);const o=s.shape,r=o[0];let i,a;this.dataFormat==="channelsFirst"?(i=2,a=3):(i=1,a=2);const l=o[i],c=o[a],u=this.kernelSize[0],h=this.kernelSize[1],d=this.strides[0],p=this.strides[1],f=Tn(l,d,u,this.padding),m=Tn(c,p,h,this.padding),g=[r,f,m,this.filters];this.dataFormat!=="channelsLast"&&(s=It(s,[0,2,3,1]));let x=Am(s,this.kernel.read(),g,this.strides,this.padding);return this.dataFormat!=="channelsLast"&&(x=It(x,[0,3,1,2])),this.bias!=null&&(x=In(x,this.bias.read(),this.dataFormat)),this.activation!=null&&(x=this.activation.apply(x)),x})}computeOutputShape(t){t=St(t);const e=t.slice();let s,o,r;this.dataFormat==="channelsFirst"?(s=1,o=2,r=3):(s=3,o=1,r=2);const i=this.kernelSize[0],a=this.kernelSize[1],l=this.strides[0],c=this.strides[1];return e[s]=this.filters,e[o]=Tn(e[o],l,i,this.padding),e[r]=Tn(e[r],c,a,this.padding),e}getConfig(){const t=super.getConfig();return delete t.dilationRate,t}}sb.className="Conv2DTranspose";j(sb);class ob extends Li{constructor(t){if(super(t),this.inputSpec=[new re({ndim:5})],this.padding!=="same"&&this.padding!=="valid")throw new E(`Conv3DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)}build(t){if(t=St(t),t.length!==5)throw new E("Input should have rank 5; Received input shape: "+JSON.stringify(t));const e=this.dataFormat==="channelsFirst"?1:t.length-1;if(t[e]==null)throw new E("The channel dimension of the inputs should be defined. Found `None`.");const s=t[e],o=this.kernelSize.concat([this.filters,s]);this.kernel=this.addWeight("kernel",o,"float32",this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight("bias",[this.filters],"float32",this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[new re({ndim:5,axes:{[e]:s}})],this.built=!0}call(t,e){return _(()=>{let s=ft(t);if(s.shape.length!==5)throw new E(`Conv3DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${s.shape.length}`);const o=s.shape,r=o[0];let i,a,l;this.dataFormat==="channelsFirst"?(l=2,i=3,a=4):(l=1,i=2,a=3);const c=o[l],u=o[i],h=o[a],d=this.kernelSize[0],p=this.kernelSize[1],f=this.kernelSize[2],m=this.strides[0],g=this.strides[1],x=this.strides[2],b=Tn(c,m,d,this.padding),w=Tn(u,g,p,this.padding),y=Tn(h,x,f,this.padding),C=[r,b,w,y,this.filters];this.dataFormat!=="channelsLast"&&(s=It(s,[0,2,3,4,1]));let I=n$(s,this.kernel.read(),C,this.strides,this.padding);return this.dataFormat!=="channelsLast"&&(I=It(I,[0,4,1,2,3])),this.bias!==null&&(I=In(I,this.bias.read(),this.dataFormat)),this.activation!==null&&(I=this.activation.apply(I)),I})}computeOutputShape(t){t=St(t);const e=t.slice();let s,o,r,i;this.dataFormat==="channelsFirst"?(s=1,o=2,r=3,i=4):(s=4,o=1,r=2,i=3);const a=this.kernelSize[0],l=this.kernelSize[1],c=this.kernelSize[2],u=this.strides[0],h=this.strides[1],d=this.strides[2];return e[s]=this.filters,e[o]=Tn(e[o],u,a,this.padding),e[r]=Tn(e[r],h,l,this.padding),e[i]=Tn(e[i],d,c,this.padding),e}getConfig(){const t=super.getConfig();return delete t.dilationRate,t}}ob.className="Conv3DTranspose";j(ob);class rb extends Uo{constructor(t,e){if(super(t,e),this.DEFAULT_DEPTHWISE_INITIALIZER="glorotUniform",this.DEFAULT_POINTWISE_INITIALIZER="glorotUniform",this.depthwiseKernel=null,this.pointwiseKernel=null,e.filters==null)throw new E("The `filters` configuration field is required by SeparableConv, but is unspecified.");if(e.kernelInitializer!=null||e.kernelRegularizer!=null||e.kernelConstraint!=null)throw new E("Fields kernelInitializer, kernelRegularizer and kernelConstraint are invalid for SeparableConv2D. Use depthwiseInitializer, depthwiseRegularizer, depthwiseConstraint, pointwiseInitializer, pointwiseRegularizer and pointwiseConstraint instead.");if(e.padding!=null&&e.padding!=="same"&&e.padding!=="valid")throw new E(`SeparableConv${this.rank}D supports only padding modes: 'same' and 'valid', but received ${JSON.stringify(e.padding)}`);this.depthMultiplier=e.depthMultiplier==null?1:e.depthMultiplier,this.depthwiseInitializer=Ut(e.depthwiseInitializer||this.DEFAULT_DEPTHWISE_INITIALIZER),this.depthwiseRegularizer=Gt(e.depthwiseRegularizer),this.depthwiseConstraint=ae(e.depthwiseConstraint),this.pointwiseInitializer=Ut(e.depthwiseInitializer||this.DEFAULT_POINTWISE_INITIALIZER),this.pointwiseRegularizer=Gt(e.pointwiseRegularizer),this.pointwiseConstraint=ae(e.pointwiseConstraint)}build(t){if(t=St(t),t.length<this.rank+2)throw new E(`Inputs to SeparableConv${this.rank}D should have rank ${this.rank+2}, but received input shape: ${JSON.stringify(t)}`);const e=this.dataFormat==="channelsFirst"?1:t.length-1;if(t[e]==null||t[e]<0)throw new E(`The channel dimension of the inputs should be defined, but found ${JSON.stringify(t[e])}`);const s=t[e],o=this.kernelSize.concat([s,this.depthMultiplier]),r=[];for(let a=0;a<this.rank;++a)r.push(1);r.push(s*this.depthMultiplier,this.filters);const i=!0;this.depthwiseKernel=this.addWeight("depthwise_kernel",o,"float32",this.depthwiseInitializer,this.depthwiseRegularizer,i,this.depthwiseConstraint),this.pointwiseKernel=this.addWeight("pointwise_kernel",r,"float32",this.pointwiseInitializer,this.pointwiseRegularizer,i,this.pointwiseConstraint),this.useBias?this.bias=this.addWeight("bias",[this.filters],"float32",this.biasInitializer,this.biasRegularizer,i,this.biasConstraint):this.bias=null,this.inputSpec=[new re({ndim:this.rank+2,axes:{[e]:s}})],this.built=!0}call(t,e){return _(()=>{t=ft(t);let s;if(this.rank===1)throw new xt("1D separable convolution is not implemented yet.");return this.rank===2&&(this.dataFormat==="channelsFirst"&&(t=It(t,[0,2,3,1])),s=Ym(t,this.depthwiseKernel.read(),this.pointwiseKernel.read(),this.strides,this.padding,this.dilationRate,"NHWC")),this.useBias&&(s=In(s,this.bias.read(),this.dataFormat)),this.activation!=null&&(s=this.activation.apply(s)),this.dataFormat==="channelsFirst"&&(s=It(s,[0,3,1,2])),s})}getConfig(){const t=super.getConfig();return delete t.rank,delete t.kernelInitializer,delete t.kernelRegularizer,delete t.kernelConstraint,t.depthwiseInitializer=Kt(this.depthwiseInitializer),t.pointwiseInitializer=Kt(this.pointwiseInitializer),t.depthwiseRegularizer=_t(this.depthwiseRegularizer),t.pointwiseRegularizer=_t(this.pointwiseRegularizer),t.depthwiseConstraint=ie(this.depthwiseConstraint),t.pointwiseConstraint=ie(this.pointwiseConstraint),t}}rb.className="SeparableConv";class ib extends rb{constructor(t){super(2,t)}}ib.className="SeparableConv2D";j(ib);class tc extends Uo{constructor(t){super(1,t),tc.verifyArgs(t),this.inputSpec=[{ndim:3}]}getConfig(){const t=super.getConfig();return delete t.rank,delete t.dataFormat,t}static verifyArgs(t){if(typeof t.kernelSize!="number"&&!fd(t.kernelSize,"number",1,1))throw new E(`Conv1D expects config.kernelSize to be number or number[] with length 1, but received ${JSON.stringify(t.kernelSize)}.`)}}tc.className="Conv1D";j(tc);class ab extends $t{constructor(t){super(t),typeof t.cropping=="number"?this.cropping=[[t.cropping,t.cropping],[t.cropping,t.cropping]]:typeof t.cropping[0]=="number"?this.cropping=[[t.cropping[0],t.cropping[0]],[t.cropping[1],t.cropping[1]]]:this.cropping=t.cropping,this.dataFormat=t.dataFormat===void 0?"channelsLast":t.dataFormat,this.inputSpec=[{ndim:4}]}computeOutputShape(t){return this.dataFormat==="channelsFirst"?[t[0],t[1],t[2]-this.cropping[0][0]-this.cropping[0][1],t[3]-this.cropping[1][0]-this.cropping[1][1]]:[t[0],t[1]-this.cropping[0][0]-this.cropping[0][1],t[2]-this.cropping[1][0]-this.cropping[1][1],t[3]]}call(t,e){return _(()=>{if(t=ft(t),this.dataFormat==="channelsLast"){const s=ji(t,this.cropping[0][0],t.shape[1]-this.cropping[0][0]-this.cropping[0][1],2);return ji(s,this.cropping[1][0],t.shape[2]-this.cropping[1][1]-this.cropping[1][0],3)}else{const s=ji(t,this.cropping[0][0],t.shape[2]-this.cropping[0][0]-this.cropping[0][1],3);return ji(s,this.cropping[1][0],t.shape[3]-this.cropping[1][1]-this.cropping[1][0],4)}})}getConfig(){const t={cropping:this.cropping,dataFormat:this.dataFormat},e=super.getConfig();return Object.assign(t,e),t}}ab.className="Cropping2D";j(ab);class lb extends $t{constructor(t){super(t),this.DEFAULT_SIZE=[2,2],this.inputSpec=[{ndim:4}],this.size=t.size==null?this.DEFAULT_SIZE:t.size,this.dataFormat=t.dataFormat==null?"channelsLast":t.dataFormat,Qt(this.dataFormat),this.interpolation=t.interpolation==null?"nearest":t.interpolation,d2(this.interpolation)}computeOutputShape(t){if(this.dataFormat==="channelsFirst"){const e=t[2]==null?null:this.size[0]*t[2],s=t[3]==null?null:this.size[1]*t[3];return[t[0],t[1],e,s]}else{const e=t[1]==null?null:this.size[0]*t[1],s=t[2]==null?null:this.size[1]*t[2];return[t[0],e,s,t[3]]}}call(t,e){return _(()=>{let s=ft(t);const o=s.shape;if(this.dataFormat==="channelsFirst"){s=It(s,[0,2,3,1]);const r=this.size[0]*o[2],i=this.size[1]*o[3],a=this.interpolation==="nearest"?Kn.resizeNearestNeighbor(s,[r,i]):Kn.resizeBilinear(s,[r,i]);return It(a,[0,3,1,2])}else{const r=this.size[0]*o[1],i=this.size[1]*o[2];return this.interpolation==="nearest"?Kn.resizeNearestNeighbor(s,[r,i]):Kn.resizeBilinear(s,[r,i])}})}getConfig(){const t={size:this.size,dataFormat:this.dataFormat,interpolation:this.interpolation},e=super.getConfig();return Object.assign(t,e),t}}lb.className="UpSampling2D";j(lb);function zT(n,t,e=[1,1],s="valid",o,r){return _(()=>{o==null&&(o=Cn()),Qt(o);let i=Td(n,o);if(n.rank!==4)throw new E(`Input for depthwiseConv2d is required to be 4-D, but is instead ${n.rank}-D`);if(t.rank!==4)throw new E(`depthwiseKernel is required to be 4-D, but is instead ${t.rank}-D`);return i=gh(i,t,e,s==="same"?"same":"valid","NHWC",r),o==="channelsFirst"&&(i=It(i,[0,3,1,2])),i})}class cb extends Ql{constructor(t){super(2,t),this.depthwiseKernel=null,this.depthMultiplier=t.depthMultiplier==null?1:t.depthMultiplier,this.depthwiseInitializer=Ut(t.depthwiseInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.depthwiseConstraint=ae(t.depthwiseConstraint),this.depthwiseRegularizer=Gt(t.depthwiseRegularizer)}build(t){if(t=St(t),t.length<4)throw new E(`Inputs to DepthwiseConv2D should have rank 4. Received input shape: ${JSON.stringify(t)}.`);const e=this.dataFormat==="channelsFirst"?1:3;if(t[e]==null||t[e]<0)throw new E(`The channel dimension of the inputs to DepthwiseConv2D should be defined, but is not (${t[e]}).`);const s=t[e],o=[this.kernelSize[0],this.kernelSize[1],s,this.depthMultiplier];this.depthwiseKernel=this.addWeight("depthwise_kernel",o,null,this.depthwiseInitializer,this.depthwiseRegularizer,!0,this.depthwiseConstraint),this.useBias?this.bias=this.addWeight("bias",[s*this.depthMultiplier],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(t,e){return _(()=>{t=ft(t);let s=zT(t,this.depthwiseKernel.read(),this.strides,this.padding,this.dataFormat,null);return this.useBias&&(s=In(s,this.bias.read(),this.dataFormat)),this.activation!=null&&(s=this.activation.apply(s)),s})}computeOutputShape(t){t=St(t);const e=this.dataFormat==="channelsFirst"?t[2]:t[1],s=this.dataFormat==="channelsFirst"?t[3]:t[2],o=this.dataFormat==="channelsFirst"?t[1]*this.depthMultiplier:t[3]*this.depthMultiplier,r=yn(e,this.kernelSize[0],this.padding,this.strides[0]),i=yn(s,this.kernelSize[1],this.padding,this.strides[1]);return this.dataFormat==="channelsFirst"?[t[0],o,r,i]:[t[0],r,i,o]}getConfig(){const t=super.getConfig();return t.depthMultiplier=this.depthMultiplier,t.depthwiseInitializer=Kt(this.depthwiseInitializer),t.depthwiseRegularizer=_t(this.depthwiseRegularizer),t.depthwiseConstraint=ie(this.depthwiseRegularizer),t}}cb.className="DepthwiseConv2D";j(cb);function ub(n,t,e,s){if(Array.isArray(n)){if(t!=null||e!=null)throw new E("When inputs is an array, neither initialState or constants should be provided");s!=null&&(e=n.slice(n.length-s,n.length),n=n.slice(0,n.length-s)),n.length>1&&(t=n.slice(1,n.length)),n=n[0]}function o(r){return r==null||Array.isArray(r)?r:[r]}return t=o(t),e=o(e),{inputs:n,initialState:t,constants:e}}function hb(n,t,e,s=!1,o,r,i=!1,a=!1){return _(()=>{const l=t.shape.length;if(l<3)throw new E(`Input should be at least 3D, but is ${l}D.`);const c=[1,0].concat(wn(2,l));t=It(t,c),i&&console.warn("Backend rnn(): the unroll = true option is not applicable to the imperative deeplearn.js backend."),o!=null&&(o=st(st(o,"bool"),"float32"),o.rank===l-1&&(o=Oe(o,-1)),o=It(o,c)),s&&(t=Js(t,0),o!=null&&(o=Js(o,0)));const u=[];let h,d=e;const p=t.shape[0],f=Zs(t);let m;o!=null&&(m=Zs(o));for(let x=0;x<p;++x){const b=f[x],w=_(()=>n(b,d));if(o==null)h=w[0],d=w[1];else{const y=_(()=>{const C=m[x],I=pt(an(C),C),k=Y(R(w[0],C),R(d[0],I)),v=d.map((N,T)=>Y(R(w[1][T],C),R(N,I)));return{output:k,newStates:v}});h=y.output,d=y.newStates}a&&u.push(h)}let g;return a&&(g=qn(u,1)),[h,g,d]})}class Ns extends $t{constructor(t){super(t);let e;if(t.cell==null)throw new E("cell property is missing for the constructor of RNN.");if(Array.isArray(t.cell)?e=new Dd({cells:t.cell}):e=t.cell,e.stateSize==null)throw new E("The RNN cell should have an attribute `stateSize` (tuple of integers, one integer per RNN state).");this.cell=e,this.returnSequences=t.returnSequences==null?!1:t.returnSequences,this.returnState=t.returnState==null?!1:t.returnState,this.goBackwards=t.goBackwards==null?!1:t.goBackwards,this._stateful=t.stateful==null?!1:t.stateful,this.unroll=t.unroll==null?!1:t.unroll,this.supportsMasking=!0,this.inputSpec=[new re({ndim:3})],this.stateSpec=null,this.states_=null,this.numConstants=null,this.keptStates=[]}getStates(){if(this.states_==null){const t=Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1;return wn(0,t).map(e=>null)}else return this.states_}setStates(t){this.states_=t}computeOutputShape(t){eu(t)&&(t=t[0]),t=t;let e=this.cell.stateSize;Array.isArray(e)||(e=[e]);const s=e[0];let o;if(this.returnSequences?o=[t[0],t[1],s]:o=[t[0],s],this.returnState){const r=[];for(const i of e)r.push([t[0],i]);return[o].concat(r)}else return o}computeMask(t,e){return _(()=>{Array.isArray(e)&&(e=e[0]);const s=this.returnSequences?e:null;if(this.returnState){const o=this.states.map(r=>null);return[s].concat(o)}else return s})}get states(){if(this.states_==null){const t=Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1,e=[];for(let s=0;s<t;++s)e.push(null);return e}else return this.states_}set states(t){this.states_=t}build(t){if(this.numConstants!=null)throw new xt("Constants support is not implemented in RNN yet.");eu(t)&&(t=t[0]),t=t;const e=this.stateful?t[0]:null,s=t.slice(2);this.inputSpec[0]=new re({shape:[e,null,...s]});const o=[t[0]].concat(t.slice(2));this.cell.build(o);let r;if(Array.isArray(this.cell.stateSize)?r=this.cell.stateSize:r=[this.cell.stateSize],this.stateSpec!=null){if(!Et(this.stateSpec.map(i=>i.shape[i.shape.length-1]),r))throw new E(`An initialState was passed that is not compatible with cell.stateSize. Received stateSpec=${this.stateSpec}; However cell.stateSize is ${this.cell.stateSize}`)}else this.stateSpec=r.map(i=>new re({shape:[null,i]}));this.stateful&&this.resetStates()}resetStates(t,e=!1){_(()=>{if(!this.stateful)throw new Sn("Cannot call resetStates() on an RNN Layer that is not stateful.");const s=this.inputSpec[0].shape[0];if(s==null)throw new E("If an RNN is stateful, it needs to know its batch size. Specify the batch size of your input tensors: \n- If using a Sequential model, specify the batch size by passing a `batchInputShape` option to your first layer.\n- If using the functional API, specify the batch size by passing a `batchShape` option to your Input layer.");if(this.states_==null)Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(o=>de([s,o])):this.states_=[de([s,this.cell.stateSize])];else if(t==null)yt(this.states_),this.keptStates!=null&&(yt(this.keptStates),this.keptStates=[]),Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(o=>de([s,o])):this.states_[0]=de([s,this.cell.stateSize]);else{if(Array.isArray(t)||(t=[t]),t.length!==this.states_.length)throw new E(`Layer ${this.name} expects ${this.states_.length} state(s), but it received ${t.length} state value(s). Input received: ${t}`);e===!0?this.keptStates.push(this.states_.slice()):yt(this.states_);for(let o=0;o<this.states_.length;++o){const r=t[o],i=Array.isArray(this.cell.stateSize)?this.cell.stateSize[o]:this.cell.stateSize,a=[s,i];if(!Et(r.shape,a))throw new E(`State ${o} is incompatible with layer ${this.name}: expected shape=${a}, received shape=${r.shape}`);this.states_[o]=r}}this.states_=this.states_.map(o=>Dn(o.clone()))})}apply(t,e){let s=e==null?null:e.initialState,o=e==null?null:e.constants;e==null&&(e={});const r=ub(t,s,o,this.numConstants);t=r.inputs,s=r.initialState,o=r.constants;let i=[],a=[];if(s!=null){e.initialState=s,i=i.concat(s),this.stateSpec=[];for(const c of s)this.stateSpec.push(new re({shape:c.shape}));a=a.concat(this.stateSpec)}if(o!=null&&(e.constants=o,i=i.concat(o),this.numConstants=o.length),i[0]instanceof zn){const c=[t].concat(i),u=this.inputSpec.concat(a),h=this.inputSpec;this.inputSpec=u;const d=super.apply(c,e);return this.inputSpec=h,d}else return super.apply(t,e)}call(t,e){return _(()=>{const s=e==null?null:e.mask,o=e==null?null:e.training;let r=e==null?null:e.initialState;t=ft(t),r==null&&(this.stateful?r=this.states_:r=this.getInitialState(t));const i=Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1;if(r.length!==i)throw new E(`RNN Layer has ${i} state(s) but was passed ${r.length} initial state(s).`);this.unroll&&console.warn("Ignoring unroll = true for RNN layer, due to imperative backend.");const a={training:o},c=hb((f,m)=>{const g=this.cell.call([f].concat(m),a);return[g[0],g.slice(1)]},t,r,this.goBackwards,s,null,this.unroll,this.returnSequences),u=c[0],h=c[1],d=c[2];this.stateful&&this.resetStates(d,o);const p=this.returnSequences?h:u;return this.returnState?[p].concat(d):p})}getInitialState(t){return _(()=>{let e=de(t.shape);return e=ct(e,[1,2]),e=Ri(e),Array.isArray(this.cell.stateSize)?this.cell.stateSize.map(s=>s>1?Qc(e,[1,s]):e):this.cell.stateSize>1?[Qc(e,[1,this.cell.stateSize])]:[e]})}get trainableWeights(){return this.trainable?this.cell.trainableWeights:[]}get nonTrainableWeights(){return this.trainable?this.cell.nonTrainableWeights:this.cell.weights}setFastWeightInitDuringBuild(t){super.setFastWeightInitDuringBuild(t),this.cell!=null&&this.cell.setFastWeightInitDuringBuild(t)}getConfig(){const t=super.getConfig(),e={returnSequences:this.returnSequences,returnState:this.returnState,goBackwards:this.goBackwards,stateful:this.stateful,unroll:this.unroll};this.numConstants!=null&&(e.numConstants=this.numConstants);const s=this.cell.getConfig();return this.getClassName()===Ns.className&&(e.cell={className:this.cell.getClassName(),config:s}),Object.assign(Object.assign(Object.assign({},s),t),e)}static fromConfig(t,e,s={}){const o=e.cell,r=_n(o,s);return new t(Object.assign(e,{cell:r}))}}Ns.className="RNN";j(Ns);class ec extends $t{}class Ed extends ec{constructor(t){super(t),this.DEFAULT_ACTIVATION="tanh",this.DEFAULT_KERNEL_INITIALIZER="glorotNormal",this.DEFAULT_RECURRENT_INITIALIZER="orthogonal",this.DEFAULT_BIAS_INITIALIZER="zeros",this.units=t.units,pe(this.units,"units"),this.activation=gs(t.activation==null?this.DEFAULT_ACTIVATION:t.activation),this.useBias=t.useBias==null?!0:t.useBias,this.kernelInitializer=Ut(t.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Ut(t.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Ut(t.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelRegularizer=Gt(t.kernelRegularizer),this.recurrentRegularizer=Gt(t.recurrentRegularizer),this.biasRegularizer=Gt(t.biasRegularizer),this.kernelConstraint=ae(t.kernelConstraint),this.recurrentConstraint=ae(t.recurrentConstraint),this.biasConstraint=ae(t.biasConstraint),this.dropout=Ro([1,fs([0,t.dropout==null?0:t.dropout])]),this.recurrentDropout=Ro([1,fs([0,t.recurrentDropout==null?0:t.recurrentDropout])]),this.dropoutFunc=t.dropoutFunc,this.stateSize=this.units,this.dropoutMask=null,this.recurrentDropoutMask=null}build(t){t=St(t),this.kernel=this.addWeight("kernel",[t[t.length-1],this.units],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight("recurrent_kernel",[this.units,this.units],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias?this.bias=this.addWeight("bias",[this.units],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(t,e){return _(()=>{if(t=t,t.length!==2)throw new E(`SimpleRNNCell expects 2 input Tensors, got ${t.length}.`);let s=t[1];t=t[0];const o=e.training==null?!1:e.training;0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=xs({ones:()=>an(t),rate:this.dropout,training:o,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=xs({ones:()=>an(s),rate:this.recurrentDropout,training:o,dropoutFunc:this.dropoutFunc}));let r;const i=this.dropoutMask,a=this.recurrentDropoutMask;i!=null?r=On(R(t,i),this.kernel.read()):r=On(t,this.kernel.read()),this.bias!=null&&(r=In(r,this.bias.read())),a!=null&&(s=R(s,a));let l=Y(r,On(s,this.recurrentKernel.read()));return this.activation!=null&&(l=this.activation.apply(l)),[l,l]})}getConfig(){const t=super.getConfig(),e={units:this.units,activation:ms(this.activation),useBias:this.useBias,kernelInitializer:Kt(this.kernelInitializer),recurrentInitializer:Kt(this.recurrentInitializer),biasInitializer:Kt(this.biasInitializer),kernelRegularizer:_t(this.kernelRegularizer),recurrentRegularizer:_t(this.recurrentRegularizer),biasRegularizer:_t(this.biasRegularizer),activityRegularizer:_t(this.activityRegularizer),kernelConstraint:ie(this.kernelConstraint),recurrentConstraint:ie(this.recurrentConstraint),biasConstraint:ie(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout};return Object.assign(Object.assign({},t),e)}}Ed.className="SimpleRNNCell";j(Ed);class db extends Ns{constructor(t){t.cell=new Ed(t),super(t)}call(t,e){return _(()=>{this.cell.dropoutMask!=null&&(yt(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(yt(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);const s=e==null?null:e.mask,o=e==null?null:e.training,r=e==null?null:e.initialState;return super.call(t,{mask:s,training:o,initialState:r})})}static fromConfig(t,e){return new t(e)}}db.className="SimpleRNN";j(db);class Rd extends ec{constructor(t){if(super(t),this.DEFAULT_ACTIVATION="tanh",this.DEFAULT_RECURRENT_ACTIVATION="hardSigmoid",this.DEFAULT_KERNEL_INITIALIZER="glorotNormal",this.DEFAULT_RECURRENT_INITIALIZER="orthogonal",this.DEFAULT_BIAS_INITIALIZER="zeros",t.resetAfter)throw new E("GRUCell does not support reset_after parameter set to true.");this.units=t.units,pe(this.units,"units"),this.activation=gs(t.activation===void 0?this.DEFAULT_ACTIVATION:t.activation),this.recurrentActivation=gs(t.recurrentActivation===void 0?this.DEFAULT_RECURRENT_ACTIVATION:t.recurrentActivation),this.useBias=t.useBias==null?!0:t.useBias,this.kernelInitializer=Ut(t.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Ut(t.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Ut(t.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelRegularizer=Gt(t.kernelRegularizer),this.recurrentRegularizer=Gt(t.recurrentRegularizer),this.biasRegularizer=Gt(t.biasRegularizer),this.kernelConstraint=ae(t.kernelConstraint),this.recurrentConstraint=ae(t.recurrentConstraint),this.biasConstraint=ae(t.biasConstraint),this.dropout=Ro([1,fs([0,t.dropout==null?0:t.dropout])]),this.recurrentDropout=Ro([1,fs([0,t.recurrentDropout==null?0:t.recurrentDropout])]),this.dropoutFunc=t.dropoutFunc,this.implementation=t.implementation,this.stateSize=this.units,this.dropoutMask=null,this.recurrentDropoutMask=null}build(t){t=St(t);const e=t[t.length-1];this.kernel=this.addWeight("kernel",[e,this.units*3],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight("recurrent_kernel",[this.units,this.units*3],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias?this.bias=this.addWeight("bias",[this.units*3],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(t,e){return _(()=>{if(t=t,t.length!==2)throw new E(`GRUCell expects 2 input Tensors (inputs, h, c), got ${t.length}.`);const s=e.training==null?!1:e.training;let o=t[1];t=t[0],0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=xs({ones:()=>an(t),rate:this.dropout,training:s,count:3,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=xs({ones:()=>an(o),rate:this.recurrentDropout,training:s,count:3,dropoutFunc:this.dropoutFunc}));const r=this.dropoutMask,i=this.recurrentDropoutMask;let a,l,c;0<this.dropout&&this.dropout<1&&(t=R(t,r[0]));let u=On(t,this.kernel.read());this.useBias&&(u=In(u,this.bias.read())),0<this.recurrentDropout&&this.recurrentDropout<1&&(o=R(o,i[0]));const h=this.recurrentKernel.read(),[d,p]=Xe(h,[2*this.units,this.units],h.rank-1),f=On(o,d),[m,g,x]=Xe(u,3,u.rank-1),[b,w]=Xe(f,2,f.rank-1);a=this.recurrentActivation.apply(Y(m,b)),l=this.recurrentActivation.apply(Y(g,w));const y=On(R(l,o),p);c=this.activation.apply(Y(x,y));const C=Y(R(a,o),R(Y(1,Yt(a)),c));return[C,C]})}getConfig(){const t=super.getConfig(),e={units:this.units,activation:ms(this.activation),recurrentActivation:ms(this.recurrentActivation),useBias:this.useBias,kernelInitializer:Kt(this.kernelInitializer),recurrentInitializer:Kt(this.recurrentInitializer),biasInitializer:Kt(this.biasInitializer),kernelRegularizer:_t(this.kernelRegularizer),recurrentRegularizer:_t(this.recurrentRegularizer),biasRegularizer:_t(this.biasRegularizer),activityRegularizer:_t(this.activityRegularizer),kernelConstraint:ie(this.kernelConstraint),recurrentConstraint:ie(this.recurrentConstraint),biasConstraint:ie(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout,implementation:this.implementation,resetAfter:!1};return Object.assign(Object.assign({},t),e)}}Rd.className="GRUCell";j(Rd);class pb extends Ns{constructor(t){t.implementation===0&&console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."),t.cell=new Rd(t),super(t)}call(t,e){return _(()=>{this.cell.dropoutMask!=null&&(yt(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(yt(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);const s=e==null?null:e.mask,o=e==null?null:e.training,r=e==null?null:e.initialState;return super.call(t,{mask:s,training:o,initialState:r})})}static fromConfig(t,e){return e.implmentation===0&&(e.implementation=1),new t(e)}}pb.className="GRU";j(pb);class nc extends ec{constructor(t){super(t),this.DEFAULT_ACTIVATION="tanh",this.DEFAULT_RECURRENT_ACTIVATION="hardSigmoid",this.DEFAULT_KERNEL_INITIALIZER="glorotNormal",this.DEFAULT_RECURRENT_INITIALIZER="orthogonal",this.DEFAULT_BIAS_INITIALIZER="zeros",this.units=t.units,pe(this.units,"units"),this.activation=gs(t.activation===void 0?this.DEFAULT_ACTIVATION:t.activation),this.recurrentActivation=gs(t.recurrentActivation===void 0?this.DEFAULT_RECURRENT_ACTIVATION:t.recurrentActivation),this.useBias=t.useBias==null?!0:t.useBias,this.kernelInitializer=Ut(t.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Ut(t.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Ut(t.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.unitForgetBias=t.unitForgetBias,this.kernelRegularizer=Gt(t.kernelRegularizer),this.recurrentRegularizer=Gt(t.recurrentRegularizer),this.biasRegularizer=Gt(t.biasRegularizer),this.kernelConstraint=ae(t.kernelConstraint),this.recurrentConstraint=ae(t.recurrentConstraint),this.biasConstraint=ae(t.biasConstraint),this.dropout=Ro([1,fs([0,t.dropout==null?0:t.dropout])]),this.recurrentDropout=Ro([1,fs([0,t.recurrentDropout==null?0:t.recurrentDropout])]),this.dropoutFunc=t.dropoutFunc,this.implementation=t.implementation,this.stateSize=[this.units,this.units],this.dropoutMask=null,this.recurrentDropoutMask=null}build(t){var e;t=St(t);const s=t[t.length-1];this.kernel=this.addWeight("kernel",[s,this.units*4],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight("recurrent_kernel",[this.units,this.units*4],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint);let o;if(this.useBias){if(this.unitForgetBias){const r=this.biasInitializer,i=this.units;o=new(e=class extends cn{apply(l,c){const u=r.apply([i]),h=new gd().apply([i]),d=r.apply([i*2]);return Rp(Rp(u,h),d)}},e.className="CustomInit",e)}else o=this.biasInitializer;this.bias=this.addWeight("bias",[this.units*4],null,o,this.biasRegularizer,!0,this.biasConstraint)}else this.bias=null;this.built=!0}call(t,e){return _(()=>{const s=e.training==null?!1:e.training;if(t=t,t.length!==3)throw new E(`LSTMCell expects 3 input Tensors (inputs, h, c), got ${t.length}.`);let o=t[1];const r=t[2];t=t[0],0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=xs({ones:()=>an(t),rate:this.dropout,training:s,count:4,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=xs({ones:()=>an(o),rate:this.recurrentDropout,training:s,count:4,dropoutFunc:this.dropoutFunc}));const i=this.dropoutMask,a=this.recurrentDropoutMask;let l,c,u,h;0<this.dropout&&this.dropout<1&&(t=R(t,i[0]));let d=On(t,this.kernel.read());0<this.recurrentDropout&&this.recurrentDropout<1&&(o=R(o,a[0])),d=Y(d,On(o,this.recurrentKernel.read())),this.useBias&&(d=In(d,this.bias.read()));const[p,f,m,g]=Xe(d,4,d.rank-1);l=this.recurrentActivation.apply(p),c=this.recurrentActivation.apply(f),u=Y(R(c,r),R(l,this.activation.apply(m))),h=this.recurrentActivation.apply(g);const x=R(h,this.activation.apply(u));return[x,x,u]})}getConfig(){const t=super.getConfig(),e={units:this.units,activation:ms(this.activation),recurrentActivation:ms(this.recurrentActivation),useBias:this.useBias,kernelInitializer:Kt(this.kernelInitializer),recurrentInitializer:Kt(this.recurrentInitializer),biasInitializer:Kt(this.biasInitializer),unitForgetBias:this.unitForgetBias,kernelRegularizer:_t(this.kernelRegularizer),recurrentRegularizer:_t(this.recurrentRegularizer),biasRegularizer:_t(this.biasRegularizer),activityRegularizer:_t(this.activityRegularizer),kernelConstraint:ie(this.kernelConstraint),recurrentConstraint:ie(this.recurrentConstraint),biasConstraint:ie(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout,implementation:this.implementation};return Object.assign(Object.assign({},t),e)}}nc.className="LSTMCell";j(nc);class fb extends Ns{constructor(t){t.implementation===0&&console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."),t.cell=new nc(t),super(t)}call(t,e){return _(()=>{this.cell.dropoutMask!=null&&(yt(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(yt(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);const s=e==null?null:e.mask,o=e==null?null:e.training,r=e==null?null:e.initialState;return super.call(t,{mask:s,training:o,initialState:r})})}static fromConfig(t,e){return e.implmentation===0&&(e.implementation=1),new t(e)}}fb.className="LSTM";j(fb);class Dd extends ec{constructor(t){super(t),this.cells=t.cells}get stateSize(){const t=[];for(const e of this.cells.slice().reverse())Array.isArray(e.stateSize)?t.push(...e.stateSize):t.push(e.stateSize);return t}call(t,e){return _(()=>{t=t;let s=t.slice(1);const o=[];for(const a of this.cells.slice().reverse())Array.isArray(a.stateSize)?o.push(s.splice(0,a.stateSize.length)):o.push(s.splice(0,1));o.reverse();const r=[];let i;for(let a=0;a<this.cells.length;++a){const l=this.cells[a];s=o[a],a===0?i=[t[0]].concat(s):i=[i[0]].concat(s),i=l.call(i,e),r.push(i.slice(1))}s=[];for(const a of r.slice().reverse())s.push(...a);return[i[0]].concat(s)})}build(t){eu(t)&&(t=t[0]),t=t;let e;this.cells.forEach((s,o)=>{Bs(`RNNCell_${o}`,()=>{s.build(t),Array.isArray(s.stateSize)?e=s.stateSize[0]:e=s.stateSize,t=[t[0],e]})}),this.built=!0}getConfig(){const t=super.getConfig(),e=r=>({className:r.getClassName(),config:r.getConfig()}),o={cells:this.cells.map(e)};return Object.assign(Object.assign({},t),o)}static fromConfig(t,e,s={}){const o=[];for(const r of e.cells)o.push(_n(r,s));return new t({cells:o})}get trainableWeights(){if(!this.trainable)return[];const t=[];for(const e of this.cells)t.push(...e.trainableWeights);return t}get nonTrainableWeights(){const t=[];for(const e of this.cells)t.push(...e.nonTrainableWeights);if(!this.trainable){const e=[];for(const s of this.cells)e.push(...s.trainableWeights);return e.concat(t)}return t}getWeights(){const t=[];for(const e of this.cells)t.push(...e.weights);return nu(t)}setWeights(t){const e=[];for(const s of this.cells){const o=s.weights.length,r=t.splice(o);for(let i=0;i<s.weights.length;++i)e.push([s.weights[i],r[i]])}Id(e)}}Dd.className="StackedRNNCells";j(Dd);function xs(n){const{ones:t,rate:e,training:s=!1,count:o=1,dropoutFunc:r}=n,i=()=>r!=null?r(t(),e):rx(t(),e),a=()=>Ai(i,t,s);return!o||o<=1?Dn(a().clone()):Array(o).fill(void 0).map(a).map(c=>Dn(c.clone()))}var BT=function(n,t){var e={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&t.indexOf(s)<0&&(e[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var o=0,s=Object.getOwnPropertySymbols(n);o<s.length;o++)t.indexOf(s[o])<0&&Object.prototype.propertyIsEnumerable.call(n,s[o])&&(e[s[o]]=n[s[o]]);return e};class mb extends Ns{constructor(t){if(t.unroll)throw new xt("Unrolling is not possible with convolutional RNNs.");if(Array.isArray(t.cell))throw new xt("It is not possible at the moment to stack convolutional cells.");super(t),this.inputSpec=[new re({ndim:5})]}call(t,e){return _(()=>{if(this.cell.dropoutMask!=null&&(yt(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(yt(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null),e&&e.constants)throw new E("ConvRNN2D cell does not support constants");const s=e==null?null:e.mask,o=e==null?null:e.training,r=e==null?null:e.initialState;return super.call(t,{mask:s,training:o,initialState:r})})}computeOutputShape(t){let e=this.computeSingleOutputShape(t);return this.returnSequences||(e=[e[0],...e.slice(2)]),this.returnState&&(e=[e,...Array(2).fill([t[0],...e.slice(-3)])]),e}getInitialState(t){return _(()=>{const{stateSize:e}=this.cell,s=t.shape,o=this.computeSingleOutputShape(s),r=[o[0],...o.slice(2)],i=de(r);return Array.isArray(e)?Array(e.length).fill(i):[i]})}resetStates(t,e=!1){_(()=>{if(!this.stateful)throw new Sn("Cannot call resetStates() on an RNN Layer that is not stateful.");const s=this.inputSpec[0].shape,o=this.computeSingleOutputShape(s),r=[o[0],...o.slice(2)];if(s[0]==null)throw new E("If an RNN is stateful, it needs to know its batch size. Specify the batch size of your input tensors: \n- If using a Sequential model, specify the batch size by passing a `batchInputShape` option to your first layer.\n- If using the functional API, specify the batch size by passing a `batchShape` option to your Input layer.");if(this.getStates()==null)Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(()=>de(r)):this.states_=[de(r)];else if(t==null)yt(this.states_),this.keptStates!=null&&(yt(this.keptStates),this.keptStates=[]),Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(()=>de(r)):this.states_[0]=de(r);else{if(Array.isArray(t)||(t=[t]),t.length!==this.states_.length)throw new E(`Layer ${this.name} expects ${this.states_.length} state(s), but it received ${t.length} state value(s). Input received: ${t}`);e?this.keptStates.push(this.states_.slice()):yt(this.states_);for(let a=0;a<this.states_.length;++a){const l=t[a],c=r;if(!Et(l.shape,c))throw new E(`State ${a} is incompatible with layer ${this.name}: expected shape=${c}, received shape=${l.shape}`);this.states_[a]=l}}this.states_=this.states_.map(a=>Dn(a.clone()))})}computeSingleOutputShape(t){const{dataFormat:e,filters:s,kernelSize:o,padding:r,strides:i,dilationRate:a}=this.cell,l=e==="channelsFirst",c=t[l?3:2],u=t[l?4:3],h=yn(c,o[0],r,i[0],a[0]),d=yn(u,o[1],r,i[1],a[1]);return[...t.slice(0,2),...l?[s,h,d]:[h,d,s]]}}mb.className="ConvRNN2D";class Ad extends nc{constructor(t){const{filters:e,kernelSize:s,strides:o,padding:r,dataFormat:i,dilationRate:a}=t;super(Object.assign(Object.assign({},t),{units:e})),this.filters=e,pe(this.filters,"filters"),this.kernelSize=ko(s,2,"kernelSize"),this.kernelSize.forEach(l=>pe(l,"kernelSize")),this.strides=ko(o||1,2,"strides"),this.strides.forEach(l=>pe(l,"strides")),this.padding=r||"valid",Ze(this.padding),this.dataFormat=i||"channelsLast",Qt(this.dataFormat),this.dilationRate=ko(a||1,2,"dilationRate"),this.dilationRate.forEach(l=>pe(l,"dilationRate"))}build(t){var e;t=St(t);const s=this.dataFormat==="channelsFirst"?1:t.length-1;if(t[s]==null)throw new E(`The channel dimension of the input should be defined. Found ${t[s]}`);const o=t[s],r=4,i=this.kernelSize.concat([o,this.filters*r]);this.kernel=this.addWeight("kernel",i,null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint);const a=this.kernelSize.concat([this.filters,this.filters*r]);if(this.recurrentKernel=this.addWeight("recurrent_kernel",a,null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias){let l;if(this.unitForgetBias){const c=this.biasInitializer,u=this.filters;l=new(e=class extends cn{apply(d,p){const f=c.apply([u]),m=vs([u]),g=c.apply([u*2]);return md([f,m,g])}},e.className="CustomInit",e)}else l=this.biasInitializer;this.bias=this.addWeight("bias",[this.filters*r],null,l,this.biasRegularizer,!0,this.biasConstraint)}this.built=!0}call(t,e){return _(()=>{if(t.length!==3)throw new E(`ConvLSTM2DCell expects 3 input Tensors (inputs, h, c), got ${t.length}.`);const s=e.training||!1,o=t[0],r=t[1],i=t[2],a=4;0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=xs({ones:()=>an(o),rate:this.dropout,training:s,count:a,dropoutFunc:this.dropoutFunc}));const l=this.dropoutMask,c=(q,X,Z)=>!X||!X[Z]?q:R(X[Z],q);let u=c(o,l,0),h=c(o,l,1),d=c(o,l,2),p=c(o,l,3);0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=xs({ones:()=>an(r),rate:this.recurrentDropout,training:s,count:a,dropoutFunc:this.dropoutFunc}));const f=this.recurrentDropoutMask;let m=c(r,f,0),g=c(r,f,1),x=c(r,f,2),b=c(r,f,3);const w=3,[y,C,I,k]=Xe(this.kernel.read(),a,w),[v,N,T,O]=this.useBias?Xe(this.bias.read(),a):[null,null,null,null];u=this.inputConv(u,y,v,this.padding),h=this.inputConv(h,C,N,this.padding),d=this.inputConv(d,I,T,this.padding),p=this.inputConv(p,k,O,this.padding);const[P,z,B,M]=Xe(this.recurrentKernel.read(),a,w);m=this.recurrentConv(m,P),g=this.recurrentConv(g,z),x=this.recurrentConv(x,B),b=this.recurrentConv(b,M);const G=this.recurrentActivation.apply(Y(u,m)),H=this.recurrentActivation.apply(Y(h,g)),U=Y(R(H,i),R(G,this.activation.apply(Y(d,x)))),K=R(this.recurrentActivation.apply(Y(p,b)),this.activation.apply(U));return[K,K,U]})}getConfig(){const t=super.getConfig(),{units:e}=t,s=BT(t,["units"]),o={filters:this.filters,kernelSize:this.kernelSize,padding:this.padding,dataFormat:this.dataFormat,dilationRate:this.dilationRate,strides:this.strides};return Object.assign(Object.assign({},s),o)}inputConv(t,e,s,o){const r=Xs(t,e,this.strides,o||"valid",this.dataFormat==="channelsFirst"?"NCHW":"NHWC",this.dilationRate);return s?In(r,s,this.dataFormat):r}recurrentConv(t,e){return Xs(t,e,1,"same",this.dataFormat==="channelsFirst"?"NCHW":"NHWC")}}Ad.className="ConvLSTM2DCell";j(Ad);class gb extends mb{constructor(t){const e=new Ad(t);super(Object.assign(Object.assign({},t),{cell:e}))}static fromConfig(t,e){return new t(e)}}gb.className="ConvLSTM2D";j(gb);class Fd extends $t{constructor(t){super(t),this.rate=Math.max(Math.min(t.rate,1),0),this.noiseShape=t.noiseShape,this.seed=t.seed,this.supportsMasking=!0}getNoiseShape(t){if(this.noiseShape==null)return this.noiseShape;const e=t.shape,s=[];for(let o=0;o<this.noiseShape.length;++o)s.push(this.noiseShape[o]==null?e[o]:this.noiseShape[o]);return s}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t);if(0<this.rate&&this.rate<1){const o=e.training==null?!1:e.training,r=this.getNoiseShape(s);return Ai(()=>rx(s,this.rate,r,this.seed),()=>s,o)}return t})}getConfig(){const t={rate:this.rate,noiseShape:this.noiseShape,seed:this.seed},e=super.getConfig();return Object.assign(t,e),t}dispose(){return super.dispose()}}Fd.className="Dropout";j(Fd);class xb extends Fd{constructor(t){super(t),this.inputSpec=[{ndim:3}]}getNoiseShape(t){const e=t.shape;return[e[0],1,e[2]]}}xb.className="SpatialDropout1D";j(xb);class bb extends $t{constructor(t){if(super(t),this.activation=null,this.useBias=!0,this.kernel=null,this.bias=null,this.DEFAULT_KERNEL_INITIALIZER="glorotNormal",this.DEFAULT_BIAS_INITIALIZER="zeros",t.batchInputShape==null&&t.inputShape==null&&t.inputDim!=null){let e=null;t.batchSize!=null&&(e=t.batchSize),this.batchInputShape=[e,t.inputDim]}this.units=t.units,pe(this.units,"units"),this.activation=gs(t.activation),t.useBias!=null&&(this.useBias=t.useBias),this.kernelInitializer=Ut(t.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.biasInitializer=Ut(t.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelConstraint=ae(t.kernelConstraint),this.biasConstraint=ae(t.biasConstraint),this.kernelRegularizer=Gt(t.kernelRegularizer),this.biasRegularizer=Gt(t.biasRegularizer),this.activityRegularizer=Gt(t.activityRegularizer),this.supportsMasking=!0,this.inputSpec=[{minNDim:2}]}build(t){t=St(t);const e=t[t.length-1];this.kernel==null&&(this.kernel=this.addWeight("kernel",[e,this.units],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight("bias",[this.units],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint))),this.inputSpec=[{minNDim:2,axes:{[-1]:e}}],this.built=!0}computeOutputShape(t){t=St(t);const e=t.slice();return e[e.length-1]=this.units,e}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t),o=Zg(this.activation.getClassName());let r;return o!=null?r=On(s,this.kernel.read(),o,this.bias?this.bias.read():null):(r=On(s,this.kernel.read()),this.bias!=null&&(r=In(r,this.bias.read())),this.activation!=null&&(r=this.activation.apply(r))),r})}getConfig(){const t={units:this.units,activation:ms(this.activation),useBias:this.useBias,kernelInitializer:Kt(this.kernelInitializer),biasInitializer:Kt(this.biasInitializer),kernelRegularizer:_t(this.kernelRegularizer),biasRegularizer:_t(this.biasRegularizer),activityRegularizer:_t(this.activityRegularizer),kernelConstraint:ie(this.kernelConstraint),biasConstraint:ie(this.biasConstraint)},e=super.getConfig();return Object.assign(t,e),t}}bb.className="Dense";j(bb);class yb extends $t{constructor(t){t=t||{},super(t),this.inputSpec=[{minNDim:3}],this.dataFormat=t.dataFormat}computeOutputShape(t){t=St(t);for(const e of t.slice(1))if(e==null)throw new E(`The shape of the input to "Flatten" is not fully defined (got ${t.slice(1)}). Make sure to pass a complete "input_shape" or "batch_input_shape" argument to the first layer in your model.`);return[t[0],ds(t,1)]}call(t,e){return _(()=>{this.invokeCallHook(t,e);let s=ft(t);if(this.dataFormat==="channelsFirst"&&s.rank>1){const o=[0];for(let r=2;r<s.rank;++r)o.push(r);o.push(1),s=It(s,o)}return b2(s)})}getConfig(){const t={};this.dataFormat!=null&&(t.dataFormat=this.dataFormat);const e=super.getConfig();return Object.assign(t,e),t}}yb.className="Flatten";j(yb);class wb extends $t{constructor(t){super(t),this.supportsMasking=!0,this.activation=gs(t.activation)}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t);return this.activation.apply(s)})}getConfig(){const t={activation:ms(this.activation)},e=super.getConfig();return Object.assign(t,e),t}}wb.className="Activation";j(wb);class Cb extends $t{constructor(t){super(t),this.n=t.n,this.inputSpec=[{ndim:2}]}computeOutputShape(t){return[t[0],this.n,t[1]]}call(t,e){return _(()=>(t=ft(t),g2(t,this.n)))}getConfig(){const t={n:this.n},e=super.getConfig();return Object.assign(t,e),t}}Cb.className="RepeatVector";j(Cb);class $b extends $t{constructor(t){super(t),this.targetShape=t.targetShape;for(let e=0;e<this.targetShape.length;++e)this.isUnknown(this.targetShape[e])&&(this.targetShape[e]=null)}isUnknown(t){return t<0||t==null}fixUnknownDimension(t,e){const s="Total size of new array must be unchanged.",o=e.slice();let r=1,i=null;for(let l=0;l<o.length;++l){const c=o[l];if(this.isUnknown(c))if(i===null)i=l;else throw new E("Can only specifiy one unknown dimension.");else r*=c}const a=ds(t);if(i!==null){if(r===0||a%r!==0)throw new E(s);o[i]=a/r}else if(a!==r)throw new E(s);return o}computeOutputShape(t){let e=!1;for(let s=0;s<t.length;++s)if(this.isUnknown(t[s])){e=!0;break}return e?t.slice(0,1).concat(this.targetShape):t.slice(0,1).concat(this.fixUnknownDimension(t.slice(1),this.targetShape))}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t),o=s.shape,r=o.slice(0,1).concat(this.fixUnknownDimension(o.slice(1),this.targetShape));return A(s,r)})}getConfig(){const t={targetShape:this.targetShape},e=super.getConfig();return Object.assign(t,e),t}}$b.className="Reshape";j($b);class Ib extends $t{constructor(t){if(super(t),t.dims==null)throw new Error("Required configuration field `dims` is missing during Permute constructor call.");if(!Array.isArray(t.dims))throw new Error(`Permute constructor requires \`dims\` to be an Array, but received ${t.dims} instead.`);const e=wn(1,t.dims.length+1);if(!Et(t.dims.slice().sort(),e))throw new Error("Invalid permutation `dims`: "+JSON.stringify(t.dims)+" `dims` must contain consecutive integers starting from 1.");this.dims=t.dims,this.dimsIncludingBatch=[0].concat(this.dims),this.inputSpec=[new re({ndim:this.dims.length+1})]}computeOutputShape(t){t=St(t);const e=t.slice();return this.dims.forEach((s,o)=>{e[o+1]=t[s]}),e}call(t,e){return It(ft(t),this.dimsIncludingBatch)}getConfig(){const t={dims:this.dims},e=super.getConfig();return Object.assign(t,e),t}}Ib.className="Permute";j(Ib);class kb extends $t{constructor(t){super(t??{}),this.supportsMasking=!0,t!=null?this.maskValue=t.maskValue==null?0:t.maskValue:this.maskValue=0}computeOutputShape(t){return t}getConfig(){const t=super.getConfig(),e={maskValue:this.maskValue};return Object.assign(e,t),e}computeMask(t,e){const s=ft(t);return Kc(pa(s,this.maskValue),-1)}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t),i=Kc(pa(s,this.maskValue),-1,!0);return R(s,st(i,s.dtype))})}}kb.className="Masking";j(kb);class vb extends $t{constructor(t){if(super(t),this.embeddings=null,this.DEFAULT_EMBEDDINGS_INITIALIZER="randomUniform",t.batchInputShape==null&&t.inputShape==null){let e=null;t.batchSize!=null&&(e=t.batchSize),t.inputLength==null?this.batchInputShape=[e,null]:this.batchInputShape=[e].concat(Dt(t.inputLength))}this.inputDim=t.inputDim,pe(this.inputDim,"inputDim"),this.outputDim=t.outputDim,pe(this.outputDim,"outputDim"),this.embeddingsInitializer=Ut(t.embeddingsInitializer||this.DEFAULT_EMBEDDINGS_INITIALIZER),this.embeddingsRegularizer=Gt(t.embeddingsRegularizer),this.activityRegularizer=Gt(t.activityRegularizer),this.embeddingsConstraint=ae(t.embeddingsConstraint),this.maskZero=t.maskZero,this.supportsMasking=t.maskZero,this.inputLength=t.inputLength}build(t){this.embeddings=this.addWeight("embeddings",[this.inputDim,this.outputDim],this.dtype,this.embeddingsInitializer,this.embeddingsRegularizer,!0,this.embeddingsConstraint),this.built=!0}warnOnIncompatibleInputShape(t){}computeMask(t,e){return _(()=>this.maskZero?(t=ft(t),pa(t,kt(t))):null)}computeOutputShape(t){if(t=St(t),this.inputLength==null)return[...t,this.outputDim];const e=Dt(this.inputLength);if(e.length!==t.length-1)throw new E(`"inputLength" is ${this.inputLength}, but received input shape has shape ${t}`);{let s=0;for(let o=0;o<e.length;++o){const r=e[o],i=t[o+1];if(r!=null&&i!=null&&r!==i)throw new E(`"inputLength" is ${this.inputLength}, but received input shape has shape ${t}`);r==null&&(e[s]=i),s++}}return[t[0],...e,this.outputDim]}call(t,e){return _(()=>{this.invokeCallHook(t,e);let s=ft(t);s.dtype!=="int32"&&(s=Fn(s,"int32"));const o=ox(this.embeddings.read(),A(s,[s.size]));return A(o,St(this.computeOutputShape(s.shape)))})}getConfig(){const t={inputDim:this.inputDim,outputDim:this.outputDim,embeddingsInitializer:Kt(this.embeddingsInitializer),embeddingsRegularizer:_t(this.embeddingsRegularizer),activityRegularizer:_t(this.activityRegularizer),embeddingsConstraint:ie(this.embeddingsConstraint),maskZero:this.maskZero,inputLength:this.inputLength},e=super.getConfig();return Object.assign(t,e),t}}vb.className="Embedding";j(vb);class lo extends $t{constructor(t){super(t||{}),this.supportsMasking=!0}mergeFunction(t){throw new xt}computeElementwiseOpOutputShape(t,e){if(t==null||e==null)return null;if(t.length<e.length)return this.computeElementwiseOpOutputShape(e,t);if(e.length===0)return t;const s=t.slice(0,t.length-e.length);for(let o=0;o<e.length;++o){const r=t[t.length-e.length+o],i=e[o];if(r==null||i==null||r<0||i<0)s.push(null);else if(r===1)s.push(i);else if(i===1)s.push(r);else{if(r!==i)throw new E("Operands could not be broadcast together with shapes "+JSON.stringify(t)+" "+JSON.stringify(e));s.push(r)}}return s}build(t){if(Array.isArray(t)&&!Array.isArray(t[0])&&(t=[St(t)]),t=t,t.length<2)throw new E(`A merge layer should be called on an Array of at least 2 inputs. Got ${t.length} input(s).`);let e=[];for(const r of t)r!=null&&r[0]!==null&&e.push(r[0]);if(e=hs(e),e.length>1)throw new E(`Can not merge tensors with different batch sizes. Got tensors with shapes: ${JSON.stringify(t)}.`);let s=t[0]==null?null:t[0].slice(1);for(let r=1;r<t.length;++r){const i=t[r]==null?null:t[r].slice(1);s=this.computeElementwiseOpOutputShape(s,i)}const o=t.map(r=>r.length);t.indexOf(null)===-1&&hs(o).length===1?this.reshapeRequired=!1:this.reshapeRequired=!0}call(t,e){return _(()=>{if(t=t,this.reshapeRequired){const s=[],o=t.map(r=>r.rank);if(o.indexOf(null)===-1){const r=fs(o);for(let i of t){const a=i.rank;for(let l=0;l<r-a;++l)i=Ri(i,1);s.push(i)}return this.mergeFunction(s)}else{let r=!1;for(const l of t){const c=l.rank;if(c==null){const u=l.shape,h=u[0],d=u.slice(1).concat([h]);let p=A(l,[h].concat(ds(u.slice(1))));p=It(p,[1,0]),p=A(p,d),s.push(p),r=!0}else if(c>1){const u=wn(1,c).concat([0]);s.push(It(l,u)),r=!0}else s.push(l)}let i=this.mergeFunction(s);const a=i.rank;if(r){if(a==null){const l=i.shape,c=l.length,u=l[c-1],h=[u].concat(l.slice(0,l.length-1));i=A(It(A(i,[-1,u]),[1,0]),h)}else if(a>1){const l=[a-1].concat(wn(0,a-1));i=It(i,l)}}return i}}else return this.mergeFunction(t)})}computeOutputShape(t){t=t;let e;t[0]==null?e=null:e=t[0].slice(1);for(let o=1;o<t.length;++o){const r=t[o]==null?null:t[o].slice(1);e=this.computeElementwiseOpOutputShape(e,r)}let s=[];for(const o of t)o!=null&&o[0]!==null&&s.push(o[0]);return s=hs(s),s.length===1?e=s.concat(e):e=[null].concat(e),e}computeMask(t,e){return _(()=>{if(e==null)return null;if(!Array.isArray(e))throw new E("`mask` should be an Array");if(!Array.isArray(t))throw new E("`inputs` should be an Array");if(e.length!==t.length)throw new E(`The Array 'inputs' and 'mask' are expected to have the same length, but have different lengths (${t.length} vs ${e.length})`);if(e.every(o=>o==null))return null;e=e.map(o=>o==null?o:Oe(o,0));let s=e[0];for(let o=1;o<e.length-1;++o)s=jn(s,e[o]);return s})}}class Sb extends lo{constructor(t){super(t)}mergeFunction(t){return _(()=>{let e=t[0].clone();for(let s=1;s<t.length;++s)e=Y(e,t[s]);return e})}}Sb.className="Add";j(Sb);class Nb extends lo{constructor(t){super(t)}mergeFunction(t){return _(()=>{let e=t[0].clone();for(let s=1;s<t.length;++s)e=R(e,t[s]);return e})}}Nb.className="Multiply";j(Nb);class Tb extends lo{constructor(t){super(t)}mergeFunction(t){return _(()=>{let e=t[0].clone();for(let s=1;s<t.length;++s)e=Y(e,t[s]);return R(1/t.length,e)})}}Tb.className="Average";j(Tb);class Eb extends lo{constructor(t){super(t)}mergeFunction(t){return _(()=>{let e=t[0];for(let s=1;s<t.length;++s)e=ks(e,t[s]);return e})}}Eb.className="Maximum";j(Eb);class Rb extends lo{constructor(t){super(t)}mergeFunction(t){return _(()=>{let e=t[0];for(let s=1;s<t.length;++s)e=mr(e,t[s]);return e})}}Rb.className="Minimum";j(Rb);class Db extends lo{constructor(t){super(t),this.DEFAULT_AXIS=-1,t==null&&(t={}),this.axis=t.axis==null?this.DEFAULT_AXIS:t.axis,this.supportsMasking=!0,this.reshapeRequired=!1}build(t){if(!(Array.isArray(t)&&Array.isArray(t[0]))||t.length===1)throw new E("A `Concatenate` layer should be called on a list of at least 2 inputs");t=t;let e=!0;for(const o of t)if(o!=null){e=!1;break}if(e)return;const s=[];for(let o=0;o<t.length;++o){const r=t[o].slice();r.splice(this.axis,1);let i=!1;for(const a of s)if(Et(a,r)){i=!0;break}i||s.push(r)}if(s.length>1)throw new E("A `Concatenate` layer requires inputs with matching shapes except for the concat axis. Got input shapes: "+JSON.stringify(t))}mergeFunction(t){return _(()=>md(t,this.axis))}computeOutputShape(t){if(!(Array.isArray(t)&&Array.isArray(t[0])))throw new E("A `Concatenate` layer should be called on a list of inputs.");const e=t,s=e[0].slice(),o=this.axis<0?s.length+this.axis:this.axis;for(const r of e.slice(1)){if(s[o]==null||r[o]==null){s[o]=null;break}s[o]+=r[o]}return s}computeMask(t,e){if(e==null)return null;if(!Array.isArray(e))throw new E("`mask` should be an array for Concatenate");if(!Array.isArray(t))throw new E("`inputs` should be an array for Concatenate");if(e.length!==t.length)throw new E(`Mismatch in the length of mask (${e.length}) and the legnth of inputs (${t.length})`);return _(()=>{let s=!0;if(e.forEach(i=>{if(i!=null){s=!1;return}}),s)return null;const o=[];for(let i=0;i<t.length;++i)e[i]==null?o.push(st(an(t[i]),"bool")):e[i].rank<t[i].rank?o.push(Oe(e[i],-1)):o.push(e[i]);const r=Le(o,this.axis);return Rm(r,-1,!1)})}getConfig(){const t={axis:this.axis},e=super.getConfig();return Object.assign(t,e),t}}Db.className="Concatenate";j(Db);function nr(n,t){for(;n<0;)n+=t;return n}function VT(n,t,e){if(n.shape.length>3||t.shape.length>3)throw new xt("batchDot is not implemented for tensors of 4D or higher rank yet");if($(n.shape.length>=2,()=>`batchDot requires the rank of x to be >= 2, but got ${n.shape.length}`),$(n.shape.length>=2,()=>`batchDot requires the rank of y to be >= 2, but got ${t.shape.length}`),typeof e=="number"&&(e=[e,e]),n.dtype==="complex64"||t.dtype==="complex64")throw new xt("batchDot is not implemented for complex64-type Tensors yet.");const s=n.shape.length,o=t.shape.length;e==null&&(e=[s-1,o-2]);const r=e;return _(()=>{let i;if(s>o){i=s-o;const l=[];for(let c=0;c<i;++c)l.push(1);t=A(t,t.shape.concat(l))}else if(o>s){i=o-s;const l=[];for(let c=0;c<i;++c)l.push(1);n=A(n,n.shape.concat(l))}else i=0;let a;if(n.shape.length===2&&t.shape.length===2)r[0]===r[1]?a=ct(R(n,t),r[0]):a=ct(R(It(n,[1,0]),t),r[1]);else{const l=r[0]!==n.shape.length-1,c=r[1]===t.shape.length-1;a=Nt(n,t,l,c)}if(i>0){let l;s>o?l=s+o-3:l=s-1;const c=[];for(let u=l;u<l+i;++u)c.push(u);a=ki(a,c)}return a.shape.length===1&&(a=Oe(a,1)),a})}class Ab extends lo{constructor(t){super(t),this.axes=t.axes,this.normalize=t.normalize==null?!1:t.normalize,this.supportsMasking=!0,this.reshapeRequired=!1}build(t){$(Array.isArray(t)&&t.length===2&&Array.isArray(t[0])&&Array.isArray(t[1]),()=>"A `Dot` layer should be called on a list of exactly 2 inputs.");const e=t[0],s=t[1];if(e.length>3||s.length>3)throw new xt("Dot layer does not support tensors of 4D or higher rank yet.");const o=this.interpretAxes(e,s);if(e[o[0]]!==s[o[1]])throw new E(`Dimension incompatibility: ${e[o[0]]} !== ${s[o[1]]}`)}mergeFunction(t){if(t.length!==2)throw new E(`A \`Dot\` layer must be called on exactly 2 inputs, but received ${t.length} input(s).`);let e=t[0],s=t[1],o;return Array.isArray(this.axes)?o=this.axes.map((r,i)=>nr(r,t[i].shape.length)):o=[nr(this.axes,e.shape.length),nr(this.axes,s.shape.length)],this.normalize&&(e=wa(e,o[0]),s=wa(s,o[1])),VT(e,s,o)}interpretAxes(t,e){let s;return Array.isArray(this.axes)?s=this.axes:s=[nr(this.axes,t.length),nr(this.axes,e.length)],s}computeOutputShape(t){$(Array.isArray(t)&&t.length===2&&Array.isArray(t[0])&&Array.isArray(t[1]),()=>"A `Dot` layer should be called on a list of exactly 2 inputs.");const e=t[0].slice(),s=t[1].slice();if(e.length>3||s.length>3)throw new xt("Dot layer does not support tensors of 4D or higher rank yet.");const o=this.interpretAxes(e,s);e.splice(o[0],1),s.splice(o[1],1),s.splice(0,1);const r=e.concat(s);return r.length===1&&r.push(1),r}computeMask(t,e){return null}getConfig(){const t={axes:this.axes,normalize:this.normalize},e=super.getConfig();return Object.assign(t,e),t}}Ab.className="Dot";j(Ab);class Fb extends $t{constructor(t){super(t),this.supportsMasking=!0,this.stddev=t.stddev}computeOutputShape(t){return t}getConfig(){const t=super.getConfig(),e={stddev:this.stddev};return Object.assign(e,t),e}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t);return Ai(()=>Y(Xl(s.shape,0,this.stddev),s),()=>s,e.training||!1)})}}Fb.className="GaussianNoise";j(Fb);class Ob extends $t{constructor(t){super(t),this.supportsMasking=!0,this.rate=t.rate}computeOutputShape(t){return t}getConfig(){const t=super.getConfig(),e={rate:this.rate};return Object.assign(e,t),e}call(t,e){return _(()=>{this.invokeCallHook(t,e);const s=ft(t);return this.rate>0&&this.rate<1?Ai(()=>{const r=Math.sqrt(this.rate/(1-this.rate));return R(s,Xl(s.shape,1,r))},()=>s,e.training||!1):s})}}Ob.className="GaussianDropout";j(Ob);class _b extends $t{constructor(t){super(t),this.supportsMasking=!0,this.rate=t.rate,this.noiseShape=t.noiseShape}_getNoiseShape(t){return this.noiseShape||ft(t).shape}computeOutputShape(t){return t}getConfig(){const t=super.getConfig(),e={rate:this.rate};return Object.assign(e,t),e}call(t,e){return _(()=>{if(this.rate<1&&this.rate>0){const s=this._getNoiseShape(t);return Ai(()=>{const r=ft(t),a=-1.6732632423543772*1.0507009873554805;let l=oo(Ii(s),this.rate);l=Fn(l,"float32");const c=((1-this.rate)*(1+this.rate*a**2))**-.5,u=-c*a*this.rate,h=Y(R(r,l),R(Y(l,-1),a));return Y(R(h,c),u)},()=>ft(t),e.training||!1)}return t})}}_b.className="AlphaDropout";j(_b);function wr(n,t,e,s,o,r=.001){let i;if(n.rank===2)i=EC(n,t,e,s,o,r);else if(n.rank===3)i=DC(n,t,e,s,o,r);else if(n.rank===4)i=FC(n,t,e,s,o,r);else throw new xt(`batchNormalization is not implemented for array of rank ${n.rank} yet`);return i}function WT(n,t,e,s,o=.001){return _(()=>{const r=Ih(n,s),i=r.mean,a=r.variance;return[wr(n,i,a,e,t,o),i,a]})}function UT(n,t,e,s,o=.001){return _(()=>{const r=Ih(n,s),i=r.mean,a=r.variance,l=[];for(const f of wn(0,n.rank))s.indexOf(f)!==-1?l.push(1):l.push(n.shape[f]);const c=A(i,l),u=A(a,l),h=t==null?null:A(t,l),d=e==null?null:A(e,l);return[wr(n,c,u,d,h,o),i,a]})}function GT(n,t,e,s,o=.001){return Et(s.slice().sort(),wn(0,n.rank-1))?WT(n,t,e,s,o):UT(n,t,e,s,o)}class Lb extends $t{constructor(t){t==null&&(t={}),super(t),this.supportsMasking=!0,this.axis=t.axis==null?-1:t.axis,this.momentum=t.momentum==null?.99:t.momentum,this.epsilon=t.epsilon==null?.001:t.epsilon,this.center=t.center==null?!0:t.center,this.scale=t.scale==null?!0:t.scale,this.betaInitializer=Ut(t.betaInitializer||"zeros"),this.gammaInitializer=Ut(t.gammaInitializer||"ones"),this.movingMeanInitializer=Ut(t.movingMeanInitializer||"zeros"),this.movingVarianceInitializer=Ut(t.movingVarianceInitializer||"ones"),this.betaConstraint=ae(t.betaConstraint),this.gammaConstraint=ae(t.gammaConstraint),this.betaRegularizer=Gt(t.betaRegularizer),this.gammaRegularizer=Gt(t.gammaRegularizer)}build(t){t=St(t);const e=this.axis>=0?this.axis:this.axis+t.length,s=t[e];if(s==null)throw new E(`Axis ${e} of input tensor should have a defined dimension but the layer received an input with shape ${JSON.stringify(t)}.`);this.inputSpec=[new re({ndim:t.length,axes:{[e]:s}})];const o=[s];this.scale&&(this.gamma=this.addWeight("gamma",o,null,this.gammaInitializer,this.gammaRegularizer,!0,this.gammaConstraint)),this.center&&(this.beta=this.addWeight("beta",o,null,this.betaInitializer,this.betaRegularizer,!0,this.betaConstraint)),this.movingMean=this.addWeight("moving_mean",o,null,this.movingMeanInitializer,null,!1),this.movingVariance=this.addWeight("moving_variance",o,null,this.movingVarianceInitializer,null,!1),this.built=!0}call(t,e){return _(()=>{const s=e.training==null?!1:e.training,o=ft(t),r=o.shape,i=r.length,a=wn(0,i),l=this.axis>=0?this.axis:this.axis+i;a.splice(l,1);const c=Qs(1,i);c[l]=r[l];const u=a.slice();u.sort();const h=!Et(u,wn(0,i).slice(0,i-1)),d=()=>{if(h){const b=A(this.movingMean.read(),c),w=A(this.movingVariance.read(),c),y=this.center?A(this.beta.read(),c):null,C=this.scale?A(this.gamma.read(),c):null;return wr(o,b,w,y,C,this.epsilon)}else return wr(o,this.movingMean.read(),this.movingVariance.read(),this.beta==null?null:this.beta.read(),this.gamma==null?null:this.gamma.read(),this.epsilon)};if(!s)return d();const[p,f,m]=GT(o,this.gamma.read(),this.beta.read(),a,this.epsilon),g=(b,w,y)=>{_(()=>{const C=1-y,I=b.read(),k=R(pt(I,w),C);b.write(pt(I,k))})};return g(this.movingMean,f,this.momentum),g(this.movingVariance,m,this.momentum),p})}getConfig(){const t={axis:this.axis,momentum:this.momentum,epsilon:this.epsilon,center:this.center,scale:this.scale,betaInitializer:Kt(this.betaInitializer),gammaInitializer:Kt(this.gammaInitializer),movingMeanInitializer:Kt(this.movingMeanInitializer),movingVarianceInitializer:Kt(this.movingVarianceInitializer),betaRegularizer:_t(this.betaRegularizer),gammaRegularizer:_t(this.gammaRegularizer),betaConstraint:ie(this.betaConstraint),gammaConstraint:ie(this.gammaConstraint)},e=super.getConfig();return Object.assign(t,e),t}}Lb.className="BatchNormalization";j(Lb);class Mb extends $t{constructor(t){if(t==null&&(t={}),super(t),this.axis=t.axis==null?-1:t.axis,typeof this.axis=="number"){if(!Number.isInteger(this.axis))throw new Error(`Expected axis to be an integer, but received ${this.axis}`)}else if(Array.isArray(this.axis)){for(const e of this.axis)if(!Number.isInteger(e))throw new Error(`Expected axis to be an array of integers, but received ${JSON.stringify(this.axis)}`)}else throw new Error(`Expected axis to be an integer or an array of integers, but received ${JSON.stringify(this.axis)}`);this.epsilon=t.epsilon==null?.001:t.epsilon,this.center=t.center==null?!0:t.center,this.scale=t.scale==null?!0:t.scale,this.betaInitializer=Ut(t.betaInitializer||"zeros"),this.gammaInitializer=Ut(t.gammaInitializer||"ones"),this.betaRegularizer=Gt(t.betaRegularizer),this.gammaRegularizer=Gt(t.gammaRegularizer),this.supportsMasking=!0}build(t){t=St(t);const e=t.length;typeof this.axis=="number"&&(this.axis=[this.axis]);for(let r=0;r<this.axis.length;++r)this.axis[r]<0&&(this.axis[r]+=e);for(const r of this.axis)if(r<0||r>=e)throw new Error(`Invalid axis: ${r}`);if(this.axis.length!==hs(this.axis).length)throw new Error(`Found duplicate axes in: ${this.axis}`);const s=this.axis.map(r=>t[r]),o=!0;this.scale?this.gamma=this.addWeight("gamma",s,"float32",this.gammaInitializer,this.gammaRegularizer,o):this.gamma=null,this.center?this.beta=this.addWeight("beta",s,"float32",this.betaInitializer,this.betaRegularizer,o):this.beta=null,this.built=!0}call(t,e){const s=ft(t),o=s.shape,r=o.length;return _(()=>{let{mean:a,variance:l}=Ih(s,this.axis,!0);const c=Qs(1,r);for(const m of this.axis)c[m]=o[m];const u=m=>m!=null&&m.shape.length!==r?A(m,c):m;let h=this.scale?u(this.gamma.read()):null,d=this.center?u(this.beta.read()):null;const p=[],f=[];for(let m=0;m<r;++m)this.axis.indexOf(m)!==-1?(p.push(o[m]),f.push(1)):(p.push(1),f.push(o[m]));return a=gn(a,p),l=gn(l,p),h!=null&&(h=gn(h,f)),d!=null&&(d=gn(d,f)),wr(s,a,l,d,h,this.epsilon)})}getConfig(){const t={axis:this.axis,epsilon:this.epsilon,center:this.center,scale:this.scale,betaInitializer:Kt(this.betaInitializer),gammaInitializer:Kt(this.gammaInitializer),betaRegularizer:_t(this.betaRegularizer),gammaRegularizer:_t(this.gammaRegularizer)},e=super.getConfig();return Object.assign(t,e),t}}Mb.className="LayerNormalization";j(Mb);function HT(n,t,e){return _(()=>{if(n.rank!==4)throw new E(`temporalPadding expects input tensor to be 4-D, but received a ${n.rank}-D tensor.`);if(t==null&&(t=[[1,1],[1,1]]),t.length!==2||t[0].length!==2||t[1].length!==2)throw new E("spatial2dPadding expects `padding` to be an Array of two Arrays, each of which is an Array of two integers.");if(e==null&&(e=Cn()),e!=="channelsLast"&&e!=="channelsFirst")throw new E(`Unknown data format: ${e}. Supported data formats are 'channelsLast' and 'channelsFirst.`);let s;return e==="channelsFirst"?s=[[0,0],[0,0],t[0],t[1]]:s=[[0,0],t[0],t[1],[0,0]],kh(n,s)})}class Pb extends $t{constructor(t){if(t==null&&(t={}),super(t),this.dataFormat=t.dataFormat==null?Cn():t.dataFormat,t.padding==null)this.padding=[[1,1],[1,1]];else if(typeof t.padding=="number")this.padding=[[t.padding,t.padding],[t.padding,t.padding]];else{if(t.padding=t.padding,t.padding.length!==2)throw new E(`ZeroPadding2D expects padding to be a length-2 array, but received a length-${t.padding.length} array.`);let e,s;if(typeof t.padding[0]=="number")e=[t.padding[0],t.padding[0]],s=[t.padding[1],t.padding[1]];else{if(t.padding=t.padding,t.padding[0].length!==2)throw new E(`ZeroPadding2D expects height padding to be a length-2 array, but received a length-${t.padding[0].length} array.`);if(e=t.padding[0],t.padding[1].length!==2)throw new E(`ZeroPadding2D expects width padding to be a length-2 array, but received a length-${t.padding[1].length} array.`);s=t.padding[1]}this.padding=[e,s]}this.inputSpec=[new re({ndim:4})]}computeOutputShape(t){t=St(t);let e,s;return this.dataFormat==="channelsFirst"?(t[2]!=null&&t[2]>=0?e=t[2]+this.padding[0][0]+this.padding[0][1]:e=null,t[3]!=null&&t[3]>=0?s=t[3]+this.padding[1][0]+this.padding[1][1]:s=null,[t[0],t[1],e,s]):(t[1]!=null&&t[1]>=0?e=t[1]+this.padding[0][0]+this.padding[0][1]:e=null,t[2]!=null&&t[2]>=0?s=t[2]+this.padding[1][0]+this.padding[1][1]:s=null,[t[0],e,s,t[3]])}call(t,e){return _(()=>HT(ft(t),this.padding,this.dataFormat))}getConfig(){const t={padding:this.padding,dataFormat:this.dataFormat},e=super.getConfig();return Object.assign(t,e),t}}Pb.className="ZeroPadding2D";j(Pb);function sc(n,t,e,s,o,r){return _(()=>{Qt(o),tx(r),Ze(s),e==null&&(e=[1,1]),s==null&&(s="valid"),o==null&&(o=Cn()),r==null&&(r="max"),n=Td(n,o);let i;const a=s==="same"?"same":"valid";return r==="max"?i=$h(n,t,e,a):i=dh(n,t,e,a),o==="channelsFirst"&&(i=It(i,[0,3,1,2])),i})}function zb(n,t,e,s,o,r){return _(()=>{Qt(o),tx(r),Ze(s),e==null&&(e=[1,1,1]),s==null&&(s="valid"),o==null&&(o=Cn()),r==null&&(r="max"),n=nb(n,o);let i;const a=s==="same"?"same":"valid";return r==="max"?i=xI(n,t,e,a):i=yC(n,t,e,a),o==="channelsFirst"&&(i=It(i,[0,4,1,2,3])),i})}class Bb extends $t{constructor(t){if(t.poolSize==null&&(t.poolSize=2),super(t),typeof t.poolSize=="number")this.poolSize=[t.poolSize];else if(Array.isArray(t.poolSize)&&t.poolSize.length===1&&typeof t.poolSize[0]=="number")this.poolSize=t.poolSize;else throw new E(`poolSize for 1D convolutional layer must be a number or an Array of a single number, but received ${JSON.stringify(t.poolSize)}`);if(pe(this.poolSize,"poolSize"),t.strides==null)this.strides=this.poolSize;else if(typeof t.strides=="number")this.strides=[t.strides];else if(Array.isArray(t.strides)&&t.strides.length===1&&typeof t.strides[0]=="number")this.strides=t.strides;else throw new E(`strides for 1D convolutional layer must be a number or an Array of a single number, but received ${JSON.stringify(t.strides)}`);pe(this.strides,"strides"),this.padding=t.padding==null?"valid":t.padding,Ze(this.padding),this.inputSpec=[new re({ndim:3})]}computeOutputShape(t){t=St(t);const e=yn(t[1],this.poolSize[0],this.padding,this.strides[0]);return[t[0],e,t[2]]}call(t,e){return _(()=>{this.invokeCallHook(t,e),t=Ri(ft(t),2);const s=this.poolingFunction(ft(t),[this.poolSize[0],1],[this.strides[0],1],this.padding,"channelsLast");return ki(s,[2])})}getConfig(){const t={poolSize:this.poolSize,padding:this.padding,strides:this.strides},e=super.getConfig();return Object.assign(t,e),t}}class Vb extends Bb{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),sc(t,e,s,o,r,"max")}}Vb.className="MaxPooling1D";j(Vb);class Wb extends Bb{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),sc(t,e,s,o,r,"avg")}}Wb.className="AveragePooling1D";j(Wb);class Ub extends $t{constructor(t){if(t.poolSize==null&&(t.poolSize=[2,2]),super(t),this.poolSize=Array.isArray(t.poolSize)?t.poolSize:[t.poolSize,t.poolSize],t.strides==null)this.strides=this.poolSize;else if(Array.isArray(t.strides)){if(t.strides.length!==2)throw new E(`If the strides property of a 2D pooling layer is an Array, it is expected to have a length of 2, but received length ${t.strides.length}.`);this.strides=t.strides}else this.strides=[t.strides,t.strides];pe(this.poolSize,"poolSize"),pe(this.strides,"strides"),this.padding=t.padding==null?"valid":t.padding,this.dataFormat=t.dataFormat==null?"channelsLast":t.dataFormat,Qt(this.dataFormat),Ze(this.padding),this.inputSpec=[new re({ndim:4})]}computeOutputShape(t){t=St(t);let e=this.dataFormat==="channelsFirst"?t[2]:t[1],s=this.dataFormat==="channelsFirst"?t[3]:t[2];return e=yn(e,this.poolSize[0],this.padding,this.strides[0]),s=yn(s,this.poolSize[1],this.padding,this.strides[1]),this.dataFormat==="channelsFirst"?[t[0],t[1],e,s]:[t[0],e,s,t[3]]}call(t,e){return _(()=>(this.invokeCallHook(t,e),this.poolingFunction(ft(t),this.poolSize,this.strides,this.padding,this.dataFormat)))}getConfig(){const t={poolSize:this.poolSize,padding:this.padding,strides:this.strides,dataFormat:this.dataFormat},e=super.getConfig();return Object.assign(t,e),t}}class Gb extends Ub{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),sc(t,e,s,o,r,"max")}}Gb.className="MaxPooling2D";j(Gb);class Hb extends Ub{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),sc(t,e,s,o,r,"avg")}}Hb.className="AveragePooling2D";j(Hb);class Kb extends $t{constructor(t){if(t.poolSize==null&&(t.poolSize=[2,2,2]),super(t),this.poolSize=Array.isArray(t.poolSize)?t.poolSize:[t.poolSize,t.poolSize,t.poolSize],t.strides==null)this.strides=this.poolSize;else if(Array.isArray(t.strides)){if(t.strides.length!==3)throw new E(`If the strides property of a 3D pooling layer is an Array, it is expected to have a length of 3, but received length ${t.strides.length}.`);this.strides=t.strides}else this.strides=[t.strides,t.strides,t.strides];pe(this.poolSize,"poolSize"),pe(this.strides,"strides"),this.padding=t.padding==null?"valid":t.padding,this.dataFormat=t.dataFormat==null?"channelsLast":t.dataFormat,Qt(this.dataFormat),Ze(this.padding),this.inputSpec=[new re({ndim:5})]}computeOutputShape(t){t=St(t);let e=this.dataFormat==="channelsFirst"?t[2]:t[1],s=this.dataFormat==="channelsFirst"?t[3]:t[2],o=this.dataFormat==="channelsFirst"?t[4]:t[3];return e=yn(e,this.poolSize[0],this.padding,this.strides[0]),s=yn(s,this.poolSize[1],this.padding,this.strides[1]),o=yn(o,this.poolSize[2],this.padding,this.strides[2]),this.dataFormat==="channelsFirst"?[t[0],t[1],e,s,o]:[t[0],e,s,o,t[4]]}call(t,e){return _(()=>(this.invokeCallHook(t,e),this.poolingFunction(ft(t),this.poolSize,this.strides,this.padding,this.dataFormat)))}getConfig(){const t={poolSize:this.poolSize,padding:this.padding,strides:this.strides,dataFormat:this.dataFormat},e=super.getConfig();return Object.assign(t,e),t}}class jb extends Kb{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),zb(t,e,s,o,r,"max")}}jb.className="MaxPooling3D";j(jb);class qb extends Kb{constructor(t){super(t)}poolingFunction(t,e,s,o,r){return Qt(r),Ze(o),zb(t,e,s,o,r,"avg")}}qb.className="AveragePooling3D";j(qb);class Xb extends $t{constructor(t){super(t),this.inputSpec=[new re({ndim:3})]}computeOutputShape(t){return[t[0],t[2]]}call(t,e){throw new xt}}class Yb extends Xb{constructor(t){super(t||{})}call(t,e){return _(()=>{const s=ft(t);return ee(s,1)})}}Yb.className="GlobalAveragePooling1D";j(Yb);class Jb extends Xb{constructor(t){super(t||{})}call(t,e){return _(()=>{const s=ft(t);return bn(s,1)})}}Jb.className="GlobalMaxPooling1D";j(Jb);class Zb extends $t{constructor(t){super(t),this.dataFormat=t.dataFormat==null?"channelsLast":t.dataFormat,Qt(this.dataFormat),this.inputSpec=[new re({ndim:4})]}computeOutputShape(t){return t=t,this.dataFormat==="channelsLast"?[t[0],t[3]]:[t[0],t[1]]}call(t,e){throw new xt}getConfig(){const t={dataFormat:this.dataFormat},e=super.getConfig();return Object.assign(t,e),t}}class Qb extends Zb{call(t,e){return _(()=>{const s=ft(t);return this.dataFormat==="channelsLast"?ee(s,[1,2]):ee(s,[2,3])})}}Qb.className="GlobalAveragePooling2D";j(Qb);class ty extends Zb{call(t,e){return _(()=>{const s=ft(t);return this.dataFormat==="channelsLast"?bn(s,[1,2]):bn(s,[2,3])})}}ty.className="GlobalMaxPooling2D";j(ty);class ey extends $t{constructor(t){super(t),this.layer=t.layer}build(t){this.built=!0}get trainable(){return this.layer!=null?this.layer.trainable:!1}set trainable(t){this.layer!=null&&(this.layer.trainable=t)}get trainableWeights(){return this.layer.trainableWeights}get nonTrainableWeights(){return this.layer.nonTrainableWeights}get updates(){return this.layer._updates}get losses(){return this.layer.losses}getWeights(){return this.layer.getWeights()}setWeights(t){this.layer.setWeights(t)}getConfig(){const t={layer:{className:this.layer.getClassName(),config:this.layer.getConfig()}},e=super.getConfig();return Object.assign(t,e),t}setFastWeightInitDuringBuild(t){super.setFastWeightInitDuringBuild(t),this.layer!=null&&this.layer.setFastWeightInitDuringBuild(t)}static fromConfig(t,e,s={}){const o=e.layer,r=_n(o,s);delete e.layer;const i={layer:r};return Object.assign(i,e),new t(i)}}class ny extends ey{constructor(t){super(t),this.supportsMasking=!0}build(t){if(t=St(t),t.length<3)throw new E(`TimeDistributed layer expects an input shape >= 3D, but received input shape ${JSON.stringify(t)}`);this.inputSpec=[{shape:t}];const e=[t[0]].concat(t.slice(2));this.layer.built||(this.layer.build(e),this.layer.built=!0),super.build(t)}computeOutputShape(t){t=St(t);const e=[t[0]].concat(t.slice(2)),s=this.layer.computeOutputShape(e),o=t[1];return[s[0],o].concat(s.slice(1))}call(t,e){return _(()=>(t=ft(t),hb((i,a)=>[ft(this.layer.call(i,e)),[]],t,[],!1,null,null,!1,!0)[1]))}}ny.className="TimeDistributed";j(ny);function KT(n){ao(h2,"BidirectionalMergeMode",n)}const jT="concat";class sy extends ey{constructor(t){super(t);const e=t.layer.getConfig(),s={};s.className=t.layer.getClassName(),s.config=e,this.forwardLayer=_n(s),e.goBackwards=e.goBackwards!==!0;const o={};if(o.className=t.layer.getClassName(),o.config=e,this.backwardLayer=_n(o),this.forwardLayer.name="forward_"+this.forwardLayer.name,this.backwardLayer.name="backward_"+this.backwardLayer.name,this.mergeMode=t.mergeMode===void 0?jT:t.mergeMode,KT(this.mergeMode),t.weights)throw new xt("weights support is not implemented for Bidirectional layer yet.");this._stateful=t.layer.stateful,this.returnSequences=t.layer.returnSequences,this.returnState=t.layer.returnState,this.supportsMasking=!0,this._trainable=!0,this.inputSpec=t.layer.inputSpec,this.numConstants=null}get trainable(){return this._trainable}set trainable(t){this._trainable=t,this.forwardLayer!=null&&(this.forwardLayer.trainable=t),this.backwardLayer!=null&&(this.backwardLayer.trainable=t)}getWeights(){return this.forwardLayer.getWeights().concat(this.backwardLayer.getWeights())}setWeights(t){const e=t.length,s=Math.floor(e/2);this.forwardLayer.setWeights(t.slice(0,s)),this.backwardLayer.setWeights(t.slice(s))}computeOutputShape(t){let e=this.forwardLayer.computeOutputShape(t);Array.isArray(e)&&Array.isArray(e[0])||(e=[e]),e=e;let s,o,r;return this.returnState&&(r=e.slice(1)),s=e[0],s=s,this.mergeMode==="concat"?(s[s.length-1]*=2,o=[s]):this.mergeMode==null?o=[s,s.slice()]:o=[s],this.returnState?this.mergeMode==null?o.concat(r).concat(r.slice()):[s].concat(r).concat(r.slice()):_e(o)}apply(t,e){let s=e==null?null:e.initialState,o=e==null?null:e.constants;e==null&&(e={});const r=ub(t,s,o,this.numConstants);if(t=r.inputs,s=r.initialState,o=r.constants,Array.isArray(t)&&(s=t.slice(1),t=t[0]),(s==null||s.length===0)&&o==null)return super.apply(t,e);const i=[],a=[];if(s!=null){const c=s.length;if(c%2>0)throw new E("When passing `initialState` to a Bidrectional RNN, the state should be an Array containing the states of the underlying RNNs.");e.initialState=s,i.push(...s);const u=s.map(h=>new re({shape:h.shape}));this.forwardLayer.stateSpec=u.slice(0,c/2),this.backwardLayer.stateSpec=u.slice(c/2),a.push(...u)}if(o!=null)throw new xt("Support for constants in Bidirectional layers is not implemented yet.");const l=i[0]instanceof zn;for(const c of i)if(c instanceof zn!==l)throw new E("The initial state of a Bidirectional layer cannot be specified as a mix of symbolic and non-symbolic tensors");if(l){const c=[t].concat(i),u=this.inputSpec.concat(a),h=this.inputSpec;this.inputSpec=u;const d=super.apply(c,e);return this.inputSpec=h,d}else return super.apply(t,e)}call(t,e){return _(()=>{const s=e.initialState;let o,r;if(s==null)o=this.forwardLayer.call(t,e),r=this.backwardLayer.call(t,e);else{const l=s.slice(0,s.length/2),c=s.slice(s.length/2);o=this.forwardLayer.call(t,Object.assign(e,{initialState:l})),r=this.backwardLayer.call(t,Object.assign(e,{initialState:c}))}let i;this.returnState&&(Array.isArray(o)&&(i=o.slice(1).concat(r.slice(1))),o=o[0],r=r[0]),this.returnSequences&&(r=Js(r,1));let a;return this.mergeMode==="concat"?a=md([o,r]):this.mergeMode==="sum"?a=Y(o,r):this.mergeMode==="ave"?a=R(.5,Y(o,r)):this.mergeMode==="mul"?a=R(o,r):this.mergeMode==null&&(a=[o,r]),this.returnState?this.mergeMode==null?a.concat(i):[a].concat(i):a})}resetStates(t){this.forwardLayer.resetStates(),this.backwardLayer.resetStates()}build(t){Bs(this.forwardLayer.name,()=>{this.forwardLayer.build(t)}),Bs(this.backwardLayer.name,()=>{this.backwardLayer.build(t)}),this.built=!0}computeMask(t,e){Array.isArray(e)&&(e=e[0]);let s;if(this.returnSequences?this.mergeMode==null?s=[e,e]:s=e:this.mergeMode==null?s=[null,null]:s=null,this.returnState){const r=this.forwardLayer.states.map(i=>null);return Array.isArray(s)?s.concat(r).concat(r):[s].concat(r).concat(r)}else return s}get trainableWeights(){return this.forwardLayer.trainableWeights.concat(this.backwardLayer.trainableWeights)}get nonTrainableWeights(){return this.forwardLayer.nonTrainableWeights.concat(this.backwardLayer.nonTrainableWeights)}setFastWeightInitDuringBuild(t){super.setFastWeightInitDuringBuild(t),this.forwardLayer!=null&&this.forwardLayer.setFastWeightInitDuringBuild(t),this.backwardLayer!=null&&this.backwardLayer.setFastWeightInitDuringBuild(t)}getConfig(){const t={mergeMode:this.mergeMode},e=super.getConfig();return Object.assign(t,e),t}static fromConfig(t,e){const s=_n(e.layer);if(delete e.layer,e.numConstants!=null)throw new xt("Deserialization of a Bidirectional layer with numConstants present is not supported yet.");const o=e;return o.layer=s,new t(o)}}sy.className="Bidirectional";j(sy);class oy extends $t{constructor(t){super(t),this.scale=t.scale,t.offset?this.offset=t.offset:this.offset=0}getConfig(){const t={scale:this.scale,offset:this.offset},e=super.getConfig();return Object.assign(t,e),t}call(t,e){return _(()=>(t=ft(t),t.dtype!=="float32"&&(t=Fn(t,"float32")),Y(R(t,this.scale),this.offset)))}}oy.className="Rescaling";j(oy);const{resizeBilinear:qT,cropAndResize:XT}=Kn;class ry extends $t{constructor(t){super(t),this.height=t.height,this.width=t.width}centerCrop(t,e,s,o,r,i,a,l){return _(()=>{let c,u=!1;const h=e/i,d=s/a,p=(o+e)/i,f=(r+s)/a,m=[h,d,p,f],g=[];t.rank===3?(u=!0,c=qn([t])):c=t;for(let C=0;C<c.shape[0];C++)g.push(m);const x=cr(g,[g.length,4]),b=gr(0,g.length,1,"int32"),y=XT(c,x,b,[o,r],"nearest");return Fn(u?ft(Zs(y)):y,l)})}upsize(t,e,s,o){return _(()=>{const r=qT(t,[e,s]);return Fn(r,o)})}call(t,e){return _(()=>{const s=ft(t),o=s.dtype,r=s.shape,i=r[r.length-3],a=r[r.length-2];let l=0;i!==this.height&&(l=Math.floor((i-this.height)/2));let c=0;return a!==this.width&&(c=Math.floor((a-this.width)/2),c===0&&(c=1)),l>=0&&c>=0?this.centerCrop(s,l,c,this.height,this.width,i,a,o):this.upsize(t,this.height,this.width,o)})}getConfig(){const t={height:this.height,width:this.width},e=super.getConfig();return Object.assign(t,e),t}computeOutputShape(t){t=St(t);const e=t.length-3,s=t.length-2;return t[e]=this.height,t[s]=this.width,t}}ry.className="CenterCrop";j(ry);function YT(n,t,e,s){let o=ft(n);if(o.dtype!=="int32"&&(o=Fn(o,"int32")),t==="int")return o;const r=o.shape;if(o.rank===0&&(o=Oe(o,-1)),t==="oneHot"&&o.shape[o.shape.length-1]!==1&&(o=Oe(o,-1)),o.rank>2)throw new E(`When outputMode is not int, maximum output rank is 2 Received outputMode ${t} and input shape ${r} which would result in output rank ${o.rank}.`);const i=["multiHot","oneHot"].includes(t),a=o;let l;if(typeof s<"u"&&t==="count"?l=pp(a,s,e,i):l=pp(a,[],e,i),t!=="tfIdf")return l;if(s)return R(l,s);throw new E("When outputMode is 'tfIdf', weights must be provided.")}class iy extends $t{constructor(t){super(t),this.numTokens=t.numTokens,t.outputMode?this.outputMode=t.outputMode:this.outputMode="multiHot"}getConfig(){const t={numTokens:this.numTokens,outputMode:this.outputMode},e=super.getConfig();return Object.assign(t,e),t}computeOutputShape(t){return t=St(t),t==null?[this.numTokens]:this.outputMode==="oneHot"&&t[t.length-1]!==1?(t.push(this.numTokens),t):(t[t.length-1]=this.numTokens,t)}call(t,e){return _(()=>{t=ft(t),t.dtype!=="int32"&&(t=Fn(t,"int32"));let s;if(typeof e.countWeights<"u"){if(this.outputMode!=="count")throw new E(`countWeights is not used when outputMode !== count.
              Received countWeights=${e.countWeights}`);s=ft(e.countWeights)}const o=bn(t),r=ha(t),i=Je(this.numTokens,o).bufferSync().get(0),a=oo(r,0).bufferSync().get(0);if(!(i&&a))throw new E(`Input values must be between 0 < values <= numTokens with numTokens=${this.numTokens}`);return YT(t,this.outputMode,this.numTokens,s)})}}iy.className="CategoryEncoding";j(iy);const JT=["bilinear","nearest"],qp=new Set(JT);class ay extends $t{constructor(t){if(super(t),this.height=t.height,this.width=t.width,t.interpolation)if(qp.has(t.interpolation))this.interpolation=t.interpolation;else throw new E(`Invalid interpolation parameter: ${t.interpolation} is not implemented`);else this.interpolation="bilinear";this.cropToAspectRatio=!!t.cropToAspectRatio}computeOutputShape(t){t=St(t);const e=t[2];return[this.height,this.width,e]}getConfig(){const t={height:this.height,width:this.width,interpolation:this.interpolation,cropToAspectRatio:this.cropToAspectRatio},e=super.getConfig();return Object.assign(t,e),t}call(t,e){return _(()=>{const s=[this.height,this.width];if(this.interpolation==="bilinear")return Kn.resizeBilinear(t,s,!this.cropToAspectRatio);if(this.interpolation==="nearest")return Kn.resizeNearestNeighbor(t,s,!this.cropToAspectRatio);throw new Error(`Interpolation is ${this.interpolation} but only ${[...qp]} are supported`)})}}ay.className="Resizing";j(ay);class ly{constructor(t){this.seed=t}next(){if(this.seed!==void 0)return this.seed++}}ly.className="RandomSeed";class cy extends $t{constructor(t){super(t),this.randomGenerator=new ly(t.seed)}getConfig(){const t={seed:this.randomGenerator.seed},e=super.getConfig();return Object.assign(t,e),t}}cy.className="BaseRandomLayer";const ZT=["bilinear","nearest"],Xp=new Set(ZT);class uy extends cy{constructor(t){super(t);const{factor:e,interpolation:s="bilinear"}=t;if(this.factor=e,Array.isArray(this.factor)&&this.factor.length===2)this.widthLower=this.factor[0],this.widthUpper=this.factor[1];else if(!Array.isArray(this.factor)&&this.factor>0)this.widthLower=-this.factor,this.widthUpper=this.factor;else throw new E(`Invalid factor: ${this.factor}. Must be positive number or tuple of 2 numbers`);if(this.widthLower<-1||this.widthUpper<-1)throw new E(`factor must have values larger than -1. Got: ${this.factor}`);if(this.widthUpper<this.widthLower)throw new E(`factor cannot have upper bound less than lower bound.
        Got upper bound: ${this.widthUpper}.
        Got lower bound: ${this.widthLower}
      `);if(s)if(Xp.has(s))this.interpolation=s;else throw new E(`Invalid interpolation parameter: ${s} is not implemented`)}getConfig(){const t={factor:this.factor,interpolation:this.interpolation},e=super.getConfig();return Object.assign(t,e),t}computeOutputShape(t){t=St(t);const e=t[2];return[this.imgHeight,-1,e]}call(t,e){return _(()=>{const s=ft(t);this.imgHeight=s.shape[s.shape.length-3];const o=s.shape[s.shape.length-2];this.widthFactor=Ii([1],1+this.widthLower,1+this.widthUpper,"float32",this.randomGenerator.next());let r=this.widthFactor.dataSync()[0]*o;r=Math.round(r);const i=[this.imgHeight,r];switch(this.interpolation){case"bilinear":return Kn.resizeBilinear(t,i);case"nearest":return Kn.resizeNearestNeighbor(t,i);default:throw new Error(`Interpolation is ${this.interpolation}
          but only ${[...Xp]} are supported`)}})}}uy.className="RandomWidth";j(uy);const QT=L();QT.registerFlag("KEEP_INTERMEDIATE_TENSORS",()=>!1,n=>{n&&console.warn("Keep intermediate tensors is ON. This will print the values of all intermediate tensors during model inference. Not all models support this mode. For details, check e2e/benchmarks/ model_config.js. This significantly impacts performance.")});var Yp;(function(n){n[n.DT_INVALID=0]="DT_INVALID",n[n.DT_FLOAT=1]="DT_FLOAT",n[n.DT_DOUBLE=2]="DT_DOUBLE",n[n.DT_INT32=3]="DT_INT32",n[n.DT_UINT8=4]="DT_UINT8",n[n.DT_INT16=5]="DT_INT16",n[n.DT_INT8=6]="DT_INT8",n[n.DT_STRING=7]="DT_STRING",n[n.DT_COMPLEX64=8]="DT_COMPLEX64",n[n.DT_INT64=9]="DT_INT64",n[n.DT_BOOL=10]="DT_BOOL",n[n.DT_QINT8=11]="DT_QINT8",n[n.DT_QUINT8=12]="DT_QUINT8",n[n.DT_QINT32=13]="DT_QINT32",n[n.DT_BFLOAT16=14]="DT_BFLOAT16",n[n.DT_QINT16=15]="DT_QINT16",n[n.DT_QUINT16=16]="DT_QUINT16",n[n.DT_UINT16=17]="DT_UINT16",n[n.DT_COMPLEX128=18]="DT_COMPLEX128",n[n.DT_HALF=19]="DT_HALF",n[n.DT_RESOURCE=20]="DT_RESOURCE",n[n.DT_VARIANT=21]="DT_VARIANT",n[n.DT_UINT32=22]="DT_UINT32",n[n.DT_UINT64=23]="DT_UINT64",n[n.DT_FLOAT_REF=101]="DT_FLOAT_REF",n[n.DT_DOUBLE_REF=102]="DT_DOUBLE_REF",n[n.DT_INT32_REF=103]="DT_INT32_REF",n[n.DT_UINT8_REF=104]="DT_UINT8_REF",n[n.DT_INT16_REF=105]="DT_INT16_REF",n[n.DT_INT8_REF=106]="DT_INT8_REF",n[n.DT_STRING_REF=107]="DT_STRING_REF",n[n.DT_COMPLEX64_REF=108]="DT_COMPLEX64_REF",n[n.DT_INT64_REF=109]="DT_INT64_REF",n[n.DT_BOOL_REF=110]="DT_BOOL_REF",n[n.DT_QINT8_REF=111]="DT_QINT8_REF",n[n.DT_QUINT8_REF=112]="DT_QUINT8_REF",n[n.DT_QINT32_REF=113]="DT_QINT32_REF",n[n.DT_BFLOAT16_REF=114]="DT_BFLOAT16_REF",n[n.DT_QINT16_REF=115]="DT_QINT16_REF",n[n.DT_QUINT16_REF=116]="DT_QUINT16_REF",n[n.DT_UINT16_REF=117]="DT_UINT16_REF",n[n.DT_COMPLEX128_REF=118]="DT_COMPLEX128_REF",n[n.DT_HALF_REF=119]="DT_HALF_REF",n[n.DT_RESOURCE_REF=120]="DT_RESOURCE_REF",n[n.DT_VARIANT_REF=121]="DT_VARIANT_REF",n[n.DT_UINT32_REF=122]="DT_UINT32_REF",n[n.DT_UINT64_REF=123]="DT_UINT64_REF"})(Yp||(Yp={}));var Jp;(function(n){(function(t){t[t.LEGACY=0]="LEGACY",t[t.V1=1]="V1",t[t.V2=2]="V2"})(n.CheckpointFormatVersion||(n.CheckpointFormatVersion={}))})(Jp||(Jp={}));var Zp;(function(n){n[n.FAIL=0]="FAIL",n[n.SHORTEST=1]="SHORTEST",n[n.LONGEST=2]="LONGEST"})(Zp||(Zp={}));function rt(n,t){Array.isArray(n)||(n=[n]),n.forEach(e=>{e!=null&&$(e.dtype!=="complex64",()=>`${t} does not support complex64 tensors in the CPU backend.`)})}const tE=og;class oc extends fu{nextDataId(){return oc.nextDataId++}constructor(){super(),this.blockSize=48,this.firstUse=!0,this.data=new Ff(this,kn())}write(t,e,s){this.firstUse&&(this.firstUse=!1,L().get("IS_NODE")&&je(`
============================
Hi, looks like you are running TensorFlow.js in Node.js. To speed things up dramatically, install our node backend, visit https://github.com/tensorflow/tfjs-node for more details. 
============================`));const o={id:this.nextDataId()};return this.data.set(o,{values:t,dtype:s,refCount:1}),o}makeTensorInfo(t,e,s){let o;if(e==="string"&&s!=null&&s.length>0&&vr(s[0])){const r=s.map(i=>us(i));o=this.write(r,t,e)}else o=this.write(s,t,e);return{dataId:o,shape:t,dtype:e}}refCount(t){return this.data.has(t)?this.data.get(t).refCount:0}incRef(t){const e=this.data.get(t);e.refCount++}decRef(t){if(this.data.has(t)){const e=this.data.get(t);e.refCount--}}move(t,e,s,o,r){this.data.set(t,{values:e,dtype:o,refCount:r})}numDataIds(){return this.data.numDataIds()}async read(t){return this.readSync(t)}readSync(t){const{dtype:e,complexTensorInfos:s}=this.data.get(t);if(e==="complex64"){const o=this.readSync(s.real.dataId),r=this.readSync(s.imag.dataId);return Xn(o,r)}return v1(this.data.get(t).values,e)}bufferSync(t){const e=this.readSync(t.dataId);if(t.dtype==="string")try{const s=e.map(o=>ps(o));return wt(t.shape,t.dtype,s)}catch{throw new Error("Failed to decode encoded string bytes into utf-8")}return wt(t.shape,t.dtype,e)}makeOutput(t,e,s){return kn().makeTensorFromTensorInfo(this.makeTensorInfo(e,s,t),this)}disposeData(t,e=!1){if(this.data.has(t)){if(this.data.get(t).refCount--,!e&&this.data.get(t).refCount>0)return!1;const{complexTensorInfos:s}=this.data.get(t);s!=null&&(this.disposeData(s.real.dataId,!0),this.disposeData(s.imag.dataId,!0)),this.data.delete(t)}return!0}disposeIntermediateTensorInfo(t){this.disposeData(t.dataId)}async time(t){const e=Fe();return t(),{kernelMs:Fe()-e}}memory(){return{unreliable:!0,reasons:["The reported memory is an upper bound. Due to automatic garbage collection, the true allocated memory may be less."]}}where(t){rt([t],"where");const e=this.readSync(t.dataId);return tE(t.shape,e)}dispose(){}floatPrecision(){return 32}epsilon(){return super.epsilon()}}oc.nextDataId=0;function hy(n){const t=new Float32Array(n.length);for(let e=0;e<n.length;++e)t[e]=Math.abs(n[e]);return t}const eE=n=>{const{x:t}=n.inputs,e=n.backend;rt(t,"abs");let s=new Float32Array(W(t.shape));const o=e.data.get(t.dataId).values;return s=hy(o),e.makeOutput(s,t.shape,t.dtype)},nE={kernelName:_a,backendName:"cpu",kernelFunc:eE};function te(n){return(t,e,s,o,r)=>{const i=mt(t,e),a=i.length,l=lt(i),c=W(i),u=Ce(r,c),h=t.length,d=e.length,p=lt(t),f=lt(e),m=To(t,i),g=To(e,i);if(m.length+g.length===0)for(let x=0;x<u.length;++x)u[x]=n(s[x%s.length],o[x%o.length]);else for(let x=0;x<u.length;++x){const b=Mo(x,a,l),w=b.slice(-h);m.forEach(k=>w[k]=0);const y=Rn(w,h,p),C=b.slice(-d);g.forEach(k=>C[k]=0);const I=Rn(C,d,f);u[x]=n(s[y],o[I])}return[u,i]}}function Ve(n){const{inputs:t,backend:e}=n,{real:s,imag:o}=t,r=e.data.get(s.dataId).values,i=e.data.get(o.dataId).values,a=e.makeTensorInfo(s.shape,"complex64"),l=e.data.get(a.dataId);return l.complexTensorInfos={real:e.makeTensorInfo(s.shape,"float32",r),imag:e.makeTensorInfo(o.shape,"float32",i)},a}const sE={kernelName:Nu,backendName:"cpu",kernelFunc:Ve};function Sa(n,t,e="float32"){if(e==="complex64"){const o=Sa(n,t,"float32"),r=Sa(n,t,"float32");return Ve({inputs:{real:o,imag:r},backend:n})}const s=$e(W(t),e);return n.makeTensorInfo(t,e,s)}function Bn(n){const{inputs:t,backend:e}=n,{x:s}=t;return e.incRef(s.dataId),{dataId:s.dataId,shape:s.shape,dtype:s.dtype}}const oE={kernelName:Kr,backendName:"cpu",kernelFunc:Bn};function to(n){const{inputs:t,backend:e}=n,{input:s}=t,o=e.data.get(s.dataId).complexTensorInfos.real,r=e.data.get(o.dataId).values;return e.makeTensorInfo(o.shape,o.dtype,r)}const rE={kernelName:Zu,backendName:"cpu",kernelFunc:to};function dy(n,t,e,s){if(s==="int32"){const o=Int32Array.from(n);return[t,"int32",o]}if(s==="bool"){const o=so([0],e),[r,i]=te((a,l)=>a!==l?1:0)(t,[],n,o,"bool");return[i,"bool",r]}throw new Error(`Error in Cast: failed to cast ${e} to ${s}`)}function bs(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{dtype:r}=s;if(r==="complex64"){if(o.dtype==="complex64")return Bn({inputs:{x:o},backend:e});const u=Sa(e,o.shape,o.dtype),h=bs({inputs:{x:o},backend:e,attrs:{dtype:"float32"}}),d=Ve({inputs:{real:h,imag:u},backend:e});return e.disposeIntermediateTensorInfo(u),e.disposeIntermediateTensorInfo(h),d}if(o.dtype==="complex64"){const u=to({inputs:{input:o},backend:e}),h=bs({inputs:{x:u},backend:e,attrs:{dtype:r}});return e.disposeIntermediateTensorInfo(u),h}if(!Lf(o.dtype,r)){const u=Bn({inputs:{x:o},backend:e});return{dataId:u.dataId,shape:u.shape,dtype:r}}const i=e.data.get(o.dataId).values,[a,l,c]=dy(i,o.shape,o.dtype,r);return e.makeTensorInfo(a,l,c)}const iE={kernelName:Fr,backendName:"cpu",kernelFunc:bs};function ce(n,t,e,s){return e==null?({inputs:o,backend:r})=>{const{a:i,b:a}=o,l=r;rt([i,a],n);const c=l.data.get(i.dataId).values,u=l.data.get(a.dataId).values,h=i.dtype==="string"?Yn(c):c,d=i.dtype==="string"?Yn(u):u,p=s||i.dtype,[f,m]=t(i.shape,a.shape,h,d,p);return l.makeTensorInfo(m,p,f)}:({inputs:o,backend:r})=>{const{a:i,b:a}=o,l=r;if(i.dtype==="complex64"||a.dtype==="complex64"){const c=bs({inputs:{x:i},backend:l,attrs:{dtype:"complex64"}}),u=l.data.get(c.dataId),h=u.complexTensorInfos.real,d=u.complexTensorInfos.imag,p=l.data.get(h.dataId).values,f=l.data.get(d.dataId).values,m=bs({inputs:{x:a},backend:l,attrs:{dtype:"complex64"}}),g=l.data.get(m.dataId),x=g.complexTensorInfos.real,b=g.complexTensorInfos.imag,w=l.data.get(x.dataId).values,y=l.data.get(b.dataId).values,[C,I,k]=e(i.shape,a.shape,p,f,w,y),v=l.makeTensorInfo(k,"float32",C),N=l.makeTensorInfo(k,"float32",I),T=Ve({inputs:{real:v,imag:N},backend:l});return l.disposeIntermediateTensorInfo(c),l.disposeIntermediateTensorInfo(m),l.disposeIntermediateTensorInfo(v),l.disposeIntermediateTensorInfo(N),T}else{const c=l.data.get(i.dataId).values,u=l.data.get(a.dataId).values,h=s||i.dtype,[d,p]=t(i.shape,a.shape,c,u,h);return l.makeTensorInfo(p,h,d)}}}function Od(n){return(t,e,s,o,r,i)=>{const a=mt(t,e),l=W(a),c=a.length,u=lt(a),h=Ce("float32",l),d=Ce("float32",l),p=To(t,a),f=To(e,a),m=Xn(s,o),g=Xn(r,i),x=t.length,b=lt(t),w=e.length,y=lt(e);if(p.length+f.length===0)for(let C=0;C<h.length;C++){const I=C%m.length,k=C%g.length,v=n(m[I*2],m[I*2+1],g[k*2],g[k*2+1]);h[C]=v.real,d[C]=v.imag}else for(let C=0;C<h.length;C++){const I=Mo(C,c,u),k=I.slice(-x);p.forEach(P=>k[P]=0);const v=Rn(k,x,b),N=I.slice(-w);f.forEach(P=>N[P]=0);const T=Rn(N,w,y),O=n(m[v*2],m[v*2+1],g[T*2],g[T*2+1]);h[C]=O.real,d[C]=O.imag}return[h,d,a]}}const py=te(((n,t)=>n+t)),aE=Od(((n,t,e,s)=>({real:n+e,imag:t+s}))),Do=ce(Po,py,aE),lE={kernelName:Po,backendName:"cpu",kernelFunc:Do};function _d(n,t,e,s,o){const r=W(s),i=$e(o,e);for(let a=0;a<n.length;a++){const l=n[a];if(l<0)throw new Error("Input x must be non-negative!");l>=o||(r>0?i[l]+=t[a]:i[l]+=1)}return i}function fy(n,t,e,s=!1){const o=n.shape[0],r=n.shape[1],i=wt([o,e],t.dtype);for(let a=0;a<o;a++)for(let l=0;l<r;l++){const c=n.get(a,l);if(c<0)throw new Error("Input x must be non-negative!");c>=e||(s?i.set(1,a,c):t.size>0?i.set(i.get(a,c)+t.get(a,l),a,c):i.set(i.get(a,c)+1,a,c))}return i}const my=te(((n,t)=>n&t)),cE=ce(Su,my),uE={kernelName:Su,backendName:"cpu",kernelFunc:cE};function Vn(n){return(t,e,s)=>{const o=Xt(e,t.length);for(let r=0;r<t.length;++r)o[r]=n(t[r],s);return o}}function At(n,t,e){const s=Vn(t);return Ts(n,s,e)}function Ts(n,t,e){return({inputs:s,attrs:o,backend:r})=>{const{x:i}=s;rt(i,n);const a=r,l=a.data.get(i.dataId).values;let c;if(i.dtype==="string"){if(!Array.isArray(l))throw new Error("String tensor's value was not an instance of Array");c=Yn(l)}else c=l;const u=e||i.dtype,h=t(c,u,o);return a.makeTensorInfo(i.shape,u,h)}}const gy=Vn(n=>Math.ceil(n)),hE=Ts(Or,gy),dE={kernelName:Or,backendName:"cpu",kernelFunc:hE};function xy(n,t,e,s){const o=Xt(e,W(t));if(s&&e!=="string"){let r=0;n.forEach(i=>{const a=W(i.shape);o.set(i.vals,r),r+=a})}else{let r=0;n.forEach(i=>{const a=e==="string"?Yn(i.vals):i.vals;let l=0;for(let c=0;c<i.shape[0];++c){const u=c*t[1]+r;for(let h=0;h<i.shape[1];++h)o[u+h]=a[l++]}r+=i.shape[1]})}return o}const by=te((n,t)=>n===t?1:0),yy=ce(Ya,by,null,"bool"),pE={kernelName:Ya,backendName:"cpu",kernelFunc:yy};const wy=Vn(n=>Math.exp(n)),Cy=Ts(Vr,wy,"float32"),fE={kernelName:Vr,backendName:"cpu",kernelFunc:Cy};const $y=Vn(n=>Math.expm1(n)),mE=Ts(Wr,$y),gE={kernelName:Wr,backendName:"cpu",kernelFunc:mE};const Iy=Vn(n=>Math.floor(n)),xE=Ts(Ur,Iy),bE={kernelName:Ur,backendName:"cpu",kernelFunc:xE};const ky=te((n,t)=>Math.floor(n/t)),yE=ce(Gr,ky,null,"int32"),wE={kernelName:Gr,backendName:"cpu",kernelFunc:yE};function vy(n,t,e,s,o,r,i,a,l){const c=wt([s,r],e);for(let u=0;u<s;u++){const h=[];let d=0;for(let p=0;p<o;p++){const f=n[u*o+p];d+=f*i[p],h.push(f)}if(d<0||d>=l/r)throw new Error(`Invalid indices: ${h} does not index into ${a}`);for(let p=0;p<r;p++)c.values[u*r+p]=t.get(...t.indexToLoc(d*r+p))}return c}function Sy(n,t,e){const s=wt(e,n.dtype);for(let o=0;o<s.size;++o){const i=s.indexToLoc(o).slice(),a=i[0],l=i[2],c=t.locToIndex([a,l]);i[2]=t.values[c];const u=n.locToIndex(i);0<=u&&u<n.values.length&&(s.values[o]=n.values[u])}return s}const Ny=te((n,t)=>n>t?1:0),CE=ce(tl,Ny,null,"bool"),$E={kernelName:tl,backendName:"cpu",kernelFunc:CE};const Ty=te((n,t)=>n>=t?1:0),IE=ce(Hr,Ty,null,"bool"),kE={kernelName:Hr,backendName:"cpu",kernelFunc:IE};const Ey=te((n,t)=>n<t?1:0),vE=ce(nl,Ey,null,"bool"),SE={kernelName:nl,backendName:"cpu",kernelFunc:vE};const Ry=te((n,t)=>n<=t?1:0),NE=ce(sl,Ry,null,"bool"),TE={kernelName:sl,backendName:"cpu",kernelFunc:NE};function Dy(n,t,e){const s=(t-n)/(e-1),o=$e(e,"float32");o[0]=n;for(let r=1;r<o.length;r++)o[r]=o[r-1]+s;return o}const Ay=Vn(n=>Math.log(n)),EE=Ts(Yr,Ay),RE={kernelName:Yr,backendName:"cpu",kernelFunc:EE};function Fy(n,t,e,s){const o=Ce(s,W(e));for(let r=0;r<o.length;++r){const i=r*t;let a=n[i];for(let l=0;l<t;++l){const c=n[i+l];(Number.isNaN(c)||c>a)&&(a=c)}o[r]=a}return o}const Oy=te(((n,t)=>Math.max(n,t))),DE=ce(Zr,Oy),AE={kernelName:Zr,backendName:"cpu",kernelFunc:DE};const _y=te(((n,t)=>Math.min(n,t))),FE=ce(Qr,_y),OE={kernelName:Qr,backendName:"cpu",kernelFunc:FE};const Ld=te(((n,t)=>n*t)),_E=Od(((n,t,e,s)=>({real:n*e-t*s,imag:n*s+t*e}))),rc=ce(ei,Ld,_E),LE={kernelName:ei,backendName:"cpu",kernelFunc:rc};function Ly(n,t,e){const s=ws(-1,e);return Ld([],t,s,n,e)}function ME(n){const{inputs:t,backend:e}=n,{x:s}=t;rt(s,"neg");const o=e.data.get(s.dataId).values,[r,i]=Ly(o,s.shape,s.dtype);return e.makeTensorInfo(i,s.dtype,r)}const PE={kernelName:fl,backendName:"cpu",kernelFunc:ME};const My=te(((n,t)=>n!==t?1:0)),zE=ce(ml,My,null,"bool"),BE={kernelName:ml,backendName:"cpu",kernelFunc:zE};function Md(n,t,e,s,o){const r=t.length,i=W(t),a=lt(t),l=lt(o),c=Ce(e,W(o));for(let u=0;u<i;++u){const h=Mo(u,r,a),d=new Array(h.length);for(let f=0;f<d.length;f++)d[f]=h[s[f]];const p=Rn(d,r,l);c[p]=n[u]}return c}function Pe(n){const{inputs:t,attrs:e,backend:s}=n,{x:o}=t,{perm:r}=e;rt(o,"transpose");const i=o.shape.length,a=new Array(i);for(let h=0;h<a.length;h++)a[h]=o.shape[r[h]];const l=s.data.get(o.dataId).values,c=Md(l,o.shape,o.dtype,r,a);return{dataId:s.write(c,a,o.dtype),shape:a,dtype:o.dtype}}const VE={kernelName:Co,backendName:"cpu",kernelFunc:Pe};function Py(n,t,e,s){const[o,r]=fe(n,s),i=Ue(t,"int32"),a=$e(W(o),i),l=W(r);for(let c=0;c<a.length;++c){const u=c*l;let h=1;for(let d=0;d<l;++d)h*=e[u+d];a[c]=h}return{outVals:a,outShape:o,outDtype:i}}function WE(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;rt(o,"prod");const a=o.shape.length,l=Ct(r,o.shape),c=jt(l,a);let u=l,h=o;const d=[];c!=null&&(h=Pe({inputs:{x:o},backend:e,attrs:{perm:c}}),d.push(h),u=Zt(u.length,a));const p=e.data.get(h.dataId).values,{outVals:f,outShape:m,outDtype:g}=Py(h.shape,h.dtype,p,u);let x=m;return i&&(x=ne(m,l)),d.forEach(b=>e.disposeIntermediateTensorInfo(b)),e.makeTensorInfo(x,g,f)}const UE={kernelName:Cl,backendName:"cpu",kernelFunc:WE};function GE(n,t,e){n.forEach((s,o)=>{if(s<0||s>=e){const r=Mo(o,t.length,lt(t)).join(",");throw new Error(`indices[${r}] = ${s} is not in [0, ${e})`)}})}function HE(n,t){for(let e=0;e<n.length;++e){const s=n[e],o=e===n.length-1?t:n[e+1].length;if(s.length===0)throw new Error("Ragged splits may not be empty");if(s[0]<0)throw new Error("Ragged splits must be non-negative");if(s[s.length-1]>o)throw new Error("Ragged splits must not point past values");for(let r=1;r<s.length;++r)if(s[r-1]>s[r])throw new Error("Ragged splits must be sorted in ascending order")}}function KE(n,t,e,s){const o=[];let r=0;const i=t.length-1+e.length,a=new Array(i).fill(null).map(()=>[0]);HE(e,s);let l=1;for(let c=0;c<t.length-1;++c){l*=t[c];const u=t[c+1];for(let h=1;h<l+1;++h)a[c].push(h*u)}for(let c=0;c<n.length;++c){let u=n[c],h=n[c]+1;for(let d=0;d<e.length;++d){const p=e[d],f=d+t.length-1;if(f>=0){const m=a[f],g=m[m.length-1]-p[u];for(let x=u;x<h;++x)a[f].push(p[x+1]+g)}u=p[u],h=p[h]}h!==u&&(o.push([u,h]),r+=h-u)}return{outSplits:a,valueSlices:o,numValues:r}}function jE(n){const t=[];for(let e=0;e<n.length;++e){const s=n[e].length,o=Xt("int32",s);t.push(o),n[e].forEach((r,i)=>o[i]=r)}return t}function Qp(n,t){const e=n.slice(0,t);for(;e.length<t;)e.push(1);for(let s=t;s<n.length;s++)e[t-1]*=n[s];return e}function qE(n,t,e,s,o,r){const i=Qp(t,2)[1],a=Qp(r,2)[1];let l=0;for(const c of e)for(let u=c[0];u<c[1];++u){for(let h=0;h<s;++h)o[l*a+h]=n[u*i+h];++l}}function XE(n,t,e,s,o){const r=t.slice();r[0]=o;const i=Xt(e,W(r)),a=n.length,l=a===0?0:a/t[0];return qE(n,t,s,l,i,r),[i,r]}function zy(n,t,e,s,o,r,i,a){if(n.length===0)throw new Error("paramsNestedSplits must be non empty");if(t[0].length===0)throw new Error("Split tensors must not be scalars");const l=t[0][0]-1;if(GE(r,i,l),s.length===0)throw new Error("params.rank must be nonzero");const c=s[0],{outSplits:u,valueSlices:h,numValues:d}=KE(r,i,n,c),p=jE(u),f=XE(e,s,o,h,d);return[p,f[0],f[1]]}const tf=2147483647;function By(n,t,e,s,o,r,i){if(t.length>1)throw new Error("starts must be a scalar or vector");if(o.length>1)throw new Error("limits must be a scalar or vector");if(i.length>1)throw new Error("deltas must be a scalar or vector");const a=t.length===0,l=o.length===0,c=i.length===0,u=[];a||u.push(t[0]),l||u.push(o[0]),c||u.push(i[0]);for(let g=1;g<u.length;++g)if(u[g]!==u[g-1])throw new Error("starts, limits, and deltas must have the same shape");const h=u.length===0?1:u[0],d=Xt("int32",h+1);d[0]=0;for(let g=0;g<h;++g){const x=a?n[0]:n[g],b=l?s[0]:s[g],w=c?r[0]:r[g];if(w===0)throw new Error("Requires delta != 0");let y;if(w>0&&b<x||w<0&&b>x)y=0;else if(y=Math.ceil(Math.abs((b-x)/w)),y>tf)throw new Error(`Requires ((limit - start) / delta) <= ${tf}`);d[g+1]=d[g]+y}const p=d[h],f=Xt(e,p);let m=0;for(let g=0;g<h;++g){const x=d[g+1]-d[g];let b=a?n[0]:n[g];const w=c?r[0]:r[g];for(let y=0;y<x;++y)f[m++]=b,b+=w}return[d,f]}var tn=mn;class Na{constructor(t,e,s,o,r,i,a,l,c,u){this.shape=t,this.shapeShape=e,this.values=s,this.valuesShape=o,this.valuesDType=r,this.defaultValue=i,this.defaultValueShape=a,this.rowPartitionValues=l,this.rowPartitionValuesShapes=c,this.rowPartitionTypes=vg(u),this.raggedRank=Sg(this.rowPartitionTypes)}getRowPartitionTypeByDimension(t){return this.rowPartitionTypes[0]===tn.FIRST_DIM_SIZE?this.rowPartitionTypes[t+1]:this.rowPartitionTypes[t]}getRowPartitionTensor(t){return this.rowPartitionTypes[0]===tn.FIRST_DIM_SIZE?this.rowPartitionValues[t+1]:this.rowPartitionValues[t]}getMaxWidth(t){const e=this.getRowPartitionTensor(t-1);switch(this.getRowPartitionTypeByDimension(t-1)){case tn.VALUE_ROWIDS:return Na.getMaxWidthValueRowID(e);case tn.ROW_SPLITS:return Na.getMaxWidthRowSplit(e);default:throw new Error(`Cannot handle partition type ${tn[this.getRowPartitionTypeByDimension(t-1)]}`)}}static getMaxWidthRowSplit(t){const e=t.length;if(e===0||e===1)return 0;let s=0;for(let o=0;o<e-1;++o){const r=t[o+1]-t[o];r>s&&(s=r)}return s}static getMaxWidthValueRowID(t){const e=t.length;if(e===0)return 0;let s=0,o=t[0],r=0;for(let i=1;i<e;++i){const a=t[i];a!==o&&(o=a,r=Math.max(i-s,r),s=i)}return Math.max(e-s,r)}tensorShapeFromTensor(t,e,s=!0){if(e.length===0){if(t[0]===-1)return[];throw new Error("The only valid scalar shape tensor is the fully unknown shape specified as -1.")}return nf(t,s)}calculateOutputSize(t){const e=this.valuesShape,s=this.defaultValueShape;Ng(s,e);const o=this.tensorShapeFromTensor(this.shape,this.shapeShape),i=kg(this.raggedRank,o,e);i[0]<0&&(i[0]=t);for(let a=1;a<=this.raggedRank;++a)i[a]<0&&(i[a]=this.getMaxWidth(a));return i}calculateFirstParentOutputIndex(t,e,s){const o=Math.min(t,s),r=[];let i=0;for(let a=0;a<o;++a,i+=e)r.push(i);for(let a=o;a<t;++a)r.push(-1);return $(r.length===t,()=>"Final length of result must be equal to firstDimension."),r}calculateOutputIndexRowSplit(t,e,s,o){const r=t.length,i=[];for(let a=0;a<r-1;++a){const l=t[a+1]-t[a];let c=Math.min(o,l),u=e[a];u===-1&&(c=0);for(let h=0;h<c;++h)i.push(u),u+=s;for(let h=0;h<l-c;++h)i.push(-1)}if(r>0&&i.length!==t[r-1])throw new Error("Invalid row split size.");return i}calculateOutputIndexValueRowID(t,e,s,o){const r=t.length,i=[];if(r===0)return[];let a=0,l=t[0];if(l>=e.length)throw new Error(`Got currentValueRowId=${l}, which is not less than ${e.length}`);let c=e[l];i.push(c);for(let u=1;u<r;++u){const h=t[u];if(h===l)c>=0&&(++a,a<o?c+=s:c=-1);else{if(a=0,l=h,h>=e.length)throw new Error(`Got nextValueRowId=${h} which is not less than ${e.length}`);c=e[h]}i.push(c)}if(i.length!==t.length)throw new Error("Invalid row ids.");return i}calculateOutputIndex(t,e,s,o){const r=this.getRowPartitionTensor(t),i=this.getRowPartitionTypeByDimension(t);switch(i){case tn.VALUE_ROWIDS:return this.calculateOutputIndexValueRowID(r,e,s,o);case tn.ROW_SPLITS:if(r.length-1>e.length)throw new Error(`Row partition size is greater than output size: ${r.length-1} > ${e.length}`);return this.calculateOutputIndexRowSplit(r,e,s,o);default:throw new Error(`Unsupported partition type: ${tn[i]}`)}}getFirstDimensionSize(){const t=this.rowPartitionValues[0];if(this.rowPartitionTypes.length===0)throw new Error("No row_partition_types given.");const e=this.rowPartitionTypes[0];switch(e){case tn.FIRST_DIM_SIZE:return t[0];case tn.VALUE_ROWIDS:throw new Error("Cannot handle VALUE_ROWIDS in first dimension.");case tn.ROW_SPLITS:return this.rowPartitionValuesShapes[0][0]-1;default:throw new Error(`Cannot handle type ${tn[e]}`)}}compute(){if(this.rowPartitionValues[0].length<=0)throw new Error("Invalid first partition input. Tensor requires at least one element.");const e=this.getFirstDimensionSize(),s=this.calculateOutputSize(e),o=new Array(this.raggedRank+1);o[o.length-1]=1;for(let l=o.length-2;l>=0;--l)o[l]=o[l+1]*s[l+1];const r=nf(s,!1),i=Xt(this.valuesDType,W(r));if(o[0]*s[0]>0){let l=this.calculateFirstParentOutputIndex(e,o[0],s[0]);for(let c=1;c<=this.raggedRank;++c)l=this.calculateOutputIndex(c-1,l,o[c],s[c]);this.setOutput(this.raggedRank,l,i,r)}return[r,i]}setOutput(t,e,s,o){if(s.length===0)return;const r=this.values,i=s;let a=o.slice();a=a.slice(t+1);const l=W(a),c=e.length;let u=this.defaultValue;if(u.length!==l&&u.length!==1){const f=this.defaultValueShape;_(()=>{const m=A(u,f);u=ur(m,a).dataSync()})}let h=0,d=0,p=0;for(let f=0;f<=c;++f){let m=f<c?e[f]:-1;if(m===p){++p;continue}if(d<p){const g=r.subarray(h*l),x=i.subarray(d*l),b=(p-d)*l;ef(x,g,b)}if(f>=c){const g=s.length;m=Math.floor(g/l)}if(m>p)if(this.defaultValue.length===1)i.subarray(p*l,m*l).fill(this.defaultValue[0]),p=m;else for(;m>p;){const g=i.slice(p*l);ef(g,u,l),++p}m<0?(h=f+1,d=p):(h=f,d=p,p=d+1)}}}function ef(n,t,e){for(let s=0;s<e;s++)n[s]=t[s]}function nf(n,t){const e=[];for(let s of n){if(s<0){if(!t)throw new Error(`Dimension ${s} must be >= 0`);if(s<-1)throw new Error(`Dimension ${s} must be >= -1`);s=-1}e.push(s)}return e}function Vy(n,t,e,s,o,r,i,a,l,c){return new Na(n,t,e,s,o,r,i,a,l,c).compute()}function Wy(n,t,e,s){const o=n===t,r=n<t&&e<0,i=t<n&&e>1;if(o||r||i)return $e(0,s);const a=Math.abs(Math.ceil((t-n)/e)),l=$e(a,s);t<n&&e===1&&(e=-1),l[0]=n;for(let c=1;c<l.length;c++)l[c]=l[c-1]+e;return l}const Uy=Vn(n=>1/Math.sqrt(n)),YE=Ts(ai,Uy),JE={kernelName:ai,backendName:"cpu",kernelFunc:YE};function Ps(n,t,e,s,o,r,i,a,l,c){const u=[s/o,o],h=n.values,d=t.values;if(s===0)return wt(e,t.dtype);const p=l instanceof xe?l:wt(u,t.dtype);typeof l=="string"||typeof l=="number"?p.values.fill(l):typeof l=="boolean"&&p.values.fill(+l);for(let f=0;f<r;f++){const m=[];let g=0;for(let x=0;x<i;x++){const b=h[f*i+x];m.push(b),g+=b*a[x]}if(g<0||g>=s/o)throw new Error(`Invalid indices: ${m} does not index into ${e}`);for(let x=0;x<o;x++)c?p.values[g*o+x]+=d[f*o+x]:p.values[g*o+x]=t.rank===0?d[0]:d[f*o+x]}return p}const ZE=Vn(n=>1/(1+Math.exp(-n))),Gy=At(di,n=>1/(1+Math.exp(-n))),QE={kernelName:di,backendName:"cpu",kernelFunc:Gy};function Hy(n,t,e,s,o){const r=Gh(s,t,e),i=W(e),a=lt(s);if(r){const h=Hh(t,a);return o==="string"?n.slice(h,h+i):n.subarray(h,h+i)}const l=o==="string"?Yn(n):n,c=wt(s,o,l),u=wt(e,o);for(let h=0;h<u.size;++h){const d=u.indexToLoc(h),p=d.map((f,m)=>f+t[m]);u.set(c.get(...p),...d)}return o==="string"?jg(u.values):u.values}function eo(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{begin:r,size:i}=s;rt(o,"slice");const[a,l]=Gl(o,r,i);Wh(o,a,l);const c=e.data.get(o.dataId).values,u=Hy(c,a,l,o.shape,o.dtype);return e.makeTensorInfo(l,o.dtype,u)}const tR={kernelName:Nl,backendName:"cpu",kernelFunc:eo};function Ky(n,t,e,s,o,r,i){const a=t[0],l=r[0],c=new Array(l),u=new Array(a),h=t[1];if(l===0){if(a!==0)throw new Error(Og(a));const g=Xt(e,0),x=Xt(o,0);return[g,[0,h],x,c,u]}let d=!0,p=0;const f=new Array(l).fill(0);for(let g=0;g<a;++g){const x=n[g*h];if(x<0)throw new Error(_g(g,x));if(x>=l)throw new Error(Lg(g,x,l));++f[x],d=d&&x>=p,p=x}let m=!0;for(let g=0;g<l;++g){const x=f[g]===0;c[g]=x,m=m&&!x,f[g]=Math.max(f[g],1),g>0&&(f[g]+=f[g-1])}if(m&&d){const g=n,x=s;for(let b=0;b<a;++b)u[b]=b;return[g,[a,h],x,c,u]}else{const g=f[l-1],x=Xt(e,g*h),b=Xt(o,g),w=new Array(l).fill(0);for(let y=0;y<a;++y){const C=n[y*h],I=w[C],k=(C===0?0:f[C-1])+I;w[C]++;for(let v=0;v<h;++v)x[k*h+v]=n[y*h+v];b[k]=s[y],u[y]=k}for(let y=0;y<l;++y)if(w[y]===0){const I=y===0?0:f[y-1];x[I*h+0]=y;for(let k=1;k<h;++k)x[I*h+k]=0;b[I]=i}return[x,[g,h],b,c,u]}}function jy(n,t,e,s,o){const r=W(s),i=t[0],a=o.length,l=[];let c=1,u=-1;for(let g=0;g<a;++g){const x=o[g];if(x===-1){if(u!==-1)throw new Error(Mg(u,g));u=g,l.push(1)}else{if(x<0)throw new Error(Pg(g,x));c*=x,l.push(x)}}if(u!==-1){if(c<=0)throw new Error(zg());const g=Math.trunc(r/c);if(c*g!==r)throw new Error(Bg(s,l));l[u]=g}if(W(l)!==r)throw new Error(Vg(s,l));const d=s.length,p=[];if(d>0){p[d-1]=1;for(let g=d-2;g>=0;--g)p[g]=p[g+1]*s[g+1]}const f=[];if(a>0){f[a-1]=1;for(let g=a-2;g>=0;--g)f[g]=f[g+1]*l[g+1]}const m=Xt(e,i*a);for(let g=0;g<i;++g){let x=0;for(let b=0;b<d;++b)x+=n[g*d+b]*p[b];for(let b=0;b<a;++b)m[g*a+b]=Math.trunc(x/f[b]),x%=f[b]}return[m,[i,a],l]}function Pd(n,t,e,s,o,r=!1,i=0){const a=s.length,l=[t[0],n.length/t[0]],c=l[1],h=a>0?o[a-1]+1:0;if(h<0)throw new Error(Jc());const d=t.slice();d[0]=h;const p=d.reduce((w,y)=>w*y,1),f=Xt(e,p);if(a===0)return h>0&&f.fill(i),[f,d];if(h<=0)throw new Error(Jc());let m=0,g=1,x=0,b=o[m];for(;;){let w=0;if(g<a){if(w=o[g],b===w){++g;continue}if(b>=w)throw new Error(Wg())}if(b<0||b>=h)throw new Error(Ug(b,h));b>x&&f.fill(i,x*c,b*c);for(let y=m;y<g;++y){const C=s[y];if(C<0||C>=l[0])throw new Error(Gg(y,s[y],l[0]));for(let I=0;I<c;I++)f[b*c+I]+=n[C*c+I]}if(r)for(let y=0;y<c;y++)f[b*c+y]/=g-m;if(m=g,++g,x=b+1,b=w,g>a)break}return x<h&&f.fill(i,x*c,h*c),[f,d]}const eR=Vn(n=>Math.sqrt(n)),nR=At(fi,n=>Math.sqrt(n)),sR={kernelName:fi,backendName:"cpu",kernelFunc:nR};const qy=te(((n,t)=>{const e=n-t;return e*e})),oR=ce(mi,qy),rR={kernelName:mi,backendName:"cpu",kernelFunc:oR};const Xy=Vn((n,t)=>{const{pattern:e,replaceGlobal:s,rewrite:o}=t;return n.replace(new RegExp(e,s?"g":""),o)}),iR=Ts(nh,Xy),aR={kernelName:nh,backendName:"cpu",kernelFunc:iR};function Yy(n,t,e,s){const o=wt(n,t.dtype);for(let r=0;r<o.size;r++){const i=o.indexToLoc(r),a=new Array(i.length);for(let l=0;l<a.length;l++)a[l]=i[l]*e[l]+s[l];o.set(t.get(...a),...i)}return o}class lR{constructor(t,e,s,o,r,i){this.separator=us(t),this.nGramWidths=e,this.leftPad=us(s),this.rightPad=us(o),this.padWidth=r,this.preserveShort=i}getPadWidth(t){return Math.min(this.padWidth<0?t-1:this.padWidth,t-1)}getNumNGrams(t,e){const s=this.getPadWidth(e);return Math.max(0,t+2*s-e+1)}createNGrams(t,e,s,o,r,i){for(let a=0;a<r;++a){const l=this.getPadWidth(i),c=Math.max(0,l-a),u=Math.max(0,l-(r-(a+1))),h=i-(c+u),d=e+(c>0?0:a-l);let p=0;p+=c*this.leftPad.length;for(let b=0;b<h;++b)p+=t[d+b].length;p+=u*this.rightPad.length;const f=c+u+h-1;p+=f*this.separator.length,s[o+a]=new Uint8Array(p);const m=s[o+a];let g=0;const x=b=>b.forEach(w=>m[g++]=w);for(let b=0;b<c;++b)x(this.leftPad),x(this.separator);for(let b=0;b<h-1;++b)x(t[d+b]),x(this.separator);if(h>0){x(t[d+h-1]);for(let b=0;b<u;++b)x(this.separator),x(this.rightPad)}else{for(let b=0;b<u-1;++b)x(this.rightPad),x(this.separator);x(this.rightPad)}}}compute(t,e){const s=t.length,o=e.length;if(o>0){let l=e[0];if(l!==0)throw new Error(`First split value must be 0, got ${l}`);for(let c=1;c<o;++c){let u=e[c]>=l;if(u=u&&e[c]<=s,!u)throw new Error(`Invalid split value ${e[c]}, must be in [${l}, ${s}]`);l=e[c]}if(l!==s)throw new Error(`Last split value must be data size. Expected ${s}, got ${l}`)}const r=o-1,i=Xt("int32",o);if(s===0||o===0){const l=new Array(s);for(let c=0;c<=r;++c)i[c]=0;return[l,i]}i[0]=0;for(let l=1;l<=r;++l){const c=e[l]-e[l-1];let u=0;this.nGramWidths.forEach(h=>{u+=this.getNumNGrams(c,h)}),this.preserveShort&&c>0&&u===0&&(u=1),i[l]=i[l-1]+u}const a=new Array(i[r]);for(let l=0;l<r;++l){const c=e[l];let u=i[l];if(this.nGramWidths.forEach(h=>{const d=e[l+1]-e[l],p=this.getNumNGrams(d,h);this.createNGrams(t,c,a,u,p,h),u+=p}),this.preserveShort&&u===i[l]){const h=e[l+1]-e[l];if(h===0)continue;const d=h+2*this.padWidth;this.createNGrams(t,c,a,u,1,d)}}return[a,i]}}function Jy(n,t,e,s,o,r,i,a){return new lR(e,s,o,r,i,a).compute(n,t)}function cR(n,t,e,s){if(!n.length)return;if(t.length===0){for(let r=0;r<n.length;++r)s.push(n.subarray(r,r+1));return}if(t.length===1){const r=t[0];let i=n.indexOf(r);for(;i!==-1;){const a=n.subarray(0,i);(!e||a.length!==0)&&s.push(a),n=n.subarray(i+1),i=n.indexOf(r)}(!e||n.length!==0)&&s.push(n);return}let o=0;for(let r=0;r<n.length+1;r++)if(r===n.length||t.indexOf(n[r])!==-1){const i=n.subarray(o,r);(!e||i.length!==0)&&s.push(i),o=r+1}}function Zy(n,t,e){const s=n.length,o=[];let r=0,i=0;const a=new Array(s);for(let d=0;d<s;++d){const p=o.length;cR(n[d],t,e,o);const f=o.length-p;a[d]=f,r+=f,i=Math.max(i,f)}const l=Xt("int32",r*2),c=new Array(r),u=[s,i];let h=0;for(let d=0;d<s;++d)for(let p=0;p<a[d];++p)l[h*2]=d,l[h*2+1]=p,c[h]=o[h],++h;return[l,c,u]}function Qy(n,t){const e=Xt("int32",n.length);for(let s=0;s<n.length;++s)e[s]=W1(n[s]).modulo(t).getLowBitsUnsigned();return e}const t0=te(((n,t)=>n-t)),uR=Od(((n,t,e,s)=>({real:n-e,imag:t-s}))),zd=ce(gi,t0,uR),hR={kernelName:gi,backendName:"cpu",kernelFunc:zd};function e0(n,t){const e=new Array(n.rank);for(let o=0;o<e.length;o++)e[o]=n.shape[o]*t[o];const s=wt(e,n.dtype);for(let o=0;o<s.values.length;++o){const r=s.indexToLoc(o),i=new Array(n.rank);for(let l=0;l<i.length;l++)i[l]=r[l]%n.shape[l];const a=n.locToIndex(i);s.values[o]=n.values[a]}return s}const ir=(n,t)=>{const e=t.value-n.value;return e===0?n.index-t.index:e};function n0(n,t,e=0,s=n.length-1){for(;s>e;){if(s-e>600){const a=s-e+1,l=t-e+1,c=Math.log(a),u=.5*Math.exp(2*c/3),h=.5*Math.sqrt(c*u*(a-u)/a)*Math.sign(l-a/2),d=Math.max(e,Math.floor(t-l*u/a+h)),p=Math.min(s,Math.floor(t+(a-l)*u/a+h));n0(n,t,d,p)}const o=n[t];let r=e,i=s;for(xo(n,e,t),ir(n[s],o)>0&&xo(n,e,s);r<i;){for(xo(n,r,i),r++,i--;ir(n[r],o)<0;)r=r+1;for(;ir(n[i],o)>0;)i=i-1}ir(n[e],o)===0?xo(n,e,i):(i=i+1,xo(n,i,s)),i<=t&&(e=i+1),t<=i&&(s=i-1)}}function s0(n,t,e,s,o){const r=t[t.length-1],[i,a]=[n.length/r,r],l=Ce(e,i*s),c=Ce("int32",i*s);for(let h=0;h<i;h++){const d=h*a,p=n.subarray(d,d+a);let f=new Array(p.length);p.forEach((b,w)=>f[w]={value:b,index:w}),s<f.length&&(n0(f,s),f=f.slice(0,s)),o&&f.sort(ir);const m=h*s,g=l.subarray(m,m+s),x=c.subarray(m,m+s);for(let b=0;b<s;b++)g[b]=f[b].value,x[b]=f[b].index}const u=t.slice();return u[u.length-1]=s,[wt(u,e,l),wt(u,"int32",c)]}function o0(n,t,e,s){const o=Ct(t,e)[0],r=[1,e[0],1];for(let f=0;f<o;f++)r[0]*=e[f];r[1]=e[o];for(let f=o+1;f<e.length;f++)r[2]*=e[f];const i=new Map,a=new Int32Array(e[o]),l=new xe(r,s,n),c=[],u=r[0]===1&&r[2]===1;for(let f=0;f<e[o];f++){let m;if(u)m=n[f].toString();else{const x=[];for(let b=0;b<r[0];b++)for(let w=0;w<r[2];w++)x.push(l.get(b,f,w));m=x.join(",")}const g=i.get(m);if(g!=null)a[f]=g;else{const x=i.size;i.set(m,x),a[f]=x,c.push(f)}}const h=r.slice();h[1]=i.size;const d=new xe(h,s);c.forEach((f,m)=>{for(let g=0;g<r[0];g++)for(let x=0;x<r[2];x++)d.set(l.get(g,f,x),g,m,x)});const p=e.slice();return p[o]=h[1],{outputValues:d.values,outputShape:p,indices:a}}const dR=Object.freeze(Object.defineProperty({__proto__:null,addImpl:py,bincountImpl:_d,bincountReduceImpl:fy,bitwiseAndImpl:my,castImpl:dy,ceilImpl:gy,concatImpl:xy,equalImpl:by,expImpl:wy,expm1Impl:$y,floorDivImpl:ky,floorImpl:Iy,gatherNdImpl:vy,gatherV2Impl:Sy,greaterEqualImpl:Ty,greaterImpl:Ny,lessEqualImpl:Ry,lessImpl:Ey,linSpaceImpl:Dy,logImpl:Ay,maxImpl:Fy,maximumImpl:Oy,minimumImpl:_y,multiplyImpl:Ld,negImpl:Ly,notEqualImpl:My,prodImpl:Py,raggedGatherImpl:zy,raggedRangeImpl:By,raggedTensorToTensorImpl:Vy,rangeImpl:Wy,rsqrtImpl:Uy,scatterImpl:Ps,sigmoidImpl:ZE,simpleAbsImpl:hy,sliceImpl:Hy,sparseFillEmptyRowsImpl:Ky,sparseReshapeImpl:jy,sparseSegmentReductionImpl:Pd,sqrtImpl:eR,squaredDifferenceImpl:qy,staticRegexReplaceImpl:Xy,stridedSliceImpl:Yy,stringNGramsImpl:Jy,stringSplitImpl:Zy,stringToHashBucketFastImpl:Qy,subImpl:t0,tileImpl:e0,topKImpl:s0,transposeImpl:Md,uniqueImpl:o0},Symbol.toStringTag,{value:"Module"}));$m("cpu",()=>new oc,1);const r0=At(zr,n=>n>=0?n:Math.exp(n)-1),pR={kernelName:zr,backendName:"cpu",kernelFunc:r0};function i0(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{alpha:r}=s;rt([o],"leakyRelu");const i=W(o.shape),a=e.data.get(o.dataId).values,l=Ce("float32",i);for(let c=0;c<a.length;c++)l[c]=a[c]<0?r*a[c]:a[c];return e.makeTensorInfo(o.shape,"float32",l)}const fR={kernelName:el,backendName:"cpu",kernelFunc:i0};const mR=te((n,t)=>n<0?t*n:n);function a0(n){const{inputs:t,backend:e}=n,{x:s,alpha:o}=t;rt([s,o],"prelu");const r=e.data.get(s.dataId).values,i=e.data.get(o.dataId).values,[a,l]=mR(s.shape,o.shape,r,i,"float32");return e.makeTensorInfo(l,"float32",a)}const gR={kernelName:wl,backendName:"cpu",kernelFunc:a0};const l0=At(oi,n=>Math.max(0,n)),xR={kernelName:oi,backendName:"cpu",kernelFunc:l0};const c0=At(ri,n=>Math.min(Math.max(0,n),6)),bR={kernelName:ri,backendName:"cpu",kernelFunc:c0};function Ta(n,t,e,s,o){if(e==="linear")return Bn({inputs:{x:t},backend:n});if(e==="relu")return l0({inputs:{x:t},backend:n});if(e==="elu")return r0({inputs:{x:t},backend:n});if(e==="relu6")return c0({inputs:{x:t},backend:n});if(e==="prelu")return a0({inputs:{x:t,alpha:s},backend:n});if(e==="leakyrelu")return i0({inputs:{x:t},backend:n,attrs:{alpha:o}});if(e==="sigmoid")return Gy({inputs:{x:t},backend:n});throw new Error(`Activation ${e} has not been implemented for the CPU backend.`)}function Bt(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{shape:r}=s,i=W(o.shape),a=_f(r,i),l=W(a);$(i===l,()=>`The new shape (${a}) has ${l} elements and the old shape (${o.shape}) has ${i} elements. The new shape and old shape must have the same number of elements.`),e.incRef(o.dataId);const c=e.data.get(o.dataId);if(c.complexTensorInfos!=null){const u=c.complexTensorInfos.real,h=c.complexTensorInfos.imag;u.shape=a,h.shape=a}return{dataId:o.dataId,shape:a,dtype:o.dtype}}const yR={kernelName:$l,backendName:"cpu",kernelFunc:Bt};function u0(n){const{inputs:t,backend:e,attrs:s}=n,{a:o,b:r}=t,{transposeA:i,transposeB:a}=s;rt([o,r],"matMul");const l=o.shape.length,c=r.shape.length,u=i?o.shape[l-2]:o.shape[l-1],h=a?r.shape[c-1]:r.shape[c-2],d=i?o.shape[l-1]:o.shape[l-2],p=a?r.shape[c-2]:r.shape[c-1],f=o.shape.slice(0,-2),m=r.shape.slice(0,-2),g=W(f),x=W(m),w=mt(o.shape.slice(0,-2),r.shape.slice(0,-2)).concat([d,p]);$(u===h,()=>`Error in matMul: inner shapes (${u}) and (${h}) of Tensors with shapes ${o.shape} and ${r.shape} and transposeA=${i} and transposeB=${a} must match.`);const y=i?[g,u,d]:[g,d,u],C=a?[x,p,h]:[x,h,p],I=Bt({inputs:{x:o},backend:e,attrs:{shape:y}}),k=Bt({inputs:{x:r},backend:e,attrs:{shape:C}}),v=i?I.shape[1]:I.shape[2],N=i?I.shape[2]:I.shape[1],T=a?k.shape[1]:k.shape[2],O=Math.max(g,x),P=e.data.get(I.dataId).values,z=e.data.get(k.dataId).values,B=lt(I.shape),M=lt(k.shape),[G,H,U]=i?[B[0],1,B[1]]:[B[0],B[1],1],[K,q,X]=a?[1,M[1],M[0]]:[M[1],1,M[0]],Z=N*T,J=wt([O,N,T],I.dtype),et=J.values,Q=e.blockSize;for(let ot=0;ot<O;ot++){const at=ot%g,dt=ot%x;for(let ht=0;ht<N;ht+=Q){const gt=Math.min(ht+Q,N);for(let bt=0;bt<T;bt+=Q){const Rt=Math.min(bt+Q,T);for(let Lt=0;Lt<v;Lt+=Q){const qt=Math.min(Lt+Q,v);for(let Mt=ht;Mt<gt;Mt++)for(let Ft=bt;Ft<Rt;Ft++){let Ht=0;for(let Wt=Lt;Wt<qt;Wt++){const Wn=P[at*G+Mt*H+Wt*U],me=z[Wt*K+Ft*q+dt*X];Ht+=Wn*me}et[ot*Z+(Mt*T+Ft)]+=Ht}}}}}return e.disposeIntermediateTensorInfo(I),e.disposeIntermediateTensorInfo(k),e.makeTensorInfo(w,J.dtype,J.values)}const wR={kernelName:Ba,backendName:"cpu",kernelFunc:u0};function CR(n){const{inputs:t,backend:e,attrs:s}=n,{a:o,b:r,bias:i,preluActivationWeights:a}=t,{transposeA:l,transposeB:c,activation:u,leakyreluAlpha:h}=s;let d,p,f;const m=[];d=u0({inputs:{a:o,b:r},attrs:{transposeA:l,transposeB:c},backend:e}),i&&(p=Do({inputs:{a:d,b:i},backend:e}),m.push(d),d=p),u&&(f=Ta(e,d,u,a,h),m.push(d),d=f);for(const x of m)e.disposeIntermediateTensorInfo(x);return d}const $R={kernelName:ia,backendName:"cpu",kernelFunc:CR};const IR=At(Sr,n=>Math.acos(n)),kR={kernelName:Sr,backendName:"cpu",kernelFunc:IR};const vR=At(Nr,n=>Math.acosh(n)),SR={kernelName:Nr,backendName:"cpu",kernelFunc:vR};function NR(n){const{inputs:t,backend:e}=n,s=t;rt(t,"addN");const o=s.map(a=>e.data.get(a.dataId).values),r=wt(s[0].shape,s[0].dtype),i=r.values;for(let a=0;a<s.length;a++){const l=o[a];for(let c=0;c<i.length;c++)i[c]+=l[c]}return e.makeTensorInfo(r.shape,r.dtype,r.values)}const TR={kernelName:wu,backendName:"cpu",kernelFunc:NR};function ER(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;rt(o,"all");const a=Ct(r,o.shape);let l=a;const c=jt(l,o.shape.length);let u=o;c!=null&&(u=Pe({inputs:{x:o},backend:e,attrs:{perm:c}}),l=Zt(l.length,o.shape.length)),ye("all",l,u.shape.length);const[h,d]=fe(u.shape,l),p=W(d),f=$e(W(h),u.dtype),m=e.data.get(u.dataId).values;for(let x=0;x<f.length;++x){const b=x*p;let w=m[b];for(let y=0;y<p;++y){const C=m[b+y];w=w&&C}f[x]=w}c!=null&&e.disposeIntermediateTensorInfo(u);const g=e.makeTensorInfo(h,u.dtype,f);if(i){const x=ne(h,a),b=Bt({inputs:{x:g},backend:e,attrs:{shape:x}});return e.disposeIntermediateTensorInfo(g),b}return g}const RR={kernelName:Cu,backendName:"cpu",kernelFunc:ER};function DR(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;rt(o,"any");const a=Ct(r,o.shape);let l=a;const c=jt(l,o.shape.length);let u=o;c!=null&&(u=Pe({inputs:{x:o},backend:e,attrs:{perm:c}}),l=Zt(l.length,o.shape.length)),ye("any",l,u.shape.length);const[h,d]=fe(u.shape,l),p=W(d),f=$e(W(h),u.dtype),m=e.data.get(u.dataId).values;for(let x=0;x<f.length;++x){const b=x*p;let w=m[b];for(let y=0;y<p;++y){const C=m[b+y];w=w||C}f[x]=w}c!=null&&e.disposeIntermediateTensorInfo(u);const g=e.makeTensorInfo(h,u.dtype,f);if(i){const x=ne(h,a),b=Bt({inputs:{x:g},backend:e,attrs:{shape:x}});return e.disposeIntermediateTensorInfo(g),b}return g}const AR={kernelName:$u,backendName:"cpu",kernelFunc:DR};function FR(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r}=s;rt(o,"argMax");let i=Ct(r,o.shape);const a=jt(i,o.shape.length);let l=o;const c=[];a!=null&&(l=Pe({inputs:{x:o},backend:e,attrs:{perm:a}}),c.push(l),i=Zt(i.length,l.shape.length)),i=[i[0]],ye("argMax",i,l.shape.length);const[u,h]=fe(l.shape,i),d=W(u),p=$e(d,"int32"),f=W(h),m=e.data.get(l.dataId).values;for(let g=0;g<p.length;++g){const x=g*f;let b=m[x],w=0;for(let y=0;y<f;++y){const C=m[x+y];C>b&&(b=C,w=y)}p[g]=w}return c.forEach(g=>e.disposeIntermediateTensorInfo(g)),e.makeTensorInfo(u,"int32",p)}const OR={kernelName:La,backendName:"cpu",kernelFunc:FR};function _R(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r}=s;rt(o,"argMin");let i=Ct(r,o.shape);const a=jt(i,o.shape.length);let l=o;const c=[];a!=null&&(l=Pe({inputs:{x:o},backend:e,attrs:{perm:a}}),c.push(l),i=Zt(i.length,l.shape.length)),i=[i[0]],ye("argMin",i,l.shape.length);const[u,h]=fe(l.shape,i),d=W(u),p=$e(d,"int32"),f=W(h),m=e.data.get(l.dataId).values;for(let g=0;g<p.length;++g){const x=g*f;let b=m[x],w=0;for(let y=0;y<f;++y){const C=m[x+y];C<b&&(b=C,w=y)}p[g]=w}return c.forEach(g=>e.disposeIntermediateTensorInfo(g)),e.makeTensorInfo(u,"int32",p)}const LR={kernelName:Ma,backendName:"cpu",kernelFunc:_R};const MR=At(Tr,n=>Math.asin(n)),PR={kernelName:Tr,backendName:"cpu",kernelFunc:MR};const zR=At(Er,n=>Math.asinh(n)),BR={kernelName:Er,backendName:"cpu",kernelFunc:zR};const VR=At(Rr,n=>Math.atan(n)),WR={kernelName:Rr,backendName:"cpu",kernelFunc:VR};const UR=te((n,t)=>Math.atan2(n,t)),GR=ce(Ar,UR),HR={kernelName:Ar,backendName:"cpu",kernelFunc:GR};const KR=At(Dr,n=>Math.atanh(n)),jR={kernelName:Dr,backendName:"cpu",kernelFunc:KR};function Bd(n,t,e,s,o,r){const i=o.strideHeight,a=o.strideWidth,l=o.dilationHeight,c=o.dilationWidth,u=o.effectiveFilterHeight,h=o.effectiveFilterWidth,d=o.padInfo.top,p=o.padInfo.left,f=r==="max"?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY,m=wt(o.outShape,e),g=m.values,x=o.outShape[1]*o.outShape[2]*o.outShape[3],b=o.outShape[2]*o.outShape[3],w=o.outShape[3];for(let y=0;y<o.batchSize;++y){const C=y*x,I=y*s[0];for(let k=0;k<o.inChannels;++k)for(let v=0;v<o.outHeight;++v){const N=v*i-d,T=Math.max(0,N),O=Math.min(o.inHeight,u+N),P=C+v*b;for(let z=0;z<o.outWidth;++z){const B=z*a-p,M=Math.max(0,B),G=Math.min(o.inWidth,h+B);let H=f,U=0,K=0;for(let X=T;X<O;X+=l){const Z=I+X*s[1];for(let J=M;J<G;J+=c){const et=Z+J*s[2],Q=n[et+k];r==="max"&&Q>H?H=Q:r==="avg"&&(U+=Q,K++)}if(isNaN(H))break}const q=P+z*w+k;g[q]=r==="avg"?U/K:H}}}return m}function h0(n,t,e,s,o=!1,r=!1){const i=wt(s.outShape,"int32"),a=s.strideHeight,l=s.strideWidth,c=s.dilationHeight,u=s.dilationWidth,h=s.effectiveFilterHeight,d=s.effectiveFilterWidth,p=s.padInfo.top,f=s.padInfo.left,m=wt(t,e,n);for(let g=0;g<s.batchSize;++g)for(let x=0;x<s.inChannels;++x)for(let b=0;b<s.outHeight;++b){const w=b*a-p;let y=w;for(;y<0;)y+=c;const C=Math.min(s.inHeight,h+w);for(let I=0;I<s.outWidth;++I){const k=I*l-f;let v=k;for(;v<0;)v+=u;const N=Math.min(s.inWidth,d+k);let T=Number.NEGATIVE_INFINITY,O=-1;for(let P=y;P<C;P+=c){const z=P-w;for(let B=v;B<N;B+=u){const M=B-k,G=m.get(g,P,B,x);G>T&&(T=G,o?O=r?((g*s.inHeight+P)*s.inWidth+B)*s.inChannels+x:(P*s.inWidth+B)*s.inChannels+x:O=z*d+M)}}i.set(O,g,b,I,x)}}return i}function d0(n,t,e,s,o,r){const i=o.strideDepth,a=o.strideHeight,l=o.strideWidth,c=o.dilationDepth,u=o.dilationHeight,h=o.dilationWidth,d=o.effectiveFilterDepth,p=o.effectiveFilterHeight,f=o.effectiveFilterWidth,m=o.padInfo.front,g=o.padInfo.top,x=o.padInfo.left,b=r==="max"?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY,w=wt(o.outShape,e),y=w.values,C=o.outShape[1]*o.outShape[2]*o.outShape[3]*o.outShape[4],I=o.outShape[2]*o.outShape[3]*o.outShape[4],k=o.outShape[3]*o.outShape[4],v=o.outShape[4];for(let N=0;N<o.batchSize;++N){const T=N*C,O=N*s[0];for(let P=0;P<o.inChannels;++P)for(let z=0;z<o.outDepth;++z){const B=z*i-m;let M=B;for(;M<0;)M+=c;const G=Math.min(o.inDepth,d+B),H=T+z*I;for(let U=0;U<o.outHeight;++U){const K=U*a-g;let q=K;for(;q<0;)q+=u;const X=Math.min(o.inHeight,p+K),Z=H+U*k;for(let J=0;J<o.outWidth;++J){const et=J*l-x;let Q=et;for(;Q<0;)Q+=h;const ot=Math.min(o.inWidth,f+et),at=Z+J*v;let dt=b,ht=0,gt=0;for(let Rt=M;Rt<G;Rt+=c){const Lt=O+Rt*s[1];for(let qt=q;qt<X;qt+=u){const Mt=Lt+qt*s[2];for(let Ft=Q;Ft<ot;Ft+=h){const Ht=Mt+Ft*s[3],Wt=n[Ht+P];if(r==="max"&&Wt>dt?dt=Wt:r==="avg"&&(ht+=Wt,gt++),isNaN(dt))break}if(isNaN(dt))break}if(isNaN(dt))break}const bt=at+P;y[bt]=r==="avg"?ht/Math.max(gt,1):dt}}}}return w}function qR(n,t){const e=wt(t.outShape,"int32"),s=t.strideDepth,o=t.strideHeight,r=t.strideWidth,i=t.dilationDepth,a=t.dilationHeight,l=t.dilationWidth,c=t.effectiveFilterDepth,u=t.effectiveFilterHeight,h=t.effectiveFilterWidth,d=t.padInfo.front,p=t.padInfo.top,f=t.padInfo.left;for(let m=0;m<t.batchSize;++m)for(let g=0;g<t.inChannels;++g)for(let x=0;x<t.outDepth;++x){const b=x*s-d;let w=b;for(;w<0;)w+=i;const y=Math.min(t.inDepth,c+b);for(let C=0;C<t.outHeight;++C){const I=C*o-p;let k=I;for(;k<0;)k+=a;const v=Math.min(t.inHeight,u+I);for(let N=0;N<t.outWidth;++N){const T=N*r-f;let O=T;for(;O<0;)O+=l;const P=Math.min(t.inWidth,h+T);let z=Number.NEGATIVE_INFINITY,B=-1;for(let M=w;M<y;M+=i){const G=M-b;for(let H=k;H<v;H+=a){const U=H-I;for(let K=O;K<P;K+=l){const q=K-T,X=n.get(m,M,H,K,g);X>=z&&(z=X,B=G*u*h+U*u+q)}}}e.set(B,m,x,C,N,g)}}}return e}function XR(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t;rt(o,"avgPool");const{filterSize:r,strides:i,pad:a,dimRoundingMode:l}=s,c=1;$(ke(i,c),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${i} and dilations '${c}'`);const u=ln(o.shape,r,i,c,a,l);let h;if(u.filterWidth===1&&u.filterHeight===1&&Et(u.inShape,u.outShape))h=Bn({inputs:{x:o},backend:e});else{const d=e.data.get(o.dataId).values,p=lt(o.shape),f=Bd(d,o.shape,o.dtype,p,u,"avg");h=e.makeTensorInfo(u.outShape,o.dtype,f.values)}return h}const YR={kernelName:Pa,backendName:"cpu",kernelFunc:XR};function JR(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{filterSize:r,strides:i,pad:a,dimRoundingMode:l,dataFormat:c}=s;rt(o,"avgPool3d");const u=Zn(o.shape,r,i,1,a,l,c),h=e.data.get(o.dataId).values,d=d0(h,o.shape,o.dtype,lt(o.shape),u,"avg");return e.makeTensorInfo(d.shape,"float32",d.values)}const ZR={kernelName:za,backendName:"cpu",kernelFunc:JR};function QR(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,{filterSize:i,strides:a,pad:l,dimRoundingMode:c}=s;rt([o,r],"avgPool3DGrad");const u=Zn(r.shape,i,a,1,l,c),h=u.strideDepth,d=u.strideHeight,p=u.strideWidth,f=u.filterDepth,m=u.filterHeight,g=u.filterWidth,x=u.dilationDepth,b=u.dilationHeight,w=u.dilationWidth,y=u.effectiveFilterDepth,C=u.effectiveFilterHeight,I=u.effectiveFilterWidth,k=y-1-u.padInfo.front,v=I-1-u.padInfo.left,N=C-1-u.padInfo.top,T=wt(r.shape,"float32"),O=1/(f*m*g),P=e.bufferSync(o);for(let z=0;z<u.batchSize;++z)for(let B=0;B<u.inChannels;++B)for(let M=0;M<u.inDepth;++M)for(let G=0;G<u.inHeight;++G)for(let H=0;H<u.inWidth;++H){const U=M-k,K=G-N,q=H-v;let X=0;for(let Z=0;Z<y;Z+=x){const J=(U+Z)/h;if(!(J<0||J>=u.outDepth||Math.floor(J)!==J))for(let et=0;et<C;et+=b){const Q=(K+et)/d;if(!(Q<0||Q>=u.outHeight||Math.floor(Q)!==Q))for(let ot=0;ot<I;ot+=w){const at=(q+ot)/p;if(at<0||at>=u.outWidth||Math.floor(at)!==at)continue;const dt=P.get(z,J,Q,at,B);X+=dt}}}T.set(X*O,z,M,G,H,B)}return e.makeTensorInfo(T.shape,T.dtype,T.values)}const tD={kernelName:ku,backendName:"cpu",kernelFunc:QR};function eD(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,i=r;rt([o,r],"avgPoolGrad");const{filterSize:a,strides:l,pad:c}=s,u=ln(i.shape,a,l,1,c),h=u.strideHeight,d=u.strideWidth,p=u.filterHeight,f=u.filterWidth,m=u.dilationHeight,g=u.dilationWidth,x=u.effectiveFilterHeight,b=u.effectiveFilterWidth,w=b-1-u.padInfo.left,y=x-1-u.padInfo.top,C=wt(i.shape,"float32"),I=1/(p*f),k=e.data.get(o.dataId).values,v=wt(o.shape,"float32",k);for(let N=0;N<u.batchSize;++N)for(let T=0;T<u.inChannels;++T)for(let O=0;O<u.inHeight;++O)for(let P=0;P<u.inWidth;++P){const z=O-y,B=P-w;let M=0;for(let G=0;G<x;G+=m){const H=(z+G)/h;if(!(H<0||H>=u.outHeight||Math.floor(H)!==H))for(let U=0;U<b;U+=g){const K=(B+U)/d;if(K<0||K>=u.outWidth||Math.floor(K)!==K)continue;const q=v.get(N,H,K,T);M+=q}}C.set(M*I,N,O,P,T)}return e.makeTensorInfo(C.shape,C.dtype,C.values)}const nD={kernelName:Iu,backendName:"cpu",kernelFunc:eD};function sD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,scale:r,offset:i,mean:a,variance:l}=t;$(a.shape.length===l.shape.length,()=>"Batch normalization gradient requires mean and variance to have equal ranks."),$(i==null||a.shape.length===i.shape.length,()=>"Batch normalization gradient requires mean and offset to have equal ranks."),$(r==null||a.shape.length===r.shape.length,()=>"Batch normalization gradient requires mean and scale to have equal ranks."),rt([o,a,l,r,i],"batchNorm");let{varianceEpsilon:c}=s;c==null&&(c=.001);const u=e.data.get(o.dataId).values,h=e.data.get(a.dataId).values,d=e.data.get(l.dataId).values,p=r?e.data.get(r.dataId).values:new Float32Array([1]),f=i?e.data.get(i.dataId).values:new Float32Array([0]),m=new Float32Array(u.length),g=f.length,x=p.length,b=d.length,w=h.length;let y=0,C=0,I=0,k=0;for(let v=0;v<u.length;++v)m[v]=f[y++]+(u[v]-h[C++])*p[I++]/Math.sqrt(d[k++]+c),y>=g&&(y=0),C>=w&&(C=0),I>=x&&(I=0),k>=b&&(k=0);return e.makeTensorInfo(o.shape,o.dtype,m)}const oD={kernelName:Za,backendName:"cpu",kernelFunc:sD};function rD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockShape:r,crops:i}=s;rt([o],"batchToSpaceND");const a=r.reduce((x,b)=>x*b),l=Si(o.shape,r,a),c=Ni(l.length,r.length),u=Ti(o.shape,r,a),h=Yh(i,r.length),d=Jh(u,i,r.length),p=Bt({inputs:{x:o},backend:e,attrs:{shape:l}}),f=Pe({inputs:{x:p},backend:e,attrs:{perm:c}}),m=Bt({inputs:{x:f},backend:e,attrs:{shape:u}}),g=eo({inputs:{x:m},backend:e,attrs:{begin:h,size:d}});return e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),e.disposeIntermediateTensorInfo(m),g}const iD={kernelName:Va,backendName:"cpu",kernelFunc:rD};function aD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,weights:r}=t,{size:i}=s,a=e.data.get(o.dataId).values,l=e.data.get(r.dataId).values,c=_d(a,l,r.dtype,r.shape,i);return e.makeTensorInfo([i],r.dtype,c)}const lD={kernelName:vu,backendName:"cpu",kernelFunc:aD};function cD(n){const{inputs:t,backend:e}=n,{s0:s,s1:o}=t,r=e.data.get(s.dataId).values,i=e.data.get(o.dataId).values,a=mt(Array.from(r),Array.from(i));return e.makeTensorInfo([a.length],"int32",Int32Array.from(a))}const uD={kernelName:Vf,backendName:"cpu",kernelFunc:cD};const hD=At(_r,(n,t)=>{const e=t;return n>e.clipValueMax?e.clipValueMax:n<e.clipValueMin?e.clipValueMin:n}),dD={kernelName:_r,backendName:"cpu",kernelFunc:hD};const pD=n=>{const{x:t}=n.inputs,e=n.backend,s=new Float32Array(W(t.shape)),o=e.data.get(t.dataId),r=o.complexTensorInfos.real,i=o.complexTensorInfos.imag,a=e.data.get(r.dataId).values,l=e.data.get(i.dataId).values;for(let c=0;c<a.length;c++){const u=a[c],h=l[c];s[c]=Math.hypot(u,h)}return e.makeOutput(s,t.shape,"float32")},fD={kernelName:Wa,backendName:"cpu",kernelFunc:pD};function Ao(n){const{inputs:t,backend:e}=n,{input:s}=t,o=e.data.get(s.dataId).complexTensorInfos.imag,r=e.data.get(o.dataId).values;return e.makeTensorInfo(o.shape,o.dtype,r)}const mD={kernelName:Uu,backendName:"cpu",kernelFunc:Ao};function Fo(n){const{inputs:t,backend:e,attrs:s}=n,{axis:o}=s,r=Ct(o,t[0].shape)[0],i=t.map(m=>m.shape);jh(i,r);let a=An(t.map(m=>m.shape),r);if(W(a)===0)return e.makeTensorInfo(a,t[0].dtype,[]);const l=t.filter(m=>W(m.shape)>0);if(l.length===1)return Bn({inputs:{x:l[0]},backend:e});if(l[0].dtype==="complex64"){const m=l.map(y=>to({inputs:{input:y},backend:e})),g=l.map(y=>Ao({inputs:{input:y},backend:e})),x=Fo({inputs:m,backend:e,attrs:{axis:r}}),b=Fo({inputs:g,backend:e,attrs:{axis:r}}),w=Ve({inputs:{real:x,imag:b},backend:e});return m.forEach(y=>e.disposeIntermediateTensorInfo(y)),g.forEach(y=>e.disposeIntermediateTensorInfo(y)),e.disposeIntermediateTensorInfo(x),e.disposeIntermediateTensorInfo(b),w}const c=l.map(m=>{const x=[-1,W(m.shape.slice(r))];return Bt({inputs:{x:m},backend:e,attrs:{shape:x}})}),u=c.map(m=>({vals:e.data.get(m.dataId).values,shape:m.shape}));a=An(c.map(m=>m.shape),1);const h=c[0].shape[0]===1,d=xy(u,a,t[0].dtype,h),p=An(l.map(m=>m.shape),r),f=e.makeTensorInfo(p,t[0].dtype,d);return c.forEach(m=>e.disposeIntermediateTensorInfo(m)),f}const gD={kernelName:Ua,backendName:"cpu",kernelFunc:Fo};function p0(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dataFormat:l,dilations:c,dimRoundingMode:u}=s;rt([o,r],"conv2d");const h=Qn(l),d=be(o.shape,r.shape,i,c,a,u,!1,h),p=d.filterHeight,f=d.filterWidth,m=d.dilationHeight,g=d.dilationWidth,x=d.padInfo.left,b=d.padInfo.top,w=d.dataFormat==="channelsLast",y=new xe(d.outShape,o.dtype),C=lt(o.shape),I=lt(r.shape),k=C[0],v=w?C[1]:C[2],N=w?C[2]:1,T=w?1:C[1],O=y.strides[0],P=w?y.strides[1]:y.strides[2],z=w?y.strides[2]:1,B=w?1:y.strides[1],M=e.data.get(o.dataId).values,G=e.data.get(r.dataId).values,H=y.values;for(let U=0;U<d.batchSize;++U){const K=U*k,q=U*O;for(let X=0;X<d.outHeight;++X){const Z=q+X*P,J=X*d.strideHeight-b;for(let et=0;et<p;++et){const Q=J+et*m;if(Q<0||Q>=d.inHeight)continue;const ot=et*I[0],at=K+Q*v;for(let dt=0;dt<d.outWidth;++dt){const ht=Z+dt*z,gt=dt*d.strideWidth-x;for(let bt=0;bt<f;++bt){const Rt=gt+bt*g;if(Rt<0||Rt>=d.inWidth)continue;const Lt=ot+bt*I[1],qt=at+Rt*N;let Mt=Lt;for(let Ft=0;Ft<d.inChannels;++Ft){const Ht=M[qt+Ft*T];for(let Wt=0;Wt<d.outChannels;++Wt)H[ht+Wt*B]+=Ht*G[Mt+Wt];Mt+=d.outChannels}}}}}}return e.makeTensorInfo(y.shape,y.dtype,H)}const xD={kernelName:Ga,backendName:"cpu",kernelFunc:p0};function bD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,pad:a,dataFormat:l,dimRoundingMode:c,filterShape:u}=s;rt([o,r],"conv2dBackpropFilter");const h=Qn(l),d=be(o.shape,u,i,1,a,c,!1,h),{strideHeight:p,strideWidth:f,filterHeight:m,filterWidth:g}=d,x=d.dataFormat==="channelsLast",b=new xe(d.filterShape,"float32"),w=d.padInfo.left,y=d.padInfo.top,C=e.data.get(o.dataId).values,I=e.data.get(r.dataId).values,k=new xe(o.shape,o.dtype,C),v=new xe(r.shape,r.dtype,I);for(let N=0;N<m;++N){const T=Math.max(0,Math.ceil((y-N)/p)),O=Math.min(d.outHeight,(d.inHeight+y-N)/p);for(let P=0;P<g;++P){const z=Math.max(0,Math.ceil((w-P)/f)),B=Math.min(d.outWidth,(d.inWidth+w-P)/f);for(let M=0;M<d.inChannels;++M)for(let G=0;G<d.outChannels;++G){let H=0;for(let U=0;U<d.batchSize;++U)for(let K=T;K<O;++K){const q=N+K*p-y;for(let X=z;X<B;++X){const Z=P+X*f-w;x?H+=k.get(U,q,Z,M)*v.get(U,K,X,G):H+=k.get(U,M,q,Z)*v.get(U,G,K,X)}}b.set(H,N,P,M,G)}}}return e.makeTensorInfo(b.shape,b.dtype,b.values)}const yD={kernelName:Tu,backendName:"cpu",kernelFunc:bD};function wD(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{inputShape:i,strides:a,pad:l,dataFormat:c,dimRoundingMode:u}=s;rt([o,r],"conv2dBackpropInput");const h=lt(r.shape),d=lt(o.shape);let p=Qn(c);const f=be(i,r.shape,a,1,l,u,!1,p),m=new xe(f.inShape,"float32"),g=m.values,x=e.data.get(o.dataId).values,b=e.data.get(r.dataId).values,[w,y,C]=h,{batchSize:I,filterHeight:k,filterWidth:v,inChannels:N,inHeight:T,inWidth:O,outChannels:P,outHeight:z,outWidth:B,strideHeight:M,strideWidth:G}=f;p=f.dataFormat;const H=k-1-f.padInfo.top,U=v-1-f.padInfo.left,K=p==="channelsLast",q=m.strides[0],X=K?m.strides[1]:m.strides[2],Z=K?m.strides[2]:1,J=K?1:m.strides[1],et=d[0],Q=K?d[1]:d[2],ot=K?d[2]:1,at=K?1:d[1];for(let dt=0;dt<I;++dt)for(let ht=0;ht<N;++ht)for(let gt=0;gt<T;++gt){const bt=gt-H,Rt=Math.max(0,Math.ceil(bt/M)),Lt=Math.min(z,(k+bt)/M);for(let qt=0;qt<O;++qt){const Mt=qt-U,Ft=Math.max(0,Math.ceil(Mt/G)),Ht=Math.min(B,(v+Mt)/G);let Wt=0;for(let me=Rt;me<Lt;++me){const es=me*M-bt;for(let Ke=Ft;Ke<Ht;++Ke){const Rs=Ke*G-Mt,hn=et*dt+Q*me+ot*Ke,Un=w*(k-1-es)+y*(v-1-Rs)+C*ht;for(let ns=0;ns<P;++ns){const ss=x[hn+at*ns],os=b[Un+ns];Wt+=ss*os}}}const Wn=q*dt+X*gt+Z*qt+J*ht;g[Wn]=Wt}}return e.makeTensorInfo(m.shape,m.dtype,m.values)}const CD={kernelName:Ha,backendName:"cpu",kernelFunc:wD};function $D(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dilations:l}=s;rt([o,r],"conv3d");const c=$s(o.shape,r.shape,i,l,a),{filterDepth:u,filterHeight:h,filterWidth:d,dilationDepth:p,dilationHeight:f,dilationWidth:m,padInfo:g}=c,x=g.front,b=g.left,w=g.top,y=new xe(c.outShape,o.dtype),C=e.data.get(o.dataId).values,I=e.data.get(r.dataId).values,k=y.values,v=lt(o.shape),N=lt(r.shape);for(let T=0;T<c.batchSize;++T){const O=T*v[0],P=T*y.strides[0];for(let z=0;z<c.outDepth;++z){const B=P+z*y.strides[1],M=z*c.strideDepth-x;for(let G=0;G<u;++G){const H=M+G*p;if(H<0||H>=c.inDepth)continue;const U=G*N[0],K=O+H*v[1];for(let q=0;q<c.outHeight;++q){const X=B+q*y.strides[2],Z=q*c.strideHeight-w;for(let J=0;J<h;++J){const et=Z+J*f;if(et<0||et>=c.inHeight)continue;const Q=U+J*N[1],ot=K+et*v[2];for(let at=0;at<c.outWidth;++at){const dt=X+at*c.outChannels,ht=at*c.strideWidth-b;for(let gt=0;gt<d;++gt){const bt=ht+gt*m;if(bt<0||bt>=c.inWidth)continue;const Rt=Q+gt*N[2],Lt=ot+bt*c.inChannels;let qt=Rt;for(let Mt=0;Mt<c.inChannels;++Mt){const Ft=C[Lt+Mt];for(let Ht=0;Ht<c.outChannels;++Ht)k[dt+Ht]+=Ft*I[qt+Ht];qt+=c.outChannels}}}}}}}}return e.makeTensorInfo(y.shape,y.dtype,y.values)}const ID={kernelName:Ka,backendName:"cpu",kernelFunc:$D};function kD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,pad:a,filterShape:l}=s;rt([o,r],"conv3dBackpropFilterV2");const c=lt(o.shape),u=lt(r.shape),h=$s(o.shape,l,i,1,a),d=h.strideDepth,p=h.strideHeight,f=h.strideWidth,m=h.filterDepth,g=h.filterHeight,x=h.filterWidth,b=new xe(h.filterShape,"float32"),w=b.values,[y,C,I,k]=b.strides,v=e.data.get(r.dataId).values,[N,T,O,P]=u,z=e.data.get(o.dataId).values,[B,M,G,H]=c,U=h.padInfo.front,K=h.padInfo.left,q=h.padInfo.top;for(let X=0;X<m;++X){const Z=Math.max(0,Math.ceil((U-X)/d)),J=Math.min(h.outDepth,(h.inDepth+U-X)/d),et=X*y;for(let Q=0;Q<g;++Q){const ot=Math.max(0,Math.ceil((q-Q)/p)),at=Math.min(h.outHeight,(h.inHeight+q-Q)/p),dt=Q*C+et;for(let ht=0;ht<x;++ht){const gt=Math.max(0,Math.ceil((K-ht)/f)),bt=Math.min(h.outWidth,(h.inWidth+K-ht)/f),Rt=ht*I+dt;for(let Lt=0;Lt<h.inChannels;++Lt){const qt=Lt*k+Rt;for(let Mt=0;Mt<h.outChannels;++Mt){let Ft=0;for(let Ht=0;Ht<h.batchSize;++Ht){const Wt=Ht*B,Wn=Ht*N;for(let me=Z;me<J;++me){const Ke=(X+me*d-U)*M+Wt,Rs=me*T+Wn;for(let hn=ot;hn<at;++hn){const ns=(Q+hn*p-q)*G+Ke,ss=hn*O+Rs;for(let os=gt;os<bt;++os){const hc=(ht+os*f-K)*H+ns,dc=os*P+ss;Ft+=z[hc+Lt]*v[dc+Mt]}}}}w[qt+Mt]=Ft}}}}}return e.makeTensorInfo(b.shape,b.dtype,b.values)}const vD={kernelName:Eu,backendName:"cpu",kernelFunc:kD};function SD(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{pad:i,strides:a,inputShape:l}=s;rt([o],"conv3dBackpropInputV2");const c=lt(o.shape),u=lt(r.shape),h=$s(l,r.shape,a,1,i),d=new xe(h.inShape,"float32"),p=d.values,[f,m,g,x]=d.strides,b=e.data.get(o.dataId).values,[w,y,C,I]=c,k=e.data.get(r.dataId).values,[v,N,T,O]=u,{batchSize:P,filterDepth:z,filterHeight:B,filterWidth:M,inChannels:G,inDepth:H,inHeight:U,inWidth:K,outChannels:q,outDepth:X,outHeight:Z,outWidth:J,strideDepth:et,strideHeight:Q,strideWidth:ot}=h,at=z-1-h.padInfo.front,dt=B-1-h.padInfo.top,ht=M-1-h.padInfo.left;for(let gt=0;gt<P;++gt)for(let bt=0;bt<G;++bt)for(let Rt=0;Rt<H;++Rt){const Lt=Rt-at,qt=Math.max(0,Math.ceil(Lt/et)),Mt=Math.min(X,(z+Lt)/et);for(let Ft=0;Ft<U;++Ft){const Ht=Ft-dt,Wt=Math.max(0,Math.ceil(Ht/Q)),Wn=Math.min(Z,(B+Ht)/Q);for(let me=0;me<K;++me){const es=me-ht,Ke=Math.max(0,Math.ceil(es/ot)),Rs=Math.min(J,(M+es)/ot);let hn=0;for(let Un=qt;Un<Mt;++Un){const ns=Un*et-Lt;for(let ss=Wt;ss<Wn;++ss){const os=ss*Q-Ht;for(let Zo=Ke;Zo<Rs;++Zo){const hc=Zo*ot-es,dc=w*gt+y*Un+C*ss+I*Zo,d1=v*(z-1-ns)+N*(B-1-os)+T*(M-1-hc)+O*bt;for(let Ui=0;Ui<q;++Ui){const p1=b[dc+Ui],f1=k[d1+Ui];hn+=p1*f1}}}}p[f*gt+m*Rt+g*Ft+x*me+bt]=hn}}}return e.makeTensorInfo(d.shape,d.dtype,d.values)}const ND={kernelName:Ru,backendName:"cpu",kernelFunc:SD};const TD=At(Lr,n=>Math.cos(n)),ED={kernelName:Lr,backendName:"cpu",kernelFunc:TD};const RD=At(Mr,n=>Math.cosh(n)),DD={kernelName:Mr,backendName:"cpu",kernelFunc:RD};function AD(n){const{inputs:t,backend:e,attrs:s}=n,{image:o,boxes:r,boxInd:i}=t,{cropSize:a,method:l,extrapolationValue:c}=s,[u,h,d,p]=o.shape,f=r.shape[0],[m,g]=a,x=wt([f,m,g,p],"float32"),b=e.data.get(r.dataId).values,w=e.data.get(i.dataId).values,y=e.data.get(o.dataId).values,C=lt(o.shape),I=lt(x.shape);for(let k=0;k<f;k++){const v=k*4,N=b[v],T=b[v+1],O=b[v+2],P=b[v+3],z=w[k];if(z>=u)continue;const B=m>1?(O-N)*(h-1)/(m-1):0,M=g>1?(P-T)*(d-1)/(g-1):0;for(let G=0;G<m;G++){const H=m>1?N*(h-1)+G*B:.5*(N+O)*(h-1);if(H<0||H>h-1){for(let U=0;U<g;U++)for(let K=0;K<p;K++){const q=K+U*I[2]+G*I[1]+k*I[0];x.values[q]=c}continue}if(l==="bilinear"){const U=Math.floor(H),K=Math.ceil(H),q=H-U;for(let X=0;X<g;X++){const Z=g>1?T*(d-1)+X*M:.5*(T+P)*(d-1);if(Z<0||Z>d-1){for(let ot=0;ot<p;ot++){const at=ot+X*I[2]+G*I[1]+k*I[0];x.values[at]=c}continue}const J=Math.floor(Z),et=Math.ceil(Z),Q=Z-J;for(let ot=0;ot<p;ot++){let at=ot+J*C[2]+U*C[1]+z*C[0];const dt=y[at];at=ot+et*C[2]+U*C[1]+z*C[0];const ht=y[at];at=ot+J*C[2]+K*C[1]+z*C[0];const gt=y[at];at=ot+et*C[2]+K*C[1]+z*C[0];const bt=y[at],Rt=dt+(ht-dt)*Q,Lt=gt+(bt-gt)*Q;at=ot+X*I[2]+G*I[1]+k*I[0],x.values[at]=Rt+(Lt-Rt)*q}}}else for(let U=0;U<g;++U){const K=g>1?T*(d-1)+U*M:.5*(T+P)*(d-1);if(K<0||K>d-1){for(let Z=0;Z<p;Z++){const J=Z+U*I[2]+G*I[1]+k*I[0];x.values[J]=c}continue}const q=Math.round(K),X=Math.round(H);for(let Z=0;Z<p;Z++){const J=Z+q*C[2]+X*C[1]+z*C[0],et=Z+U*I[2]+G*I[1]+k*I[0];x.values[et]=y[J]}}}}return e.makeTensorInfo(x.shape,x.dtype,x.values)}const FD={kernelName:Au,backendName:"cpu",kernelFunc:AD};function OD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,exclusive:i,reverse:a}=s;rt(o,"cumprod");const l=jt([r],o.shape.length);let c=o;l!=null&&(c=Pe({inputs:{x:o},backend:e,attrs:{perm:l}}));const u=Zt(1,o.shape.length)[0];if(u!==c.shape.length-1)throw new Error(`backend.cumprod in CPU expects an inner-most axis=${c.shape.length-1} but got axis=${u}`);const h=Ue(c.dtype,"int32"),d=xu(W(c.shape),h),p=e.data.get(c.dataId).values,f=c.shape[c.shape.length-1],m=a?(x,b)=>x+f-b-1:(x,b)=>x+b;for(let x=0;x<p.length;x+=f)for(let b=0;b<f;b++){const w=m(x,b);if(b===0)d[w]=i?1:p[w];else{const y=m(x,b-1);d[w]=i?p[y]*d[y]:p[w]*d[y]}}const g=e.makeTensorInfo(c.shape,h,d);if(l!=null){const x=Is(l),b=Pe({inputs:{x:g},backend:e,attrs:{perm:x}});return e.disposeIntermediateTensorInfo(g),e.disposeIntermediateTensorInfo(c),b}return g}const _D={kernelName:Du,backendName:"cpu",kernelFunc:OD};function LD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,exclusive:i,reverse:a}=s;rt(o,"cumsum");const l=jt([r],o.shape.length);let c=o;l!=null&&(c=Pe({inputs:{x:o},backend:e,attrs:{perm:l}}));const u=Zt(1,o.shape.length)[0];if(u!==c.shape.length-1)throw new Error(`backend.cumsum in CPU expects an inner-most axis=${c.shape.length-1} but got axis=${u}`);const h=Ue(c.dtype,"int32"),d=$e(W(c.shape),h),p=e.data.get(c.dataId).values,f=c.shape[c.shape.length-1],m=a?(x,b)=>x+f-b-1:(x,b)=>x+b;for(let x=0;x<p.length;x+=f)for(let b=0;b<f;b++){const w=m(x,b);if(b===0)d[w]=i?0:p[w];else{const y=m(x,b-1);d[w]=i?p[y]+d[y]:p[w]+d[y]}}const g=e.makeTensorInfo(c.shape,h,d);if(l!=null){const x=Is(l),b=Pe({inputs:{x:g},backend:e,attrs:{perm:x}});return e.disposeIntermediateTensorInfo(g),e.disposeIntermediateTensorInfo(c),b}return g}const MD={kernelName:ja,backendName:"cpu",kernelFunc:LD};function PD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,weights:r}=t,{size:i,binaryOutput:a}=s;if(o.shape.length===1){const l=e.data.get(o.dataId).values,c=e.data.get(r.dataId).values,u=_d(l,c,r.dtype,r.shape,i);return e.makeTensorInfo([i],r.dtype,u)}else if(o.shape.length===2){const l=e.bufferSync(o),c=e.bufferSync(r),u=fy(l,c,i,a);return e.makeTensorInfo(u.shape,r.dtype,u.values)}throw new Error(`Error in denseBincount: input must be at most rank 2, but got rank${o.shape.length}.`)}const zD={kernelName:Fu,backendName:"cpu",kernelFunc:PD};function BD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockSize:r,dataFormat:i}=s;$(i==="NHWC",()=>`Only NHWC dataFormat supported on CPU for depthToSpace. Got ${i}`);const a=o.shape[0],l=o.shape[1],c=o.shape[2],u=o.shape[3],h=l*r,d=c*r,p=u/(r*r),f=e.data.get(o.dataId).values,m=new Float32Array(a*h*d*p);let g=0;for(let x=0;x<a;++x)for(let b=0;b<h;++b){const w=Math.floor(b/r),y=b%r;for(let C=0;C<d;++C){const I=Math.floor(C/r),k=C%r,v=(y*r+k)*p;for(let N=0;N<p;++N){const O=N+v+u*(I+c*(w+l*x));m[g++]=f[O]}}}return e.makeTensorInfo([a,h,d,p],o.dtype,m)}const VD={kernelName:Ou,backendName:"cpu",kernelFunc:BD};function f0(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dilations:l,dimRoundingMode:c}=s;rt([o,r],"depthwiseConv2DNative");const u=lt(o.shape),h=lt(r.shape);let d=l;d==null&&(d=[1,1]),$(ke(i,d),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${i} and dilations '${d}'`);const p=be(o.shape,r.shape,i,d,a,c,!0),{filterHeight:f,filterWidth:m,dilationHeight:g,dilationWidth:x,padInfo:b}=p,w=b.left,y=b.top,C=p.outChannels/p.inChannels,I=new xe(p.outShape,o.dtype),k=e.data.get(o.dataId).values,v=e.data.get(r.dataId).values,N=I.values;for(let T=0;T<p.batchSize;++T){const O=T*u[0],P=T*I.strides[0];for(let z=0;z<p.outHeight;++z){const B=P+z*I.strides[1],M=z*p.strideHeight-y;for(let G=0;G<f;++G){const H=M+G*g;if(H<0||H>=p.inHeight)continue;const U=G*h[0],K=O+H*u[1];for(let q=0;q<p.outWidth;++q){const X=B+q*I.strides[2],Z=q*p.strideWidth-w;for(let J=0;J<m;++J){const et=Z+J*x;if(et<0||et>=p.inWidth)continue;const Q=U+J*h[1],ot=K+et*p.inChannels;let at=X,dt=Q;for(let ht=0;ht<p.inChannels;++ht){const gt=k[ot+ht];for(let bt=0;bt<C;++bt)N[at+bt]+=gt*v[dt+bt];at+=C,dt+=C}}}}}}return e.makeTensorInfo(I.shape,I.dtype,I.values)}const WD={kernelName:qa,backendName:"cpu",kernelFunc:f0};function UD(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,dilations:a,pad:l,dimRoundingMode:c,filterShape:u}=s;rt([o,r],"depthwiseConv2dNativeBackpropFilter");const h=be(o.shape,u,i,a,l,c,!0),{strideHeight:d,strideWidth:p,filterHeight:f,filterWidth:m}=h,g=new xe(h.filterShape,"float32"),x=h.padInfo.left,b=h.padInfo.top,w=h.outChannels/h.inChannels,y=e.data.get(o.dataId).values,C=new xe(o.shape,o.dtype,y),I=e.data.get(r.dataId).values,k=new xe(r.shape,r.dtype,I);for(let v=0;v<f;++v){const N=Math.max(0,Math.ceil((b-v)/d)),T=Math.min(h.outHeight,(h.inHeight+b-v)/d);for(let O=0;O<m;++O){const P=Math.max(0,Math.ceil((x-O)/p)),z=Math.min(h.outWidth,(h.inWidth+x-O)/p);for(let B=0;B<h.outChannels;++B){const M=Math.trunc(B/w),G=B%w;let H=0;for(let U=0;U<h.batchSize;++U)for(let K=N;K<T;++K){const q=v+K*d-b;for(let X=P;X<z;++X){const Z=O+X*p-x;H+=C.get(U,q,Z,M)*k.get(U,K,X,B)}}g.set(H,v,O,M,G)}}}return e.makeTensorInfo(g.shape,g.dtype,g.values)}const GD={kernelName:_u,backendName:"cpu",kernelFunc:UD};function HD(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{strides:i,dilations:a,pad:l,dimRoundingMode:c,inputShape:u}=s;rt([o,r],"depthwiseConv2DNativeBackpropInput");const h=lt(o.shape),d=lt(r.shape),p=be(u,r.shape,i,a,l,c,!0),f=new xe(p.inShape,"float32"),m=f.values,[g,x,b]=f.strides,w=e.data.get(o.dataId).values,[y,C,I]=h,k=e.data.get(r.dataId).values,[v,N,T]=d,{batchSize:O,filterHeight:P,filterWidth:z,inChannels:B,inHeight:M,inWidth:G,outChannels:H,outHeight:U,outWidth:K,strideHeight:q,strideWidth:X}=p,Z=P-1-p.padInfo.top,J=z-1-p.padInfo.left,et=H/B;for(let Q=0;Q<O;++Q)for(let ot=0;ot<B;++ot)for(let at=0;at<M;++at){const dt=at-Z,ht=Math.max(0,Math.ceil(dt/q)),gt=Math.min(U,(P+dt)/q);for(let bt=0;bt<G;++bt){const Rt=bt-J,Lt=Math.max(0,Math.ceil(Rt/X)),qt=Math.min(K,(z+Rt)/X);let Mt=0;for(let Ft=ht;Ft<gt;++Ft){const Ht=Ft*q-dt;for(let Wt=Lt;Wt<qt;++Wt){const Wn=Wt*X-Rt,me=y*Q+C*Ft+I*Wt,es=v*(P-1-Ht)+N*(z-1-Wn)+T*ot;for(let Ke=0;Ke<et;++Ke){const Rs=ot*et+Ke,hn=w[me+Rs],Un=k[es+Ke];Mt+=hn*Un}}}m[g*Q+x*at+b*bt+ot]=Mt}}return e.makeTensorInfo(f.shape,f.dtype,f.values)}const KD={kernelName:Lu,backendName:"cpu",kernelFunc:HD};function jD(n){const{inputs:t,backend:e}=n,{x:s}=t,o=W(s.shape),r=e.data.get(s.dataId).values,i=wt([o,o],s.dtype),a=i.values;for(let c=0;c<r.length;c++)a[c*o+c]=r[c];const l=[...s.shape,...s.shape];return e.makeTensorInfo(l,i.dtype,i.values)}const qD={kernelName:Wf,backendName:"cpu",kernelFunc:jD};const XD={kernelName:Xa,backendName:"cpu",kernelFunc:({inputs:n,backend:t,attrs:e})=>{const{x:s,filter:o}=n,{strides:r,pad:i,dilations:a}=e,l=t,c=l.data.get(s.dataId).values,u=s.shape.length,h=l.data.get(o.dataId).values,d=o.shape.length,{batchSize:p,inHeight:f,inWidth:m,inChannels:g,outHeight:x,outWidth:b,padInfo:w,strideHeight:y,strideWidth:C,filterHeight:I,filterWidth:k,dilationHeight:v,dilationWidth:N,outShape:T}=Ci(s.shape,o.shape,r,i,"NHWC",a),O=W(T),P=T.length,z=Xt(s.dtype,O);for(let M=0;M<p;++M)for(let G=0;G<x;++G){const H=G*y-w.top;for(let U=0;U<b;++U){const K=U*C-w.left;for(let q=0;q<g;++q){let X=Number.MIN_SAFE_INTEGER;for(let J=0;J<I;++J){const et=H+J*v;if(et>=0&&et<f)for(let Q=0;Q<k;++Q){const ot=K+Q*N;if(ot>=0&&ot<m){const at=Rn([M,et,ot,q],u,lt(s.shape)),dt=Rn([J,Q,q],d,lt(o.shape)),ht=c[at]+h[dt];ht>X&&(X=ht)}}}const Z=Rn([M,G,U,q],P,lt(T));z[Z]=X}}}return{dataId:l.write(so(z,s.dtype),T,s.dtype),shape:T,dtype:s.dtype}}};const YD={kernelName:Lc,backendName:"cpu",kernelFunc:({inputs:n,backend:t,attrs:e})=>{const{x:s,filter:o,dy:r}=n,{strides:i,pad:a,dilations:l}=e,c=t,u=xn(s.shape,c.data.get(s.dataId).values),h=xn(o.shape,c.data.get(o.dataId).values),{batchSize:d,inHeight:p,inWidth:f,inChannels:m,outHeight:g,outWidth:x,padInfo:b,strideHeight:w,strideWidth:y,filterHeight:C,filterWidth:I,dilationHeight:k,dilationWidth:v,outShape:N}=Ci(s.shape,o.shape,i,a,"NHWC",l);$(r.rank===N.length,()=>`Error in ${Lc}, dy must have the same rank as output ${N.length}, but got ${r.rank}`);const T=xn(N,c.data.get(r.dataId).values),O=Pf(o.shape,o.dtype);for(let z=0;z<d;++z)for(let B=0;B<g;++B){const M=B*w-b.top;for(let G=0;G<x;++G){const H=G*y-b.left;for(let U=0;U<m;++U){let K=Number.MIN_SAFE_INTEGER,q=0,X=0;for(let Z=0;Z<C;++Z){const J=M+Z*k;if(J>=0&&J<p)for(let et=0;et<I;++et){const Q=H+et*v;if(Q>=0&&Q<f){const ot=u[z][J][Q][U]+h[Z][et][U];ot>K&&(K=ot,q=Z,X=et)}}}O[q][X][U]+=T[z][B][G][U]}}}return{dataId:c.write(so(O,s.dtype),o.shape,o.dtype),shape:o.shape,dtype:o.dtype}}};const JD={kernelName:_c,backendName:"cpu",kernelFunc:({inputs:n,backend:t,attrs:e})=>{const{x:s,filter:o,dy:r}=n,{strides:i,pad:a,dilations:l}=e,c=t,u=xn(s.shape,c.data.get(s.dataId).values),h=xn(o.shape,c.data.get(o.dataId).values),{batchSize:d,inHeight:p,inWidth:f,inChannels:m,outHeight:g,outWidth:x,padInfo:b,strideHeight:w,strideWidth:y,filterHeight:C,filterWidth:I,dilationHeight:k,dilationWidth:v,outShape:N}=Ci(s.shape,o.shape,i,a,"NHWC",l);$(r.rank===N.length,()=>`Error in ${_c}, dy must have the same rank as output ${N.length}, but got ${r.rank}`);const T=xn(N,c.data.get(r.dataId).values),O=Pf(s.shape,s.dtype);for(let z=0;z<d;++z)for(let B=0;B<g;++B){const M=B*w-b.top;for(let G=0;G<x;++G){const H=G*y-b.left;for(let U=0;U<m;++U){let K=Number.MIN_SAFE_INTEGER,q=M<0?0:M,X=H<0?0:H;for(let Z=0;Z<C;++Z){const J=M+Z*k;if(J>=0&&J<p)for(let et=0;et<I;++et){const Q=H+et*v;if(Q>=0&&Q<f){const ot=u[z][J][Q][U]+h[Z][et][U];ot>K&&(K=ot,q=J,X=Q)}}}O[z][q][X][U]+=T[z][B][G][U]}}}return{dataId:c.write(so(O,s.dtype),s.shape,s.dtype),shape:s.shape,dtype:s.dtype}}};function ZD(n){const{inputs:t,backend:e,attrs:s}=n,{image:o}=t,{canvas:r,options:i}=s,{contextOptions:a,imageOptions:l}=i||{},c=l?.alpha||1,u=a?.contextType||"2d";if(u!=="2d")throw new Error(`Context type ${a.contextType} is not supported by the CPU backend.`);const h=r.getContext(u,a?.contextAttributes||{});if(h==null)throw new Error(`Could not get the context with ${u} type.`);const[d,p]=o.shape.slice(0,2),f=o.shape.length===2?1:o.shape[2],m=e.data.get(o.dataId).values,g=o.dtype==="float32"?255:1,x=new Uint8ClampedArray(p*d*4);for(let w=0;w<d*p;++w){const y=[0,0,0,255*c];for(let I=0;I<f;I++){const k=m[w*f+I];if(o.dtype==="float32"){if(k<0||k>1)throw new Error(`Tensor values for a float32 Tensor must be in the range [0 - 1] but encountered ${k}.`)}else if(o.dtype==="int32"&&(k<0||k>255))throw new Error(`Tensor values for a int32 Tensor must be in the range [0 - 255] but encountered ${k}.`);f===1?(y[0]=k*g,y[1]=k*g,y[2]=k*g):y[I]=k*g}const C=w*4;x[C+0]=Math.round(y[0]),x[C+1]=Math.round(y[1]),x[C+2]=Math.round(y[2]),x[C+3]=Math.round(y[3])}r.width=p,r.height=d;const b=new ImageData(x,p,d);return h.putImageData(b,0,0),o}const QD={kernelName:F1,backendName:"cpu",kernelFunc:ZD};function Mi(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;rt(o,"sum");let a;o.dtype==="bool"?a=bs({inputs:{x:o},backend:e,attrs:{dtype:"int32"}}):a=Bn({inputs:{x:o},backend:e});const l=a.shape.length,c=Ct(r,a.shape),u=jt(c,l);let h=c,d=a;u!=null&&(d=Pe({inputs:{x:a},backend:e,attrs:{perm:u}}),h=Zt(h.length,l)),ye("sum",h,d.shape.length);const[p,f]=fe(d.shape,h),m=Ue(d.dtype,"int32");let g=Sa(e,p,m);const x=W(f),b=e.data.get(g.dataId).values,w=e.data.get(d.dataId).values;for(let y=0;y<b.length;++y){const C=y*x;let I=0;for(let k=0;k<x;++k)I+=w[C+k];b[y]=I}if(i){const y=ne(g.shape,c),C=g;g=Bt({inputs:{x:g},backend:e,attrs:{shape:y}}),e.disposeIntermediateTensorInfo(C)}return e.disposeIntermediateTensorInfo(a),u!=null&&e.disposeIntermediateTensorInfo(d),g}const tA={kernelName:Tl,backendName:"cpu",kernelFunc:Mi};function eA(n){const{inputs:t,backend:e,attrs:s}=n,{equation:o}=s,r=t,{allDims:i,summedDims:a,idDims:l}=rd(o,r.length);ad(i.length,l,r);const{path:c,steps:u}=ld(a,l),h=u.length;let d=null,p=i.length;const f=[];for(let m=0;m<h;++m){for(const g of u[m]){const{permutationIndices:x,expandDims:b}=id(p,l[g]);let w;cd(x)?w=r[g]:(w=Pe({inputs:{x:r[g]},backend:e,attrs:{perm:x}}),f.push(w));const y=w.shape.slice();for(let C=0;C<b.length;++C)y.splice(b[C],0,1);Et(w.shape,y)||(w=Bt({inputs:{x:w},backend:e,attrs:{shape:y}}),f.push(w)),d===null?d=w:(d=rc({inputs:{a:w,b:d},backend:e}),f.push(d))}m<h-1&&(c[m]>=0&&(d=Mi({inputs:{x:d},backend:e,attrs:{axis:c[m]-(i.length-p),keepDims:!1}}),f.push(d)),p--)}for(const m of f)m!==d&&e.disposeIntermediateTensorInfo(m);return d}const nA={kernelName:Mu,backendName:"cpu",kernelFunc:eA};function sA(n){const{inputs:t,backend:e}=n,{dy:s,y:o}=t;rt([s,o],"eluGrad");const r=new Float32Array(W(o.shape)),i=e.data.get(o.dataId).values,a=e.data.get(s.dataId).values;for(let l=0;l<i.length;++l){const c=i[l];c>=0?r[l]=a[l]:r[l]=a[l]*(c+1)}return e.makeTensorInfo(o.shape,"float32",r)}const oA={kernelName:Pu,backendName:"cpu",kernelFunc:sA};const rA=Zh,iA=Qh,aA=td,lA=ed,cA=nd,uA=sd,hA=At(Br,n=>{const t=Math.sign(n),e=Math.abs(n),s=1/(1+rA*e);return t*(1-((((uA*s+cA)*s+lA)*s+aA)*s+iA)*s*Math.exp(-e*e))}),dA={kernelName:Br,backendName:"cpu",kernelFunc:hA};function Ea(n){const{inputs:t,backend:e,attrs:s}=n,{input:o}=t,{dim:r}=s,i=o.shape.length,a=o.shape.slice();let l=r;return r<0&&($(-(i+1)<=r,()=>`Axis must be in the interval [${-(i+1)}, ${i}]`),l=i+r+1),a.splice(l,0,1),Bt({inputs:{x:o},backend:e,attrs:{shape:a}})}const pA={kernelName:Ja,backendName:"cpu",kernelFunc:Ea};const fA=te((n,t)=>n/t),Vd=ce(Pr,fA),au={kernelName:Pr,backendName:"cpu",kernelFunc:Vd};function m0(n,t,e){const s=n.shape,o=s[0],r=s[1],i=e.data.get(n.dataId),a=i.complexTensorInfos.real,l=i.complexTensorInfos.imag,c=[o,r],u=W(c),h=Ce("float32",u),d=Ce("float32",u);for(let g=0;g<o;g++){const x=eo({inputs:{x:a},backend:e,attrs:{begin:[g,0],size:[1,r]}}),b=eo({inputs:{x:l},backend:e,attrs:{begin:[g,0],size:[1,r]}}),w=Ve({inputs:{real:x,imag:b},backend:e}),{real:y,imag:C}=mA(w,t,e),I=Xn(y,C);for(let k=0;k<r;k++){const v=od(I,k);h[g*r+k]=v.real,d[g*r+k]=v.imag}e.disposeIntermediateTensorInfo(x),e.disposeIntermediateTensorInfo(b),e.disposeIntermediateTensorInfo(w)}const p=e.makeTensorInfo(c,"float32",h),f=e.makeTensorInfo(c,"float32",d),m=Ve({inputs:{real:p,imag:f},backend:e});return e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),m}function mA(n,t,e){const s=W(n.shape),o=e.data.get(n.dataId),r=e.data.get(o.complexTensorInfos.real.dataId).values,i=e.data.get(o.complexTensorInfos.imag.dataId).values;if(gA(s)){const a=lu(r,i,s,t,e),l=[n.shape[0],n.shape[1]];if(t){const c=e.makeTensorInfo(l,"float32",a.real),u=e.makeTensorInfo(l,"float32",a.imag),h=e.makeTensorInfo([],"float32",ws(s,"float32")),d=Bn({inputs:{x:h},backend:e}),p=au.kernelFunc({inputs:{a:c,b:h},backend:e}),f=au.kernelFunc({inputs:{a:u,b:d},backend:e}),m=e.data.get(p.dataId).values,g=e.data.get(f.dataId).values;return e.disposeIntermediateTensorInfo(c),e.disposeIntermediateTensorInfo(u),e.disposeIntermediateTensorInfo(h),e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),{real:m,imag:g}}return a}else{const a=Xn(r,i),l=xA(a,s,t);return Tg(l)}}function gA(n){return(n&n-1)===0}function lu(n,t,e,s,o){if(e===1)return{real:n,imag:t};const r=Xn(n,t),i=e/2,a=Eg(r),l=a.real,c=a.imag,u=[l.length],h=o.makeTensorInfo(u,"float32",l),d=o.makeTensorInfo(u,"float32",c),p=Ve({inputs:{real:h,imag:d},backend:o}),f=Rg(r),m=f.real,g=f.imag,x=[m.length],b=o.makeTensorInfo(x,"float32",m),w=o.makeTensorInfo(x,"float32",g),y=Ve({inputs:{real:b,imag:w},backend:o}),C=lu(l,c,i,s,o),I=C.real,k=C.imag,v=[I.length],N=o.makeTensorInfo(v,"float32",I),T=o.makeTensorInfo(v,"float32",k),O=Ve({inputs:{real:N,imag:T},backend:o}),P=lu(m,g,i,s,o),z=P.real,B=P.imag,M=[z.length],G=o.makeTensorInfo(M,"float32",z),H=o.makeTensorInfo(M,"float32",B),U=Ve({inputs:{real:G,imag:H},backend:o}),K=Ag(e,s),q=[K.real.length],X=o.makeTensorInfo(q,"float32",K.real),Z=o.makeTensorInfo(q,"float32",K.imag),J=Ve({inputs:{real:X,imag:Z},backend:o}),et=rc({inputs:{a:J,b:U},backend:o}),Q=Do({inputs:{a:O,b:et},backend:o}),ot=zd({inputs:{a:O,b:et},backend:o}),at=to({inputs:{input:Q},backend:o}),dt=to({inputs:{input:ot},backend:o}),ht=Ao({inputs:{input:Q},backend:o}),gt=Ao({inputs:{input:ot},backend:o}),bt=Fo({inputs:[at,dt],backend:o,attrs:{axis:0}}),Rt=Fo({inputs:[ht,gt],backend:o,attrs:{axis:0}}),Lt=o.data.get(bt.dataId).values,qt=o.data.get(Rt.dataId).values;return o.disposeIntermediateTensorInfo(h),o.disposeIntermediateTensorInfo(d),o.disposeIntermediateTensorInfo(p),o.disposeIntermediateTensorInfo(b),o.disposeIntermediateTensorInfo(w),o.disposeIntermediateTensorInfo(y),o.disposeIntermediateTensorInfo(N),o.disposeIntermediateTensorInfo(T),o.disposeIntermediateTensorInfo(O),o.disposeIntermediateTensorInfo(G),o.disposeIntermediateTensorInfo(H),o.disposeIntermediateTensorInfo(U),o.disposeIntermediateTensorInfo(X),o.disposeIntermediateTensorInfo(Z),o.disposeIntermediateTensorInfo(J),o.disposeIntermediateTensorInfo(et),o.disposeIntermediateTensorInfo(Q),o.disposeIntermediateTensorInfo(ot),o.disposeIntermediateTensorInfo(at),o.disposeIntermediateTensorInfo(ht),o.disposeIntermediateTensorInfo(dt),o.disposeIntermediateTensorInfo(gt),o.disposeIntermediateTensorInfo(bt),o.disposeIntermediateTensorInfo(Rt),{real:Lt,imag:qt}}function xA(n,t,e){const s=new Float32Array(t*2);for(let o=0;o<t;o++){let r=0,i=0;for(let a=0;a<t;a++){const l=Fg(o*a,t,e),c=od(n,a);r+=c.real*l.real-c.imag*l.imag,i+=c.real*l.imag+c.imag*l.real}e&&(r/=t,i/=t),Dg(s,r,i,o)}return s}function bA(n){const{inputs:t,backend:e}=n,{input:s}=t,o=W(s.shape),r=s.shape[s.shape.length-1],i=o/r,a=Bt({inputs:{x:s},backend:e,attrs:{shape:[i,r]}}),l=m0(a,!1,e),c=Bt({inputs:{x:l},backend:e,attrs:{shape:s.shape}});return e.disposeIntermediateTensorInfo(a),e.disposeIntermediateTensorInfo(l),c}const yA={kernelName:zu,backendName:"cpu",kernelFunc:bA};function Wd(n){const{backend:t,attrs:e}=n,{shape:s,value:o,dtype:r}=e,i=r||Lo(o),a=Xt(i,W(s));return CA(a,o,i),t.makeTensorInfo(s,i,a)}const wA={kernelName:Bu,backendName:"cpu",kernelFunc:Wd};function CA(n,t,e){n.fill(t)}const $A={kernelName:Vu,backendName:"cpu",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{image:s}=n,o=e,r=Ce(s.dtype,W(s.shape)),[i,a,l,c]=s.shape,u=o.data.get(s.dataId).values;for(let d=0;d<i;d++){const p=d*l*a*c;for(let f=0;f<a;f++){const m=f*(l*c);for(let g=0;g<l;g++){const x=g*c;for(let b=0;b<c;b++){const w=Math.round(l-g-1),y=p+m+x+b;let C=u[y];if(w>=0&&w<l){const I=w*c,k=p+m+I+b;C=u[k]}r[y]=C}}}}return{dataId:o.write(r,s.shape,s.dtype),shape:s.shape,dtype:s.dtype}}};function IA(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r,bias:i,preluActivationWeights:a}=t,{strides:l,pad:c,dataFormat:u,dilations:h,dimRoundingMode:d,activation:p,leakyreluAlpha:f}=s;let m=p0({inputs:{x:o,filter:r},backend:e,attrs:{strides:l,pad:c,dataFormat:u,dilations:h,dimRoundingMode:d}});if(i){const g=m;if(u==="NCHW"&&i.shape.length===1&&i.shape[0]!==1){const x=Bt({inputs:{x:i},backend:e,attrs:{shape:[i.shape[0],1,1]}});m=Do({inputs:{a:m,b:x},backend:e}),e.disposeIntermediateTensorInfo(x)}else m=Do({inputs:{a:m,b:i},backend:e});e.disposeIntermediateTensorInfo(g)}if(p){const g=m;if(u==="NCHW"&&p==="prelu"&&a.shape.length===1&&a.shape[0]!==1){const x=Bt({inputs:{x:a},backend:e,attrs:{shape:[a.shape[0],1,1]}});m=Ta(e,m,p,x,f),e.disposeIntermediateTensorInfo(x)}else m=Ta(e,m,p,a,f);e.disposeIntermediateTensorInfo(g)}return m}const kA={kernelName:aa,backendName:"cpu",kernelFunc:IA};function vA(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r,bias:i,preluActivationWeights:a}=t,{strides:l,pad:c,dataFormat:u,dilations:h,dimRoundingMode:d,activation:p,leakyreluAlpha:f}=s;let m=f0({inputs:{x:o,filter:r},backend:e,attrs:{strides:l,pad:c,dataFormat:u,dilations:h,dimRoundingMode:d}});if(i){const g=m;m=Do({inputs:{a:m,b:i},backend:e}),e.disposeIntermediateTensorInfo(g)}if(p){const g=m;m=Ta(e,m,p,a,f),e.disposeIntermediateTensorInfo(g)}return m}const SA={kernelName:im,backendName:"cpu",kernelFunc:vA};function NA(n){const{inputs:t,backend:e}=n,{params:s,indices:o}=t,r=W(s.shape),i=o.shape,a=i[i.length-1],[l,c,u,h]=Vh(s,o);if(c===0)return e.makeTensorInfo(l,s.dtype,[]);const d=e.data.get(o.dataId).values,p=e.bufferSync(s),f=vy(d,p,s.dtype,c,a,u,h,s.shape,r);return e.makeTensorInfo(l,s.dtype,f.values)}const TA={kernelName:Uf,backendName:"cpu",kernelFunc:NA};function EA(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,indices:r}=t,{axis:i,batchDims:a}=s;rt([o,r],"gatherV2");const l=Ct(i,o.shape)[0],c=e.data.get(r.dataId).values,u=o.shape[l];for(let y=0;y<c.length;++y){const C=c[y];$(C<=u-1&&C>=0,()=>`GatherV2: the index value ${C} is not in [0, ${u-1}]`)}let h=a;a==null&&(h=0);const d=W(r.shape),p=hd(o,r,l,h),f=Bt({inputs:{x:o},backend:e,attrs:{shape:[p.batchSize,p.outerSize,p.dimSize,p.sliceSize]}}),m=Bt({inputs:{x:r},backend:e,attrs:{shape:[p.batchSize,d/p.batchSize]}}),g=[p.batchSize,p.outerSize,d/p.batchSize,p.sliceSize],x=e.bufferSync(m),b=e.bufferSync(f),w=Sy(b,x,g);return e.disposeIntermediateTensorInfo(f),e.disposeIntermediateTensorInfo(m),e.makeTensorInfo(p.outputShape,w.dtype,w.values)}const RA={kernelName:Qa,backendName:"cpu",kernelFunc:EA};function DA(n){const{inputs:t,backend:e}=n,{input:s}=t,o=W(s.shape),r=s.shape[s.shape.length-1],i=o/r,a=Bt({inputs:{x:s},backend:e,attrs:{shape:[i,r]}}),l=m0(a,!0,e),c=Bt({inputs:{x:l},backend:e,attrs:{shape:s.shape}});return e.disposeIntermediateTensorInfo(a),e.disposeIntermediateTensorInfo(l),c}const AA={kernelName:Wu,backendName:"cpu",kernelFunc:DA};const FA=At(jr,n=>Number.isFinite(n)?1:0,"bool"),OA={kernelName:jr,backendName:"cpu",kernelFunc:FA};const _A=At(qr,n=>Math.abs(n)===1/0?1:0,"bool"),LA={kernelName:qr,backendName:"cpu",kernelFunc:_A};const MA=At(Xr,n=>Number.isNaN(n)?1:0,"bool"),PA={kernelName:Xr,backendName:"cpu",kernelFunc:MA};function zA(n){const{backend:t,attrs:e}=n,{start:s,stop:o,num:r}=e,i=Dy(s,o,r);return t.makeTensorInfo([i.length],"float32",i)}const BA={kernelName:Gu,backendName:"cpu",kernelFunc:zA};const VA=At(Jr,n=>Math.log1p(n)),WA={kernelName:Jr,backendName:"cpu",kernelFunc:VA};const UA=te((n,t)=>n&&t),GA=ce(ol,UA,null,"bool"),HA={kernelName:ol,backendName:"cpu",kernelFunc:GA};const KA=At(rl,n=>n?0:1,"bool"),jA={kernelName:rl,backendName:"cpu",kernelFunc:KA};const qA=te((n,t)=>n||t),XA=ce(il,qA,null,"bool"),YA={kernelName:il,backendName:"cpu",kernelFunc:XA};function JA(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{depthRadius:r,bias:i,alpha:a,beta:l}=s;rt(o,"LRN");const c=o.shape[3],u=c-1,h=e.data.get(o.dataId).values,d=W(o.shape),p=new Float32Array(d);function f(m){const g=m%c;let x=m-g+Math.max(0,g-r);const b=m-g+Math.min(g+r,u);let w=0;for(;x<=b;x++){const y=h[x];w+=y*y}return w}for(let m=0;m<d;m++){const g=f(m),x=h[m]*Math.pow(i+a*g,-l);p[m]=x}return e.makeTensorInfo(o.shape,o.dtype,p)}const ZA={kernelName:al,backendName:"cpu",kernelFunc:JA};function QA(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,y:r,dy:i}=t,{depthRadius:a,bias:l,alpha:c,beta:u}=s;rt(i,"LRNGrad");const h=W(i.shape),d=i.shape[3],p=e.data.get(i.dataId).values,f=e.data.get(o.dataId).values,m=e.data.get(r.dataId).values,g=new Float32Array(h),x=h;for(let b=0;b<x;b++){const w=b%d,y=b-w+Math.max(0,w-a),C=b-w+Math.min(d,w+a+1);let I=0;for(let k=y;k<C;k++)I+=Math.pow(f[k],2);I=c*I+l;for(let k=y;k<C;k++){let v=-2*c*u*f[k]*m[b]/I;b===k&&(v+=Math.pow(I,-u)),v*=p[b],g[k]+=v}}return e.makeTensorInfo(i.shape,o.dtype,g)}const tF={kernelName:Hu,backendName:"cpu",kernelFunc:QA};function g0(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{reductionIndices:r,keepDims:i}=s,a=e;let l=o.shape;const c=l.length,u=Ct(r,l);let h=u;const d=jt(h,c);let p=a.data.get(o.dataId).values;if(d!=null){const y=new Array(c);for(let C=0;C<y.length;C++)y[C]=l[d[C]];p=Md(p,l,o.dtype,d,y),h=Zt(h.length,c),l=y}rt(o,"max"),ye("max",h,c);const[f,m]=fe(l,h),g=W(m),x=Fy(p,g,f,o.dtype),b=a.write(x,f,o.dtype);let w=f;return i&&(w=ne(f,u)),{dataId:b,shape:w,dtype:o.dtype}}const eF={kernelName:ll,backendName:"cpu",kernelFunc:g0};function nF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t;rt(o,"maxPool");const{filterSize:r,strides:i,pad:a,dimRoundingMode:l}=s,c=1;$(ke(i,c),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${i} and dilations '${c}'`);const u=ln(o.shape,r,i,c,a,l);let h;if(u.filterWidth===1&&u.filterHeight===1&&Et(u.inShape,u.outShape))h=Bn({inputs:{x:o},backend:e});else{const d=e.data.get(o.dataId).values,p=lt(o.shape),f=Bd(d,o.shape,o.dtype,p,u,"max");h=e.makeTensorInfo(u.outShape,o.dtype,f.values)}return h}const sF={kernelName:cl,backendName:"cpu",kernelFunc:nF};function oF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{filterSize:r,strides:i,pad:a,dimRoundingMode:l,dataFormat:c}=s;rt(o,"maxPool3d");const u=Zn(o.shape,r,i,1,a,l,c),h=e.data.get(o.dataId).values,d=d0(h,o.shape,o.dtype,lt(o.shape),u,"max");return e.makeTensorInfo(d.shape,"float32",d.values)}const rF={kernelName:ul,backendName:"cpu",kernelFunc:oF};function iF(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,{filterSize:i,strides:a,pad:l,dimRoundingMode:c}=s;rt([o,r],"maxPool3DGrad");const u=Zn(r.shape,i,a,1,l,c),h=e.bufferSync(r),d=qR(h,u),p=u.strideDepth,f=u.strideHeight,m=u.strideWidth,g=u.dilationDepth,x=u.dilationHeight,b=u.dilationWidth,w=u.effectiveFilterDepth,y=u.effectiveFilterHeight,C=u.effectiveFilterWidth,I=w-1-u.padInfo.front,k=C-1-u.padInfo.left,v=y-1-u.padInfo.top,N=wt(r.shape,"float32"),T=e.bufferSync(o);for(let O=0;O<u.batchSize;++O)for(let P=0;P<u.inChannels;++P)for(let z=0;z<u.inDepth;++z)for(let B=0;B<u.inHeight;++B)for(let M=0;M<u.inWidth;++M){const G=z-I,H=B-v,U=M-k;let K=0;for(let q=0;q<w;q+=g){const X=(G+q)/p;if(!(X<0||X>=u.outDepth||Math.floor(X)!==X))for(let Z=0;Z<y;Z+=x){const J=(H+Z)/f;if(!(J<0||J>=u.outHeight||Math.floor(J)!==J))for(let et=0;et<C;et+=b){const Q=(U+et)/m;if(Q<0||Q>=u.outWidth||Math.floor(Q)!==Q)continue;const ot=w*y*C-1-d.get(O,X,J,Q,P),at=q*y*C+Z*C+et,dt=ot===at?1:0;if(dt===0)continue;const ht=T.get(O,X,J,Q,P);K+=ht*dt}}}N.set(K,O,z,B,M,P)}return e.makeTensorInfo(N.shape,N.dtype,N.values)}const aF={kernelName:ju,backendName:"cpu",kernelFunc:iF};function lF(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r,output:i}=t,a=r;rt([r,i],"maxPoolGrad");const{filterSize:l,strides:c,pad:u,dimRoundingMode:h}=s,d=ln(a.shape,l,c,1,u,h),p=e.data.get(a.dataId).values,f=wt(d.outShape,a.dtype,h0(p,a.shape,a.dtype,d).values),m=d.strideHeight,g=d.strideWidth,x=d.dilationHeight,b=d.dilationWidth,w=d.effectiveFilterHeight,y=d.effectiveFilterWidth,C=y-1-d.padInfo.left,I=w-1-d.padInfo.top,k=wt(a.shape,"float32"),v=e.data.get(o.dataId).values,N=wt(o.shape,"float32",v);for(let T=0;T<d.batchSize;++T)for(let O=0;O<d.inChannels;++O)for(let P=0;P<d.inHeight;++P)for(let z=0;z<d.inWidth;++z){const B=P-I,M=z-C;let G=0;for(let H=0;H<w;H+=x){const U=(B+H)/m;if(!(U<0||U>=d.outHeight||Math.floor(U)!==U))for(let K=0;K<y;K+=b){const q=(M+K)/g;if(q<0||q>=d.outWidth||Math.floor(q)!==q)continue;const X=w*y-1-f.get(T,U,q,O),Z=H*y+K,J=X===Z?1:0;if(J===0)continue;const et=N.get(T,U,q,O);G+=et*J}}k.set(G,T,P,z,O)}return e.makeTensorInfo(k.shape,k.dtype,k.values)}const cF={kernelName:Ku,backendName:"cpu",kernelFunc:lF};function uF(n,t,e,s,o){const r=lt(t),i=Bd(n,t,e,r,o,"max"),a=h0(n,t,e,o,!0,s);return[i.values,a.values]}const hF={kernelName:Gf,backendName:"cpu",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{x:s}=n,{filterSize:o,strides:r,pad:i,includeBatchInIndex:a}=t,l=e;rt(s,"MaxPoolWithArgmax");const c=l.data.get(s.dataId).values,u=ln(s.shape,o,r,[1,1],i),[h,d]=uF(c,s.shape,s.dtype,a,u),p=l.write(h,u.outShape,s.dtype),f=l.write(d,u.outShape,s.dtype);return[{dataId:p,shape:u.outShape,dtype:s.dtype},{dataId:f,shape:u.outShape,dtype:"int32"}]}};function dF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s,a=Ct(r,o.shape),c=fe(o.shape,a)[1],u=W(c),h=[],d=e.makeTensorInfo([],"float32",new Float32Array([u]));h.push(d);const p=bs({inputs:{x:o},backend:e,attrs:{dtype:"float32"}});h.push(p);const f=Vd({inputs:{a:p,b:d},backend:e});h.push(f);const m=Mi({inputs:{x:f},backend:e,attrs:{axis:r,keepDims:i}});return h.forEach(g=>e.disposeIntermediateTensorInfo(g)),m}const pF={kernelName:hl,backendName:"cpu",kernelFunc:dF};function fF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;rt(o,"min");const a=Ct(r,o.shape);let l=a;const c=jt(l,o.shape.length);let u=o;c!=null&&(u=Pe({inputs:{x:o},backend:e,attrs:{perm:c}}),l=Zt(l.length,o.shape.length)),ye("min",l,u.shape.length);const[h,d]=fe(u.shape,l),p=W(d),f=$e(W(h),u.dtype),m=e.data.get(u.dataId).values;for(let x=0;x<f.length;++x){const b=x*p;let w=m[b];for(let y=0;y<p;++y){const C=m[b+y];(Number.isNaN(C)||C<w)&&(w=C)}f[x]=w}c!=null&&e.disposeIntermediateTensorInfo(u);const g=e.makeTensorInfo(h,u.dtype,f);if(i){const x=ne(h,a),b=Bt({inputs:{x:g},backend:e,attrs:{shape:x}});return e.disposeIntermediateTensorInfo(g),b}return g}const mF={kernelName:dl,backendName:"cpu",kernelFunc:fF};function gF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{paddings:r,mode:i}=s;rt(o,"mirrorPad");const a=r.map((w,y)=>w[0]+o.shape[y]+w[1]),l=r.map(w=>w[0]),c=r.map((w,y)=>w[0]+o.shape[y]),u=i==="reflect"?0:1,h=e.data.get(o.dataId).values,d=o.shape.length,p=lt(o.shape),f=W(a),m=a.length,g=lt(a),x=Ce(o.dtype,f);for(let w=0;w<f;w++){let y=Mo(w,m,g);for(let I=0;I<m;I++)y[I]<l[I]?y[I]=l[I]*2-y[I]-u:y[I]>=c[I]&&(y[I]=(c[I]-1)*2-y[I]+u);y=y.map((I,k)=>I-l[k]);const C=Rn(y,d,p);x[w]=h[C]}return{dataId:e.write(x,a,o.dtype),shape:a,dtype:o.dtype}}const xF={kernelName:pl,backendName:"cpu",kernelFunc:gF};const bF=te(((n,t)=>{const e=n%t;return n<0&&t<0||n>=0&&t>=0?e:(e+t)%t})),yF=ce(ti,bF),wF={kernelName:ti,backendName:"cpu",kernelFunc:yF};function x0(n){const{inputs:t,backend:e,attrs:s}=n,{logits:o}=t,{dim:r}=s,i=o.shape.length;let a=r;if(a===-1&&(a=i-1),a!==i-1)throw Error(`Softmax along a non-last dimension is not yet supported. Logits was rank ${i} and dim was ${a}`);const l=Ct([a],o.shape),c=g0({inputs:{x:o},backend:e,attrs:{reductionIndices:l,keepDims:!1}}),u=ne(c.shape,l),h=Bt({inputs:{x:c},backend:e,attrs:{shape:u}}),d=zd({inputs:{a:o,b:h},backend:e}),p=Cy({inputs:{x:d},backend:e}),f=Mi({inputs:{x:p},backend:e,attrs:{axis:l,keepDims:!1}}),m=Bt({inputs:{x:f},backend:e,attrs:{shape:u}}),g=Vd({inputs:{a:p,b:m},backend:e});return e.disposeIntermediateTensorInfo(c),e.disposeIntermediateTensorInfo(h),e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),e.disposeIntermediateTensorInfo(m),g}const CF={kernelName:Dl,backendName:"cpu",kernelFunc:x0};function $F(n){const{inputs:t,backend:e,attrs:s}=n,{logits:o}=t,{numSamples:r,seed:i,normalized:a}=s;rt(o,"multinomial");const l=a?o:x0({inputs:{logits:o},backend:e,attrs:{dim:-1}}),c=l.shape[0],u=l.shape[1],h=e.data.get(l.dataId).values,d=[c,r],p=$e(W(d),"int32");for(let f=0;f<c;++f){const m=f*u,g=new Float32Array(u-1);g[0]=h[m];for(let w=1;w<g.length;++w)g[w]=g[w-1]+h[m+w];const x=pu.alea(i.toString()),b=f*r;for(let w=0;w<r;++w){const y=x();p[b+w]=g.length;for(let C=0;C<g.length;C++)if(y<g[C]){p[b+w]=C;break}}}return a||e.disposeIntermediateTensorInfo(l),e.makeTensorInfo(d,"int32",p)}const IF={kernelName:Hf,backendName:"cpu",kernelFunc:$F};const kF=_h;function vF(n){const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l}=s;rt(o,"NonMaxSuppression");const c=e.data.get(o.dataId).values,u=e.data.get(r.dataId).values,{selectedIndices:h}=kF(c,u,i,a,l);return e.makeTensorInfo([h.length],"int32",new Int32Array(h))}const SF={kernelName:qu,backendName:"cpu",kernelFunc:vF};const NF=Lh;function TF(n){const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l,padToMaxOutputSize:c}=s;rt(o,"NonMaxSuppressionPadded");const u=e.data.get(o.dataId).values,h=e.data.get(r.dataId).values,{selectedIndices:d,validOutputs:p}=NF(u,h,i,a,l,c);return[e.makeTensorInfo([d.length],"int32",new Int32Array(d)),e.makeTensorInfo([],"int32",new Int32Array([p]))]}const EF={kernelName:Xu,backendName:"cpu",kernelFunc:TF};const RF=Mh;function DF(n){const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l,softNmsSigma:c}=s;rt(o,"NonMaxSuppressionWithScore");const u=e.data.get(o.dataId).values,h=e.data.get(r.dataId).values,d=i,p=a,f=l,m=c,{selectedIndices:g,selectedScores:x}=RF(u,h,d,p,f,m);return[e.makeTensorInfo([g.length],"int32",new Int32Array(g)),e.makeTensorInfo([x.length],"float32",new Float32Array(x))]}const AF={kernelName:Yu,backendName:"cpu",kernelFunc:DF};function FF(n){const{inputs:t,backend:e,attrs:s}=n,{indices:o}=t,{dtype:r,depth:i,onValue:a,offValue:l}=s;rt(o,"oneHot");const c=W(o.shape),u=new Float32Array(c*i);u.fill(l);const h=e.data.get(o.dataId).values;for(let d=0;d<c;++d)h[d]>=0&&h[d]<i&&(u[d*i+h[d]]=a);return e.makeTensorInfo([...o.shape,i],r,u)}const OF={kernelName:xl,backendName:"cpu",kernelFunc:FF};function Ra(n){const{inputs:t,backend:e}=n,{x:s}=t;if(s.dtype==="string")throw new Error("zerosLike is not supported for string tensors");if(s.dtype==="complex64"){const o=to({inputs:{input:s},backend:e}),r=Ra({inputs:{x:o},backend:e}),i=Ao({inputs:{input:s},backend:e}),a=Ra({inputs:{x:i},backend:e}),l=Ve({inputs:{real:r,imag:a},backend:e});return e.disposeIntermediateTensorInfo(o),e.disposeIntermediateTensorInfo(r),e.disposeIntermediateTensorInfo(i),e.disposeIntermediateTensorInfo(a),l}else return Wd({backend:e,attrs:{shape:s.shape,value:0,dtype:s.dtype}})}const _F={kernelName:Ol,backendName:"cpu",kernelFunc:Ra};function b0(n){const{inputs:t,backend:e}=n,{x:s}=t;if(s.dtype==="string")throw new Error("onesLike is not supported for string tensors");if(s.dtype==="complex64"){const o=to({inputs:{input:s},backend:e}),r=b0({inputs:{x:o},backend:e}),i=Ao({inputs:{input:s},backend:e}),a=Ra({inputs:{x:i},backend:e}),l=Ve({inputs:{real:r,imag:a},backend:e});return e.disposeIntermediateTensorInfo(o),e.disposeIntermediateTensorInfo(r),e.disposeIntermediateTensorInfo(i),e.disposeIntermediateTensorInfo(a),l}else return Wd({backend:e,attrs:{shape:s.shape,value:1,dtype:s.dtype}})}const LF={kernelName:gl,backendName:"cpu",kernelFunc:b0};function y0(n){const{inputs:t,backend:e,attrs:s}=n,{axis:o}=s;if(t.length===1)return Ea({inputs:{input:t[0]},backend:e,attrs:{dim:o}});const r=t[0].shape,i=t[0].dtype;t.forEach(u=>{gu(r,u.shape,"All tensors passed to stack must have matching shapes"),$(i===u.dtype,()=>"All tensors passed to stack must have matching dtypes")});const a=[],l=t.map(u=>{const h=Ea({inputs:{input:u},backend:e,attrs:{dim:o}});return a.push(h),h}),c=Fo({inputs:l,backend:e,attrs:{axis:o}});return a.forEach(u=>e.disposeIntermediateTensorInfo(u)),c}const MF={kernelName:bl,backendName:"cpu",kernelFunc:y0};function PF(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{paddings:r,constantValue:i}=s;rt(o,"pad");const a=r.map((b,w)=>b[0]+o.shape[w]+b[1]),l=r.map(b=>b[0]),c=e.data.get(o.dataId).values,u=W(o.shape),h=o.shape.length,d=lt(o.shape),p=W(a),f=a.length,m=lt(a),g=Ce(o.dtype,p);i!==0&&g.fill(i);for(let b=0;b<u;b++){const y=Mo(b,h,d).map((I,k)=>I+l[k]),C=Rn(y,f,m);g[C]=c[b]}return{dataId:e.write(g,a,o.dtype),shape:a,dtype:o.dtype}}const w0={kernelName:yl,backendName:"cpu",kernelFunc:PF};const zF=te((n,t)=>Math.pow(n,t)),BF=ce(ni,zF),VF={kernelName:ni,backendName:"cpu",kernelFunc:BF};function WF(n){const{inputs:t,backend:e,attrs:s}=n,{paramsNestedSplits:o,paramsDenseValues:r,indices:i}=t,{outputRaggedRank:a}=s,l=o.map(x=>e.data.get(x.dataId).values),c=o.map(x=>x.shape),u=e.data.get(r.dataId).values,h=e.data.get(i.dataId).values,[d,p,f]=zy(l,c,u,r.shape,r.dtype,h,i.shape),m=d.map(x=>e.makeTensorInfo([x.length],"int32",x)),g=e.makeTensorInfo(f,r.dtype,p);return m.concat([g])}const UF={kernelName:Kf,backendName:"cpu",kernelFunc:WF};function GF(n){const{inputs:t,backend:e}=n,{starts:s,limits:o,deltas:r}=t,i=e.data.get(s.dataId).values,a=e.data.get(o.dataId).values,l=e.data.get(r.dataId).values,[c,u]=By(i,s.shape,s.dtype,a,o.shape,l,r.shape),h=e.makeTensorInfo([c.length],"int32",c),d=e.makeTensorInfo([u.length],s.dtype,u);return[h,d]}const HF={kernelName:jf,backendName:"cpu",kernelFunc:GF};function KF(n){const{inputs:t,backend:e,attrs:s}=n,{shape:o,values:r,defaultValue:i,rowPartitionTensors:a}=t,{rowPartitionTypes:l}=s,c=e.data.get(o.dataId).values,u=e.data.get(r.dataId).values,h=e.data.get(i.dataId).values,d=a.map(g=>e.data.get(g.dataId).values),p=a.map(g=>g.shape),[f,m]=Vy(c,o.shape,u,r.shape,r.dtype,h,i.shape,d,p,l);return e.makeTensorInfo(f,r.dtype,m)}const jF={kernelName:qf,backendName:"cpu",kernelFunc:KF};function qF(n){const{backend:t,attrs:e}=n,{start:s,stop:o,dtype:r,step:i}=e,a=Wy(s,o,i,r);return t.makeTensorInfo([a.length],r,a)}const XF={kernelName:Ju,backendName:"cpu",kernelFunc:qF};const YF=At(si,n=>1/n),JF={kernelName:si,backendName:"cpu",kernelFunc:YF};function ZF(n){const{inputs:t,backend:e,attrs:s}=n,{images:o}=t,{alignCorners:r,halfPixelCenters:i,size:a}=s;rt(o,"resizeBilinear");const l=lt(o.shape),[c,u]=a,[h,d,p,f]=o.shape,m=e.data.get(o.dataId).values,g=new Float32Array(W([h,c,u,f])),x=[r&&c>1?d-1:d,r&&u>1?p-1:p],b=[r&&c>1?c-1:c,r&&u>1?u-1:u];let w=0;const y=x[0]/b[0],C=x[1]/b[1];for(let I=0;I<h;I++)for(let k=0;k<c;k++){let v;i?v=y*(k+.5)-.5:v=y*k;const N=Math.max(0,Math.floor(v)),T=v-N,O=Math.min(d-1,Math.ceil(v)),P=I*l[0]+N*l[1],z=I*l[0]+O*l[1];for(let B=0;B<u;B++){let M;i?M=C*(B+.5)-.5:M=C*B;const G=Math.max(0,Math.floor(M)),H=M-G,U=Math.min(p-1,Math.ceil(M)),K=P+G*l[2],q=z+G*l[2],X=P+U*l[2],Z=z+U*l[2];for(let J=0;J<f;J++){const et=m[K+J],Q=m[q+J],ot=m[X+J],at=m[Z+J],dt=et+(ot-et)*H,ht=Q+(at-Q)*H,gt=dt+(ht-dt)*T;g[w++]=gt}}}return e.makeTensorInfo([h,c,u,f],"float32",g)}const QF={kernelName:kl,backendName:"cpu",kernelFunc:ZF};function tO(n){const{inputs:t,backend:e,attrs:s}=n,{images:o,dy:r}=t,{alignCorners:i}=s;rt([r,o],"resizeBilinearGrad");const a=lt(o.shape),[l,c,u,h]=o.shape,[,d,p]=r.shape,f=new Float32Array(l*c*u*h),m=[i&&d>1?c-1:c,i&&p>1?u-1:u],g=[i&&d>1?d-1:d,i&&p>1?p-1:p],x=m[0]/g[0],b=m[1]/g[1],w=e.data.get(r.dataId).values;let y=0;for(let C=0;C<l;C++){const I=C*a[0];for(let k=0;k<d;k++){const v=k*x,N=Math.floor(v),T=Math.min(Math.ceil(v),c-1),O=I+N*a[1],P=I+T*a[1],z=v-N,B=1-z;for(let M=0;M<p;M++){const G=M*b,H=Math.floor(G),U=Math.min(Math.ceil(G),u-1),K=G-H,q=1-K,X=O+H*a[2],Z=O+U*a[2],J=P+H*a[2],et=P+U*a[2],Q=B*q,ot=B*K,at=z*q,dt=z*K;for(let ht=0;ht<h;ht++){const gt=w[y++];f[X+ht]+=gt*Q,f[Z+ht]+=gt*ot,f[J+ht]+=gt*at,f[et+ht]+=gt*dt}}}}return e.makeTensorInfo([l,u,c,h],"float32",f)}const eO={kernelName:th,backendName:"cpu",kernelFunc:tO};function nO(n){const{inputs:t,backend:e,attrs:s}=n,{images:o}=t,{alignCorners:r,halfPixelCenters:i,size:a}=s;rt(o,"resizeNearestNeighbor");const l=lt(o.shape),[c,u]=a,[h,d,p,f]=o.shape,m=e.data.get(o.dataId).values,g=new Float32Array(h*c*u*f),x=[r&&c>1?d-1:d,r&&u>1?p-1:p],b=[r&&c>1?c-1:c,r&&u>1?u-1:u],w=x[0]/b[0],y=x[1]/b[1];let C=0;for(let I=0;I<h;I++){const k=I*l[0];for(let v=0;v<c;v++){const N=i?w*(v+.5):w*v;let T=Math.min(d-1,r?Math.round(N):Math.floor(N));i&&(T=Math.max(0,T));const O=k+T*l[1];for(let P=0;P<u;P++){const z=i?y*(P+.5):y*P;let B=Math.min(p-1,r?Math.round(z):Math.floor(z));i&&(B=Math.max(0,B));const M=O+B*l[2];for(let G=0;G<f;G++){const H=m[M+G];g[C++]=H}}}}return e.makeTensorInfo([h,c,u,f],o.dtype,g)}const sO={kernelName:Il,backendName:"cpu",kernelFunc:nO};function oO(n){const{inputs:t,backend:e,attrs:s}=n,{images:o,dy:r}=t,{alignCorners:i}=s;rt([r,o],"resizeNearestNeighborGrad");const a=lt(o.shape),l=lt(r.shape),[c,u,h,d]=o.shape,[,p,f]=r.shape,m=new Float32Array(c*u*h*d),g=e.data.get(r.dataId).values,x=[i&&p>1?u-1:u,i&&f>1?h-1:h],b=[i&&p>1?p-1:p,i&&f>1?f-1:f],w=x[0]/b[0],y=x[1]/b[1],C=1/w,I=1/y,k=Math.ceil(C)*2+2,v=Math.ceil(I)*2+2;for(let N=0;N<c;N++){const T=N*a[0];for(let O=0;O<u;O++){const P=T+O*a[1],z=Math.floor(O*C),B=Math.floor(z-k/2);for(let M=0;M<h;M++){const G=P+M*a[2],H=Math.floor(M*I),U=Math.floor(H-v/2);for(let K=0;K<d;K++){let q=0;for(let X=0;X<k;X++){const Z=X+B;if(Z<0||Z>=p)continue;const J=T+Z*l[1],et=Z*w,Q=Math.min(u-1,i?Math.round(et):Math.floor(et));if(O===Q)for(let ot=0;ot<v;ot++){const at=ot+U;if(at<0||at>=f)continue;const dt=J+at*l[2],ht=at*y,gt=Math.min(h-1,i?Math.round(ht):Math.floor(ht));M===gt&&(q+=g[dt+K])}}m[G+K]=q}}}}return e.makeTensorInfo(o.shape,o.dtype,m)}const rO={kernelName:Qu,backendName:"cpu",kernelFunc:oO};function iO(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{dims:r}=s;rt(o,"reverse");const i=o.shape.length,a=Ct(r,o.shape);if(i===0)return Bn({inputs:{x:o},backend:e});const l=new xe(o.shape,o.dtype),c=e.bufferSync(o);for(let u=0;u<l.size;u++){const h=l.indexToLoc(u),d=h.slice();a.forEach(p=>d[p]=o.shape[p]-1-d[p]),l.set(c.get(...d),...h)}return e.makeTensorInfo(l.shape,l.dtype,l.values)}const aO={kernelName:vl,backendName:"cpu",kernelFunc:iO};const lO={kernelName:ah,backendName:"cpu",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{image:s}=n,{radians:o,fillValue:r,center:i}=t,a=e,l=Ce(s.dtype,W(s.shape)),[c,u,h,d]=s.shape,[p,f]=Xh(i,u,h),m=255,g=Math.sin(o),x=Math.cos(o),b=a.data.get(s.dataId).values;for(let y=0;y<c;y++){const C=y*h*u*d;for(let I=0;I<u;I++){const k=I*(h*d);for(let v=0;v<h;v++){const N=v*d;for(let T=0;T<d;T++){const O=[c,I,v,T],P=O[2],z=O[1];let B=(P-p)*x-(z-f)*g,M=(P-p)*g+(z-f)*x;B=Math.round(B+p),M=Math.round(M+f);let G=r;if(typeof r!="number"&&(T===3?G=m:G=r[T]),B>=0&&B<h&&M>=0&&M<u){const U=M*(h*d),K=B*d,q=C+U+K+T;G=b[q]}const H=C+k+N+T;l[H]=G}}}}return{dataId:a.write(l,s.shape,s.dtype),shape:s.shape,dtype:s.dtype}}};const cO=At(ii,n=>{const t=Math.floor(n);return n-t<.5?Math.floor(n):n-t>.5?Math.ceil(n):t%2===0?t:t+1}),uO={kernelName:ii,backendName:"cpu",kernelFunc:cO};function hO(n){const{inputs:t,backend:e,attrs:s}=n,{indices:o,updates:r}=t,{shape:i}=s,{sliceRank:a,numUpdates:l,sliceSize:c,strides:u,outputSize:h}=io(r,o,i),d=!0,p=e.bufferSync(o),f=e.bufferSync(r),m=Ps(p,f,i,h,c,l,a,u,0,d);return e.makeTensorInfo(i,m.dtype,m.values)}const dO={kernelName:Xf,backendName:"cpu",kernelFunc:hO};function pO(n,t){let e=0,s=n.length,o=0;for(;e<s;)o=Math.floor((e+s)/2),n[o]<t?e=o+1:s=o;return s}function fO(n,t){let e=0,s=n.length,o=0;for(;e<s;)o=Math.floor((e+s)/2),n[o]<=t?e=o+1:s=o;return s}function mO(n,t,e,s,o,r){const i=Xt("int32",e*o);for(let a=0;a<e;++a){const l=n.slice(a*s,(a+1)*s),c=a*o;for(let u=0;u<o;++u)i[c+u]=r==="left"?pO(l,t[u+c]):fO(l,t[u+c])}return i}function gO(n){const{inputs:t,backend:e,attrs:s}=n,{sortedSequence:o,values:r}=t,{side:i}=s,a=e.data.get(o.dataId).values,l=e.data.get(r.dataId).values,c=mO(a,l,o.shape[0],o.shape[1],r.shape[1],i);return e.makeTensorInfo(r.shape,"int32",c)}const xO={kernelName:Jf,backendName:"cpu",kernelFunc:gO};function bO(n){const{inputs:t,backend:e}=n,{condition:s,t:o,e:r}=t;rt([s,o,r],"select");const i=s.shape.length,a=e.data.get(s.dataId).values,l=e.data.get(o.dataId).values,c=e.data.get(r.dataId).values,u=Ue(o.dtype,r.dtype),h=$e(W(o.shape),u);let d=0;const p=i===0||i>1||o.shape.length===1?1:W(o.shape.slice(1));for(let f=0;f<a.length;f++)for(let m=0;m<p;m++)a[f]===1?h[d++]=l[f]:h[d++]=c[f];return e.makeTensorInfo(o.shape,u,h)}const yO={kernelName:Sl,backendName:"cpu",kernelFunc:bO};const wO=Kl,CO=jl,$O=At(li,n=>n>=0?CO*n:wO*(Math.exp(n)-1)),IO={kernelName:li,backendName:"cpu",kernelFunc:$O};const kO=At(hi,n=>n<0?-1:n>0?1:0),vO={kernelName:hi,backendName:"cpu",kernelFunc:kO};const SO=At(ci,n=>Math.sin(n)),NO={kernelName:ci,backendName:"cpu",kernelFunc:SO};const TO=At(ui,n=>Math.sinh(n)),EO={kernelName:ui,backendName:"cpu",kernelFunc:TO};const RO=11920928955078125e-23,sf=Math.log(RO)+2,DO=At(pi,n=>{const t=n>-sf,e=n<sf,s=Math.exp(n);let o;return e?o=s:t?o=n:o=Math.log(1+s),o}),AO={kernelName:pi,backendName:"cpu",kernelFunc:DO};function FO(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockShape:r,paddings:i}=s;rt([o],"spaceToBatchND");const a=W(r),l=[[0,0]];l.push(...i);for(let I=1+r.length;I<o.shape.length;++I)l.push([0,0]);const c=w0.kernelFunc({inputs:{x:o},backend:e,attrs:{paddings:l,constantValue:0}}),u=Si(c.shape,r,a,!1),h=Ni(u.length,r.length,!1),d=Ti(c.shape,r,a,!1),m=Bt({inputs:{x:c},backend:e,attrs:{shape:u}}),b=Pe({inputs:{x:m},backend:e,attrs:{perm:h}}),C=Bt({inputs:{x:b},backend:e,attrs:{shape:d}});return e.disposeIntermediateTensorInfo(c),e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(b),C}const OO={kernelName:El,backendName:"cpu",kernelFunc:FO};function _O(n){const{inputs:t,backend:e}=n,{indices:s,values:o,denseShape:r,defaultValue:i}=t;if(r.shape.length!==1)throw new Error(`Dense shape must be a vector, saw:
        ${r.shape}`);if(s.shape.length!==2)throw new Error(`Indices must be a matrix, saw:
        ${s.shape}`);if(o.shape.length!==1)throw new Error(`Values must be a vector, saw:
        ${o.shape}`);if(i.shape.length!==0)throw new Error(`Default value must be a scalar, saw:
        ${i.shape}`);const a=e.data.get(s.dataId).values,l=e.data.get(o.dataId).values,c=e.data.get(r.dataId).values,u=e.data.get(i.dataId).values[0],[h,d,p,f,m]=Ky(a,s.shape,s.dtype,l,o.dtype,c,u);return[e.makeTensorInfo(d,s.dtype,h),e.makeTensorInfo([d[0]],o.dtype,p),e.makeTensorInfo([f.length],"bool",new Uint8Array(f.map(g=>Number(g)))),e.makeTensorInfo([m.length],s.dtype,new Int32Array(m))]}const LO={kernelName:Zf,backendName:"cpu",kernelFunc:_O};function MO(n){const{inputs:t,backend:e}=n,{inputIndices:s,inputShape:o,newShape:r}=t;if(s.shape.length!==2)throw new Error(`Input indices should be a matrix but received shape
        ${s.shape}`);if(o.shape.length!==1)throw new Error(`Input shape should be a vector but received shape
        ${o.shape}`);if(r.shape.length!==1)throw new Error(`Target shape should be a vector but received shape ${r.shape}`);const i=Array.from(e.data.get(o.dataId).values),a=e.data.get(s.dataId).values,l=Array.from(e.data.get(r.dataId).values),[c,u,h]=jy(a,s.shape,s.dtype,i,l);return[e.makeTensorInfo(u,s.dtype,c),e.makeTensorInfo([h.length],r.dtype,new Int32Array(h))]}const PO={kernelName:Qf,backendName:"cpu",kernelFunc:MO};function zO(n){const{inputs:t,backend:e}=n,{data:s,indices:o,segmentIds:r}=t;if(s.shape.length<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(o.shape.length!==1)throw new Error(`Indices should be a vector but received shape
          ${o.shape}`);if(r.shape.length!==1)throw new Error(`Segment ids should be a vector but received shape
          ${r.shape}`);if(o.shape[0]!==r.shape[0])throw new Error("segmentIds and indices should have same size.");const i=e.data.get(s.dataId).values,a=e.data.get(o.dataId).values,l=e.data.get(r.dataId).values,[c,u]=Pd(i,s.shape,s.dtype,a,l,!0);return e.makeTensorInfo(u,s.dtype,c)}const BO={kernelName:tm,backendName:"cpu",kernelFunc:zO};function VO(n){const{inputs:t,backend:e}=n,{data:s,indices:o,segmentIds:r}=t;if(s.shape.length<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(o.shape.length!==1)throw new Error(`Indices should be a vector but received shape
         ${o.shape}`);if(r.shape.length!==1)throw new Error(`Segment ids should be a vector but received shape
         ${r.shape}`);if(o.shape[0]!==r.shape[0])throw new Error("segmentIds and indices should have same size.");const i=e.data.get(s.dataId).values,a=e.data.get(o.dataId).values,l=e.data.get(r.dataId).values,[c,u]=Pd(i,s.shape,s.dtype,a,l);return e.makeTensorInfo(u,s.dtype,c)}const WO={kernelName:em,backendName:"cpu",kernelFunc:VO};function UO(n){const{inputs:t,backend:e,attrs:s}=n,{sparseIndices:o,sparseValues:r,defaultValue:i}=t,{outputShape:a}=s,{sliceRank:l,numUpdates:c,sliceSize:u,strides:h,outputSize:d}=io(r,o,a),p=!1,f=e.bufferSync(o);let m;switch(r.dtype){case"bool":{const g=e.bufferSync(r),x=!!e.data.get(i.dataId).values[0];m=Ps(f,g,a,d,u,c,l,h,x,p);break}case"float32":{const g=e.bufferSync(r),x=e.data.get(i.dataId).values[0];m=Ps(f,g,a,d,u,c,l,h,x,p);break}case"int32":{const g=e.bufferSync(r),x=e.data.get(i.dataId).values[0];m=Ps(f,g,a,d,u,c,l,h,x,p);break}case"string":{const g=e.bufferSync(r),x=ps(e.data.get(i.dataId).values[0]);m=Ps(f,g,a,d,u,c,l,h,x,p);break}default:throw new Error(`Unsupported type ${r.dtype}`)}return e.makeTensorInfo(a,m.dtype,m.values)}const GO={kernelName:nm,backendName:"cpu",kernelFunc:UO};function HO(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{numOrSizeSplits:r,axis:i}=s,a=Ct(i,o.shape)[0],l=ud(o,r,a),c=new Array(o.shape.length).fill(0),u=o.shape.slice();return l.map(h=>{const d=[...u];d[a]=h;const p=eo({inputs:{x:o},backend:e,attrs:{begin:c,size:d}});return c[a]+=h,p})}const KO={kernelName:Rl,backendName:"cpu",kernelFunc:HO};const jO={kernelName:eh,backendName:"cpu",kernelFunc:({inputs:n,backend:t})=>{const{x:e}=n,s=t;rt(e,"square");const o=s.data.get(e.dataId).values,r=new Float32Array(o.length);for(let a=0;a<o.length;++a){const l=o[a];r[a]=l*l}return{dataId:s.write(r,e.shape,e.dtype),shape:e.shape,dtype:e.dtype}}};const qO=At(wi,(n,t)=>{const e=t;return isNaN(n)?NaN:n>0?1:e.alpha}),XO={kernelName:wi,backendName:"cpu",kernelFunc:qO};function YO(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{begin:r,end:i,strides:a,beginMask:l,endMask:c,ellipsisMask:u,newAxisMask:h,shrinkAxisMask:d}=s;rt(o,"stridedSlice");const{finalShapeSparse:p,finalShape:f,isIdentity:m,sliceDim0:g,isSimpleSlice:x,begin:b,end:w,strides:y}=Kh(o.shape,r,i,a,l,c,u,h,d);let C;if(m)C=Bt({inputs:{x:o},backend:e,attrs:{shape:f}});else if(g||x){$(o.shape.length>=1,()=>`Input must have rank at least 1, got: ${o.shape.length}`);const I=Uh(b,w,y),k=eo({inputs:{x:o},backend:e,attrs:{begin:b,size:I}});C=Bt({inputs:{x:k},backend:e,attrs:{shape:f}}),e.disposeIntermediateTensorInfo(k)}else{const I=e.bufferSync(o),k=Yy(p,I,y,b);C=e.makeTensorInfo(f,k.dtype,k.values)}return C}const JO={kernelName:sh,backendName:"cpu",kernelFunc:YO};function ZO(n){const{inputs:t,backend:e,attrs:s}=n,{separator:o,nGramWidths:r,leftPad:i,rightPad:a,padWidth:l,preserveShortSequences:c}=s,{data:u,dataSplits:h}=t,d=e.data.get(u.dataId).values,p=e.data.get(h.dataId).values,[f,m]=Jy(d,p,o,r,i,a,l,c);return[e.makeTensorInfo([f.length],"string",f),e.makeTensorInfo(h.shape,"int32",m)]}const QO={kernelName:sm,backendName:"cpu",kernelFunc:ZO};function t_(n){const{inputs:t,backend:e,attrs:s}=n,{skipEmpty:o}=s,{input:r,delimiter:i}=t;if(r.dtype!=="string")throw new Error("Input must be of datatype string");if(r.shape.length!==1)throw new Error(`Input must be a vector, got shape: ${r.shape}`);if(i.shape.length!==0)throw new Error(`Delimiter must be a scalar, got shape: ${i.shape}`);const a=e.data.get(r.dataId).values,l=e.data.get(i.dataId).values[0],[c,u,h]=Zy(a,l,o),d=u.length;return[e.makeTensorInfo([d,2],"int32",c),e.makeTensorInfo([d],"string",u),e.makeTensorInfo([2],"int32",new Int32Array(h))]}const e_={kernelName:om,backendName:"cpu",kernelFunc:t_};function n_(n){const{inputs:t,backend:e,attrs:s}=n,{numBuckets:o}=s,{input:r}=t;if(r.dtype!=="string")throw new Error("Input must be of datatype string");if(o<=0)throw new Error("Number of buckets must be at least 1");const i=e.data.get(r.dataId).values,a=Qy(i,o);return e.makeTensorInfo(r.shape,"int32",a)}const s_={kernelName:rm,backendName:"cpu",kernelFunc:n_};const o_=At(xi,n=>Math.tan(n)),r_={kernelName:xi,backendName:"cpu",kernelFunc:o_};const i_=At(bi,n=>Math.tanh(n)),a_={kernelName:bi,backendName:"cpu",kernelFunc:i_};function l_(n){const{inputs:t,backend:e}=n,{tensor:s,indices:o,updates:r}=t,{sliceRank:i,numUpdates:a,sliceSize:l,strides:c,outputSize:u}=io(r,o,s.shape),h=!1,d=e.bufferSync(o),p=e.bufferSync(r),f=e.bufferSync(s),m=Ps(d,p,s.shape,u,l,a,i,c,f,h);return e.makeTensorInfo(s.shape,m.dtype,m.values)}const c_={kernelName:Yf,backendName:"cpu",kernelFunc:l_};function u_(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{reps:r}=s;rt(o,"tile");const i=e0(e.bufferSync(o),r);return e.makeTensorInfo(i.shape,i.dtype,i.values)}const h_={kernelName:yi,backendName:"cpu",kernelFunc:u_};function d_(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{k:r,sorted:i}=s;rt(o,"topk");const a=e.data.get(o.dataId).values,[l,c]=s0(a,o.shape,o.dtype,r,i);return[e.makeTensorInfo(l.shape,l.dtype,l.values),e.makeTensorInfo(c.shape,c.dtype,c.values)]}const p_={kernelName:oh,backendName:"cpu",kernelFunc:d_};function f_(n){const{inputs:t,attrs:e,backend:s}=n,{image:o,transforms:r}=t,{interpolation:i,fillMode:a,fillValue:l,outputShape:c}=e,[u,h,d,p]=o.shape,[f,m]=c??[h,d],g=[u,f,m,p],x=lt(o.shape),b=x[0],w=x[1],y=x[2],C=lt(g),I=C[0],k=C[1],v=C[2],N=Ce(o.dtype,W(g));N.fill(l);const T=s.data.get(o.dataId).values,O=s.data.get(r.dataId).values;for(let z=0;z<u;++z){const B=r.shape[0]===1?O:O.subarray(z*8,z*8+8);for(let M=0;M<f;++M)for(let G=0;G<m;++G)for(let H=0;H<p;++H){let U;const K=B[6]*G+B[7]*M+1;if(K===0)continue;const q=(B[0]*G+B[1]*M+B[2])/K,X=(B[3]*G+B[4]*M+B[5])/K,Z=of(q,d,a),J=of(X,h,a);switch(i){case"nearest":U=w_(T,h,d,b,w,y,z,J,Z,H,l);break;case"bilinear":U=C_(T,h,d,b,w,y,z,J,Z,H,l);break;default:throw new Error(`Error in Transform: Expect 'nearest' or 'bilinear', but got ${i}`)}const et=z*I+M*k+G*v+H;N[et]=U}return s.makeTensorInfo(g,o.dtype,N)}return{dataId:s.write(N,g,o.dtype),shape:o.shape,dtype:o.dtype}}const m_={kernelName:rh,backendName:"cpu",kernelFunc:f_};function of(n,t,e){switch(e){case"reflect":return g_(n,t);case"wrap":return x_(n,t);case"nearest":return y_(n,t);default:return b_(n)}}function g_(n,t){let e=n;if(e<0)if(t<=1)e=0;else{const s=2*t;e<s&&(e=s*Math.trunc(-e/s)+e),e=e<-t?e+s:-e-1}else if(e>t-1)if(t<=1)e=0;else{const s=2*t;e-=s*Math.trunc(e/s),e>=t&&(e=s-e-1)}return Ws(0,e,t-1)}function x_(n,t){let e=n;if(e<0)if(t<=1)e=0;else{const s=t-1;e+=t*(Math.trunc(-e/s)+1)}else if(e>t-1)if(t<=1)e=0;else{const s=t-1;e-=t*Math.trunc(e/s)}return Ws(0,e,t-1)}function b_(n,t){return n}function y_(n,t){return Ws(0,n,t-1)}function ar(n,t,e,s,o,r,i,a,l,c,u){const h=i*s+a*o+l*r+c;return 0<=a&&a<t&&0<=l&&l<e?n[h]:u}function w_(n,t,e,s,o,r,i,a,l,c,u){const h=Math.round(a),d=Math.round(l);return ar(n,t,e,s,o,r,i,h,d,c,u)}function C_(n,t,e,s,o,r,i,a,l,c,u){const h=Math.floor(a),d=Math.floor(l),p=h+1,f=d+1,m=(f-l)*ar(n,t,e,s,o,r,i,h,d,c,u)+(l-d)*ar(n,t,e,s,o,r,i,h,f,c,u),g=(f-l)*ar(n,t,e,s,o,r,i,p,d,c,u)+(l-d)*ar(n,t,e,s,o,r,i,p,f,c,u);return(p-a)*m+(a-h)*g}function $_(n){const{inputs:t,attrs:e,backend:s}=n,{axis:o}=e,{x:r}=t;rt(r,"unique");const i=s.data.get(r.dataId).values,{outputValues:a,outputShape:l,indices:c}=o0(i,o,r.shape,r.dtype);return[s.makeTensorInfo(l,r.dtype,a),s.makeTensorInfo([c.length],"int32",c)]}const I_={kernelName:ih,backendName:"cpu",kernelFunc:$_};function k_(n){const{inputs:t,backend:e,attrs:s}=n,{value:o}=t;let{axis:r}=s;r<0&&(r+=o.shape.length);const i=o.shape.length,a=o.shape[r],l=new Array(i-1);let c=0;for(let p=0;p<i;p++)p!==r&&(l[c++]=o.shape[p]);const u=new Array(i).fill(0),h=o.shape.slice();h[r]=1;const d=new Array(a);for(let p=0;p<d.length;p++){u[r]=p;const f=eo({inputs:{x:o},backend:e,attrs:{begin:u,size:h}});d[p]=Bt({inputs:{x:f},backend:e,attrs:{shape:l}}),e.disposeIntermediateTensorInfo(f)}return d}const v_={kernelName:Al,backendName:"cpu",kernelFunc:k_};function S_(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,segmentIds:r}=t,{numSegments:i}=s;rt(o,"unsortedSegmentSum");const a=o.shape.length,l=r.shape.length,c=[],u=[],h=a-l;let d=r;for(let f=0;f<h;++f){const m=Ea({inputs:{input:d},backend:e,attrs:{dim:f+1}});d=m,u.push(m)}for(let f=0;f<i;++f){const m=ws(f,"int32"),g=e.makeTensorInfo([],"int32",m),x=yy({inputs:{a:g,b:d},backend:e}),b=bs({inputs:{x},backend:e,attrs:{dtype:"float32"}}),w=rc({inputs:{a:b,b:o},backend:e}),y=Mi({inputs:{x:w},backend:e,attrs:{axis:0,keepDims:!1}});c.push(y),u.push(g),u.push(x),u.push(b),u.push(w),u.push(y)}const p=y0({inputs:c,backend:e,attrs:{axis:0}});return u.forEach(f=>e.disposeIntermediateTensorInfo(f)),p}const N_={kernelName:Fl,backendName:"cpu",kernelFunc:S_};const T_=[$R,nE,kR,SR,lE,TR,RR,AR,OR,LR,PR,BR,WR,HR,jR,YR,ZR,tD,nD,wR,oD,iD,lD,uE,uD,iE,dE,dD,sE,fD,gD,xD,yD,CD,ID,vD,ND,ED,DD,FD,_D,MD,zD,VD,WD,GD,KD,qD,XD,YD,JD,QD,nA,pR,oA,pE,dA,fE,pA,gE,yA,wA,$A,bE,wE,kA,SA,TA,RA,$E,kE,oE,AA,mD,OA,LA,PA,fR,SE,TE,BA,RE,WA,HA,jA,YA,ZA,tF,eF,AE,sF,rF,aF,cF,hF,pF,mF,OE,xF,wF,IF,LE,PE,SF,EF,AF,BE,OF,LF,MF,w0,VF,gR,UE,UF,HF,jF,XF,rE,au,JF,xR,bR,yR,QF,eO,sO,rO,aO,lO,uO,JE,dO,xO,yO,IO,QE,vO,NO,EO,tR,CF,AO,OO,LO,PO,BO,WO,GO,KO,sR,jO,rR,aR,XO,JO,QO,e_,s_,hR,tA,r_,a_,c_,h_,p_,m_,VE,I_,v_,N_,_F];for(const n of T_)am(n);const Ls={},Xi={alpha:!1,antialias:!1,premultipliedAlpha:!1,preserveDrawingBuffer:!1,depth:!1,stencil:!1,failIfMajorPerformanceCaveat:!0};function E_(n,t){Ls[n]=t}function $n(n,t){if(!(n in Ls)||t!=null){const s=D_(n,t);if(s!==null)Ls[n]=s;else return console.log("Could not get context for WebGL version",n),null}const e=Ls[n];return e==null||e.isContextLost()?(delete Ls[n],$n(n)):(e.disable(e.DEPTH_TEST),e.disable(e.STENCIL_TEST),e.disable(e.BLEND),e.disable(e.DITHER),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SAMPLE_COVERAGE),e.enable(e.SCISSOR_TEST),e.enable(e.CULL_FACE),e.cullFace(e.BACK),Ls[n])}function R_(n){if(!L().getBool("IS_SAFARI")&&typeof OffscreenCanvas<"u"&&n===2)return new OffscreenCanvas(300,150);if(typeof document<"u")return document.createElement("canvas");throw new Error("Cannot create a canvas in this context")}function D_(n,t){if(n!==1&&n!==2)throw new Error("Cannot get WebGL rendering context, WebGL is disabled.");const e=t??R_(n);return e.addEventListener("webglcontextlost",s=>{s.preventDefault(),delete Ls[n]},!1),L().getBool("SOFTWARE_WEBGL_ENABLED")&&(Xi.failIfMajorPerformanceCaveat=!1),n===1?e.getContext("webgl",Xi)||e.getContext("experimental-webgl",Xi):e.getContext("webgl2",Xi)}var Cr;(function(n){n[n.DENSE=0]="DENSE",n[n.SHARED_BATCH=1]="SHARED_BATCH"})(Cr||(Cr={}));var qe;(function(n){n[n.RENDER=0]="RENDER",n[n.UPLOAD=1]="UPLOAD",n[n.PIXELS=2]="PIXELS",n[n.DOWNLOAD=3]="DOWNLOAD"})(qe||(qe={}));var ge;(function(n){n[n.UNPACKED_FLOAT16=0]="UNPACKED_FLOAT16",n[n.UNPACKED_FLOAT32=1]="UNPACKED_FLOAT32",n[n.PACKED_4X1_UNSIGNED_BYTE=2]="PACKED_4X1_UNSIGNED_BYTE",n[n.PACKED_2X2_FLOAT32=3]="PACKED_2X2_FLOAT32",n[n.PACKED_2X2_FLOAT16=4]="PACKED_2X2_FLOAT16"})(ge||(ge={}));function Pi(n,t){return[t,n]}function A_(n,t){return n*t}function Yi(n){const t=W(n),e=Math.ceil(t/4);return Dc(e)}function Go(n,t){return[Math.max(1,Math.ceil(t/2)),Math.max(1,Math.ceil(n/2))]}function F_(n,t){const[e,s]=Go(n,t);return e*s*4}function Ud(n,t){const e=n;let s,o,r,i,a,l,c,u,h,d;return L().getNumber("WEBGL_VERSION")===2?(s=e.R32F,o=e.R16F,r=e.RGBA16F,i=e.RGBA32F,a=e.RED,c=4,u=1,h=e.HALF_FLOAT,d=e.FLOAT,l=e.RGBA8):(s=n.RGBA,o=n.RGBA,r=n.RGBA,i=e.RGBA,a=n.RGBA,c=4,u=4,h=t!=null?t.HALF_FLOAT_OES:null,d=n.FLOAT,l=n.RGBA),{internalFormatFloat:s,internalFormatHalfFloat:o,internalFormatPackedHalfFloat:r,internalFormatPackedFloat:i,textureFormatFloat:a,downloadTextureFormat:l,downloadUnpackNumChannels:c,defaultNumChannels:u,textureTypeHalfFloat:h,textureTypeFloat:d}}function nt(n,t){const e=t();return L().getBool("DEBUG")&&O_(n),e}function O_(n){const t=n.getError();if(t!==n.NO_ERROR)throw new Error("WebGL Error: "+P_(n,t))}const __=596e-10,L_=65504;function M_(n){return!!(L().getBool("WEBGL_RENDER_FLOAT32_ENABLED")||n===0||__<Math.abs(n)&&Math.abs(n)<L_)}function P_(n,t){switch(t){case n.NO_ERROR:return"NO_ERROR";case n.INVALID_ENUM:return"INVALID_ENUM";case n.INVALID_VALUE:return"INVALID_VALUE";case n.INVALID_OPERATION:return"INVALID_OPERATION";case n.INVALID_FRAMEBUFFER_OPERATION:return"INVALID_FRAMEBUFFER_OPERATION";case n.OUT_OF_MEMORY:return"OUT_OF_MEMORY";case n.CONTEXT_LOST_WEBGL:return"CONTEXT_LOST_WEBGL";default:return`Unknown error code ${t}`}}function Ji(n,t){return ts(n,()=>n.getExtension(t),'Extension "'+t+'" not supported on this browser.')}function z_(n,t){const e=ts(n,()=>n.createShader(n.VERTEX_SHADER),"Unable to create vertex WebGLShader.");if(nt(n,()=>n.shaderSource(e,t)),nt(n,()=>n.compileShader(e)),n.getShaderParameter(e,n.COMPILE_STATUS)===!1)throw console.log(n.getShaderInfoLog(e)),new Error("Failed to compile vertex shader.");return e}function B_(n,t){const e=ts(n,()=>n.createShader(n.FRAGMENT_SHADER),"Unable to create fragment WebGLShader.");if(nt(n,()=>n.shaderSource(e,t)),nt(n,()=>n.compileShader(e)),L().get("ENGINE_COMPILE_ONLY"))return e;if(n.getShaderParameter(e,n.COMPILE_STATUS)===!1)throw C0(t,n.getShaderInfoLog(e)),new Error("Failed to compile fragment shader.");return e}const V_=/ERROR: [0-9]+:([0-9]+):/g;function C0(n,t){const e=V_.exec(t);if(e==null){console.log(`Couldn't parse line number in error: ${t}`),console.log(n);return}const s=+e[1],o=n.split(`
`),r=o.length.toString().length+2,i=o.map((h,d)=>wo((d+1).toString(),r)+h);let a=0;for(let h=0;h<i.length;h++)a=Math.max(i[h].length,a);const l=i.slice(0,s-1),c=i.slice(s-1,s),u=i.slice(s);console.log(l.join(`
`)),console.log(t.split(`
`)[0]),console.log(`%c ${wo(c[0],a)}`,"border:1px solid red; background-color:#e3d2d2; color:#a61717"),console.log(u.join(`
`))}function W_(n){return ts(n,()=>n.createProgram(),"Unable to create WebGLProgram.")}function U_(n,t){if(nt(n,()=>n.linkProgram(t)),!L().get("ENGINE_COMPILE_ONLY")&&n.getProgramParameter(t,n.LINK_STATUS)===!1)throw console.log(n.getProgramInfoLog(t)),new Error("Failed to link vertex and fragment shaders.")}function vc(n,t){if(nt(n,()=>n.validateProgram(t)),n.getProgramParameter(t,n.VALIDATE_STATUS)===!1)throw console.log(n.getProgramInfoLog(t)),new Error("Shader program validation failed.")}function G_(n,t){const e=ts(n,()=>n.createBuffer(),"Unable to create WebGLBuffer");return nt(n,()=>n.bindBuffer(n.ARRAY_BUFFER,e)),nt(n,()=>n.bufferData(n.ARRAY_BUFFER,t,n.STATIC_DRAW)),e}function H_(n,t){const e=ts(n,()=>n.createBuffer(),"Unable to create WebGLBuffer");return nt(n,()=>n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e)),nt(n,()=>n.bufferData(n.ELEMENT_ARRAY_BUFFER,t,n.STATIC_DRAW)),e}function K_(n){return ts(n,()=>n.createTexture(),"Unable to create WebGLTexture.")}function j_(n,t){const e=L().getNumber("WEBGL_MAX_TEXTURE_SIZE");if(n<=0||t<=0){const s=`[${n}x${t}]`;throw new Error("Requested texture size "+s+" is invalid.")}if(n>e||t>e){const s=`[${n}x${t}]`,o=`[${e}x${e}]`;throw new Error("Requested texture size "+s+" greater than WebGL maximum on this browser / GPU "+o+".")}}function q_(n){return ts(n,()=>n.createFramebuffer(),"Unable to create WebGLFramebuffer.")}function rf(n,t,e,s,o,r,i){const a=n.getAttribLocation(t,e);return a===-1?!1:(nt(n,()=>n.bindBuffer(n.ARRAY_BUFFER,s)),nt(n,()=>n.vertexAttribPointer(a,o,n.FLOAT,!1,r,i)),nt(n,()=>n.enableVertexAttribArray(a)),!0)}function X_(n,t,e){tL(n,e),nt(n,()=>n.activeTexture(n.TEXTURE0+e)),nt(n,()=>n.bindTexture(n.TEXTURE_2D,t))}function Y_(n,t,e){return ts(n,()=>n.getUniformLocation(t,e),'uniform "'+e+'" not present in program.')}function J_(n,t,e){return n.getUniformLocation(t,e)}function Z_(n,t,e,s){nt(n,()=>X_(n,t,s)),nt(n,()=>n.uniform1i(e,s))}function Sc(n,t,e){nt(n,()=>n.bindFramebuffer(n.FRAMEBUFFER,e)),nt(n,()=>n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,t,0))}function af(n,t){nt(n,()=>n.bindFramebuffer(n.FRAMEBUFFER,t)),nt(n,()=>n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,null,0))}function Zi(n){const t=n.checkFramebufferStatus(n.FRAMEBUFFER);if(t!==n.FRAMEBUFFER_COMPLETE)throw new Error("Error binding framebuffer: "+Q_(n,t))}function Q_(n,t){switch(t){case n.FRAMEBUFFER_INCOMPLETE_ATTACHMENT:return"FRAMEBUFFER_INCOMPLETE_ATTACHMENT";case n.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:return"FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT";case n.FRAMEBUFFER_INCOMPLETE_DIMENSIONS:return"FRAMEBUFFER_INCOMPLETE_DIMENSIONS";case n.FRAMEBUFFER_UNSUPPORTED:return"FRAMEBUFFER_UNSUPPORTED";default:return`unknown error ${t}`}}function ts(n,t,e){const s=nt(n,()=>t());if(s==null)throw new Error(e);return s}function tL(n,t){const e=n.MAX_COMBINED_TEXTURE_IMAGE_UNITS-1,s=t+n.TEXTURE0;if(s<n.TEXTURE0||s>e){const o=`[gl.TEXTURE0, gl.TEXTURE${e}]`;throw new Error(`textureUnit must be in ${o}.`)}}function Oo(n,t=2){return W(n.slice(0,n.length-t))}function _o(n){if(n.length===0)throw Error("Cannot get rows and columns of an empty shape array.");return[n.length>1?n[n.length-2]:1,n[n.length-1]]}function Qi(n){let t=[1,1,1];return n.length===0||n.length===1&&n[0]===1||(t=[Oo(n),..._o(n)]),t}function eL(n,t=!1){let e=L().getNumber("WEBGL_MAX_TEXTURE_SIZE"),s=L().getNumber("WEBGL_MAX_SIZE_FOR_NARROW_TEXTURE");s===1/0&&L().getBool("WEBGL_AUTO_SQUARIFY_NARROW_TEXTURE_SHAPE")&&(s=e/2),t&&(e=e*2,s=s*2,n=n.map((a,l)=>l>=n.length-2?mu(n[l]):n[l]),n.length===1&&(n=[2,n[0]])),n.length!==2&&(n=ys(n).newShape);let o=W(n),r=null;n.length<=1&&o<=e?r=[1,o]:n.length===2&&n[0]<=e&&n[1]<=e?r=n:n.length===3&&n[0]*n[1]<=e&&n[2]<=e?r=[n[0]*n[1],n[2]]:n.length===3&&n[0]<=e&&n[1]*n[2]<=e?r=[n[0],n[1]*n[2]]:n.length===4&&n[0]*n[1]*n[2]<=e&&n[3]<=e?r=[n[0]*n[1]*n[2],n[3]]:n.length===4&&n[0]<=e&&n[1]*n[2]*n[3]<=e&&(r=[n[0],n[1]*n[2]*n[3]]);const i=r!=null&&Math.max(...r)>s&&Math.min(...r)<=(t?2:1)&&Math.min(...r)>0;if(r==null||i)if(t){const a=Oo(n);let l=2,c=2;n.length&&([l,c]=_o(n)),o=a*(l/2)*(c/2),r=Dc(o).map(u=>u*2)}else r=Dc(o);return r}function ta(n){return n%2===0}function Da(n,t){if(n=n.slice(-2),t=t.slice(-2),Et(n,t)||!n.length||!t.length||n[0]===0||n[1]===0||t[0]===0||t[1]===0)return!0;if(n.length!==t.length){const e=n[n.length-1],s=t[t.length-1];if(e===s||ta(e)&&ta(s)&&(n[0]===1||t[0]===1))return!0}return n[1]===t[1]&&ta(n[0])&&ta(t[0])}let Nc,Tc;function nL(n){if(Nc==null){const t=$n(n);Nc=t.getParameter(t.MAX_TEXTURE_SIZE)}return Nc}function sL(n){if(Tc==null){const t=$n(n);Tc=t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS)}return Math.min(16,Tc)}function oL(n){if(n===0)return 0;let t;const e=$n(n);return on(e,"EXT_disjoint_timer_query_webgl2")&&n===2?t=2:on(e,"EXT_disjoint_timer_query")?t=1:t=0,t}function on(n,t){return n.getExtension(t)!=null}function lf(n){try{if($n(n)!=null)return!0}catch(t){return console.log("Error when getting WebGL context: ",t),!1}return!1}function rL(n){if(n===0)return!1;const t=$n(n);if(n===1){if(!on(t,"OES_texture_float"))return!1}else if(!on(t,"EXT_color_buffer_float"))return!1;return cu(t)}function iL(n){if(n===0)return!1;const t=$n(n);if(n===1){if(!on(t,"OES_texture_float")||!on(t,"WEBGL_color_buffer_float"))return!1}else{if(on(t,"EXT_color_buffer_float"))return cu(t);const s="EXT_color_buffer_half_float";if(on(t,s)){const o=t.getExtension(s);return aL(t,o)}return!1}return cu(t)}function cu(n){const t=Ud(n),e=n.createTexture();n.bindTexture(n.TEXTURE_2D,e),n.texImage2D(n.TEXTURE_2D,0,t.internalFormatFloat,1,1,0,t.textureFormatFloat,t.textureTypeFloat,null);const r=n.createFramebuffer();n.bindFramebuffer(n.FRAMEBUFFER,r),n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,e,0);const i=n.checkFramebufferStatus(n.FRAMEBUFFER)===n.FRAMEBUFFER_COMPLETE;return n.bindTexture(n.TEXTURE_2D,null),n.bindFramebuffer(n.FRAMEBUFFER,null),n.deleteTexture(e),n.deleteFramebuffer(r),i}function aL(n,t){const e=Ud(n,t),s=n.createTexture();n.bindTexture(n.TEXTURE_2D,s),n.texImage2D(n.TEXTURE_2D,0,e.internalFormatHalfFloat,1,1,0,e.textureFormatFloat,e.textureTypeHalfFloat,null);const i=n.createFramebuffer();n.bindFramebuffer(n.FRAMEBUFFER,i),n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,s,0);const a=n.checkFramebufferStatus(n.FRAMEBUFFER)===n.FRAMEBUFFER_COMPLETE;return n.bindTexture(n.TEXTURE_2D,null),n.bindFramebuffer(n.FRAMEBUFFER,null),n.deleteTexture(s),n.deleteFramebuffer(i),a}function lL(n){return n!==2?!1:$n(n).fenceSync!=null}function zi(n,t){Array.isArray(n)||(n=[n]),n.forEach(e=>{e!=null&&$(e.dtype!=="complex64",()=>`${t} does not support complex64 tensors in the WebGL backend.`)})}const it=L();it.registerFlag("HAS_WEBGL",()=>it.getNumber("WEBGL_VERSION")>0);it.registerFlag("WEBGL_VERSION",()=>lf(2)?2:lf(1)?1:0);it.registerFlag("WEBGL_CHECK_NUMERICAL_PROBLEMS",()=>!1);it.registerFlag("WEBGL_BUFFER_SUPPORTED",()=>it.get("WEBGL_VERSION")===2);it.registerFlag("WEBGL_CPU_FORWARD",()=>!0);it.registerFlag("WEBGL_FORCE_F16_TEXTURES",()=>!1);it.registerFlag("WEBGL_PACK",()=>it.getBool("HAS_WEBGL"));it.registerFlag("WEBGL_PACK_NORMALIZATION",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_CLIP",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_DEPTHWISECONV",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_BINARY_OPERATIONS",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_UNARY_OPERATIONS",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_ARRAY_OPERATIONS",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_IMAGE_OPERATIONS",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_REDUCE",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_LAZILY_UNPACK",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_CONV_IM2COL",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_PACK_CONV2DTRANSPOSE",()=>it.getBool("WEBGL_PACK"));it.registerFlag("WEBGL_MAX_TEXTURE_SIZE",()=>nL(it.getNumber("WEBGL_VERSION")));it.registerFlag("WEBGL_MAX_TEXTURES_IN_SHADER",()=>sL(it.getNumber("WEBGL_VERSION")));it.registerFlag("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION",()=>{const n=it.getNumber("WEBGL_VERSION");return n===0?0:oL(n)});it.registerFlag("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE",()=>it.getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION")>0&&!bm());it.registerFlag("WEBGL_RENDER_FLOAT32_CAPABLE",()=>rL(it.getNumber("WEBGL_VERSION")));it.registerFlag("WEBGL_RENDER_FLOAT32_ENABLED",()=>it.getBool("WEBGL_FORCE_F16_TEXTURES")?!1:it.getBool("WEBGL_RENDER_FLOAT32_CAPABLE"));it.registerFlag("WEBGL_DOWNLOAD_FLOAT_ENABLED",()=>iL(it.getNumber("WEBGL_VERSION")));it.registerFlag("WEBGL_FENCE_API_ENABLED",()=>lL(it.getNumber("WEBGL_VERSION")));it.registerFlag("WEBGL_SIZE_UPLOAD_UNIFORM",()=>it.getBool("WEBGL_RENDER_FLOAT32_ENABLED")?4:0);it.registerFlag("WEBGL_DELETE_TEXTURE_THRESHOLD",()=>-1,n=>{if(typeof n!="number")throw new Error(`WEBGL_DELETE_TEXTURE_THRESHOLD must be a number but got ${n}.`);if(n<0&&n!==-1)throw new Error(`WEBGL_DELETE_TEXTURE_THRESHOLD must be -1 (indicating never delete) or at least 0, but got ${n}.`)});it.registerFlag("WEBGL_FLUSH_THRESHOLD",()=>bm()?1:-1,n=>{if(typeof n!="number")throw new Error(`WEBGL_FLUSH_THRESHOLD must be a number but got ${n}.`);if(n<0&&n!==-1)throw new Error(`WEBGL_FLUSH_THRESHOLD must be -1 (indicating never manual flush) or at least 0, but got ${n}.`)});it.registerFlag("CPU_HANDOFF_SIZE_THRESHOLD",()=>128);it.registerFlag("WEBGL_USE_SHAPES_UNIFORMS",()=>!1);it.registerFlag("TOPK_LAST_DIM_CPU_HANDOFF_SIZE_THRESHOLD",()=>1e5);it.registerFlag("TOPK_K_CPU_HANDOFF_THRESHOLD",()=>128);it.registerFlag("WEBGL_EXP_CONV",()=>!1);it.registerFlag("SOFTWARE_WEBGL_ENABLED",()=>it.getBool("IS_TEST"));it.registerFlag("WEBGL_MAX_SIZE_FOR_NARROW_TEXTURE",()=>1/0);it.registerFlag("WEBGL_AUTO_SQUARIFY_NARROW_TEXTURE_SHAPE",()=>!1);it.registerFlag("WEBGL2_ISNAN_CUSTOM",()=>!1);it.registerFlag("ENGINE_COMPILE_ONLY",()=>!1);function Ae(){let n,t,e,s,o,r,i,a,l,c;return L().getNumber("WEBGL_VERSION")===2?(n="#version 300 es",t="in",e="out",s="in",o="texture",r="outputColor",i="out vec4 outputColor;",a=L().getBool("WEBGL2_ISNAN_CUSTOM")?`
      bool isnan_custom(float val) {
        uint floatToUint = floatBitsToUint(val);
        return (floatToUint & 0x7fffffffu) > 0x7f800000u;
      }

      bvec4 isnan_custom(vec4 val) {
        return bvec4(isnan_custom(val.x),
          isnan_custom(val.y), isnan_custom(val.z), isnan_custom(val.w));
      }

      #define isnan(value) isnan_custom(value)
    `:"",l="",c=`
      #define round(value) newRound(value)
      int newRound(float value) {
        return int(floor(value + 0.5));
      }

      ivec4 newRound(vec4 value) {
        return ivec4(floor(value + vec4(0.5)));
      }
    `):(n="",t="attribute",e="varying",s="varying",o="texture2D",r="gl_FragColor",i="",a=`
      #define isnan(value) isnan_custom(value)
      bool isnan_custom(float val) {
        return (val > 0. || val < 1. || val == 0.) ? false : true;
      }
      bvec4 isnan_custom(vec4 val) {
        return bvec4(isnan(val.x), isnan(val.y), isnan(val.z), isnan(val.w));
      }
    `,l=`
      uniform float INFINITY;

      bool isinf(float val) {
        return abs(val) == INFINITY;
      }
      bvec4 isinf(vec4 val) {
        return equal(abs(val), vec4(INFINITY));
      }
    `,c=`
      int round(float value) {
        return int(floor(value + 0.5));
      }

      ivec4 round(vec4 value) {
        return ivec4(floor(value + vec4(0.5)));
      }
    `),{version:n,attribute:t,varyingVs:e,varyingFs:s,texture2D:o,output:r,defineOutput:i,defineSpecialNaN:a,defineSpecialInf:l,defineRound:c}}function co(n,t,e="index"){const s=lt(t);return s.map((o,r)=>{const i=`int ${n[r]} = ${e} / ${o}`,a=r===s.length-1?`int ${n[r+1]} = ${e} - ${n[r]} * ${o}`:`index -= ${n[r]} * ${o}`;return`${i}; ${a};`}).join("")}function ic(n,t,e="index"){const s=lt(t);return s.map((o,r)=>{const i=`int ${n[r]} = ${e} / outShapeStrides[${r}]`,a=r===s.length-1?`int ${n[r+1]} = ${e} - ${n[r]} * outShapeStrides[${r}]`:`index -= ${n[r]} * outShapeStrides[${r}]`;return`${i}; ${a};`}).join("")}function cL(n,t){const e=n.length,s=n.map(r=>`${t}[${r}]`),o=new Array(e-1);o[e-2]=s[e-1];for(let r=e-3;r>=0;--r)o[r]=`(${o[r+1]} * ${s[r+1]})`;return o}function uL(n,t,e="index"){const s=n.map((r,i)=>i),o=cL(s,t);return o.map((r,i)=>{const a=`int ${n[i]} = ${e} / ${o[i]}`,l=i===o.length-1?`int ${n[i+1]} = ${e} - ${n[i]} * ${o[i]}`:`index -= ${n[i]} * ${o[i]}`;return`${a}; ${l};`}).join("")}function Gd(n){const t=lt(n).map(e=>e.toString());return`
  int getFlatIndex(ivec3 coords) {
    return coords.x * ${t[0]} + coords.y * ${t[1]} + coords.z;
  }
`}function Hd(){return`
  int getFlatIndex(ivec3 coords) {
    return coords.x * outShapeStrides[0] + coords.y * outShapeStrides[1] + coords.z;
  }
`}const $0=`
  const float FLOAT_MAX = 1.70141184e38;
  const float FLOAT_MIN = 1.17549435e-38;

  lowp vec4 encode_float(highp float v) {
    if (isnan(v)) {
      return vec4(255, 255, 255, 255);
    }

    highp float av = abs(v);

    if(av < FLOAT_MIN) {
      return vec4(0.0, 0.0, 0.0, 0.0);
    } else if(v > FLOAT_MAX) {
      return vec4(0.0, 0.0, 128.0, 127.0) / 255.0;
    } else if(v < -FLOAT_MAX) {
      return vec4(0.0, 0.0,  128.0, 255.0) / 255.0;
    }

    highp vec4 c = vec4(0,0,0,0);

    highp float e = floor(log2(av));
    highp float m = exp2(fract(log2(av))) - 1.0;

    c[2] = floor(128.0 * m);
    m -= c[2] / 128.0;
    c[1] = floor(32768.0 * m);
    m -= c[1] / 32768.0;
    c[0] = floor(8388608.0 * m);

    highp float ebias = e + 127.0;
    c[3] = floor(ebias / 2.0);
    ebias -= c[3] * 2.0;
    c[2] += floor(ebias) * 128.0;

    c[3] += 128.0 * step(0.0, -v);

    return c / 255.0;
  }
`;const{getBroadcastDims:I0}=Zv;function hL(n,t,e){const s=[];if(n.forEach(p=>{const f=W(p.shapeInfo.logicalShape);if(p.shapeInfo.isUniform?s.push(`uniform float ${p.name}${f>1?`[${f}]`:""};`):(s.push(`uniform sampler2D ${p.name};`),s.push(`uniform int offset${p.name};`)),e.enableShapeUniforms){const{uniformShape:m}=Kd(e.packedInputs,p.shapeInfo.logicalShape,p.shapeInfo.texShape);switch(m.length){case 1:s.push(`uniform int ${p.name}Shape;`);break;case 2:s.push(`uniform ivec2 ${p.name}Shape;`);break;case 3:s.push(`uniform ivec3 ${p.name}Shape;`);break;case 4:s.push(`uniform ivec4 ${p.name}Shape;`);break}s.push(`uniform ivec2 ${p.name}TexShape;`)}}),e.enableShapeUniforms){switch(t.logicalShape.length){case 1:s.push("uniform int outShape;");break;case 2:s.push("uniform ivec2 outShape;"),s.push("uniform int outShapeStrides;");break;case 3:s.push("uniform ivec3 outShape;"),s.push("uniform ivec2 outShapeStrides;");break;case 4:s.push("uniform ivec4 outShape;"),s.push("uniform ivec3 outShapeStrides;");break}s.push("uniform ivec2 outTexShape;")}e.customUniforms&&e.customUniforms.forEach(p=>{s.push(`uniform ${p.type} ${p.name}${p.arrayIndex?`[${p.arrayIndex}]`:""};`)});const o=s.join(`
`),r=n.map(p=>dL(p,t,e.packedInputs,e.enableShapeUniforms)).join(`
`),i=t.texShape,a=Ae(),l=mL(a);let c,u,h=bL(a);return t.isPacked?(c=pL(t.logicalShape,i,e.enableShapeUniforms),u=xL(a)):(c=fL(t.logicalShape,i,e.enableShapeUniforms),u=gL(a)),e.packedInputs&&(h+=$L),[h,l,u,o,c,r,e.userCode].join(`
`)}function Ho(n,t=!1){const e=n.shapeInfo.logicalShape;switch(e.length){case 0:return OL(n,t);case 1:return LL(n,t);case 2:return PL(n,t);case 3:return BL(n,t);case 4:return WL(n,t);case 5:return UL(n);case 6:return GL(n);default:throw new Error(`${e.length}-D input sampling is not yet supported`)}}function k0(n,t){switch(n.shapeInfo.logicalShape.length){case 0:return FL(n);case 1:return _L(n,t);case 2:return ML(n,t);case 3:return zL(n,t);default:return VL(n,t)}}function dL(n,t,e=!1,s){let o="";e?o+=k0(n,s):o+=Ho(n,s);const r=n.shapeInfo.logicalShape,i=t.logicalShape;return r.length<=i.length&&(e?o+=HL(n,t):o+=KL(n,t)),o}function pL(n,t,e){switch(n.length){case 0:return v0();case 1:return IL(n,t,e);case 2:return DL(n,t,e);case 3:return vL(n,t,e);default:return NL(n,t,e)}}function fL(n,t,e){switch(n.length){case 0:return v0();case 1:return kL(n,t,e);case 2:return AL(n,t,e);case 3:return SL(n,t,e);case 4:return TL(n,t,e);case 5:return EL(n,t);case 6:return RL(n,t);default:throw new Error(`${n.length}-D output sampling is not yet supported`)}}function mL(n){return`
    float sampleTexture(sampler2D textureSampler, vec2 uv) {
      return ${n.texture2D}(textureSampler, uv).r;
    }
  `}function gL(n){return`
    void setOutput(float val) {
      ${n.output} = vec4(val, 0, 0, 0);
    }
  `}function xL(n){return`
    void setOutput(vec4 val) {
      ${n.output} = val;
    }
  `}function bL(n){return`${n.version}
    precision highp float;
    precision highp int;
    precision highp sampler2D;
    ${n.varyingFs} vec2 resultUV;
    ${n.defineOutput}
    const vec2 halfCR = vec2(0.5, 0.5);

    struct ivec5
    {
      int x;
      int y;
      int z;
      int w;
      int u;
    };

    struct ivec6
    {
      int x;
      int y;
      int z;
      int w;
      int u;
      int v;
    };

    uniform float NAN;
    ${n.defineSpecialNaN}
    ${n.defineSpecialInf}
    ${n.defineRound}

    int imod(int x, int y) {
      return x - y * (x / y);
    }

    int idiv(int a, int b, float sign) {
      int res = a / b;
      int mod = imod(a, b);
      if (sign < 0. && mod != 0) {
        res -= 1;
      }
      return res;
    }

    //Based on the work of Dave Hoskins
    //https://www.shadertoy.com/view/4djSRW
    #define HASHSCALE1 443.8975
    float random(float seed){
      vec2 p = resultUV * seed;
      vec3 p3  = fract(vec3(p.xyx) * HASHSCALE1);
      p3 += dot(p3, p3.yzx + 19.19);
      return fract((p3.x + p3.y) * p3.z);
    }

    ${yL}
    ${wL}
    ${CL}
  `}const yL=`
vec2 uvFromFlat(int texNumR, int texNumC, int index) {
  int texR = index / texNumC;
  int texC = index - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
vec2 packedUVfrom1D(int texNumR, int texNumC, int index) {
  int texelIndex = index / 2;
  int texR = texelIndex / texNumC;
  int texC = texelIndex - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,wL=`
vec2 packedUVfrom2D(int texelsInLogicalRow, int texNumR,
  int texNumC, int row, int col) {
  int texelIndex = (row / 2) * texelsInLogicalRow + (col / 2);
  int texR = texelIndex / texNumC;
  int texC = texelIndex - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,CL=`
vec2 packedUVfrom3D(int texNumR, int texNumC,
    int texelsInBatch, int texelsInLogicalRow, int b,
    int row, int col) {
  int index = b * texelsInBatch + (row / 2) * texelsInLogicalRow + (col / 2);
  int texR = index / texNumC;
  int texC = index - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,$L=`
  float getChannel(vec4 frag, vec2 innerDims) {
    vec2 modCoord = mod(innerDims, 2.);
    return modCoord.x == 0. ?
      (modCoord.y == 0. ? frag.r : frag.g) :
      (modCoord.y == 0. ? frag.b : frag.a);
  }
  float getChannel(vec4 frag, int dim) {
    float modCoord = mod(float(dim), 2.);
    return modCoord == 0. ? frag.r : frag.g;
  }
`;function v0(){return`
    int getOutputCoords() {
      return 0;
    }
  `}function IL(n,t,e){const s=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)];return s[0]===1?e?`
      int getOutputCoords() {
        return 2 * int(resultUV.x * ceil(float(outTexShape[1]) / 2.0));
      }
    `:`
      int getOutputCoords() {
        return 2 * int(resultUV.x * ${s[1]}.0);
      }
    `:s[1]===1?e?`
      int getOutputCoords() {
        return 2 * int(resultUV.y * ceil(float(outTexShape[0]) / 2.0));
      }
    `:`
      int getOutputCoords() {
        return 2 * int(resultUV.y * ${s[0]}.0);
      }
    `:e?`
    int getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      return 2 * (resTexRC.x * packedTexShape[1] + resTexRC.y);
    }
  `:`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${s[0]}, ${s[1]}));
      return 2 * (resTexRC.x * ${s[1]} + resTexRC.y);
    }
  `}function kL(n,t,e){return t[0]===1?e?`
      int getOutputCoords() {
        return int(resultUV.x * float(outTexShape[1]));
      }
    `:`
      int getOutputCoords() {
        return int(resultUV.x * ${t[1]}.0);
      }
    `:t[1]===1?e?`
      int getOutputCoords() {
        return int(resultUV.y * float(outTexShape[0]));
      }
    `:`
      int getOutputCoords() {
        return int(resultUV.y * ${t[0]}.0);
      }
    `:e?`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(outTexShape[0], outTexShape[1]));
      return resTexRC.x * outTexShape[1] + resTexRC.y;
    }
  `:`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      return resTexRC.x * ${t[1]} + resTexRC.y;
    }
  `}function vL(n,t,e){if(e)return`
    ivec3 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      int texelsInLogicalRow = int(ceil(float(outShape[2]) / 2.0));
      int texelsInBatch = texelsInLogicalRow * int(ceil(float(outShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;

      int b = index / texelsInBatch;
      index -= b * texelsInBatch;

      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec3(b, r, c);
    }
  `;const s=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)],o=Math.ceil(n[2]/2),r=o*Math.ceil(n[1]/2);return`
    ivec3 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${s[0]}, ${s[1]}));
      int index = resTexRC.x * ${s[1]} + resTexRC.y;

      int b = index / ${r};
      index -= b * ${r};

      int r = 2 * (index / ${o});
      int c = imod(index, ${o}) * 2;

      return ivec3(b, r, c);
    }
  `}function SL(n,t,e){if(e)return`
  ivec3 getOutputCoords() {
    ivec2 resTexRC = ivec2(resultUV.yx *
                           vec2(outTexShape[0], outTexShape[1]));
    int index = resTexRC.x * outTexShape[1] + resTexRC.y;
    ${ic(["r","c","d"],n)}
    return ivec3(r, c, d);
  }
`;const s=co(["r","c","d"],n);return`
    ivec3 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      ${s}
      return ivec3(r, c, d);
    }
  `}function NL(n,t,e){if(e)return`
    ivec4 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;

      int texelsInLogicalRow = int(ceil(float(outShape[3]) / 2.0));
      int texelsInBatch = texelsInLogicalRow * int(ceil(float(outShape[2]) / 2.0));
      int texelsInBatchN = texelsInBatch * outShape[1];

      int b2 = index / texelsInBatchN;
      index -= b2 * texelsInBatchN;

      int b = index / texelsInBatch;
      index -= b * texelsInBatch;

      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec4(b2, b, r, c);
    }
  `;const s=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)],o=Math.ceil(n[n.length-1]/2),r=o*Math.ceil(n[n.length-2]/2);let i=r,a="",l="b, r, c";for(let c=2;c<n.length-1;c++)i*=n[n.length-c-1],a=`
      int b${c} = index / ${i};
      index -= b${c} * ${i};
    `+a,l=`b${c}, `+l;return`
    ivec${n.length} getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${s[0]}, ${s[1]}));
      int index = resTexRC.x * ${s[1]} + resTexRC.y;

      ${a}

      int b = index / ${r};
      index -= b * ${r};

      int r = 2 * (index / ${o});
      int c = imod(index, ${o}) * 2;

      return ivec${n.length}(${l});
    }
  `}function TL(n,t,e){if(e)return`
    ivec4 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(outTexShape[0], outTexShape[1]));
      int index = resTexRC.x * outTexShape[1] + resTexRC.y;
      ${ic(["r","c","d","d2"],n)}
      return ivec4(r, c, d, d2);
    }
  `;const s=co(["r","c","d","d2"],n);return`
    ivec4 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      ${s}
      return ivec4(r, c, d, d2);
    }
  `}function EL(n,t){const e=co(["r","c","d","d2","d3"],n);return`
    ivec5 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx * vec2(${t[0]},
                             ${t[1]}));

      int index = resTexRC.x * ${t[1]} + resTexRC.y;

      ${e}

      ivec5 outShape = ivec5(r, c, d, d2, d3);
      return outShape;
    }
  `}function RL(n,t){const e=co(["r","c","d","d2","d3","d4"],n);return`
    ivec6 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;

      ${e}

      ivec6 result = ivec6(r, c, d, d2, d3, d4);
      return result;
    }
  `}function DL(n,t,e){const s=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)];if(Et(n,t))return e?`
      ivec2 getOutputCoords() {
        ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
        return 2 * ivec2(resultUV.yx * vec2(packedTexShape[0], packedTexShape[1]));
      }
    `:`
      ivec2 getOutputCoords() {
        return 2 * ivec2(resultUV.yx * vec2(${s[0]}, ${s[1]}));
      }
    `;const o=Math.ceil(n[1]/2);return e?`
    ivec2 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      int texelsInLogicalRow = int(ceil(float(outShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));

      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;
      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec2(r, c);
    }
  `:`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${s[0]}, ${s[1]}));

      int index = resTexRC.x * ${s[1]} + resTexRC.y;
      int r = 2 * (index / ${o});
      int c = imod(index, ${o}) * 2;

      return ivec2(r, c);
    }
  `}function AL(n,t,e){return Et(n,t)?e?`
      ivec2 getOutputCoords() {
        return ivec2(resultUV.yx * vec2(outTexShape[0], outTexShape[1]));
      }
    `:`
      ivec2 getOutputCoords() {
        return ivec2(resultUV.yx * vec2(${t[0]}, ${t[1]}));
      }
    `:n[1]===1?e?`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(outTexShape[0], outTexShape[1]));
        int index = resTexRC.x * outTexShape[1] + resTexRC.y;
        return ivec2(index, 0);
      }
    `:`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(${t[0]}, ${t[1]}));
        int index = resTexRC.x * ${t[1]} + resTexRC.y;
        return ivec2(index, 0);
      }
    `:n[0]===1?e?`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(outTexShape[0], outTexShape[1]));
        int index = resTexRC.x * outTexShape[1] + resTexRC.y;
        return ivec2(0, index);
      }
    `:`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(${t[0]}, ${t[1]}));
        int index = resTexRC.x * ${t[1]} + resTexRC.y;
        return ivec2(0, index);
      }
    `:e?`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(outTexShape[0], outTexShape[1]));
      int index = resTexRC.x * outTexShape[1] + resTexRC.y;
      int r = index / outShape[1];
      int c = index - r * outShape[1];
      return ivec2(r, c);
    }
  `:`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      int r = index / ${n[1]};
      int c = index - r * ${n[1]};
      return ivec2(r, c);
    }
  `}function uo(n){return`offset${n}`}function FL(n){const t=n.name,e="get"+t.charAt(0).toUpperCase()+t.slice(1),s=Ae();return`
    vec4 ${e}() {
      return ${s.texture2D}(${t}, halfCR);
    }
  `}function OL(n,t){const e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1);if(n.shapeInfo.isUniform)return`float ${s}() {return ${e};}`;const[o,r]=n.shapeInfo.texShape;if(o===1&&r===1)return`
      float ${s}() {
        return sampleTexture(${e}, halfCR);
      }
    `;const i=uo(e);if(t)return`
    float ${s}() {
      vec2 uv = uvFromFlat(${e}TexShape[0], ${e}TexShape[1], ${i});
      return sampleTexture(${e}, uv);
    }
  `;const[a,l]=n.shapeInfo.texShape;return`
    float ${s}() {
      vec2 uv = uvFromFlat(${a}, ${l}, ${i});
      return sampleTexture(${e}, uv);
    }
  `}function _L(n,t){const e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1),o=n.shapeInfo.texShape,r=Ae();if(t)return`
    vec4 ${s}(int index) {
      ivec2 packedTexShape = ivec2(ceil(float(${e}TexShape[0]) / 2.0), ceil(float(${e}TexShape[1]) / 2.0));
      vec2 uv = packedUVfrom1D(
        packedTexShape[0], packedTexShape[1], index);
      return ${r.texture2D}(${e}, uv);
    }
  `;const i=[Math.ceil(o[0]/2),Math.ceil(o[1]/2)];return`
    vec4 ${s}(int index) {
      vec2 uv = packedUVfrom1D(
        ${i[0]}, ${i[1]}, index);
      return ${r.texture2D}(${e}, uv);
    }
  `}function LL(n,t){const e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1);if(n.shapeInfo.isUniform)return`
      float ${s}(int index) {
        ${Ko(n)}
      }
    `;const o=n.shapeInfo.texShape,r=o[0],i=o[1];if(i===1&&r===1)return`
      float ${s}(int index) {
        return sampleTexture(${e}, halfCR);
      }
    `;const a=uo(e);return i===1?t?`
      float ${s}(int index) {
        vec2 uv = vec2(0.5, (float(index + ${a}) + 0.5) / float(${e}TexShape[0]));
        return sampleTexture(${e}, uv);
      }
    `:`
      float ${s}(int index) {
        vec2 uv = vec2(0.5, (float(index + ${a}) + 0.5) / ${r}.0);
        return sampleTexture(${e}, uv);
      }
    `:r===1?t?`
      float ${s}(int index) {
        vec2 uv = vec2((float(index + ${a}) + 0.5) / float(${e}TexShape[1]), 0.5);
        return sampleTexture(${e}, uv);
      }
    `:`
      float ${s}(int index) {
        vec2 uv = vec2((float(index + ${a}) + 0.5) / ${i}.0, 0.5);
        return sampleTexture(${e}, uv);
      }
    `:t?`
    float ${s}(int index) {
      vec2 uv = uvFromFlat(${e}TexShape[0], ${e}TexShape[1], index + ${a});
      return sampleTexture(${e}, uv);
    }
  `:`
    float ${s}(int index) {
      vec2 uv = uvFromFlat(${r}, ${i}, index + ${a});
      return sampleTexture(${e}, uv);
    }
  `}function ML(n,t){const e=n.shapeInfo.logicalShape,s=n.name,o="get"+s.charAt(0).toUpperCase()+s.slice(1),r=n.shapeInfo.texShape,i=r[0],a=r[1],l=Ae();if(r!=null&&Et(e,r))return t?`
      vec4 ${o}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${s}TexShape[1], ${s}TexShape[0]);

        return ${l.texture2D}(${s}, uv);
      }
    `:`
      vec4 ${o}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${a}.0, ${i}.0);

        return ${l.texture2D}(${s}, uv);
      }
    `;if(t)return`
    vec4 ${o}(int row, int col) {
      ivec2 packedTexShape = ivec2(ceil(float(${s}TexShape[0]) / 2.0), ceil(float(${s}TexShape[1]) / 2.0));
      int valuesPerRow = int(ceil(float(${s}Shape[1]) / 2.0));
      vec2 uv = packedUVfrom2D(valuesPerRow, packedTexShape[0], packedTexShape[1], row, col);
      return ${l.texture2D}(${s}, uv);
    }
  `;const c=[Math.ceil(r[0]/2),Math.ceil(r[1]/2)],u=Math.ceil(e[1]/2);return`
    vec4 ${o}(int row, int col) {
      vec2 uv = packedUVfrom2D(${u}, ${c[0]}, ${c[1]}, row, col);
      return ${l.texture2D}(${s}, uv);
    }
  `}function PL(n,t){const e=n.shapeInfo.logicalShape,s=n.name,o="get"+s.charAt(0).toUpperCase()+s.slice(1),r=n.shapeInfo.texShape;if(r!=null&&Et(e,r)){if(t)return`
      float ${o}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${s}TexShape[1], ${s}TexShape[0]);
        return sampleTexture(${s}, uv);
      }
    `;const d=r[0],p=r[1];return`
    float ${o}(int row, int col) {
      vec2 uv = (vec2(col, row) + halfCR) / vec2(${p}.0, ${d}.0);
      return sampleTexture(${s}, uv);
    }
  `}const{newShape:i,keptDims:a}=ys(e),l=i;if(l.length<e.length){const d=jo(n,l),p=["row","col"];return`
      ${Ho(d,t)}
      float ${o}(int row, int col) {
        return ${o}(${qo(p,a)});
      }
    `}if(n.shapeInfo.isUniform)return`
      float ${o}(int row, int col) {
        int index = round(dot(vec2(row, col), vec2(${e[1]}, 1)));
        ${Ko(n)}
      }
    `;const c=r[0],u=r[1],h=uo(s);return u===1?t?`
      float ${o}(int row, int col) {
        float index = dot(vec3(row, col, ${h}), vec3(${s}Shape[1], 1, 1));
        vec2 uv = vec2(0.5, (index + 0.5) / float(${s}TexShape[0]));
        return sampleTexture(${s}, uv);
      }
    `:`
    float ${o}(int row, int col) {
      float index = dot(vec3(row, col, ${h}), vec3(${e[1]}, 1, 1));
      vec2 uv = vec2(0.5, (index + 0.5) / ${c}.0);
      return sampleTexture(${s}, uv);
    }
  `:c===1?t?`
      float ${o}(int row, int col) {
        float index = dot(vec3(row, col, ${h}), vec3(${s}Shape[1], 1, 1));
        vec2 uv = vec2((index + 0.5) / float(${s}TexShape[1]), 0.5);
        return sampleTexture(${s}, uv);
      }
    `:`
    float ${o}(int row, int col) {
      float index = dot(vec3(row, col, ${h}), vec3(${e[1]}, 1, 1));
      vec2 uv = vec2((index + 0.5) / ${u}.0, 0.5);
      return sampleTexture(${s}, uv);
    }
  `:t?`
      float ${o}(int row, int col) {
        // Explicitly use integer operations as dot() only works on floats.
        int index = row * ${s}Shape[1] + col + ${h};
        vec2 uv = uvFromFlat(${s}TexShape[0], ${s}TexShape[1], index);
        return sampleTexture(${s}, uv);
      }
    `:`
  float ${o}(int row, int col) {
    // Explicitly use integer operations as dot() only works on floats.
    int index = row * ${e[1]} + col + ${h};
    vec2 uv = uvFromFlat(${c}, ${u}, index);
    return sampleTexture(${s}, uv);
  }
`}function zL(n,t){const e=n.shapeInfo.logicalShape,s=n.name,o="get"+s.charAt(0).toUpperCase()+s.slice(1),r=n.shapeInfo.texShape,i=[Math.ceil(r[0]/2),Math.ceil(r[1]/2)];if(e[0]===1){const d=e.slice(1),p=[1,2],f=jo(n,d),m=["b","row","col"];return`
        ${k0(f,t)}
        vec4 ${o}(int b, int row, int col) {
          return ${o}(${qo(m,p)});
        }
      `}const a=Ae();if(t)return`
    vec4 ${o}(int b, int row, int col) {
      ivec2 packedTexShape = ivec2(ceil(float(${s}TexShape[0]) / 2.0), ceil(float(${s}TexShape[1]) / 2.0));
      int valuesPerRow = int(ceil(float(${s}Shape[2]) / 2.0));
      int texelsInBatch = valuesPerRow * int(ceil(float(${s}Shape[1]) / 2.0));
      vec2 uv = packedUVfrom3D(
        packedTexShape[0], packedTexShape[1], texelsInBatch, valuesPerRow, b, row, col);
      return ${a.texture2D}(${s}, uv);
    }
  `;const l=i[0],c=i[1],u=Math.ceil(e[2]/2),h=u*Math.ceil(e[1]/2);return`
    vec4 ${o}(int b, int row, int col) {
      vec2 uv = packedUVfrom3D(
        ${l}, ${c}, ${h}, ${u}, b, row, col);
      return ${a.texture2D}(${s}, uv);
    }
  `}function BL(n,t){const e=n.shapeInfo.logicalShape,s=n.name,o="get"+s.charAt(0).toUpperCase()+s.slice(1),r=e[1]*e[2],i=e[2],{newShape:a,keptDims:l}=ys(e),c=a;if(c.length<e.length){const m=jo(n,c),g=["row","col","depth"];return`
        ${Ho(m,t)}
        float ${o}(int row, int col, int depth) {
          return ${o}(${qo(g,l)});
        }
      `}if(n.shapeInfo.isUniform)return`
      float ${o}(int row, int col, int depth) {
        int index = round(dot(vec3(row, col, depth),
                          vec3(${r}, ${i}, 1)));
        ${Ko(n)}
      }
    `;const u=n.shapeInfo.texShape,h=u[0],d=u[1],p=n.shapeInfo.flatOffset;if(d===r&&p==null)return t?`
      float ${o}(int row, int col, int depth) {
        int stride1 = ${s}Shape[2];
        float texR = float(row);
        float texC = dot(vec2(col, depth), vec2(stride1, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${s}TexShape[1], ${s}TexShape[0]);
        return sampleTexture(${s}, uv);
      }
    `:`
        float ${o}(int row, int col, int depth) {
          float texR = float(row);
          float texC = dot(vec2(col, depth), vec2(${i}, 1));
          vec2 uv = (vec2(texC, texR) + halfCR) /
                     vec2(${d}.0, ${h}.0);
          return sampleTexture(${s}, uv);
        }
      `;if(d===i&&p==null)return t?`
      float ${o}(int row, int col, int depth) {
        float texR = dot(vec2(row, col), vec2(${s}Shape[1], 1));
        float texC = float(depth);
        vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${s}TexShape[1], ${s}TexShape[0]);
        return sampleTexture(${s}, uv);
      }
    `:`
    float ${o}(int row, int col, int depth) {
      float texR = dot(vec2(row, col), vec2(${e[1]}, 1));
      float texC = float(depth);
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${d}.0, ${h}.0);
      return sampleTexture(${s}, uv);
    }
  `;const f=uo(s);return t?`
    float ${o}(int row, int col, int depth) {
      // Explicitly use integer operations as dot() only works on floats.
      int stride0 = ${s}Shape[1] * ${s}Shape[2];
      int stride1 = ${s}Shape[2];
      int index = row * stride0 + col * stride1 + depth + ${f};
      vec2 uv = uvFromFlat(${s}TexShape[0], ${s}TexShape[1], index);
      return sampleTexture(${s}, uv);
    }
    `:`
      float ${o}(int row, int col, int depth) {
        // Explicitly use integer operations as dot() only works on floats.
        int index = row * ${r} + col * ${i} + depth + ${f};
        vec2 uv = uvFromFlat(${h}, ${d}, index);
        return sampleTexture(${s}, uv);
      }
  `}function VL(n,t){const e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1),o=Ae();if(t)return`
    vec4 ${s}(int b2, int b, int row, int col) {
      int valuesPerRow = int(ceil(float(${e}Shape[3]) / 2.0));
      int texelsInBatch = valuesPerRow * int(ceil(float(${e}Shape[2]) / 2.0));
      int index = b * texelsInBatch + (row / 2) * valuesPerRow + (col / 2);
      texelsInBatch *= ${e}Shape[1];
      index = b2 * texelsInBatch + index;
      ivec2 packedTexShape = ivec2(ceil(float(${e}TexShape[0]) / 2.0), ceil(float(${e}TexShape[1]) / 2.0));
      int texR = index / packedTexShape[1];
      int texC = index - texR * packedTexShape[1];
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(packedTexShape[1], packedTexShape[0]); return ${o.texture2D}(${e}, uv);
    }
  `;const r=n.shapeInfo.logicalShape,i=r.length,a=n.shapeInfo.texShape,l=[Math.ceil(a[0]/2),Math.ceil(a[1]/2)],c=l[0],u=l[1],h=Math.ceil(r[i-1]/2);let d=h*Math.ceil(r[i-2]/2),p="int b, int row, int col",f=`b * ${d} + (row / 2) * ${h} + (col / 2)`;for(let m=2;m<i-1;m++)p=`int b${m}, `+p,d*=r[i-m-1],f=`b${m} * ${d} + `+f;return`
    vec4 ${s}(${p}) {
      int index = ${f};
      int texR = index / ${u};
      int texC = index - texR * ${u};
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${u}, ${c});
      return ${o.texture2D}(${e}, uv);
    }
  `}function WL(n,t){const e=n.shapeInfo.logicalShape,s=n.name,o="get"+s.charAt(0).toUpperCase()+s.slice(1),r=e[3],i=e[2]*r,a=e[1]*i,{newShape:l,keptDims:c}=ys(e);if(l.length<e.length){const b=jo(n,l),w=["row","col","depth","depth2"];return`
      ${Ho(b,t)}
      float ${o}(int row, int col, int depth, int depth2) {
        return ${o}(${qo(w,c)});
      }
    `}if(n.shapeInfo.isUniform)return`
      float ${o}(int row, int col, int depth, int depth2) {
        int index = round(dot(vec4(row, col, depth, depth2),
                          vec4(${a}, ${i}, ${r}, 1)));
        ${Ko(n)}
      }
    `;const u=n.shapeInfo.flatOffset,h=n.shapeInfo.texShape,d=h[0],p=h[1],f=`int stride2 = ${s}Shape[3];`,m=`int stride1 = ${s}Shape[2] * stride2;`,g=`int stride0 = ${s}Shape[1] * stride1;`;if(p===a&&u==null)return t?`
      float ${o}(int row, int col, int depth, int depth2) {
        ${f}
        ${m}
        float texR = float(row);
        float texC =
            dot(vec3(col, depth, depth2),
                vec3(stride1, stride2, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${s}TexShape[1], ${s}TexShape[0]);
        return sampleTexture(${s}, uv);
      }
    `:`
      float ${o}(int row, int col, int depth, int depth2) {
        float texR = float(row);
        float texC =
            dot(vec3(col, depth, depth2),
                vec3(${i}, ${r}, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${p}.0, ${d}.0);
        return sampleTexture(${s}, uv);
      }
    `;if(p===r&&u==null)return t?`
      float ${o}(int row, int col, int depth, int depth2) {
        float texR = dot(vec3(row, col, depth),
                         vec3(${s}Shape[1] * ${s}Shape[2], ${s}Shape[2], 1));
        float texC = float(depth2);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${s}TexShape[1], ${s}TexShape[0]);
        return sampleTexture(${s}, uv);
      }
    `:`
      float ${o}(int row, int col, int depth, int depth2) {
        float texR = dot(vec3(row, col, depth),
                         vec3(${e[1]*e[2]}, ${e[2]}, 1));
        float texC = float(depth2);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${p}.0, ${d}.0);
        return sampleTexture(${s}, uv);
      }
    `;const x=uo(s);return t?`
    float ${o}(int row, int col, int depth, int depth2) {
      // Explicitly use integer operations as dot() only works on floats.
      ${f}
      ${m}
      ${g}
      int index = row * stride0 + col * stride1 +
          depth * stride2 + depth2;
      vec2 uv = uvFromFlat(${s}TexShape[0], ${s}TexShape[1], index + ${x});
      return sampleTexture(${s}, uv);
    }
  `:`
    float ${o}(int row, int col, int depth, int depth2) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${a} + col * ${i} +
          depth * ${r} + depth2;
      vec2 uv = uvFromFlat(${d}, ${p}, index + ${x});
      return sampleTexture(${s}, uv);
    }
  `}function UL(n){const t=n.shapeInfo.logicalShape,e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1),o=t[4],r=t[3]*o,i=t[2]*r,a=t[1]*i,{newShape:l,keptDims:c}=ys(t);if(l.length<t.length){const m=jo(n,l),g=["row","col","depth","depth2","depth3"];return`
      ${Ho(m)}
      float ${s}(int row, int col, int depth, int depth2, int depth3) {
        return ${s}(${qo(g,c)});
      }
    `}if(n.shapeInfo.isUniform)return`
      float ${s}(int row, int col, int depth, int depth2, int depth3) {
        float index = dot(
          vec4(row, col, depth, depth2),
          vec4(${a}, ${i}, ${r}, ${o})) +
          depth3;
        ${Ko(n)}
      }
    `;const u=n.shapeInfo.flatOffset,h=n.shapeInfo.texShape,d=h[0],p=h[1];if(p===a&&u==null)return`
      float ${s}(int row, int col, int depth, int depth2, int depth3) {
        int texR = row;
        float texC = dot(vec4(col, depth, depth2, depth3),
                         vec4(${i}, ${r}, ${o}, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${p}.0, ${d}.0);
        return sampleTexture(${e}, uv);
      }
    `;if(p===o&&u==null)return`
      float ${s}(int row, int col, int depth, int depth2, int depth3) {
        float texR = dot(
          vec4(row, col, depth, depth2),
          vec4(${t[1]*t[2]*t[3]},
               ${t[2]*t[3]}, ${t[3]}, 1));
        int texC = depth3;
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${p}.0, ${d}.0);
        return sampleTexture(${e}, uv);
      }
    `;const f=uo(e);return`
    float ${s}(int row, int col, int depth, int depth2, int depth3) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${a} + col * ${i} + depth * ${r} +
          depth2 * ${o} + depth3 + ${f};
      vec2 uv = uvFromFlat(${d}, ${p}, index);
      return sampleTexture(${e}, uv);
    }
  `}function GL(n){const t=n.shapeInfo.logicalShape,e=n.name,s="get"+e.charAt(0).toUpperCase()+e.slice(1),{newShape:o,keptDims:r}=ys(t);if(o.length<t.length){const g=jo(n,o),x=["row","col","depth","depth2","depth3","depth4"];return`
      ${Ho(g)}
      float ${s}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        return ${s}(${qo(x,r)});
      }
    `}const i=t[5],a=t[4]*i,l=t[3]*a,c=t[2]*l,u=t[1]*c;if(n.shapeInfo.isUniform)return`
      float ${s}(int row, int col, int depth,
                  int depth2, int depth3, int depth4) {
        int index = round(dot(
          vec4(row, col, depth, depth2),
          vec4(${u}, ${c}, ${l}, ${a})) +
          dot(
            vec2(depth3, depth4),
            vec2(${i}, 1)));
        ${Ko(n)}
      }
    `;const h=n.shapeInfo.flatOffset,d=n.shapeInfo.texShape,p=d[0],f=d[1];if(f===u&&h==null)return`
      float ${s}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        int texR = row;
        float texC = dot(vec4(col, depth, depth2, depth3),
          vec4(${c}, ${l}, ${a}, ${i})) +
               float(depth4);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${f}.0, ${p}.0);
        return sampleTexture(${e}, uv);
      }
    `;if(f===i&&h==null)return`
      float ${s}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        float texR = dot(vec4(row, col, depth, depth2),
          vec4(${t[1]*t[2]*t[3]*t[4]},
               ${t[2]*t[3]*t[4]},
               ${t[3]*t[4]},
               ${t[4]})) + float(depth3);
        int texC = depth4;
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${f}.0, ${p}.0);
        return sampleTexture(${e}, uv);
      }
    `;const m=uo(e);return`
    float ${s}(int row, int col, int depth,
                  int depth2, int depth3, int depth4) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${u} + col * ${c} + depth * ${l} +
          depth2 * ${a} + depth3 * ${i} + depth4 + ${m};
      vec2 uv = uvFromFlat(${p}, ${f}, index);
      return sampleTexture(${e}, uv);
    }
  `}function Ko(n){const t=n.name,e=W(n.shapeInfo.logicalShape);return e<2?`return ${t};`:`
    for (int i = 0; i < ${e}; i++) {
      if (i == index) {
        return ${t}[i];
      }
    }
  `}function HL(n,t){const e=n.name,s=e.charAt(0).toUpperCase()+e.slice(1),o="get"+s+"AtOutCoords",r=n.shapeInfo.logicalShape.length,i=t.logicalShape.length,a=I0(n.shapeInfo.logicalShape,t.logicalShape),l=Ot(i),c=i-r;let u;const h=["x","y","z","w","u","v"];r===0?u="":i<2&&a.length>=1?u="coords = 0;":u=a.map(b=>`coords.${h[b+c]} = 0;`).join(`
`);let d="";i<2&&r>0?d="coords":d=n.shapeInfo.logicalShape.map((b,w)=>`coords.${h[w+c]}`).join(", ");let p="return outputValue;";const m=W(n.shapeInfo.logicalShape)===1,x=W(t.logicalShape)===1;if(r===1&&!m&&!x)p=`
      return vec4(outputValue.xy, outputValue.xy);
    `;else if(m&&!x)i===1?p=`
        return vec4(outputValue.x, outputValue.x, 0., 0.);
      `:p=`
        return vec4(outputValue.x);
      `;else if(a.length){const b=r-2,w=r-1;a.indexOf(b)>-1&&a.indexOf(w)>-1?p="return vec4(outputValue.x);":a.indexOf(b)>-1?p="return vec4(outputValue.x, outputValue.y, outputValue.x, outputValue.y);":a.indexOf(w)>-1&&(p="return vec4(outputValue.xx, outputValue.zz);")}return`
    vec4 ${o}() {
      ${l} coords = getOutputCoords();
      ${u}
      vec4 outputValue = get${s}(${d});
      ${p}
    }
  `}function KL(n,t){const e=n.name,s=e.charAt(0).toUpperCase()+e.slice(1),o="get"+s+"AtOutCoords",r=t.texShape,i=n.shapeInfo.texShape,a=n.shapeInfo.logicalShape.length,l=t.logicalShape.length;if(!n.shapeInfo.isUniform&&a===l&&n.shapeInfo.flatOffset==null&&Et(i,r))return`
      float ${o}() {
        return sampleTexture(${e}, resultUV);
      }
    `;const c=Ot(l),u=I0(n.shapeInfo.logicalShape,t.logicalShape),h=l-a;let d;const p=["x","y","z","w","u","v"];a===0?d="":l<2&&u.length>=1?d="coords = 0;":d=u.map(m=>`coords.${p[m+h]} = 0;`).join(`
`);let f="";return l<2&&a>0?f="coords":f=n.shapeInfo.logicalShape.map((m,g)=>`coords.${p[g+h]}`).join(", "),`
    float ${o}() {
      ${c} coords = getOutputCoords();
      ${d}
      return get${s}(${f});
    }
  `}function Ot(n){if(n<=1)return"int";if(n===2)return"ivec2";if(n===3)return"ivec3";if(n===4)return"ivec4";if(n===5)return"ivec5";if(n===6)return"ivec6";throw Error(`GPU for rank ${n} is not yet supported`)}function Kd(n,t,e){const{newShape:s,keptDims:o}=ys(t),r=t.length,i=n&&r===3&&t[0]===1,a=i?t.slice(1):s,l=!n&&r>1&&!Et(t,e)&&s.length<r||i;return{useSqueezeShape:l,uniformShape:l?a:t,keptDims:o}}function jo(n,t){const e=JSON.parse(JSON.stringify(n));return e.shapeInfo.logicalShape=t,e}function qo(n,t){return t.map(e=>n[e]).join(", ")}function jL(n,t,e,s){const o=e.map((u,h)=>{const d={logicalShape:u.shape,texShape:u.isUniform?null:u.texData.texShape,isUniform:u.isUniform,isPacked:u.isUniform?!1:u.texData.isPacked,flatOffset:null};return u.texData!=null&&u.texData.slice!=null&&u.texData.slice.flatOffset>0&&(d.flatOffset=u.texData.slice.flatOffset),{name:t.variableNames[h],shapeInfo:d}}),r=o.map(u=>u.shapeInfo),i={logicalShape:s.shape,texShape:s.texData.texShape,isUniform:!1,isPacked:s.texData.isPacked,flatOffset:null},a=hL(o,i,t),l=B_(n.gl,a),c=n.createProgram(l);return L().get("ENGINE_COMPILE_ONLY")?{program:t,fragmentShader:l,source:a,webGLProgram:c,inShapeInfos:r,outShapeInfo:i,variablesLocations:null,customUniformLocations:null,infLoc:null,nanLoc:null,outShapeLocation:null,outShapeStridesLocation:null,outTexShapeLocation:null}:(n.buildVao(c),Object.assign({program:t,fragmentShader:l,source:a,webGLProgram:c,inShapeInfos:r,outShapeInfo:i},S0(n,t,c)))}function S0(n,t,e){const s=[],o=[];let r,i,a,l=null,c=null;c=n.getUniformLocation(e,"NAN",!1),L().getNumber("WEBGL_VERSION")===1&&(l=n.getUniformLocation(e,"INFINITY",!1));const u=!1;for(const h of t.variableNames){const d={name:h,uniform:n.getUniformLocation(e,h,u),offset:n.getUniformLocation(e,`offset${h}`,u)};t.enableShapeUniforms&&(d.shape=n.getUniformLocation(e,`${h}Shape`,u),d.texShape=n.getUniformLocation(e,`${h}TexShape`,u)),s.push(d)}if(t.enableShapeUniforms&&(r=n.getUniformLocation(e,"outShape",u),a=n.getUniformLocation(e,"outShapeStrides",u),i=n.getUniformLocation(e,"outTexShape",u)),t.customUniforms)for(const h of t.customUniforms)o.push(n.getUniformLocation(e,h.name,u));return{variablesLocations:s,customUniformLocations:o,infLoc:l,nanLoc:c,outShapeLocation:r,outShapeStridesLocation:a,outTexShapeLocation:i}}function cf(n,t){if(n.length!==t.length)throw Error(`Binary was compiled with ${n.length} inputs, but was executed with ${t.length} inputs`);n.forEach((e,s)=>{const o=e.logicalShape,r=t[s],i=r.shape;if(!Et(o,i))throw Error(`Binary was compiled with different shapes than the current args. Shapes ${o} and ${i} must match`);if(e.isUniform&&r.isUniform)return;const a=e.texShape,l=r.isUniform?null:r.texData.texShape;if(!Et(a,l))throw Error(`Binary was compiled with different texture shapes than the current args. Shape ${a} and ${l} must match`)})}function qL(n,t,e,s,o){t.program.enableShapeUniforms||(cf(t.inShapeInfos,e),cf([t.outShapeInfo],[s]));const r=s.texData.texture,i=s.texData.texShape;s.texData.isPacked?n.setOutputPackedMatrixTexture(r.texture,i[0],i[1]):n.setOutputMatrixTexture(r.texture,i[0],i[1]),n.setProgram(t.webGLProgram),n.bindVertexArray(t.webGLProgram.vao),L().getNumber("WEBGL_VERSION")===1&&t.infLoc!==null&&n.gl.uniform1f(t.infLoc,1/0),t.nanLoc!==null&&n.gl.uniform1f(t.nanLoc,NaN);for(let l=0;l<e.length;++l){const c=e[l],{uniform:u,offset:h,shape:d,texShape:p}=t.variablesLocations[l];if(d){const{uniformShape:f}=Kd(t.program.packedInputs,c.shape,c.texData.texShape);switch(f.length){case 1:n.gl.uniform1iv(d,new Int32Array(f));break;case 2:n.gl.uniform2iv(d,new Int32Array(f));break;case 3:n.gl.uniform3iv(d,new Int32Array(f));break;case 4:n.gl.uniform4iv(d,new Int32Array(f));break}}if(p&&n.gl.uniform2i(p,c.texData.texShape[0],c.texData.texShape[1]),u!=null){if(c.isUniform){if(W(c.shape)<2)n.gl.uniform1f(u,c.uniformValues[0]);else{let f=c.uniformValues;f instanceof Float32Array||(f=new Float32Array(f)),n.gl.uniform1fv(u,f)}continue}c.texData.slice!=null&&h!=null&&n.gl.uniform1i(h,c.texData.slice.flatOffset),n.setInputMatrixTexture(c.texData.texture.texture,u,l)}}const a=t.outShapeLocation;if(a)switch(s.shape.length){case 1:n.gl.uniform1iv(a,new Int32Array(s.shape));break;case 2:n.gl.uniform2iv(a,new Int32Array(s.shape));break;case 3:n.gl.uniform3iv(a,new Int32Array(s.shape));break;case 4:n.gl.uniform4iv(a,new Int32Array(s.shape));break}if(t.outShapeStridesLocation){const l=lt(s.shape);switch(s.shape.length){case 2:n.gl.uniform1iv(t.outShapeStridesLocation,new Int32Array(l));break;case 3:n.gl.uniform2iv(t.outShapeStridesLocation,new Int32Array(l));break;case 4:n.gl.uniform3iv(t.outShapeStridesLocation,new Int32Array(l));break}}if(t.outTexShapeLocation&&n.gl.uniform2i(t.outTexShapeLocation,s.texData.texShape[0],s.texData.texShape[1]),t.program.customUniforms&&o)for(let l=0;l<t.program.customUniforms.length;++l){const c=t.program.customUniforms[l],u=t.customUniformLocations[l],h=o[l];if(c.type==="float")n.gl.uniform1fv(u,h);else if(c.type==="vec2")n.gl.uniform2fv(u,h);else if(c.type==="vec3")n.gl.uniform3fv(u,h);else if(c.type==="vec4")n.gl.uniform4fv(u,h);else if(c.type==="int")n.gl.uniform1iv(u,h);else if(c.type==="ivec2")n.gl.uniform2iv(u,h);else if(c.type==="ivec3")n.gl.uniform3iv(u,h);else if(c.type==="ivec4")n.gl.uniform4iv(u,h);else throw Error(`uniform type ${c.type} is not supported yet.`)}n.executeProgram()}function XL(n,t,e){let s="";t.concat(e).forEach(i=>{const a=i.texData!=null&&i.texData.slice!=null&&i.texData.slice.flatOffset>0;if(n.enableShapeUniforms&&!i.isUniform){const l=i.texData.texShape,{useSqueezeShape:c,uniformShape:u,keptDims:h}=Kd(n.packedInputs,i.shape,l);let d="",p="",f="";if(u.length===1&&n.packedInputs){const C=[Math.ceil(l[0]/2),Math.ceil(l[1]/2)];d=`${C[0]>1}_${C[1]>1}`}else if(u.length===2&&!n.packedInputs)p=`${u[0]>1}_${u[1]>1}`;else if(u.length>2&&!n.packedInputs){const C=lt(u);f=`${C[0]===l[1]}_${C[C.length-1]===l[1]}`}const m=i.shape.length,g=u.length===2&&Et(i.shape,l),x=W(i.shape)===1,b=To(i.shape,e.shape),w=!n.packedInputs&&m===e.shape.length&&Et(l,e.texData.texShape),y=n.packedInputs||u.length>2?"":`${l[0]>1}_${l[1]>1}`;s+=`${m}_${w}_${c?h:""}_${u.length}_${x}_${b}_${g}_${d}_${p}_${f}_${y}_${a}`}else{const l=i.isUniform?"uniform":i.texData.texShape;s+=`${i.shape}_${l}_${a}`}});const o=n.userCode;let r=n.constructor.name;return r+="_"+s+"_"+o+`${L().getNumber("WEBGL_VERSION")}`,r}function Se(n){return L().getBool("WEBGL_USE_SHAPES_UNIFORMS")&&n<=4}class YL{constructor(t){this.variableNames=["A"],this.packedInputs=!1,this.packedOutput=!0,this.outPackingScheme=Cr.DENSE,this.customUniforms=[{name:"texShape",type:"ivec2"}];const e=Ae();this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length),this.userCode=`
      ivec3 outCoordsFromFlatIndex(int index) {
        ${this.enableShapeUniforms?ic(["r","c","d"],t):co(["r","c","d"],t)}
        return ivec3(r, c, d);
      }

      void main() {
        ivec2 resTexRC = ivec2(resultUV.yx * vec2(texShape[0], texShape[1]));
        int index = 4 * (resTexRC.x * texShape[1] + resTexRC.y);

        vec4 result = vec4(0.);

        for (int i=0; i<4; i++) {
          int flatIndex = index + i;
          ivec3 rc = outCoordsFromFlatIndex(flatIndex);
          result[i] = getA(rc.x, rc.y, rc.z);
        }

        ${e.output} = result;
      }
    `}}class JL{constructor(t){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outPackingScheme=Cr.DENSE,this.customUniforms=[{name:"texShape",type:"ivec2"}];const e=Ae();this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length),this.userCode=`
      ivec3 outCoordsFromFlatIndex(int index) {
        ${this.enableShapeUniforms?ic(["r","c","d"],t):co(["r","c","d"],t)}
        return ivec3(r, c, d);
      }

      void main() {
        ivec2 resTexRC = ivec2(resultUV.yx * vec2(texShape[0], texShape[1]));
        int index = 4 * (resTexRC.x * texShape[1] + resTexRC.y);

        vec4 result = vec4(0.);

        for (int i=0; i<4; i++) {
          int flatIndex = index + i;
          ivec3 rc = outCoordsFromFlatIndex(flatIndex);
          result[i] = getChannel(getA(rc.x, rc.y, rc.z), vec2(rc.y, rc.z));
        }

        ${e.output} = result;
      }
    `}}class ZL{constructor(t){this.variableNames=["A"],this.outTexUsage=qe.DOWNLOAD;const e=Ae();this.outputShape=t,this.userCode=`
      ${$0}

      void main() {
        float x = getAAtOutCoords();
        ${e.output} = encode_float(x);
      }
    `}}class QL{constructor(t){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!1,this.outTexUsage=qe.DOWNLOAD;const e=Ae();this.outputShape=t,this.userCode=`
      ${$0}

      void main() {
        ivec3 coords = getOutputCoords();
        float x = getChannel(getAAtOutCoords(), vec2(coords.y, coords.z));
        ${e.output} = encode_float(x);
      }
    `}}const tM={R:0,G:1,B:2,A:3};class uf{constructor(t,e=!1,s="RGBA"){this.variableNames=["A"],this.customUniforms=[{name:"texShape",type:"ivec2"}];const o=Ae();this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length);let r="result";e&&(r="floor(result * 255. + 0.5)");let i="";for(let a=0;a<s.length;a++){const l=s[a];i+=`
          if(offset == ${a}) {
            result = values[${tM[l]}];
          }`}this.userCode=`
      ${this.enableShapeUniforms?Hd():Gd(t)}

      void main() {
        ivec3 coords = getOutputCoords();
        int flatIndex = getFlatIndex(coords);
        float result = 0.;
        int offset = imod(flatIndex, ${s.length});

        flatIndex = idiv(flatIndex, ${s.length}, 1.);

        int r = flatIndex / texShape[1];
        if (r < texShape[0]) {
          int c = imod(flatIndex, texShape[1]);
          vec2 uv = (vec2(c, r) + halfCR) / vec2(texShape[1], texShape[0]);
          vec4 values = ${o.texture2D}(A, uv);
          ${i}
        }
        ${o.output} = vec4(${r}, 0., 0., 0.);
      }
    `}}class eM{constructor(t,e=!1){this.variableNames=["A"],this.packedInputs=!1,this.packedOutput=!0,this.customUniforms=[{name:"texShape",type:"ivec2"}];const s=Ae();this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length);let o="",r="result";e&&(r="floor(result * 255. + 0.5)");for(let i=0;i<=1;i++)for(let a=0;a<=1;a++){const l=i*2+a;o+=`
          localCoords = coords;
          if(localCoords[2] + ${a} < ${this.enableShapeUniforms?"outShape[2]":`${t[2]}`}) {
          localCoords[2] += ${a};
          if (localCoords[1] + ${i} < ${this.enableShapeUniforms?"outShape[1]":`${t[1]}`}) {
            localCoords[1] += ${i};

            flatIndex = getFlatIndex(localCoords);
            offset = imod(flatIndex, 4);

            flatIndex = idiv(flatIndex, 4, 1.);

            int r = flatIndex / texShape[1];
            int c = imod(flatIndex, texShape[1]);
            vec2 uv = (vec2(c, r) + halfCR) / vec2(texShape[1], texShape[0]);
            values = ${s.texture2D}(A, uv);

            if (offset == 0) {
              result[${l}] = values[0];
            } else if (offset == 1) {
              result[${l}] = values[1];
            } else if (offset == 2) {
              result[${l}] = values[2];
            } else {
              result[${l}] = values[3];
            }
          }
        }
        `}this.userCode=`
        ${this.enableShapeUniforms?Hd():Gd(t)}

        void main() {
          ivec3 coords = getOutputCoords();

          vec4 result = vec4(0.);
          int flatIndex, r, c, offset;
          ivec3 localCoords;
          vec2 uv;
          vec4 values;

          ${o}

          ${s.output} = ${r};
        }
    `}}function nM(n){const t=Ae(),e=`${t.version}
    precision highp float;
    ${t.attribute} vec3 clipSpacePos;
    ${t.attribute} vec2 uv;
    ${t.varyingVs} vec2 resultUV;

    void main() {
      gl_Position = vec4(clipSpacePos, 1);
      resultUV = uv;
    }`;return z_(n,e)}function sM(n){const t=new Float32Array([-1,1,0,0,1,-1,-1,0,0,0,1,1,0,1,1,1,-1,0,1,0]);return G_(n,t)}function oM(n){const t=new Uint16Array([0,1,2,2,1,3]);return H_(n,t)}function Bi(n,t,e,s,o,r){j_(t,e);const i=K_(n),a=n.TEXTURE_2D;return nt(n,()=>n.bindTexture(a,i)),nt(n,()=>n.texParameteri(a,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE)),nt(n,()=>n.texParameteri(a,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE)),nt(n,()=>n.texParameteri(a,n.TEXTURE_MIN_FILTER,n.NEAREST)),nt(n,()=>n.texParameteri(a,n.TEXTURE_MAG_FILTER,n.NEAREST)),L().getNumber("WEBGL_VERSION")===1?nt(n,()=>n.texImage2D(a,0,s,t,e,0,o,r,null)):nt(n,()=>n.texStorage2D(a,1,s,t,e)),nt(n,()=>n.bindTexture(n.TEXTURE_2D,null)),{texture:i,texShape:[e,t]}}function N0(n){return n.internalFormatFloat}function rM(n,t,e,s){const[o,r]=Pi(t,e);return Bi(n,o,r,N0(s),s.textureFormatFloat,n.FLOAT)}function T0(n){return n.internalFormatHalfFloat}function iM(n,t,e,s){const[o,r]=Pi(t,e);return Bi(n,o,r,T0(s),s.textureFormatFloat,s.textureTypeHalfFloat)}function E0(n){return n.downloadTextureFormat}function aM(n,t,e,s){const[o,r]=Pi(t,e);return Bi(n,o,r,E0(s),n.RGBA,n.UNSIGNED_BYTE)}function R0(n){return n.internalFormatPackedFloat}function lM(n,t,e,s){const[o,r]=Go(t,e);return Bi(n,o,r,R0(s),n.RGBA,n.FLOAT)}function D0(n){return n.internalFormatPackedHalfFloat}function cM(n,t,e,s){const[o,r]=Go(t,e);return Bi(n,o,r,D0(s),n.RGBA,s.textureTypeHalfFloat)}function uM(n,t,e){return nt(n,()=>n.bindBuffer(n.ARRAY_BUFFER,e)),rf(n,t,"clipSpacePos",e,3,20,0)&&rf(n,t,"uv",e,2,20,12)}function hM(n,t,e,s,o,r){nt(n,()=>n.bindTexture(n.TEXTURE_2D,t));let i,a,l;o instanceof Uint8Array?(i=new Uint8Array(e*s*4),a=n.UNSIGNED_BYTE,l=n.RGBA):(i=new Float32Array(e*s*4),a=n.FLOAT,l=r.internalFormatPackedFloat),i.set(o),L().getNumber("WEBGL_VERSION")===2?nt(n,()=>n.texSubImage2D(n.TEXTURE_2D,0,0,0,e,s,n.RGBA,a,i)):nt(n,()=>n.texImage2D(n.TEXTURE_2D,0,l,e,s,0,n.RGBA,a,i)),nt(n,()=>n.bindTexture(n.TEXTURE_2D,null))}function dM(n,t,e){nt(n,()=>n.bindTexture(n.TEXTURE_2D,t)),e.data instanceof Uint8Array?L().getNumber("WEBGL_VERSION")===2?nt(n,()=>n.texSubImage2D(n.TEXTURE_2D,0,0,0,e.width,e.height,n.RGBA,n.UNSIGNED_BYTE,e.data)):nt(n,()=>n.texImage2D(n.TEXTURE_2D,0,n.RGBA,e.width,e.height,0,n.RGBA,n.UNSIGNED_BYTE,e.data)):L().getNumber("WEBGL_VERSION")===2?nt(n,()=>n.texSubImage2D(n.TEXTURE_2D,0,0,0,n.RGBA,n.UNSIGNED_BYTE,e)):nt(n,()=>n.texImage2D(n.TEXTURE_2D,0,n.RGBA,n.RGBA,n.UNSIGNED_BYTE,e)),nt(n,()=>n.bindTexture(n.TEXTURE_2D,null))}function pM(n,t,e,s){const o=n.createBuffer();nt(n,()=>n.bindBuffer(n.PIXEL_PACK_BUFFER,o));const a=4*4*t*e;return nt(n,()=>n.bufferData(n.PIXEL_PACK_BUFFER,a,n.STREAM_READ)),nt(n,()=>n.readPixels(0,0,e,t,n.RGBA,n.FLOAT,0)),nt(n,()=>n.bindBuffer(n.PIXEL_PACK_BUFFER,null)),o}function fM(n,t,e){const s=n,o=new Float32Array(e);return s.bindBuffer(s.PIXEL_PACK_BUFFER,t),s.getBufferSubData(s.PIXEL_PACK_BUFFER,0,o),s.bindBuffer(s.PIXEL_PACK_BUFFER,null),o}function mM(n,t,e,s){const[o,r]=Pi(t,e),i=4,a=new Uint8Array(A_(t*e,i));return nt(n,()=>n.readPixels(0,0,o,r,s.downloadTextureFormat,n.UNSIGNED_BYTE,a)),new Float32Array(a.buffer)}function gM(n,t,e,s,o,r,i,a){const l=n,c=new Float32Array(F_(r,i));return l.bindBuffer(l.PIXEL_PACK_BUFFER,t),l.getBufferSubData(l.PIXEL_PACK_BUFFER,0,c),l.bindBuffer(l.PIXEL_PACK_BUFFER,null),c}function xM(n,t,e){const s=new Float32Array(t*e*4);return nt(n,()=>n.readPixels(0,0,e,t,n.RGBA,n.FLOAT,s)),s}class Ec{constructor(t){this.outputTexture=null,this.program=null,this.disposed=!1,this.itemsToPoll=[];const e=L().getNumber("WEBGL_VERSION");if(t!=null?(this.gl=t,E_(e,t)):this.gl=$n(e),t=this.gl,L().getNumber("WEBGL_VERSION")===2){const r=t;this.createVertexArray=()=>nt(r,()=>r.createVertexArray()),this.bindVertexArray=i=>nt(r,()=>r.bindVertexArray(i)),this.deleteVertexArray=i=>nt(r,()=>r.deleteVertexArray(i)),this.getVertexArray=()=>nt(r,()=>r.getParameter(r.VERTEX_ARRAY_BINDING))}else if(t!=null){const r=t.getExtension("OES_vertex_array_object");if(r==null)throw new Error("All WebGL1 implementations are expected to offer OES_vertex_array_object.");this.createVertexArray=()=>nt(t,()=>r.createVertexArrayOES()),this.bindVertexArray=i=>nt(t,()=>r.bindVertexArrayOES(i)),this.deleteVertexArray=i=>nt(t,()=>r.deleteVertexArrayOES(i)),this.getVertexArray=()=>nt(t,()=>t.getParameter(r.VERTEX_ARRAY_BINDING_OES))}let s="WEBGL_color_buffer_float";const o="EXT_color_buffer_half_float";if(this.parallelCompilationExtension=this.gl.getExtension("KHR_parallel_shader_compile"),L().getNumber("WEBGL_VERSION")===1){const r="OES_texture_float",i="OES_texture_half_float";if(this.textureFloatExtension=Ji(this.gl,r),on(this.gl,i))this.textureHalfFloatExtension=Ji(this.gl,i);else if(L().get("WEBGL_FORCE_F16_TEXTURES"))throw new Error("GL context does not support half float textures, yet the environment flag WEBGL_FORCE_F16_TEXTURES is set to true.");if(this.colorBufferFloatExtension=this.gl.getExtension(s),on(this.gl,o))this.colorBufferHalfFloatExtension=Ji(this.gl,o);else if(L().get("WEBGL_FORCE_F16_TEXTURES"))throw new Error("GL context does not support color renderable half floats, yet the environment flag WEBGL_FORCE_F16_TEXTURES is set to true.")}else if(s="EXT_color_buffer_float",on(this.gl,s))this.colorBufferFloatExtension=this.gl.getExtension(s);else if(on(this.gl,o))this.colorBufferHalfFloatExtension=this.gl.getExtension(o);else throw new Error("GL context does not support color renderable floats");this.vertexBuffer=sM(this.gl),this.indexBuffer=oM(this.gl),this.framebuffer=q_(this.gl),this.textureConfig=Ud(this.gl,this.textureHalfFloatExtension)}get debug(){return L().getBool("DEBUG")}dispose(){if(this.disposed)return;this.program!=null&&console.warn("Disposing a GPGPUContext that still has a bound WebGLProgram. This is probably a resource leak, delete the program with GPGPUContext.deleteProgram before disposing."),this.outputTexture!=null&&console.warn("Disposing a GPGPUContext that still has a bound output matrix texture.  This is probably a resource leak, delete the output matrix texture with GPGPUContext.deleteMatrixTexture before disposing.");const t=this.gl;nt(t,()=>t.finish()),nt(t,()=>t.bindFramebuffer(t.FRAMEBUFFER,null)),nt(t,()=>t.deleteFramebuffer(this.framebuffer)),nt(t,()=>t.bindBuffer(t.ARRAY_BUFFER,null)),nt(t,()=>t.bindBuffer(t.ELEMENT_ARRAY_BUFFER,null)),nt(t,()=>t.deleteBuffer(this.indexBuffer)),this.disposed=!0}createFloat32MatrixTexture(t,e){return this.throwIfDisposed(),rM(this.gl,t,e,this.textureConfig)}createFloat16MatrixTexture(t,e){return this.throwIfDisposed(),iM(this.gl,t,e,this.textureConfig)}createUnsignedBytesMatrixTexture(t,e){return this.throwIfDisposed(),aM(this.gl,t,e,this.textureConfig)}uploadPixelDataToTexture(t,e){this.throwIfDisposed(),dM(this.gl,t,e)}uploadDenseMatrixToTexture(t,e,s,o){this.throwIfDisposed(),hM(this.gl,t,e,s,o,this.textureConfig)}createFloat16PackedMatrixTexture(t,e){return this.throwIfDisposed(),cM(this.gl,t,e,this.textureConfig)}createPackedMatrixTexture(t,e){return this.throwIfDisposed(),lM(this.gl,t,e,this.textureConfig)}deleteMatrixTexture(t){this.throwIfDisposed(),this.outputTexture===t&&(af(this.gl,this.framebuffer),this.outputTexture=null),nt(this.gl,()=>this.gl.deleteTexture(t))}downloadByteEncodedFloatMatrixFromOutputTexture(t,e,s){return this.downloadMatrixDriver(t,()=>mM(this.gl,e,s,this.textureConfig))}downloadPackedMatrixFromBuffer(t,e,s,o,r,i){return gM(this.gl,t,e,s,o,r,i,this.textureConfig)}downloadFloat32MatrixFromBuffer(t,e){return fM(this.gl,t,e)}createBufferFromTexture(t,e,s){this.bindTextureToFrameBuffer(t);const o=pM(this.gl,e,s,this.textureConfig);return this.unbindTextureToFrameBuffer(),o}createAndWaitForFence(){const t=this.createFence(this.gl);return this.pollFence(t)}createFence(t){let e,s;if(L().getBool("WEBGL_FENCE_API_ENABLED")){const o=t,r=o.fenceSync(o.SYNC_GPU_COMMANDS_COMPLETE,0);t.flush(),s=()=>{const i=o.clientWaitSync(r,0,0);return i===o.ALREADY_SIGNALED||i===o.CONDITION_SATISFIED},e=r}else L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION")>0?(e=this.beginQuery(),this.endQuery(),s=()=>this.isQueryAvailable(e,L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION"))):s=()=>!0;return{query:e,isFencePassed:s}}downloadMatrixFromPackedTexture(t,e,s){return this.downloadMatrixDriver(t,()=>xM(this.gl,e,s))}createProgram(t){this.throwIfDisposed();const e=this.gl;this.vertexShader==null&&(this.vertexShader=nM(e));const s=W_(e);nt(e,()=>e.attachShader(s,this.vertexShader)),nt(e,()=>e.attachShader(s,t)),U_(e,s);const o=Object.assign(s,{vao:this.createVertexArray()});return this.debug&&vc(e,o),o}buildVao(t){this.setProgram(t),this.bindVertexArray(t.vao);const e=this.gl;nt(e,()=>e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,this.indexBuffer)),uM(e,t,this.vertexBuffer)}deleteProgram(t){this.throwIfDisposed(),t===this.program&&(this.program=null),t!=null&&(nt(this.gl,()=>this.gl.deleteProgram(t)),this.deleteVertexArray(t.vao))}setProgram(t){this.throwIfDisposed(),this.program=t,this.program!=null&&this.debug&&vc(this.gl,this.program),nt(this.gl,()=>this.gl.useProgram(t))}getUniformLocation(t,e,s=!0){return this.throwIfDisposed(),s?Y_(this.gl,t,e):J_(this.gl,t,e)}getAttributeLocation(t,e){return this.throwIfDisposed(),nt(this.gl,()=>this.gl.getAttribLocation(t,e))}getUniformLocationNoThrow(t,e){return this.throwIfDisposed(),this.gl.getUniformLocation(t,e)}setInputMatrixTexture(t,e,s){this.throwIfDisposed(),this.throwIfNoProgram(),Z_(this.gl,t,e,s)}setOutputMatrixTexture(t,e,s){this.setOutputMatrixTextureDriver(t,s,e)}setOutputPackedMatrixTexture(t,e,s){this.throwIfDisposed();const[o,r]=Go(e,s);this.setOutputMatrixTextureDriver(t,o,r)}setOutputMatrixWriteRegion(t,e,s,o){this.setOutputMatrixWriteRegionDriver(s,t,o,e)}setOutputPackedMatrixWriteRegion(t,e,s,o){throw new Error("setOutputPackedMatrixWriteRegion not implemented.")}debugValidate(){this.program!=null&&vc(this.gl,this.program),Zi(this.gl)}executeProgram(){this.throwIfDisposed(),this.throwIfNoProgram();const t=this.gl;if(this.debug){const e=this.getVertexArray();console.assert(e===this.program.vao,"VAO changed between setProgram and executeProgram!"),this.debugValidate()}nt(t,()=>t.drawElements(t.TRIANGLES,6,t.UNSIGNED_SHORT,0))}blockUntilAllProgramsCompleted(){this.throwIfDisposed(),nt(this.gl,()=>this.gl.finish())}getQueryTimerExtension(){return this.disjointQueryTimerExtension==null&&(this.disjointQueryTimerExtension=Ji(this.gl,L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION")===2?"EXT_disjoint_timer_query_webgl2":"EXT_disjoint_timer_query")),this.disjointQueryTimerExtension}getQueryTimerExtensionWebGL2(){return this.getQueryTimerExtension()}getQueryTimerExtensionWebGL1(){return this.getQueryTimerExtension()}beginQuery(){if(L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION")===2){const s=this.gl,o=this.getQueryTimerExtensionWebGL2(),r=s.createQuery();return s.beginQuery(o.TIME_ELAPSED_EXT,r),r}const t=this.getQueryTimerExtensionWebGL1(),e=t.createQueryEXT();return t.beginQueryEXT(t.TIME_ELAPSED_EXT,e),e}endQuery(){if(L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION")===2){const e=this.gl,s=this.getQueryTimerExtensionWebGL2();e.endQuery(s.TIME_ELAPSED_EXT);return}const t=this.getQueryTimerExtensionWebGL1();t.endQueryEXT(t.TIME_ELAPSED_EXT)}async waitForQueryAndGetTime(t){return await Zd(()=>this.disposed||this.isQueryAvailable(t,L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION"))),this.getQueryTime(t,L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION"))}getQueryTime(t,e){if(e===0)return null;if(e===2){const s=this.gl;return s.getQueryParameter(t,s.QUERY_RESULT)/1e6}else{const s=this.getQueryTimerExtensionWebGL1();return s.getQueryObjectEXT(t,s.QUERY_RESULT_EXT)/1e6}}isQueryAvailable(t,e){if(e===0)return!0;if(e===2){const s=this.gl,o=this.getQueryTimerExtensionWebGL2(),r=s.getQueryParameter(t,s.QUERY_RESULT_AVAILABLE);return this.disjoint==null&&(this.disjoint=this.gl.getParameter(o.GPU_DISJOINT_EXT)),r&&!this.disjoint}else{const s=this.getQueryTimerExtensionWebGL1(),o=s.getQueryObjectEXT(t,s.QUERY_RESULT_AVAILABLE_EXT);return this.disjoint==null&&(this.disjoint=this.gl.getParameter(s.GPU_DISJOINT_EXT)),o&&!this.disjoint}}pollFence(t){return new Promise(e=>{this.addItemToPoll(()=>t.isFencePassed(),()=>e())})}pollItems(){const t=bM(this.itemsToPoll.map(e=>e.isDoneFn));for(let e=0;e<=t;++e){const{resolveFn:s}=this.itemsToPoll[e];s()}this.itemsToPoll=this.itemsToPoll.slice(t+1)}addItemToPoll(t,e){if(this.itemsToPoll.push({isDoneFn:t,resolveFn:e}),this.itemsToPoll.length>1)return;let s;"setTimeoutCustom"in L().platform&&(s=L().platform.setTimeoutCustom.bind(L().platform)),Zd(()=>(this.pollItems(),this.itemsToPoll.length===0),()=>0,null,s)}bindTextureToFrameBuffer(t){this.throwIfDisposed(),Sc(this.gl,t,this.framebuffer),this.debug&&Zi(this.gl)}unbindTextureToFrameBuffer(){this.outputTexture!=null?(Sc(this.gl,this.outputTexture,this.framebuffer),this.debug&&Zi(this.gl)):af(this.gl,this.framebuffer)}downloadMatrixDriver(t,e){this.bindTextureToFrameBuffer(t);const s=e();return this.unbindTextureToFrameBuffer(),s}setOutputMatrixTextureDriver(t,e,s){this.throwIfDisposed();const o=this.gl;Sc(o,t,this.framebuffer),this.debug&&Zi(o),this.outputTexture=t,nt(o,()=>o.viewport(0,0,e,s)),nt(o,()=>o.scissor(0,0,e,s))}setOutputMatrixWriteRegionDriver(t,e,s,o){this.throwIfDisposed(),nt(this.gl,()=>this.gl.scissor(t,e,s,o))}throwIfDisposed(){if(this.disposed)throw new Error("Attempted to use disposed GPGPUContext.")}throwIfNoProgram(){if(this.program==null)throw new Error("No GPU program is currently set.")}}function bM(n){let t=0;for(;t<n.length&&n[t]();++t);return t-1}const{addImpl:yM,bincountImpl:A0,bincountReduceImpl:wM,bitwiseAndImpl:CM,castImpl:$M,ceilImpl:IM,concatImpl:kM,equalImpl:vM,expImpl:SM,expm1Impl:NM,floorImpl:TM,gatherNdImpl:EM,gatherV2Impl:RM,greaterImpl:DM,greaterEqualImpl:AM,lessImpl:FM,lessEqualImpl:OM,linSpaceImpl:_M,logImpl:LM,maxImpl:MM,maximumImpl:PM,minimumImpl:zM,multiplyImpl:BM,negImpl:VM,notEqualImpl:WM,prodImpl:UM,raggedGatherImpl:GM,raggedRangeImpl:HM,raggedTensorToTensorImpl:KM,rangeImpl:jM,rsqrtImpl:qM,scatterImpl:XM,sigmoidImpl:YM,simpleAbsImpl:F0,sliceImpl:JM,sparseFillEmptyRowsImpl:ZM,sparseReshapeImpl:QM,sparseSegmentReductionImpl:O0,sqrtImpl:tP,staticRegexReplaceImpl:eP,stridedSliceImpl:nP,stringNGramsImpl:sP,stringSplitImpl:oP,stringToHashBucketFastImpl:rP,subImpl:iP,tileImpl:aP,topKImpl:lP,transposeImpl:jd,uniqueImpl:cP}=dR;function _0(n,t){return["x","y","z","w","u","v"].slice(0,t).map(e=>`${n}.${e}`)}function Ee(n,t){return t===1?[n]:_0(n,t)}function uP(n,t){if(n===1)return"rc";let e="";for(let s=0;s<n;s++)e+=t[s],s<n-1&&(e+=",");return e}class hP{constructor(t){if(this.variableNames=["A"],this.packedInputs=!1,this.packedOutput=!0,this.outputShape=t,this.rank=t.length,this.enableShapeUniforms=Se(this.outputShape.length),this.rank===0)this.userCode=`
        void main() {
          setOutput(vec4(getA(), 0., 0., 0.));
        }
      `;else{const e=Ee("rc",this.rank),s=Ot(this.rank),o=this.getOutOfBoundsCondition(e),r=this.getSetup(e),i=this.getOutput(e);this.userCode=`
        void main() {
          ${s} rc = getOutputCoords();

          if(${o}) {
            setOutput(vec4(0));
          } else {
            ${r}

            setOutput(vec4(${i}));
          }
        }
      `}}getSourceCoordsArr(t){const e=[];for(let s=0;s<=1;s++)for(let o=0;o<=1;o++){let r=`${s===0?"r":"rp1"}, ${o===0?"c":"cp1"}`;for(let i=2;i<this.rank;i++)r=`${t[t.length-1-i]},`+r;e.push(r)}return e}getOutOfBoundsCondition(t){if(this.rank===1)return`rc > ${this.enableShapeUniforms?"outShape":this.outputShape[0]}`;let e="";for(let s=this.rank-2;s<this.rank;s++)e+=`${t[s]} >= ${this.enableShapeUniforms?`outShape[${s}]`:this.outputShape[s]}`,s<this.rank-1&&(e+="||");return e}getSetup(t){if(this.rank===1)return"";const e=t.slice(-2),s=this.enableShapeUniforms?`outShape[${this.rank} - 1]`:this.outputShape[this.rank-1],o=this.enableShapeUniforms?`outShape[${this.rank} - 2]`:this.outputShape[this.rank-2];return`
      int r = ${e[0]};
      int c = ${e[1]};
      int rp1 = r + 1;
      int cp1 = c + 1;

      bool cEdge = cp1 >= ${s};
      bool rEdge = rp1 >= ${o};
    `}getOutput(t){const e=this.getSourceCoordsArr(t);return this.rank===1?`getA(rc), (rc + 1 >= ${this.enableShapeUniforms?"outShape":this.outputShape[0]} ? 0. : getA(rc + 1)), 0, 0`:`getA(${e[0]}),
            cEdge ? 0. : getA(${e[1]}),
            rEdge ? 0. : getA(${e[2]}),
            rEdge || cEdge ? 0. : getA(${e[3]})`}}class L0{constructor(t,e){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"inputShape",type:"ivec3"}],this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length);let s="";for(let o=0;o<4;o++){let r="thisRC = rc;";o%2===1&&(r+="thisRC.z += 1;"),o>1&&(r+="thisRC.y += 1;"),s+=`
        ${r}
        ${o>0?"if(thisRC.y < rows && thisRC.z < cols){":""}
          int flatIndex = getFlatIndex(thisRC);

          ivec3 inputRC = inputCoordsFromReshapedOutCoords(flatIndex);
          vec2 inputRCInnerDims = vec2(float(inputRC.y),float(inputRC.z));

          result[${o}] =
            getChannel(getA(inputRC.x, inputRC.y, inputRC.z), inputRCInnerDims);
        ${o>0?"}":""}
      `}this.userCode=`
      ${dP(e,this.enableShapeUniforms)}
      ${this.enableShapeUniforms?Hd():Gd(t)}

      void main() {
        ivec3 rc = getOutputCoords();

        vec4 result = vec4(0.);

        ivec3 thisRC;
        int rows = ${this.enableShapeUniforms?"outShape[1]":t[1]};
        int cols = ${this.enableShapeUniforms?"outShape[2]":t[2]};

        ${s}

        setOutput(result);
      }
    `}}function dP(n,t){return`
    ivec3 inputCoordsFromReshapedOutCoords(int index) {
      ${t?uL(["r","c","d"],"inputShape"):co(["r","c","d"],n)}
      return ivec3(r, c, d);
    }
  `}class pP{constructor(t){this.gpgpu=t,this.numUsedTextures=0,this.numFreeTextures=0,this._numBytesAllocated=0,this._numBytesFree=0,this.freeTextures={},this.usedTextures={},this.logEnabled=!1}acquireTexture(t,e,s){const o=df(e,s),r=pf(t,o,s);r in this.freeTextures||(this.freeTextures[r]=[]),r in this.usedTextures||(this.usedTextures[r]=[]);const i=hf(t,o,this.gpgpu.gl,this.gpgpu.textureConfig,s);if(this.freeTextures[r].length>0){this.numFreeTextures--,this.numUsedTextures++,this._numBytesFree-=i,this.log();const l=this.freeTextures[r].pop();return this.usedTextures[r].push(l),l}let a;return o===ge.PACKED_2X2_FLOAT32?a=this.gpgpu.createPackedMatrixTexture(t[0],t[1]):o===ge.PACKED_2X2_FLOAT16?a=this.gpgpu.createFloat16PackedMatrixTexture(t[0],t[1]):o===ge.UNPACKED_FLOAT32?a=this.gpgpu.createFloat32MatrixTexture(t[0],t[1]):o===ge.UNPACKED_FLOAT16?a=this.gpgpu.createFloat16MatrixTexture(t[0],t[1]):o===ge.PACKED_4X1_UNSIGNED_BYTE&&(a=this.gpgpu.createUnsignedBytesMatrixTexture(t[0],t[1])),this.usedTextures[r].push(a),this.numUsedTextures++,this._numBytesAllocated+=i,this.log(),a}releaseTexture(t,e,s,o){if(this.freeTextures==null)return;const r=df(s,o),i=pf(e,r,o);i in this.freeTextures||(this.freeTextures[i]=[]);const a=hf(e,r,this.gpgpu.gl,this.gpgpu.textureConfig,o),l=L().getNumber("WEBGL_DELETE_TEXTURE_THRESHOLD");l!==-1&&this._numBytesAllocated>l?(this.gpgpu.deleteMatrixTexture(t.texture),this._numBytesAllocated-=a):(this.freeTextures[i].push(t),this.numFreeTextures++,this._numBytesFree+=a),this.numUsedTextures--;const c=this.usedTextures[i],u=c&&c.indexOf(t);if(u==null||u<0)throw new Error("Cannot release a texture that was never provided by this texture manager");c[u]=c[c.length-1],c.pop(),this.log()}log(){if(!this.logEnabled)return;const t=this.numFreeTextures+this.numUsedTextures;console.log("Free/Used",`${this.numFreeTextures} / ${this.numUsedTextures}`,`(${t})`);const e=this._numBytesFree/this._numBytesAllocated;console.log(`Bytes allocated: ${this._numBytesAllocated}`),console.log(`Bytes unused: ${this._numBytesFree} (${Math.round(100*e)}%)`)}get numBytesAllocated(){return this._numBytesAllocated}get numBytesFree(){return this._numBytesFree}getNumUsedTextures(){return this.numUsedTextures}getNumFreeTextures(){return this.numFreeTextures}dispose(){if(this.freeTextures!=null){for(const t in this.freeTextures)this.freeTextures[t].forEach(e=>{this.gpgpu.deleteMatrixTexture(e.texture)});for(const t in this.usedTextures)this.usedTextures[t].forEach(e=>{this.gpgpu.deleteMatrixTexture(e.texture)});this.freeTextures=null,this.usedTextures=null,this.numUsedTextures=0,this.numFreeTextures=0,this._numBytesAllocated=0,this._numBytesFree=0}}}function fP(n,t){const e=n;if(t===e.R32F)return 4;if(t===e.R16F)return 2;if(t===e.RGBA32F)return 16;if(t===n.RGBA)return 16;if(t===e.RGBA16F)return 8;if(t===e.RGBA8)return 4;throw new Error(`Unknown internal format ${t}`)}function hf(n,t,e,s,o){const r=mP(t,s);let i;if(o){const[l,c]=Go(n[0],n[1]);i=l*c}else{const[l,c]=Pi(n[0],n[1]);i=l*c}const a=fP(e,r);return i*a}function mP(n,t){switch(n){case ge.PACKED_2X2_FLOAT32:return R0(t);case ge.PACKED_2X2_FLOAT16:return D0(t);case ge.UNPACKED_FLOAT32:return N0(t);case ge.UNPACKED_FLOAT16:return T0(t);case ge.PACKED_4X1_UNSIGNED_BYTE:return E0(t);default:throw new Error(`Unknown physical texture type ${n}`)}}function gP(n){return L().getBool("WEBGL_RENDER_FLOAT32_ENABLED")?n?ge.PACKED_2X2_FLOAT32:ge.UNPACKED_FLOAT32:n?ge.PACKED_2X2_FLOAT16:ge.UNPACKED_FLOAT16}function df(n,t){if(n===qe.UPLOAD)return ge.PACKED_2X2_FLOAT32;if(n===qe.RENDER||n==null)return gP(t);if(n===qe.DOWNLOAD||n===qe.PIXELS)return ge.PACKED_4X1_UNSIGNED_BYTE;throw new Error(`Unknown logical texture type ${n}`)}function pf(n,t,e){return`${n[0]}_${n[1]}_${t}_${e}`}class En{constructor(t,e){this.variableNames=["A"],this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length),this.userCode=`
      float unaryOperation(float x) {
        ${e}
      }

      void main() {
        float x = getAAtOutCoords();
        float y = unaryOperation(x);

        setOutput(y);
      }
    `}}const un="if (isnan(x)) return x;",xP="return x;",ff="return abs(x);",bP="return (x >= 0.0) ? x : (exp(x) - 1.0);",yP=un+`
  return (x < 0.0) ? 0.0 : x;
`,wP=un+`
  return (x < 0.0) ? 0.0 : min(6.0, x);
`,rs="return x;",CP="return 1.0 / (1.0 + exp(-1.0 * x));";const $P="return x;",IP=`
  vec4 result;

  result.r = (x.r >= 0.0) ? x.r : (exp(x.r) - 1.0);
  result.g = (x.g >= 0.0) ? x.g : (exp(x.g) - 1.0);
  result.b = (x.b >= 0.0) ? x.b : (exp(x.b) - 1.0);
  result.a = (x.a >= 0.0) ? x.a : (exp(x.a) - 1.0);

  return result;
`,kP=`
  vec4 result = x * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,vP=`
  vec4 result = min(x, vec4(6.)) * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,SP="return 1.0 / (1.0 + exp(-1.0 * x));";class ls{constructor(t,e){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length),this.userCode=`
      vec4 unaryOperation(vec4 x) {
        ${e}
      }

      void main() {
        vec4 x = getAAtOutCoords();
        vec4 y = unaryOperation(x);

        setOutput(y);
      }
    `}}class NP{constructor(t){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!1,this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length);const e=t.length,s=Ee("rc",e),o=Ot(e),r=uP(e,s),i=s.slice(-2),a=e<=1?"rc":`vec2(${i.join(",")})`;this.userCode=`
      void main() {
        ${o} rc = getOutputCoords();
        vec4 packedInput = getA(${r});

        setOutput(getChannel(packedInput, ${a}));
      }
    `}}const TP=og,EP=1e-7,RP=1e-4,ea={};function DP(n){return n in ea||(ea[n]={}),ea[n]}const AP=L().getNumber("CPU_HANDOFF_SIZE_THRESHOLD"),FP=600;function OP(){return L().global.screen==null?1024:L().global.screen.height*L().global.screen.width*window.devicePixelRatio*FP/1024/1024}class ac extends fu{nextDataId(){return ac.nextDataId++}constructor(t){if(super(),this.pendingRead=new WeakMap,this.pendingDisposal=new WeakSet,this.dataRefCount=new WeakMap,this.numBytesInGPU=0,this.uploadWaitMs=0,this.downloadWaitMs=0,this.lastGlFlushTime=0,this.warnedAboutMemory=!1,this.pendingDeletes=0,this.disposed=!1,!L().getBool("HAS_WEBGL"))throw new Error("WebGL is not supported on this device");let e;if(t!=null){if(t instanceof Ec)e=t;else{const s=$n(L().getNumber("WEBGL_VERSION"),t);e=new Ec(s)}this.binaryCache={},this.gpgpuCreatedLocally=!1}else{const s=$n(L().getNumber("WEBGL_VERSION"));e=new Ec(s),this.binaryCache=DP(L().getNumber("WEBGL_VERSION")),this.gpgpuCreatedLocally=!0}this.gpgpu=e,this.canvas=this.gpgpu.gl.canvas,this.textureManager=new pP(this.gpgpu),this.numMBBeforeWarning=OP(),this.texData=new Ff(this,kn())}numDataIds(){return this.texData.numDataIds()-this.pendingDeletes}writeTexture(t,e,s,o,r,i){const a=this.makeTensorInfo(e,s),l=this.texData.get(a.dataId);l.isPacked=!1,l.texture={texture:t,texShape:[o,r]},l.texShape=[o,r];const c=Qi(e),u=new uf(c,!1,i),h=this.runWebGLProgram(u,[a],s,[[o,r]]);return h.shape=e,l.texture=null,this.disposeIntermediateTensorInfo(a),h.dataId}write(t,e,s){if((L().getBool("WEBGL_CHECK_NUMERICAL_PROBLEMS")||L().getBool("DEBUG"))&&this.checkNumericalProblems(t),s==="complex64"&&t!=null)throw new Error("Cannot write to a complex64 dtype. Please use tf.complex(real, imag).");const o={id:this.nextDataId()};return this.texData.set(o,{shape:e,dtype:s,values:t,usage:qe.UPLOAD,refCount:1}),o}refCount(t){return this.texData.has(t)?this.texData.get(t).refCount:0}incRef(t){const e=this.texData.get(t);e.refCount++}decRef(t){if(this.texData.has(t)){const e=this.texData.get(t);e.refCount--}}move(t,e,s,o,r){if(L().getBool("DEBUG")&&this.checkNumericalProblems(e),o==="complex64")throw new Error("Cannot write to a complex64 dtype. Please use tf.complex(real, imag).");this.texData.set(t,{shape:s,dtype:o,values:e,usage:qe.UPLOAD,refCount:r})}disposeIntermediateTensorInfo(t){this.disposeData(t.dataId)}readSync(t){const e=this.texData.get(t),{values:s,dtype:o,complexTensorInfos:r,slice:i,shape:a,isPacked:l}=e;if(i!=null){let d;l?d=new ls(a,rs):d=new En(a,rs);const p=this.runWebGLProgram(d,[{dataId:t,shape:a,dtype:o}],o),f=this.readSync(p.dataId);return this.disposeIntermediateTensorInfo(p),f}if(s!=null)return this.convertAndCacheOnCPU(t);if(o==="string")return s;const c=this.activeTimers!=null;let u;c&&(u=Fe());let h;if(o==="complex64"){const d=this.readSync(r.real.dataId),p=this.readSync(r.imag.dataId);h=Xn(d,p)}else h=this.getValuesFromTexture(t);return c&&(this.downloadWaitMs+=Fe()-u),this.convertAndCacheOnCPU(t,h)}async read(t){if(this.pendingRead.has(t)){const f=this.pendingRead.get(t);return new Promise(m=>f.push(m))}const e=this.texData.get(t),{values:s,shape:o,slice:r,dtype:i,complexTensorInfos:a,isPacked:l}=e;if(r!=null){let f;l?f=new ls(o,rs):f=new En(o,rs);const m=this.runWebGLProgram(f,[{dataId:t,shape:o,dtype:i}],i),g=this.read(m.dataId);return this.disposeIntermediateTensorInfo(m),g}if(s!=null)return this.convertAndCacheOnCPU(t);if(L().getBool("DEBUG")&&!L().getBool("WEBGL_DOWNLOAD_FLOAT_ENABLED")&&L().getNumber("WEBGL_VERSION")===2)throw new Error("tensor.data() with WEBGL_DOWNLOAD_FLOAT_ENABLED=false and WEBGL_VERSION=2 not yet supported.");let c=null,u;if(i!=="complex64"&&L().get("WEBGL_BUFFER_SUPPORTED")){u=this.decode(t);const f=this.texData.get(u.dataId);c=this.gpgpu.createBufferFromTexture(f.texture.texture,...Yi(o))}this.pendingRead.set(t,[]),i!=="complex64"&&await this.gpgpu.createAndWaitForFence();let h;if(i==="complex64"){const f=await Promise.all([this.read(a.real.dataId),this.read(a.imag.dataId)]),m=f[0],g=f[1];h=Xn(m,g)}else if(c==null)h=this.getValuesFromTexture(t);else{const f=W(o);h=this.gpgpu.downloadFloat32MatrixFromBuffer(c,f)}if(u!=null&&this.disposeIntermediateTensorInfo(u),c!=null){const f=this.gpgpu.gl;nt(f,()=>f.deleteBuffer(c))}const d=this.convertAndCacheOnCPU(t,h),p=this.pendingRead.get(t);return this.pendingRead.delete(t),p.forEach(f=>f(d)),this.pendingDisposal.has(t)&&(this.pendingDisposal.delete(t),this.disposeData(t)&&kn().removeDataId(t,this),this.pendingDeletes--),d}readToGPU(t,e={}){const s=this.texData.get(t),{values:o,shape:r,slice:i,dtype:a,isPacked:l,texture:c}=s;if(a==="complex64")throw new Error("Does not support reading texture for complex64 dtype.");if(i!=null){let p;l?p=new ls(r,rs):p=new En(r,rs);const f=this.runWebGLProgram(p,[{dataId:t,shape:r,dtype:a}],a),m=this.readToGPU(f,e);return this.disposeIntermediateTensorInfo(f),m}if(c==null)throw o!=null?new Error("Data is not on GPU but on CPU."):new Error("There is no data on GPU or CPU.");const u=this.decode(t,e.customTexShape),h=kn().makeTensorFromTensorInfo(u),d=this.texData.get(u.dataId);return Object.assign({tensorRef:h},d.texture)}bufferSync(t){const e=this.readSync(t.dataId);if(t.dtype==="string")try{const s=e.map(o=>ps(o));return wt(t.shape,t.dtype,s)}catch{throw new Error("Failed to decode encoded string bytes into utf-8")}return wt(t.shape,t.dtype,e)}checkNumericalProblems(t){if(t!=null)for(let e=0;e<t.length;e++){const s=t[e];if(!M_(s))throw L().getBool("WEBGL_RENDER_FLOAT32_CAPABLE")?Error(`The value ${s} cannot be represented with your current settings. Consider enabling float32 rendering: 'tf.env().set('WEBGL_RENDER_FLOAT32_ENABLED', true);'`):Error(`The value ${s} cannot be represented on this device.`)}}getValuesFromTexture(t){const{shape:e,dtype:s,isPacked:o}=this.texData.get(t),r=W(e);if(L().getBool("WEBGL_DOWNLOAD_FLOAT_ENABLED")){const d=this.decode(t),p=this.texData.get(d.dataId),f=this.gpgpu.downloadMatrixFromPackedTexture(p.texture.texture,...Yi(e)).subarray(0,r);return this.disposeIntermediateTensorInfo(d),f}const i=L().getBool("WEBGL_PACK")&&o===!0,a=i?Qi(e):e,l=i?new QL(a):new ZL(a),c=this.runWebGLProgram(l,[{shape:a,dtype:s,dataId:t}],"float32"),u=this.texData.get(c.dataId),h=this.gpgpu.downloadByteEncodedFloatMatrixFromOutputTexture(u.texture.texture,u.texShape[0],u.texShape[1]).subarray(0,r);return this.disposeIntermediateTensorInfo(c),h}timerAvailable(){return L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE")>0}time(t){const e=this.activeTimers,s=[];let o=!1;this.programTimersStack==null?(this.programTimersStack=s,o=!0):this.activeTimers.push(s),this.activeTimers=s,t();const r=Us(this.activeTimers.map(l=>l.query)).filter(l=>l!=null),i=Us(this.activeTimers.map(l=>l.name)).filter(l=>l!=null);this.activeTimers=e,o&&(this.programTimersStack=null);const a={uploadWaitMs:this.uploadWaitMs,downloadWaitMs:this.downloadWaitMs,kernelMs:null,wallMs:null};return(async()=>{if(L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE")>0){const l=await Promise.all(r);a.kernelMs=w1(l),a.getExtraProfileInfo=()=>l.map((c,u)=>({name:i[u],ms:c})).map(c=>`${c.name}: ${c.ms}`).join(", ")}else a.kernelMs={error:"WebGL query timers are not supported in this environment."};return this.uploadWaitMs=0,this.downloadWaitMs=0,a})()}memory(){return{unreliable:!1,numBytesInGPU:this.numBytesInGPU,numBytesInGPUAllocated:this.textureManager.numBytesAllocated,numBytesInGPUFree:this.textureManager.numBytesFree}}startTimer(){return L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE")>0?this.gpgpu.beginQuery():{startMs:Fe(),endMs:null}}endTimer(t){return L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE")>0?(this.gpgpu.endQuery(),t):(t.endMs=Fe(),t)}async getQueryTime(t){if(L().getNumber("WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE")>0)return this.gpgpu.waitForQueryAndGetTime(t);const e=t;return e.endMs-e.startMs}disposeData(t,e=!1){if(this.pendingDisposal.has(t))return!1;if(!this.texData.has(t))return!0;if(e?this.texData.get(t).refCount=0:this.texData.get(t).refCount--,!e&&this.texData.get(t).refCount>0)return!1;if(this.pendingRead.has(t))return this.pendingDisposal.add(t),this.pendingDeletes++,!1;this.releaseGPUData(t);const{complexTensorInfos:s}=this.texData.get(t);return s!=null&&(this.disposeData(s.real.dataId,e),this.disposeData(s.imag.dataId,e)),this.texData.delete(t),!0}releaseGPUData(t){const{texture:e,dtype:s,texShape:o,usage:r,isPacked:i,slice:a}=this.texData.get(t),l=a&&a.origDataId||t,c=this.dataRefCount.get(l);c>1?this.dataRefCount.set(l,c-1):(this.dataRefCount.delete(l),e!=null&&(this.numBytesInGPU-=this.computeBytes(o,s),this.textureManager.releaseTexture(e,o,r,i)));const u=this.texData.get(t);u.texture=null,u.texShape=null,u.isPacked=!1,u.slice=null}getTexture(t){return this.uploadToGPU(t),this.texData.get(t).texture.texture}getDataInfo(t){return this.texData.get(t)}shouldExecuteOnCPU(t,e=AP){return L().getBool("WEBGL_CPU_FORWARD")&&t.every(s=>this.texData.get(s.dataId).texture==null&&W(s.shape)<e)}getGPGPUContext(){return this.gpgpu}where(t){je("tf.where() in webgl locks the UI thread. Call tf.whereAsync() instead");const e=t.dataSync();return TP(t.shape,e)}packedUnaryOp(t,e,s){const o=new ls(t.shape,e),r=this.compileAndRun(o,[t],s);return kn().makeTensorFromTensorInfo(r)}abs(t){if(this.shouldExecuteOnCPU([t])&&t.dtype!=="complex64"){const o=F0(this.texData.get(t.dataId).values);return this.makeOutput(t.shape,t.dtype,o)}if(L().getBool("WEBGL_PACK_UNARY_OPERATIONS"))return this.packedUnaryOp(t,ff,t.dtype);const e=new En(t.shape,ff),s=this.compileAndRun(e,[t]);return kn().makeTensorFromTensorInfo(s)}makeTensorInfo(t,e,s){let o;if(e==="string"&&s!=null&&s.length>0&&vr(s[0])){const r=s.map(i=>us(i));o=this.write(r,t,e)}else o=this.write(s,t,e);return this.texData.get(o).usage=null,{dataId:o,shape:t,dtype:e}}makeOutput(t,e,s){return kn().makeTensorFromTensorInfo(this.makeTensorInfo(t,e,s),this)}unpackTensor(t){const e=new NP(t.shape);return this.runWebGLProgram(e,[t],t.dtype)}packTensor(t){const e=new hP(t.shape);return this.runWebGLProgram(e,[t],t.dtype,null,!0)}packedReshape(t,e){const s=[Oo(t.shape),..._o(t.shape)],o={dtype:t.dtype,shape:s,dataId:t.dataId},r=[Oo(e),..._o(e)],i=new L0(r,s),a=!0,l=[s],c=this.runWebGLProgram(i,[o],t.dtype,l,a);return{dataId:c.dataId,shape:e,dtype:c.dtype}}decode(t,e){const s=this.texData.get(t),{isPacked:o,shape:r,dtype:i}=s;if(e!=null){const d=W(r),p=e[0]*e[1]*4;$(d<=p,()=>"customTexShape is too small. Row * Column * 4 should be equal or larger than the size of the tensor data.")}const a=Qi(r);let l;o?l=new JL(a):l=new YL(a);const c=!0,u=[e??Yi(a)],h=this.runWebGLProgram(l,[{shape:a,dtype:i,dataId:t}],i,u,c,e);return{dtype:i,shape:r,dataId:h.dataId}}runWebGLProgram(t,e,s,o,r=!1,i){const a=this.makeTensorInfo(t.outputShape,s),l=this.texData.get(a.dataId);if(t.packedOutput&&(l.isPacked=!0),t.outPackingScheme===Cr.DENSE){const x=i??Yi(t.outputShape);l.texShape=x.map(b=>b*2)}if(t.outTexUsage!=null&&(l.usage=t.outTexUsage),W(a.shape)===0)return l.values=Ce(a.dtype,0),a;const c=[],u=e.map(x=>{if(x.dtype==="complex64")throw new Error("GPGPUProgram does not support complex64 input. For complex64 dtypes, please separate the program into real and imaginary parts.");let b=this.texData.get(x.dataId);if(b.texture==null){if(!t.packedInputs&&W(x.shape)<=L().getNumber("WEBGL_SIZE_UPLOAD_UNIFORM"))return{shape:x.shape,texData:null,isUniform:!0,uniformValues:b.values};t.packedInputs&&(b.isPacked=!0,b.shape=x.shape)}if(this.uploadToGPU(x.dataId),!!b.isPacked!=!!t.packedInputs)x=b.isPacked?this.unpackTensor(x):this.packTensor(x),c.push(x),b=this.texData.get(x.dataId);else if(b.isPacked&&!Da(b.shape,x.shape)){const w=x,y=x.shape;x.shape=b.shape,x=this.packedReshape(x,y),c.push(x),b=this.texData.get(x.dataId),w.shape=y}return{shape:x.shape,texData:b,isUniform:!1}});this.uploadToGPU(a.dataId);const h={shape:a.shape,texData:l,isUniform:!1},d=XL(t,u,h),p=this.getAndSaveBinary(d,()=>jL(this.gpgpu,t,u,h)),f=this.activeTimers!=null;let m;f&&(m=this.startTimer()),L().get("ENGINE_COMPILE_ONLY")||qL(this.gpgpu,p,u,h,o),c.forEach(x=>this.disposeIntermediateTensorInfo(x)),f&&(m=this.endTimer(m),this.activeTimers.push({name:t.constructor.name,query:this.getQueryTime(m)}));const g=L().getNumber("WEBGL_FLUSH_THRESHOLD");if(g>0){const x=Fe();x-this.lastGlFlushTime>g&&(this.gpgpu.gl.flush(),this.lastGlFlushTime=x)}if(!L().getBool("WEBGL_LAZILY_UNPACK")&&l.isPacked&&r===!1){const x=this.unpackTensor(a);return this.disposeIntermediateTensorInfo(a),x}return a}compileAndRun(t,e,s,o,r=!1){return s=s||e[0].dtype,this.runWebGLProgram(t,e,s,o,r)}getAndSaveBinary(t,e){return t in this.binaryCache||(this.binaryCache[t]=e()),this.binaryCache[t]}getTextureManager(){return this.textureManager}dispose(){this.disposed||(L().getBool("IS_TEST")||Object.keys(this.binaryCache).forEach(e=>{this.gpgpu.deleteProgram(this.binaryCache[e].webGLProgram),delete this.binaryCache[e]}),this.textureManager.dispose(),this.canvas!=null&&typeof HTMLCanvasElement<"u"&&this.canvas instanceof HTMLCanvasElement?this.canvas.remove():this.canvas=null,this.gpgpuCreatedLocally&&(this.gpgpu.program=null,this.gpgpu.dispose()),this.disposed=!0)}floatPrecision(){return this.floatPrecisionValue==null&&(this.floatPrecisionValue=_(()=>{if(!L().get("WEBGL_RENDER_FLOAT32_ENABLED")){const t=L().getBool("DEBUG");L().set("DEBUG",!1);const e=this.abs(Tt(1e-8)).dataSync()[0];if(L().set("DEBUG",t),e>0)return 32}return 16})),this.floatPrecisionValue}epsilon(){return this.floatPrecision()===32?EP:RP}uploadToGPU(t){const e=this.texData.get(t),{shape:s,dtype:o,values:r,texture:i,usage:a,isPacked:l}=e;if(i!=null)return;const c=this.activeTimers!=null;let u;c&&(u=Fe());let h=e.texShape;if(h==null&&(h=eL(s,l),e.texShape=h),r!=null){const d=Qi(s);let p,f=h[1],m=h[0];const g=r instanceof Uint8Array||r instanceof Uint8ClampedArray;(l||!g)&&([f,m]=Go(h[0],h[1])),l?p=new eM(d,g):p=new uf(d,g);const x=g?[m,f]:h,b=this.makeTensorInfo(x,o),w=this.texData.get(b.dataId);g?w.usage=qe.PIXELS:w.usage=qe.UPLOAD,w.texShape=x,this.gpgpu.uploadDenseMatrixToTexture(this.getTexture(b.dataId),f,m,r);const y=[[m,f]],I=this.runWebGLProgram(p,[b],o,y,!0),k=this.texData.get(I.dataId);e.texShape=k.texShape,e.isPacked=k.isPacked,e.usage=k.usage,L().get("ENGINE_COMPILE_ONLY")?this.disposeData(I.dataId):(e.texture=k.texture,e.values=null,this.texData.delete(I.dataId)),this.disposeIntermediateTensorInfo(b),c&&(this.uploadWaitMs+=Fe()-u)}else{const d=this.acquireTexture(h,a,o,l);e.texture=d}}convertAndCacheOnCPU(t,e){const s=this.texData.get(t),{dtype:o}=s;return e!=null&&(s.values=_P(e,o)),s.values}acquireTexture(t,e,s,o){if(this.numBytesInGPU+=this.computeBytes(t,s),!this.warnedAboutMemory&&this.numBytesInGPU>this.numMBBeforeWarning*1024*1024){const r=(this.numBytesInGPU/1024/1024).toFixed(2);this.warnedAboutMemory=!0,console.warn(`High memory usage in GPU: ${r} MB, most likely due to a memory leak`)}return this.textureManager.acquireTexture(t,e,o)}computeBytes(t,e){return t[0]*t[1]*ra(e)}checkCompileCompletion(){for(const[,t]of Object.entries(this.binaryCache))this.checkCompletion_(t)}async checkCompileCompletionAsync(){const t=[];if(this.gpgpu.parallelCompilationExtension){for(const[,e]of Object.entries(this.binaryCache))t.push(this.checkCompletionAsync_(e));return Promise.all(t)}else{for(const[,e]of Object.entries(this.binaryCache)){const s=new Promise(o=>{try{this.checkCompletion_(e),o(!0)}catch(r){throw r}});t.push(s)}return Promise.all(t)}}async checkCompletionAsync_(t){return this.gpgpu.gl.getProgramParameter(t.webGLProgram,this.gpgpu.parallelCompilationExtension.COMPLETION_STATUS_KHR)?this.checkCompletion_(t):(await Ig(),this.checkCompletionAsync_(t))}checkCompletion_(t){if(this.gpgpu.gl.getProgramParameter(t.webGLProgram,this.gpgpu.gl.LINK_STATUS)===!1)throw console.log(this.gpgpu.gl.getProgramInfoLog(t.webGLProgram)),this.gpgpu.gl.getShaderParameter(t.fragmentShader,this.gpgpu.gl.COMPILE_STATUS)===!1?(C0(t.source,this.gpgpu.gl.getShaderInfoLog(t.fragmentShader)),new Error("Failed to compile fragment shader.")):new Error("Failed to link vertex and fragment shaders.");return!0}getUniformLocations(){for(const t of Object.values(this.binaryCache)){this.gpgpu.buildVao(t.webGLProgram);const{variablesLocations:e,customUniformLocations:s,infLoc:o,nanLoc:r,outShapeLocation:i,outShapeStridesLocation:a,outTexShapeLocation:l}=S0(this.gpgpu,t.program,t.webGLProgram);t.variablesLocations=e,t.customUniformLocations=s,t.infLoc=o,t.nanLoc=r,t.outShapeLocation=i,t.outShapeStridesLocation=a,t.outTexShapeLocation=l}}createTensorFromGPUData(t,e,s){t.channels=t.channels||"RGBA";const{texture:o,height:r,width:i,channels:a}=t,l=kn().backend;if(!l.gpgpu.gl.isTexture(o))throw new Error("The texture is invalid. Also, please make sure the texture and the TFJS WebGL backend are using the same canvas. If you want to use your own custom canvas, you have to create and use the custom TFJS WebGL backend created from the canvas through 'new tf.MathBackendWebGL(customCanvas)'.");const c=l.writeTexture(o,e,s,r,i,a);return kn().makeTensorFromDataId(c,e,s,l)}}ac.nextDataId=0;function _P(n,t){if(t==="float32"||t==="complex64")return n;if(t==="int32"||t==="bool"){const e=t==="int32"?new Int32Array(n.length):new Uint8Array(n.length);for(let s=0;s<e.length;++s)e[s]=Math.round(n[s]);return e}else throw new Error(`Unknown dtype ${t}`)}ym()&&$m("webgl",()=>new ac,2);const qd=`
  if (isnan(a)) return a;
  if (isnan(b)) return b;
`;class no{constructor(t,e,s){this.variableNames=["A","B"],this.outputShape=mt(e,s),this.enableShapeUniforms=Se(this.outputShape.length),this.userCode=`
      float binaryOperation(float a, float b) {
        ${t}
      }

      void main() {
        float a = getAAtOutCoords();
        float b = getBAtOutCoords();
        setOutput(binaryOperation(a, b));
      }
    `}}const ho=`
  result.r = isNaN.r ? NAN : result.r;
  result.g = isNaN.g ? NAN : result.g;
  result.b = isNaN.b ? NAN : result.b;
  result.a = isNaN.a ? NAN : result.a;
`;class Xo{constructor(t,e,s,o=!1){this.variableNames=["A","B"],this.supportsBroadcasting=!0,this.packedInputs=!0,this.packedOutput=!0,this.outputShape=mt(e,s);const r=this.outputShape.length;this.enableShapeUniforms=Se(r);let i="";if(o)if(r===0||W(this.outputShape)===1)i=`
          result.y = 0.;
          result.z = 0.;
          result.w = 0.;
        `;else if(i=`
          ${Ot(r)} coords = getOutputCoords();
        `,r===1)this.enableShapeUniforms?i+=`
            result.y = (coords + 1) >= outShape ? 0. : result.y;
            result.z = 0.;
            result.w = 0.;
          `:i+=`
            result.y = (coords + 1) >= ${this.outputShape[0]} ? 0. : result.y;
            result.z = 0.;
            result.w = 0.;
          `;else{const l=Ee("coords",r);this.enableShapeUniforms?i+=`
            bool nextRowOutOfBounds =
              (${l[r-2]} + 1) >= outShape[${r} - 2];
            bool nextColOutOfBounds =
              (${l[r-1]} + 1) >= outShape[${r} - 1];
            result.y = nextColOutOfBounds ? 0. : result.y;
            result.z = nextRowOutOfBounds ? 0. : result.z;
            result.w = nextColOutOfBounds || nextRowOutOfBounds ? 0. : result.w;
          `:i+=`
            bool nextRowOutOfBounds =
              (${l[r-2]} + 1) >= ${this.outputShape[r-2]};
            bool nextColOutOfBounds =
              (${l[r-1]} + 1) >= ${this.outputShape[r-1]};
            result.y = nextColOutOfBounds ? 0. : result.y;
            result.z = nextRowOutOfBounds ? 0. : result.z;
            result.w = nextColOutOfBounds || nextRowOutOfBounds ? 0. : result.w;
          `}this.userCode=`
      vec4 binaryOperation(vec4 a, vec4 b) {
        ${t}
      }

      void main() {
        vec4 a = getAAtOutCoords();
        vec4 b = getBAtOutCoords();

        vec4 result = binaryOperation(a, b);
        ${i}

        setOutput(result);
      }
    `}}function He(n){const{inputs:t,backend:e}=n,{x:s}=t;return e.incRef(s.dataId),{dataId:s.dataId,shape:s.shape,dtype:s.dtype}}const LP={kernelName:Kr,backendName:"webgl",kernelFunc:He};function Es(n){const{inputs:t,backend:e}=n,{real:s,imag:o}=t,r=e.makeTensorInfo(s.shape,"complex64"),i=e.texData.get(r.dataId),a=He({inputs:{x:s},backend:e}),l=He({inputs:{x:o},backend:e});return i.complexTensorInfos={real:a,imag:l},r}const MP={kernelName:Nu,backendName:"webgl",kernelFunc:Es};const M0="return (a < 0.) ? b * a : a;",P0=`
  vec4 aLessThanZero = vec4(lessThan(a, vec4(0.)));
  return (aLessThanZero * (b * a)) + ((vec4(1.0) - aLessThanZero) * a);
`;function PP(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{alpha:r}=s,i=e.makeTensorInfo([],"float32",ws(r,"float32")),a=L().getBool("WEBGL_PACK_BINARY_OPERATIONS")?new Xo(P0,o.shape,i.shape):new no(M0,o.shape,i.shape),l=e.runWebGLProgram(a,[o,i],"float32");return e.disposeIntermediateTensorInfo(i),l}const zP={kernelName:el,backendName:"webgl",kernelFunc:PP};const z0="return (a < 0.) ? b * a : a;",B0=`
  vec4 aLessThanZero = vec4(lessThan(a, vec4(0.)));
  return (aLessThanZero * (b * a)) + ((vec4(1.0) - aLessThanZero) * a);
`;function BP(n){const{inputs:t,backend:e}=n,{x:s,alpha:o}=t,r=L().getBool("WEBGL_PACK_BINARY_OPERATIONS")?new Xo(B0,s.shape,o.shape):new no(z0,s.shape,o.shape);return e.runWebGLProgram(r,[s,o],"float32")}const VP={kernelName:wl,backendName:"webgl",kernelFunc:BP};const Yo="if (isnan(x)) return x;";function vt({opSnippet:n,packedOpSnippet:t,cpuKernelImpl:e,dtype:s}){return({inputs:o,backend:r})=>{const{x:i}=o,a=r,l=s||i.dtype;if(a.shouldExecuteOnCPU([i])&&e!=null){const h=a.texData.get(i.dataId),d=e(h.values,l);return a.makeTensorInfo(i.shape,l,d)}const c=L().getBool("WEBGL_PACK_UNARY_OPERATIONS")&&t!=null;let u;return c?u=new ls(i.shape,t):u=new En(i.shape,n),a.runWebGLProgram(u,[i],l)}}function we({opSnippet:n,packedOpSnippet:t,checkOutOfBounds:e=!1,supportsComplex:s=!1,cpuKernelImpl:o,dtype:r}){return({inputs:i,backend:a})=>{const{a:l,b:c}=i,u=a;if(s&&l.dtype==="complex64"){const f=u.texData.get(l.dataId),m=u.texData.get(c.dataId),[g,x]=[[f.complexTensorInfos.real,m.complexTensorInfos.real],[f.complexTensorInfos.imag,m.complexTensorInfos.imag]].map(w=>{const[y,C]=w,I={dataId:y.dataId,dtype:y.dtype,shape:l.shape},k={dataId:C.dataId,dtype:C.dtype,shape:c.shape},v=new no(n,l.shape,c.shape);return u.runWebGLProgram(v,[I,k],Ue(y.dtype,C.dtype))}),b=Es({inputs:{real:g,imag:x},backend:u});return u.disposeIntermediateTensorInfo(g),u.disposeIntermediateTensorInfo(x),b}const h=r||Ue(l.dtype,c.dtype);if((l.dtype==="string"||c.dtype==="string"||u.shouldExecuteOnCPU([l,c]))&&o!=null){const f=u.texData.get(l.dataId).values,m=u.texData.get(c.dataId).values,g=l.dtype==="string"?Yn(f):f,x=l.dtype==="string"?Yn(m):m,[b,w]=o(l.shape,c.shape,g,x,h),y=u.makeTensorInfo(w,h),C=u.texData.get(y.dataId);return C.values=b,y}const d=L().getBool("WEBGL_PACK_BINARY_OPERATIONS")&&t!=null;let p;return d?p=new Xo(t,l.shape,c.shape,e):p=new no(n,l.shape,c.shape),u.runWebGLProgram(p,[l,c],h)}}function $r(n,t=!1){if(n==="linear")return t?$P:xP;if(n==="relu")return t?kP:yP;if(n==="elu")return t?IP:bP;if(n==="relu6")return t?vP:wP;if(n==="prelu")return t?B0:z0;if(n==="leakyrelu")return t?P0:M0;if(n==="sigmoid")return t?SP:CP;throw new Error(`Activation ${n} has not been implemented for the WebGL backend.`)}class V0{constructor(t,e,s,o=!1,r=!1,i=!1,a=null,l=!1,c=!1){this.variableNames=["matrixA","matrixB"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=s,this.enableShapeUniforms=Se(this.outputShape.length);const u=o?t[1]:t[2],h=Math.ceil(u/2),d=o?"i * 2, rc.y":"rc.y, i * 2",p=r?"rc.z, i * 2":"i * 2, rc.z",f=o?["a.xxyy","a.zzww"]:["a.xxzz","a.yyww"],m=r?["b.xzxz","b.ywyw"]:["b.xyxy","b.zwzw"];let g="",x="";a&&(l?g=`vec4 activation(vec4 a) {
          vec4 b = getPreluActivationWeightsAtOutCoords();
          ${a}
        }`:c?g=`vec4 activation(vec4 a) {
          vec4 b = getLeakyreluAlphaAtOutCoords();
          ${a}
        }`:g=`vec4 activation(vec4 x) {
          ${a}
        }`,x="result = activation(result);");const b=i?"result += getBiasAtOutCoords();":"";i&&this.variableNames.push("bias"),l&&this.variableNames.push("preluActivationWeights"),c&&this.variableNames.push("leakyreluAlpha");let w="rc.x",y="rc.x";t[0]<e[0]?w=`imod(rc.x, ${t[0]})`:e[0]<t[0]&&(y=`imod(rc.x, ${e[0]})`),this.userCode=`
      ${g}
      // Don't use uniform for sharedDimensionPacked for performance.
      const float sharedDimension = ${h}.0;

      vec4 dot2x2ARowBCol(ivec3 rc) {
        vec4 result = vec4(0);
        int batchA = ${w};
        int batchB = ${y};
        for (int i = 0; i < ${h}; i++) {
          vec4 a = getMatrixA(batchA, ${d});
          vec4 b = getMatrixB(batchB, ${p});

          // These swizzled products need to be separately added.
          // See: https://github.com/tensorflow/tfjs/issues/1735
          result += (${f[0]} * ${m[0]});
          result += (${f[1]} * ${m[1]});
        }
        return result;
      }

      void main() {
        ivec3 rc = getOutputCoords();
        vec4 result = dot2x2ARowBCol(rc);

        ${b}

        ${x}

        setOutput(result);
      }
    `}}const mf={REAL:"return areal * breal - aimag * bimag;",IMAG:"return areal * bimag + aimag * breal;"};class gf{constructor(t,e,s){this.variableNames=["AReal","AImag","BReal","BImag"],this.outputShape=mt(e,s),this.userCode=`
      float binaryOpComplex(
          float areal, float aimag, float breal, float bimag) {
        ${t}
      }

      void main() {
        float areal = getARealAtOutCoords();
        float aimag = getAImagAtOutCoords();
        float breal = getBRealAtOutCoords();
        float bimag = getBImagAtOutCoords();
        setOutput(binaryOpComplex(areal, aimag, breal, bimag));
      }
    `}}const xf="return a * b;";function Xd(n){const{inputs:t,backend:e}=n,{a:s,b:o}=t,r=Ue(s.dtype,o.dtype);if(s.dtype==="complex64"){const a=e.texData.get(s.dataId),l=e.texData.get(o.dataId),c=new gf(mf.REAL,s.shape,o.shape),u=new gf(mf.IMAG,s.shape,o.shape),h=[{dataId:a.complexTensorInfos.real.dataId,dtype:a.complexTensorInfos.real.dtype,shape:s.shape},{dataId:a.complexTensorInfos.imag.dataId,dtype:a.complexTensorInfos.imag.dtype,shape:s.shape},{dataId:l.complexTensorInfos.real.dataId,dtype:l.complexTensorInfos.real.dtype,shape:o.shape},{dataId:l.complexTensorInfos.imag.dataId,dtype:l.complexTensorInfos.imag.dtype,shape:o.shape}],d=e.runWebGLProgram(c,h,"float32"),p=e.runWebGLProgram(u,h,"float32"),f=Es({inputs:{real:d,imag:p},backend:e});return e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p),f}if(e.shouldExecuteOnCPU([s,o])){const a=e.texData.get(s.dataId),l=e.texData.get(o.dataId),[c,u]=BM(s.shape,o.shape,a.values,l.values,r),h=e.makeTensorInfo(u,r),d=e.texData.get(h.dataId);return d.values=c,h}let i;return L().getBool("WEBGL_PACK_BINARY_OPERATIONS")?i=new Xo(xf,s.shape,o.shape):i=new no(xf,s.shape,o.shape),e.runWebGLProgram(i,[s,o],r)}const WP={kernelName:ei,backendName:"webgl",kernelFunc:Xd};function UP(n,t,e){const s=[Oo(n.shape),..._o(n.shape)],o={dtype:n.dtype,shape:s,dataId:n.dataId},r=[Oo(t),..._o(t)],i=new L0(r,s),a=!0,l=[s],c=e.runWebGLProgram(i,[o],n.dtype,l,a);return{dataId:c.dataId,shape:t,dtype:c.dtype}}function tt(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{shape:r}=s,i=e,a=W(o.shape),l=_f(r,a),c=W(l);$(a===c,()=>`The new shape (${l}) has ${c} elements and the old shape (${o.shape}) has ${a} elements. The new shape and old shape must have the same number of elements.`);const u=i.texData.get(o.dataId);return u.isPacked&&!Da(o.shape,l)&&!(u.texture!==null&&Da(u.shape,l))?UP(o,l,i):(i.incRef(o.dataId),{dataId:o.dataId,shape:l,dtype:o.dtype})}const GP={kernelName:$l,backendName:"webgl",kernelFunc:tt};class bf{constructor(t,e){this.variableNames=["x"];const{windowSize:s,batchSize:o,inSize:r,outSize:i}=t;this.outputShape=[o,i];const a=Math.floor(s/4)*4,l=s%4;let c="sumValue += dot(values, ones);";if(e!=null){const h=1/e;c=`sumValue += dot(values * ${vo(h)?h.toPrecision(2):h}, ones);`}let u="";r%s>0&&(u=`
        if (inIdx < 0 || inIdx >= ${r}) {
          return 0.0;
        }
      `),this.userCode=`
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float getValue(int batch, int inIdx) {
        ${u}
        return getX(batch, inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${s};

        float sumValue = 0.0;

        for (int i = 0; i < ${a}; i += 4) {
          int inIdx = inOffset + i;
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          ${c}
        }

        int inIdx = inOffset + ${a};
        if (${l===1}) {
          vec4 values = vec4(getValue(batch, inIdx), 0.0, 0.0, 0.0);

          ${c}
        } else if (${l===2}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1), 0.0, 0.0);

          ${c}
        } else if (${l===3}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2), 0.0);

          ${c}
        }
        setOutput(sumValue);
      }
    `}}class HP{constructor(t,e){this.variableNames=["x"];const{windowSize:s,batchSize:o,inSize:r,outSize:i}=t;this.outputShape=[o,i];let a="0.0",l="";e==="prod"?a="1.0":e==="min"?(a="1.0 / 1e-20",l="min"):e==="max"&&(a="-1.0 / 1e-20",l="max");let c=`${e}(${e}(${e}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;e==="sum"?c="sumValue":e==="prod"?c="prodValue":e==="all"?c="allValue":e==="any"&&(c="anyValue");const u=Math.floor(s/4)*4,h=s%4;let d=`
      if (${e==="sum"}) {
        sumValue += dot(values, ones);
      } else if (${e==="prod"}) {
        vec2 tmp = vec2(values[0], values[1]) * vec2(values[2], values[3]);
        prodValue *= tmp[0] * tmp[1];
      } else {
        minMaxValue = ${l}(values, minMaxValue);
        if (${e==="min"} || ${e==="max"}) {
          minMaxValue = ${l}(values, minMaxValue);
          bvec4 isNaN = isnan(values);
          if (isNaN.r || isNaN.g || isNaN.b || isNaN.a) {
            minMaxValue = vec4(NAN);
          }
        }
      }
    `,p="vec4";e==="all"?(a="1.0",d=`
        bool reducedAllValue = all(values);
        float floatedReducedAllValue = float(reducedAllValue);
        allValue = float(allValue >= 1.0 && floatedReducedAllValue >= 1.0);
      `,p="bvec4"):e==="any"&&(a="0.0",d=`
        bool reducedAnyValue = any(values);
        float floatedReducedAnyValue = float(reducedAnyValue);
        anyValue = float(anyValue >= 1.0 || floatedReducedAnyValue >= 1.0);
      `,p="bvec4");let f="";r%s>0&&(f=`
        if (inIdx < 0 || inIdx >= ${r}) {
          return initializationValue;
        }
      `),this.userCode=`
      const float initializationValue = ${a};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float getValue(int batch, int inIdx) {
        ${f}
        return getX(batch, inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${s};

        vec4 minMaxValue = vec4(${a});
        float prodValue = 1.0;
        float sumValue = 0.0;
        float allValue = 1.0;
        float anyValue = 0.0;

        for (int i = 0; i < ${u}; i += 4) {
          int inIdx = inOffset + i;
          ${p} values = ${p}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          ${d}
        }

        int inIdx = inOffset + ${u};
        if (${h===1}) {
          ${p} values = ${p}(
            getValue(batch, inIdx),
            initializationValue,
            initializationValue,
            initializationValue
          );

          ${d}
        } else if (${h===2}) {
          ${p} values = ${p}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            initializationValue,
            initializationValue
          );

          ${d}
        } else if (${h===3}) {
          ${p} values = ${p}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            initializationValue
          );

          ${d}
        }
        setOutput(${c});
      }
    `}}function KP(n){const t=[];for(;t.length===0||t[t.length-1].outSize!==1;){const e=t.length?t[t.length-1].outSize:n[1],s=Hl(e);t.push({inSize:e,windowSize:s,outSize:Math.ceil(e/s)})}return t}function po(n,t,e,s){const o=KP(n.shape);let r=n;for(let i=0;i<o.length;i++){const{inSize:a,windowSize:l,outSize:c}=o[i];let u,h;e==="mean"?u=i===0?new bf({windowSize:l,inSize:a,batchSize:n.shape[0],outSize:c},a):new bf({windowSize:l,inSize:a,batchSize:n.shape[0],outSize:c}):u=new HP({windowSize:l,inSize:a,batchSize:n.shape[0],outSize:c},e),h=r,r=s.runWebGLProgram(u,[r],t),h.dataId!==n.dataId&&s.disposeIntermediateTensorInfo(h)}return r}class jP{constructor(t,e){this.variableNames=["A"];const s=new Array(t.length);for(let i=0;i<s.length;i++)s[i]=t[e[i]];this.outputShape=s,this.rank=s.length;const o=Ot(this.rank),r=qP(e);this.userCode=`
    void main() {
      ${o} resRC = getOutputCoords();
      setOutput(getA(${r}));
    }
    `}}function qP(n){const t=n.length;if(t>6)throw Error(`Transpose for rank ${t} is not yet supported`);const e=["resRC.x","resRC.y","resRC.z","resRC.w","resRC.u","resRC.v"],s=new Array(t);for(let o=0;o<n.length;o++)s[n[o]]=e[o];return s.join()}class XP{constructor(t,e){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0;const s=new Array(t.length);for(let u=0;u<s.length;u++)s[u]=t[e[u]];if(this.outputShape=s,this.rank=s.length,this.rank>6)throw Error(`Packed transpose for rank ${this.rank} is not yet supported.`);const o=Ot(this.rank),r=_0("rc",this.rank),i=new Array(this.rank);for(let u=0;u<e.length;u++)i[e[u]]=r[u];const a=`vec2(${i.slice(-2).join()})`,l=`++${r[this.rank-1]} < ${s[this.rank-1]}`,c=`getChannel(getA(${i.join()}), ${a})`;this.userCode=`
    void main() {
      ${o} rc = getOutputCoords();
      vec4 result = vec4(0.);
      result[0] = ${c};
      if(${l}) {
        result[1] = ${c};
      }
      --${r[this.rank-1]};
      if(++${r[this.rank-2]} < ${s[this.rank-2]}) {
        result[2] = ${c};
        if(${l}) {
          result[3] = ${c};
        }
      }
      setOutput(result);
    }
    `}}function lc(n,t,e){const s=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")?new XP(n.shape,t):new jP(n.shape,t);return e.runWebGLProgram(s,[n],n.dtype)}function YP(n,t,e,s){const o=t,r=n.shape.length,i=Ct(o,n.shape);let a=i;const l=jt(a,r),c=l!=null;let u=n;c&&(u=lc(n,l,s),a=Zt(a.length,r)),ye("sum",a,r);const[h,d]=fe(u.shape,a);let p=h;e&&(p=ne(h,i));const f=W(d),g=W(n.shape)/f,x=tt({inputs:{x:u},attrs:{shape:[g,f]},backend:s}),b=lh(n.dtype),w=po(x,b,"sum",s),y=tt({inputs:{x:w},attrs:{shape:p},backend:s});return s.disposeIntermediateTensorInfo(x),s.disposeIntermediateTensorInfo(w),c&&s.disposeIntermediateTensorInfo(u),y}function cc(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s;return YP(o,r,i,e)}const JP={kernelName:Tl,backendName:"webgl",kernelFunc:cc};function De(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{perm:r}=s,i=e,a=o.shape.length,l=new Array(a);for(let u=0;u<l.length;u++)l[u]=o.shape[r[u]];let c;if(i.shouldExecuteOnCPU([o])){const h=i.texData.get(o.dataId).values,d=jd(h,o.shape,o.dtype,r,l);c=i.makeTensorInfo(l,o.dtype);const p=i.texData.get(c.dataId);p.values=d}else c=lc(o,r,i);return c}const ZP={kernelName:Co,backendName:"webgl",kernelFunc:De};const W0=1e3;function Aa({a:n,b:t,transposeA:e,transposeB:s,backend:o,bias:r=null,preluActivationWeights:i=null,leakyreluAlpha:a=0,activation:l=null}){const c=n.shape.length,u=t.shape.length,h=e?n.shape[c-2]:n.shape[c-1],d=s?t.shape[u-1]:t.shape[u-2],p=e?n.shape[c-1]:n.shape[c-2],f=s?t.shape[u-2]:t.shape[u-1],m=n.shape.slice(0,-2),g=t.shape.slice(0,-2),x=W(m),b=W(g),y=mt(n.shape.slice(0,-2),t.shape.slice(0,-2)).concat([p,f]);$(h===d,()=>`Error in matMul: inner shapes (${h}) and (${d}) of Tensors with shapes ${n.shape} and ${t.shape} and transposeA=${e} and transposeB=${s} must match.`);const C=e?[x,h,p]:[x,p,h],I=s?[b,f,d]:[b,d,f],k=tt({inputs:{x:n},backend:o,attrs:{shape:C}}),v=tt({inputs:{x:t},backend:o,attrs:{shape:I}}),N=[k,v],T=Math.max(x,b),O=e?k.shape[1]:k.shape[2],P=r!=null,z=i!=null,B=l==="leakyrelu",M=l!=null?$r(l,!0):null,G=P||z||B||M!=null;let H;if((p===1||f===1)&&O>W0&&G===!1){let K=k,q=v;e&&(K=De({inputs:{x:k},backend:o,attrs:{perm:[0,2,1]}}),N.push(K)),s&&(q=De({inputs:{x:v},backend:o,attrs:{perm:[0,2,1]}}),N.push(q));const X=f!==1,Z=f===1;let J=K;X&&(J=tt({inputs:{x:K},backend:o,attrs:{shape:[T,O,1]}}),N.push(J));const et=f===1?2:1;let Q=q;Z&&(Q=tt({inputs:{x:q},backend:o,attrs:{shape:[T,1,O]}}),N.push(Q));const ot=Xd({inputs:{a:J,b:Q},backend:o});H=cc({inputs:{x:ot},backend:o,attrs:{axis:et,keepDims:!0}}),N.push(ot)}else{const K=Ue(n.dtype,t.dtype),q=new V0(C,I,[T,p,f],e,s,P,M,z,B),X=[k,v];if(r!=null&&X.push(r),z&&X.push(i),B){const Z=o.makeTensorInfo([],"float32",ws(a,"float32"));X.push(Z),N.push(Z)}H=o.runWebGLProgram(q,X,K)}const U=tt({inputs:{x:H},backend:o,attrs:{shape:y}});N.push(H);for(const K of N)o.disposeIntermediateTensorInfo(K);return U}function QP(n){const{inputs:t,backend:e,attrs:s}=n,{a:o,b:r,bias:i,preluActivationWeights:a}=t,{transposeA:l,transposeB:c,activation:u,leakyreluAlpha:h}=s;return Aa({a:o,b:r,transposeA:l,transposeB:c,backend:e,bias:i,preluActivationWeights:a,leakyreluAlpha:h,activation:u})}const t3={kernelName:ia,backendName:"webgl",kernelFunc:QP};const yf="return abs(x);";function e3(n){const{inputs:t,backend:e}=n,{x:s}=t;if(e.shouldExecuteOnCPU([s])&&s.dtype!=="complex64"){const r=e.texData.get(s.dataId),i=F0(r.values);return e.makeTensorInfo(s.shape,s.dtype,i)}let o;return L().getBool("WEBGL_PACK_UNARY_OPERATIONS")?o=new ls(s.shape,yf):o=new En(s.shape,yf),e.runWebGLProgram(o,[s],s.dtype)}const n3={kernelName:_a,backendName:"webgl",kernelFunc:e3};const s3=un+`
  if (abs(x) > 1.) {
    return NAN;
  }
  return acos(x);
`,o3=vt({opSnippet:s3}),r3={kernelName:Sr,backendName:"webgl",kernelFunc:o3};const i3=un+`
  if (x < 1.0) return NAN;
return log(x + sqrt(x * x - 1.0));`,a3=vt({opSnippet:i3}),l3={kernelName:Nr,backendName:"webgl",kernelFunc:a3};const wf="return a + b;",c3=we({opSnippet:wf,packedOpSnippet:wf,supportsComplex:!0,cpuKernelImpl:yM}),u3={kernelName:Po,backendName:"webgl",kernelFunc:c3};class h3{constructor(t,e){this.outputShape=[],this.outputShape=t,this.variableNames=e.map((r,i)=>`T${i}`);const s=[];this.variableNames.forEach(r=>{s.push(`float v${r} = get${r}AtOutCoords();`)});const o=this.variableNames.map(r=>`v${r}`).join(" + ");this.userCode=`
      void main() {
        ${s.join(`
        `)}

        float result = ${o};
        setOutput(result);
      }
    `}}class d3{constructor(t,e){this.outputShape=[],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=t,this.variableNames=e.map((r,i)=>`T${i}`);const s=[];this.variableNames.forEach(r=>{s.push(`vec4 v${r} = get${r}AtOutCoords();`)});const o=this.variableNames.map(r=>`v${r}`).join(" + ");this.userCode=`
      void main() {
        ${s.join(`
        `)}

        vec4 result = ${o};
        setOutput(result);
      }
    `}}function oa(n){const{inputs:t,backend:e}=n,s=t;if(s.length===1)return He({inputs:{x:s[0]},backend:e});if(s.length>L().getNumber("WEBGL_MAX_TEXTURES_IN_SHADER")){const l=Math.floor(s.length/2),c=oa({inputs:s.slice(0,l),backend:e}),u=oa({inputs:s.slice(l),backend:e});return oa({inputs:[c,u],backend:e})}const o=s.map(l=>l.dtype).reduce((l,c)=>Ue(l,c)),r=s.map(l=>l.shape),a=L().getBool("WEBGL_PACK")?new d3(s[0].shape,r):new h3(s[0].shape,r);return e.runWebGLProgram(a,s,o)}const p3={kernelName:wu,backendName:"webgl",kernelFunc:oa};function f3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s,a=o.shape.length,l=Ct(r,o.shape);let c=l;const u=jt(c,a);let h=o;u!=null&&(h=De({inputs:{x:o},backend:e,attrs:{perm:u}}),c=Zt(c.length,a)),ye("all",c,a);const[d,p]=fe(h.shape,c),f=W(p),m=tt({inputs:{x:h},backend:e,attrs:{shape:[-1,f]}}),g=po(m,m.dtype,"all",e);let x;if(i){const b=ne(d,l);x=tt({inputs:{x:g},backend:e,attrs:{shape:b}})}else x=tt({inputs:{x:g},backend:e,attrs:{shape:d}});return e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(g),u!=null&&e.disposeIntermediateTensorInfo(h),x}const m3={kernelName:Cu,backendName:"webgl",kernelFunc:f3};function g3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s,a=o.shape.length,l=Ct(r,o.shape);let c=l;const u=jt(c,a);let h=o;u!=null&&(h=De({inputs:{x:o},backend:e,attrs:{perm:u}}),c=Zt(c.length,a)),ye("any",c,a);const[d,p]=fe(h.shape,c),f=W(p),m=tt({inputs:{x:h},backend:e,attrs:{shape:[-1,f]}}),g=po(m,m.dtype,"any",e);let x;if(i){const b=ne(d,l);x=tt({inputs:{x:g},backend:e,attrs:{shape:b}})}else x=tt({inputs:{x:g},backend:e,attrs:{shape:d}});return e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(g),u!=null&&e.disposeIntermediateTensorInfo(h),x}const x3={kernelName:$u,backendName:"webgl",kernelFunc:g3};class b3{constructor(t,e,s){this.variableNames=["A"];const{windowSize:o,batchSize:r,outSize:i}=t;s||this.variableNames.push("bestIndicesA"),this.outputShape=[r,i];const a=e==="max"?">":"<",l=s?"inOffset + i;":"round(getBestIndicesA(batch, inOffset + i));";this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${o};

        int bestIndex = inOffset;
        float bestValue = getA(batch, bestIndex);

        for (int i = 0; i < ${o}; i++) {
          int inIdx = ${l};
          float candidate = getA(batch, inIdx);
          if (candidate ${a} bestValue) {
            bestValue = candidate;
            bestIndex = inIdx;
          }
        }
        setOutput(float(bestIndex));
      }
    `}}class y3{constructor(t,e,s,o){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,$(t.length>2,()=>`Packed arg${s.charAt(0).toUpperCase()+s.slice(1)} supports only inputs with rank above 2.`);const r=t[t.length-1],i=Math.ceil(r/e);this.outputShape=t.slice(0,-1),i>1&&this.outputShape.push(i),o||this.variableNames.push("bestIndicesA");const a=this.outputShape,l=a.length,c=Ot(l),u=Ee("coords",l);let h,d;if(i===1){d=l+1;const v=Ot(d);h=`
        ${v} sourceLocR = ${v}(${u.join()}, 0);
        ++${u[l-1]};
        ${v} sourceLocG = ${v}(${u.join()}, 0);
        ++${u[l-2]};
        ${v} sourceLocA = ${v}(${u.join()}, 0);
        --${u[l-1]};
        ${v} sourceLocB = ${v}(${u.join()}, 0);
        --${u[l-2]};`}else d=l,h=`
        ${c} sourceLocR = coords;
        ++${u[l-1]};
        ${c} sourceLocG = coords;
        ++${u[l-2]};
        ${c} sourceLocA = coords;
        --${u[l-1]};
        ${c} sourceLocB = coords;
        --${u[l-2]};`;const p=["x","y","z","w","u","v"].slice(0,d),f="."+p[d-1],m=p.map(v=>"int "+v),g=Ee("sourceLocR",d-1).concat("inIdx.r"),x=Ee("sourceLocG",d-1).concat("inIdx.g"),b=Ee("sourceLocB",d-1).concat("inIdx.b"),w=Ee("sourceLocA",d-1).concat("inIdx.a"),y=s==="max"?"greaterThan":"lessThan",C=o?"":`
          inIdx = round(vec4(getBestIndicesAChannel(${g.join()}),
                             getBestIndicesAChannel(${x.join()}),
                             getBestIndicesAChannel(${b.join()}),
                             getBestIndicesAChannel(${w.join()})));`,I=`vec4(
            getAChannel(${g.join()}),
            hasNextCol ? getAChannel(${x.join()}) : 0.,
            hasNextRow ? getAChannel(${b.join()}) : 0.,
            hasNextRow && hasNextCol ? getAChannel(${w.join()}) : 0.)`,k=o?"":`
      float getBestIndicesAChannel(${m.join()}) {
        return getChannel(getBestIndicesA(${p.join()}),
                                          vec2(${p.slice(-2).join()}));
      }`;this.userCode=`
      float getAChannel(${m.join()}) {
        return getChannel(getA(${p.join()}),
                               vec2(${p.slice(-2).join()}));
      }
      ${k}
      void main() {
        ${c} coords = getOutputCoords();
        bool hasNextCol = ${u[l-1]} < ${a[l-1]-1};
        bool hasNextRow = ${u[l-2]} < ${a[l-2]-1};
        ${h}
        ivec4 srcIdx = ivec4(sourceLocR${f}, sourceLocG${f},
          sourceLocB${f}, sourceLocA${f}) * ${e};
        ivec4 inIdx = srcIdx;
        vec4 bestIndex = vec4(inIdx);
        vec4 bestValue = ${I};

        for (int i = 0; i < ${e}; i++) {
          inIdx = srcIdx;
          ${C}
          vec4 candidate = ${I};
          bvec4 nan = isnan(candidate);
          bvec4 replace = bvec4(
            vec4(${y}(candidate, bestValue)) * (vec4(1.0) - vec4(nan)));

          bestValue = vec4(replace.x  ? candidate.x : bestValue.x,
                           replace.y  ? candidate.y : bestValue.y,
                           replace.z  ? candidate.z : bestValue.z,
                           replace.w  ? candidate.w : bestValue.w);
          bestIndex = mix(bestIndex, vec4(inIdx), vec4(replace));
          srcIdx++;
        }
        setOutput(bestIndex);
      }
    `}}function U0(n,t,e,s=null){let o=t.shape[0],r=t.shape[1];s!=null&&(o=s.shape[0],r=s.shape[1]);const i=Hl(r),a={windowSize:i,inSize:r,batchSize:o,outSize:Math.ceil(r/i)},l=new b3(a,e,s==null),c=[t];s!=null&&c.push(s);const u=n.runWebGLProgram(l,c,"int32");if(u.shape[1]===1)return u;const h=U0(n,t,e,u);return n.disposeIntermediateTensorInfo(u),h}function G0(n,t,e,s=null){const o=s!=null?s.shape:t.shape,r=o[o.length-1],i=Hl(r),a=new y3(o,i,e,s==null),l=s==null?[t]:[t,s],c=n.runWebGLProgram(a,l,"int32");if(c.shape.length===t.shape.length){const u=G0(n,t,e,c);return n.disposeIntermediateTensorInfo(c),u}return c}function H0(n,t,e,s){const o=[e];if(ye("arg"+s.charAt(0).toUpperCase()+s.slice(1),o,t.shape.length),!L().getBool("WEBGL_PACK_REDUCE")||t.shape.length<=2){const r=[],i=n.texData.get(t.dataId),a=i!==null&&i.isPacked;let l=t;a&&(l=n.unpackTensor(t),r.push(l));const[c,u]=fe(l.shape,o),h=W(u),d=tt({inputs:{x:l},backend:n,attrs:{shape:[-1,h]}});r.push(d);const p=U0(n,d,s);r.push(p);const f=tt({inputs:{x:p},backend:n,attrs:{shape:c}});return r.forEach(m=>n.disposeIntermediateTensorInfo(m)),f}return G0(n,t,s)}function w3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r}=s;let i=Ct(r,o.shape);const a=jt(i,o.shape.length);let l=o;const c=[];a!=null&&(l=De({inputs:{x:o},backend:e,attrs:{perm:a}}),c.push(l),i=Zt(i.length,l.shape.length)),ye("argMax",[i[0]],l.shape.length);const u=H0(e,l,i[0],"max");return c.forEach(h=>e.disposeIntermediateTensorInfo(h)),u}const C3={kernelName:La,backendName:"webgl",kernelFunc:w3};function $3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r}=s;let i=Ct(r,o.shape);const a=jt(i,o.shape.length);let l=o;const c=[];a!=null&&(l=De({inputs:{x:o},backend:e,attrs:{perm:a}}),c.push(l),i=Zt(i.length,l.shape.length)),ye("argMin",[i[0]],l.shape.length);const u=H0(e,l,i[0],"min");return c.forEach(h=>e.disposeIntermediateTensorInfo(h)),u}const I3={kernelName:Ma,backendName:"webgl",kernelFunc:$3};const k3=un+`
  if (abs(x) > 1.) {
    return NAN;
  }
  return asin(x);
`,v3=vt({opSnippet:k3}),S3={kernelName:Tr,backendName:"webgl",kernelFunc:v3};const N3=un+"return log(x + sqrt(x * x + 1.0));",T3=vt({opSnippet:N3}),E3={kernelName:Er,backendName:"webgl",kernelFunc:T3};const R3=un+`
  return atan(x);
`,D3=vt({opSnippet:R3}),A3={kernelName:Rr,backendName:"webgl",kernelFunc:D3};const F3=qd+`
  return atan(a, b);
`,O3=`
  vec4 result = atan(a, b);
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+ho+`
  return result;
`,_3=we({opSnippet:F3,packedOpSnippet:O3}),L3={kernelName:Ar,backendName:"webgl",kernelFunc:_3};const M3=un+`
  if ((x < -1.0) || (x > 1.0)) return NAN;
return (log(1.0 + x) - log(1.0 - x)) / 2.0;`,P3=vt({opSnippet:M3}),z3={kernelName:Dr,backendName:"webgl",kernelFunc:P3};class Ir{constructor(t,e,s,o=!1,r=!1){if(this.variableNames=["x"],e==="avg"&&s)throw new Error("Cannot compute positions for average pool.");const i=t.filterWidth,a=t.strideHeight,l=t.strideWidth,c=t.dilationHeight,u=t.dilationWidth,h=t.effectiveFilterHeight,d=t.effectiveFilterWidth,p=t.padInfo.top,f=t.padInfo.left;this.outputShape=t.outShape;const m=e==="avg",g=`((batch  * ${t.inHeight} + xR) * ${t.inWidth} + xC) * ${t.inChannels} + d`,x=`(xR * ${t.inWidth} + xC) * ${t.inChannels} + d`;let b="0.0";if(m||(b="-1.0 / 1e-20"),s){this.userCode=`
        const ivec2 strides = ivec2(${a}, ${l});
        const ivec2 pads = ivec2(${p}, ${f});

        void main() {
          ivec4 coords = getOutputCoords();
          int batch = coords[0];
          int d = coords[3];

          ivec2 xRCCorner = coords.yz * strides - pads;
          int xRCorner = xRCCorner.x;
          int xCCorner = xRCCorner.y;

          // max/min x(?, ?, d) to get y(yR, yC, d).
          // ? = to be determined
          float minMaxValue = 0.0;
          float minMaxValueFound = 0.0;
          int minMaxPosition = 0;
          float avgValue = 0.0;

          for (int wR = 0; wR < ${h};
              wR += ${c}) {
            int xR = xRCorner + wR;

            if (xR < 0 || xR >= ${t.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${d};
                wC += ${u}) {
              int xC = xCCorner + wC;

              if (xC < 0 || xC >= ${t.inWidth}) {
                continue;
              }

              float value = getX(batch, xR, xC, d);

              // If a min / max value has already been found, use it. If not,
              // use the current value.
              float currMinMaxValue = mix(
                  value, minMaxValue, minMaxValueFound);
              if (value >= currMinMaxValue) {
                minMaxValue = value;
                minMaxValueFound = 1.0;
                minMaxPosition = ${o?r?g:x:`wR * ${d} + wC`};
              }
            }
          }
          setOutput(float(minMaxPosition));
        }
      `;return}const w="max";let y=`${e}(${e}(${e}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;e==="avg"&&(y="avgValue / max(count, 1.0)");const C=Math.floor(i/4)*4,I=i%4,k=`
      if (${m}) {
        avgValue += dot(values, ones);
      } else {
        minMaxValue = ${w}(values, minMaxValue);
      }
    `;this.userCode=`
      const ivec2 strides = ivec2(${a}, ${l});
      const ivec2 pads = ivec2(${p}, ${f});
      const float initializationValue = ${b};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float count = 0.0;

      float getValue(int batch, int xR, int xC, int d) {
        if (xC < 0 || xC >= ${t.inWidth}) {
          return initializationValue;
        }
        count += 1.0;
        return getX(batch, xR, xC, d);
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d = coords[3];

        ivec2 xRCCorner = coords.yz * strides - pads;
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // max/min x(?, ?, d) to get y(yR, yC, d).
        // ? = to be determined
        vec4 minMaxValue = vec4(${b});
        float avgValue = 0.0;
        count = 0.0;

        for (int wR = 0; wR < ${h};
            wR += ${c}) {
          int xR = xRCorner + wR;

          if (xR < 0 || xR >= ${t.inHeight}) {
            continue;
          }

          for (int wC = 0; wC < ${C}; wC += 4) {
            int xC = xCCorner + wC * ${u};

            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${u}, d),
              getValue(batch, xR, xC + 2 * ${u}, d),
              getValue(batch, xR, xC + 3 * ${u}, d)
            );

            ${k}
          }

          int xC = xCCorner + ${C};
          if (${I===1}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              initializationValue,
              initializationValue,
              initializationValue
            );

            ${k}
          } else if (${I===2}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${u}, d),
              initializationValue,
              initializationValue
            );

            ${k}
          } else if (${I===3}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${u}, d),
              getValue(batch, xR, xC + 2 * ${u}, d),
              initializationValue
            );

            ${k}
          }
        }
        setOutput(${y});
      }
    `}}class Yd{constructor(t,e,s,o=!1,r=!1){if(this.variableNames=["x"],e==="avg"&&s)throw new Error("Cannot compute positions for average pool.");const i=t.filterWidth,a=t.strideDepth,l=t.strideHeight,c=t.strideWidth,u=t.dilationDepth,h=t.dilationHeight,d=t.dilationWidth,p=t.effectiveFilterDepth,f=t.effectiveFilterHeight,m=t.effectiveFilterWidth,g=t.padInfo.front,x=t.padInfo.top,b=t.padInfo.left;this.outputShape=t.outShape;const w=e==="avg";let y="0.0";if(w||(y="-1.0 / 1e-20"),s){this.userCode=`
        const ivec3 strides =
            ivec3(${a}, ${l}, ${c});
        const ivec3 pads = ivec3(${g}, ${x}, ${b});

        void main() {
          ivec5 coords = getOutputCoords();
          int batch = coords.x;
          int ch = coords.u;

          ivec3 xCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
          int xDCorner = xCorner.x;
          int xRCorner = xCorner.y;
          int xCCorner = xCorner.z;

          // max/min x(?, ?, ?, ch) to get y(yD, yR, yC, ch).
          // ? = to be determined
          float minMaxValue = 0.0;
          float minMaxValueFound = 0.0;
          int minMaxPosition = 0;

          for (int wD = 0; wD < ${p};
              wD += ${u}) {
            int xD = xDCorner + wD;

            if (xD < 0 || xD >= ${t.inDepth}) {
              continue;
            }

            for (int wR = 0; wR < ${f};
                wR += ${h}) {
              int xR = xRCorner + wR;

              if (xR < 0 || xR >= ${t.inHeight}) {
                continue;
              }

              for (int wC = 0; wC < ${m};
                  wC += ${d}) {
                int xC = xCCorner + wC;

                if (xC < 0 || xC >= ${t.inWidth}) {
                  continue;
                }

                float value = getX(batch, xD, xR, xC, ch);

                // If a min / max value has already been found, use it. If not,
                // use the current value.
                float currMinMaxValue = mix(
                    value, minMaxValue, minMaxValueFound);
                if (value >= currMinMaxValue) {
                  minMaxValue = value;
                  minMaxValueFound = 1.0;
                  minMaxPosition = ${o?r?`(((batch * ${t.inDepth} + xD) * ${t.inHeight} + xR) * ${t.inWidth} + xC) * ${t.inChannels} + ch`:`((xD * ${t.inHeight} + xR) * ${t.inWidth} + xC) * ${t.inChannels} + ch`:`wD * ${f} * ${m} +
                      wR * ${m} + wC`};
                }
              }
            }
          }
          setOutput(float(minMaxPosition));
        }
      `;return}const C="max";let I=`${e}(${e}(${e}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;e==="avg"&&(I="avgValue / max(count, 1.0)");const k=Math.floor(i/4)*4,v=i%4,N=`
      if (${w}) {
        avgValue += dot(values, ones);
      } else {
        minMaxValue = ${C}(values, minMaxValue);
      }
    `;this.userCode=`
      const ivec3 strides =
        ivec3(${a}, ${l}, ${c});
      const ivec3 pads = ivec3(${g}, ${x}, ${b});
      const float initializationValue = ${y};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float count = 0.0;

      float getValue(int batch, int xD, int xR, int xC, int ch) {
        if (xC < 0 || xC >= ${t.inWidth}) {
          return initializationValue;
        }
        count += 1.0;
        return getX(batch, xD, xR, xC, ch);
      }

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 xCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
        int xDCorner = xCorner.x;
        int xRCorner = xCorner.y;
        int xCCorner = xCorner.z;

        // max/min x(?, ?, ?, d) to get y(yD, yR, yC, ch).
        // ? = to be determined
        vec4 minMaxValue = vec4(${y});
        float avgValue = 0.0;
        count = 0.0;

        for (int wD = 0; wD < ${p};
            wD += ${u}) {
          int xD = xDCorner + wD;

          if (xD < 0 || xD >= ${t.inDepth}) {
            continue;
          }

          for (int wR = 0; wR < ${f};
            wR += ${h}) {
            int xR = xRCorner + wR;

            if (xR < 0 || xR >= ${t.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${k}; wC += 4) {
              int xC = xCCorner + wC * ${d};

              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                getValue(batch, xD, xR, xC + 2 * ${d}, ch),
                getValue(batch, xD, xR, xC + 3 * ${d}, ch)
              );

              ${N}
            }

            int xC = xCCorner + ${k};
            if (${v===1}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                initializationValue,
                initializationValue,
                initializationValue
              );

              ${N}
            } else if (${v===2}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                initializationValue,
                initializationValue
              );

              ${N}
            } else if (${v===3}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                getValue(batch, xD, xR, xC + 2 * ${d}, ch),
                initializationValue
              );

              ${N}
            }
          }
        }
        setOutput(${I});
      }
    `}}function B3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t;zi(o,"avgPool");const{filterSize:r,strides:i,pad:a,dimRoundingMode:l}=s,c=1;$(ke(i,c),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${i} and dilations '${c}'`);const u=ln(o.shape,r,i,c,a,l);if(u.filterWidth===1&&u.filterHeight===1&&Et(u.inShape,u.outShape))return He({inputs:{x:o},backend:e});const h=new Ir(u,"avg",!1);return e.runWebGLProgram(h,[o],"float32")}const V3={kernelName:Pa,backendName:"webgl",kernelFunc:B3};function W3(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{filterSize:r,strides:i,pad:a,dimRoundingMode:l,dataFormat:c}=s,u=[1,1,1],h=Zn(o.shape,r,i,u,a,l,c),d=new Yd(h,"avg",!1);return e.runWebGLProgram(d,[o],"float32")}const U3={kernelName:za,backendName:"webgl",kernelFunc:W3};class G3{constructor(t){this.variableNames=["dy"],this.outputShape=t.inShape;const e=t.filterHeight,s=t.filterWidth,o=t.strideHeight,r=t.strideWidth,i=t.dilationHeight,a=t.dilationWidth,l=t.effectiveFilterHeight,c=t.effectiveFilterWidth,u=l-1-t.padInfo.top,h=c-1-t.padInfo.left,d=1/(e*s);this.userCode=`
      const ivec2 pads = ivec2(${u}, ${h});
      const float avgMultiplier = float(${d});

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];

        ivec2 dyRCCorner = coords.yz - pads;
        int dyRCorner = dyRCCorner.x;
        int dyCCorner = dyRCCorner.y;

        // Convolve dy(?, ?, d) with pos mask(:, :, d) to get dx(xR, xC, d).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${l};
            wR += ${i}) {
          float dyR = float(dyRCorner + wR) / ${o}.0;

          if (dyR < 0.0 || dyR >= ${t.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          for (int wC = 0; wC < ${c};
            wC+= ${a}) {
            float dyC = float(dyCCorner + wC) / ${r}.0;

            if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            float dyValue = getDy(b, idyR, idyC, d);

            dotProd += dyValue * avgMultiplier;
          }
        }
        setOutput(dotProd);
      }
    `}}class H3{constructor(t){this.variableNames=["dy"],this.outputShape=t.inShape;const e=t.filterDepth,s=t.filterHeight,o=t.filterWidth,r=t.strideDepth,i=t.strideHeight,a=t.strideWidth,l=t.dilationDepth,c=t.dilationHeight,u=t.dilationWidth,h=t.effectiveFilterDepth,d=t.effectiveFilterHeight,p=t.effectiveFilterWidth,f=h-1-t.padInfo.front,m=d-1-t.padInfo.top,g=p-1-t.padInfo.left,x=1/(e*s*o);this.userCode=`
      const ivec3 pads = ivec3(${f}, ${m}, ${g});
      const float avgMultiplier = float(${x});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyDCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        // Convolve dy(?, ?, ?, d) with pos mask(:, :, :, ch) to get
        // dx(xD, xR, xC, ch).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int wD = 0; wD < ${h};
            wD += ${l}) {
          float dyD = float(dyDCorner + wD) / ${r}.0;

          if (dyD < 0.0 || dyD >= ${t.outDepth}.0 || fract(dyD) > 0.0) {
            continue;
          }
          int idyD = int(dyD);

          for (int wR = 0; wR < ${d};
              wR += ${c}) {
            float dyR = float(dyRCorner + wR) / ${i}.0;

            if (dyR < 0.0 || dyR >= ${t.outHeight}.0 ||
                fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            for (int wC = 0; wC < ${p};
                wC += ${u}) {
              float dyC = float(dyCCorner + wC) / ${a}.0;

              if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              float dyValue = getDy(batch, idyD, idyR, idyC, ch);

              dotProd += dyValue * avgMultiplier;
            }
          }
        }
        setOutput(dotProd);
      }
    `}}function K3(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,i=r,{filterSize:a,strides:l,pad:c,dimRoundingMode:u}=s,h=[1,1,1],d=Zn(i.shape,a,l,h,c,u),p=new H3(d);return e.runWebGLProgram(p,[o],i.dtype)}const j3={kernelName:ku,backendName:"webgl",kernelFunc:K3};function q3(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,i=r;zi([o,r],"avgPoolGrad");const{filterSize:a,strides:l,pad:c}=s,u=ln(i.shape,a,l,1,c),h=new G3(u);return e.runWebGLProgram(h,[o],i.dtype)}const X3={kernelName:Iu,backendName:"webgl",kernelFunc:q3};function Y3(n){const{inputs:t,backend:e,attrs:s}=n,{a:o,b:r}=t,{transposeA:i,transposeB:a}=s;return Aa({a:o,b:r,transposeA:i,transposeB:a,backend:e})}const J3={kernelName:Ba,backendName:"webgl",kernelFunc:Y3};class Z3{constructor(t,e,s,o,r,i){this.outputShape=[],this.variableNames=["x","mean","variance"],mt(t,e),mt(t,s);let a="0.0";o!=null&&(mt(t,o),this.variableNames.push("offset"),a="getOffsetAtOutCoords()");let l="1.0";r!=null&&(mt(t,r),this.variableNames.push("scale"),l="getScaleAtOutCoords()"),this.outputShape=t,this.userCode=`
      void main() {
        float x = getXAtOutCoords();
        float mean = getMeanAtOutCoords();
        float variance = getVarianceAtOutCoords();
        float offset = ${a};
        float scale = ${l};
        float inv = scale * inversesqrt(variance + float(${i}));
        setOutput(dot(vec3(x, -mean, offset), vec3(inv, inv, 1)));
      }
    `}}class Q3{constructor(t,e,s,o,r,i){this.packedInputs=!0,this.packedOutput=!0,this.variableNames=["x","mean","variance"],mt(t,e),mt(t,s);let a="vec4(0.0)";o!=null&&(mt(t,o),this.variableNames.push("offset"),a="getOffsetAtOutCoords()");let l="vec4(1.0)";r!=null&&(mt(t,r),this.variableNames.push("scale"),l="getScaleAtOutCoords()"),this.outputShape=t,this.userCode=`
      void main() {
        vec4 offset = ${a};
        vec4 scale = ${l};

        vec4 x = getXAtOutCoords();
        vec4 mean = getMeanAtOutCoords();
        vec4 variance = getVarianceAtOutCoords();

        vec4 inv = scale * inversesqrt(variance + vec4(${i}));

        setOutput((x - mean) * inv + offset);
      }
    `}}const tz=({inputs:n,backend:t,attrs:e})=>{const{x:s,mean:o,variance:r,offset:i,scale:a}=n;$(o.shape.length===r.shape.length,()=>"Batch normalization gradient requires mean and variance to have equal ranks."),$(i==null||o.shape.length===i.shape.length,()=>"Batch normalization gradient requires mean and offset to have equal ranks."),$(a==null||o.shape.length===a.shape.length,()=>"Batch normalization gradient requires mean and scale to have equal ranks.");let{varianceEpsilon:l}=e;l==null&&(l=.001);const c=[s,o,r];let u=null;i!=null&&(u=i.shape,c.push(i));let h=null;a!=null&&(h=a.shape,c.push(a));const d=L().getBool("WEBGL_PACK_NORMALIZATION")?new Q3(s.shape,o.shape,r.shape,u,h,l):new Z3(s.shape,o.shape,r.shape,u,h,l);return t.runWebGLProgram(d,c,c[0].dtype)},ez={kernelName:Za,backendName:"webgl",kernelFunc:tz};class nz{constructor(t){this.variableNames=["source"],this.outputShape=t,this.rank=t.length;const e=Ot(this.rank);this.customUniforms=[{name:"start",arrayIndex:this.rank,type:"int"}];const s=sz(this.rank);let o;const r=t.map((i,a)=>`sourceLoc.${uu[a]} = start[${a}] + coords.${uu[a]};`);o=`
        ${e} sourceLoc;
        ${e} coords = getOutputCoords();
        ${r.join(`
`)}
      `,this.userCode=`
      void main() {
        ${o}
        setOutput(getSource(${s}));
      }
    `}}const uu=["x","y","z","w","u","v"];function sz(n){if(n===1)return"sourceLoc";if(n<=6)return uu.slice(0,n).map(t=>"sourceLoc."+t).join(",");throw Error(`Slicing for rank ${n} is not yet supported`)}class oz{constructor(t){this.variableNames=["source"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=t,this.rank=t.length,this.customUniforms=[{name:"start",arrayIndex:this.rank,type:"int"}];const e=Ot(this.rank),s=Ee("coords",this.rank),o=Ee("sourceLoc",this.rank),r=this.rank===1?"sourceLoc":`vec2(${o.slice(-2).join()})`,i=`getChannel(getSource(${o.join()}), ${r})`,a=`
      result.x = ${i};
      if (++${s[this.rank-1]} < ${t[this.rank-1]}) {
        ++${o[this.rank-1]};
        result.y = ${i};
        --${o[this.rank-1]};
      }
    `,l=this.rank===1?"":`
      --${s[this.rank-1]};
      if (++${s[this.rank-2]} < ${t[this.rank-2]}) {
        ++${o[this.rank-2]};
        result.z = ${i};
        if (++${s[this.rank-1]} < ${t[this.rank-1]}) {
          ++${o[this.rank-1]};
          result.w = ${i};
        }
      }
    `,c=this.rank<=4?`sourceLoc = coords +
            ${e}(${t.map((u,h)=>`start[${h}]`).join()});`:t.map((u,h)=>`${o[h]} = ${s[h]} + start[${h}];`).join(`
`);this.userCode=`
      void main() {
        ${e} coords = getOutputCoords();
        ${e} sourceLoc;
        ${c}
        vec4 result = vec4(0.);
        ${a}
        ${l}
        setOutput(result);
      }
    `}}function rz(n,t,e,s){const o=s.texData.get(n.dataId),r=s.makeTensorInfo(e,n.dtype),i=s.texData.get(r.dataId);Object.assign(i,o),i.refCount=1,i.shape=e,i.dtype=n.dtype;let a=Hh(t,lt(n.shape));o.slice&&(a+=o.slice.flatOffset),i.slice={flatOffset:a,origDataId:o.slice&&o.slice.origDataId||n.dataId};const l=s.dataRefCount.get(i.slice.origDataId)||1;return s.dataRefCount.set(i.slice.origDataId,l+1),r}function Jo(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{begin:r,size:i}=s,[a,l]=Gl(o,r,i);if(Wh(o,a,l),W(l)===0)return e.makeTensorInfo(l,o.dtype,[]);if(e.shouldExecuteOnCPU([o])||o.dtype==="string"){const h=e.texData.get(o.dataId),d=JM(h.values,a,l,o.shape,o.dtype);return e.makeTensorInfo(l,o.dtype,d)}const{isPacked:c}=e.texData.get(o.dataId),u=Gh(o.shape,a,l);if(c||!u){const h=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")?new oz(l):new nz(l),d=[a];return e.runWebGLProgram(h,[o],o.dtype,d)}return e.uploadToGPU(o.dataId),rz(o,a,l,e)}const iz={kernelName:Nl,backendName:"webgl",kernelFunc:Jo};const az=n=>{const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockShape:r,crops:i}=s;$(o.shape.length<=4,()=>"batchToSpaceND for rank > 4 with a WebGL backend not implemented yet");const a=r.reduce((b,w)=>b*w),l=Si(o.shape,r,a),c=Ni(l.length,r.length),u=Ti(o.shape,r,a),h=Yh(i,r.length),d=Jh(u,i,r.length),p=[],f=tt({inputs:{x:o},backend:e,attrs:{shape:l}}),m=De({inputs:{x:f},backend:e,attrs:{perm:c}}),g=tt({inputs:{x:m},backend:e,attrs:{shape:u}}),x=Jo({inputs:{x:g},backend:e,attrs:{begin:h,size:d}});return p.push(f),p.push(m),p.push(g),p.forEach(b=>e.disposeIntermediateTensorInfo(b)),x},lz={kernelName:Va,backendName:"webgl",kernelFunc:az};function cz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,weights:r}=t,{size:i}=s,a=e.readSync(o.dataId),l=e.readSync(r.dataId),c=A0(a,l,r.dtype,r.shape,i);return e.makeTensorInfo([i],r.dtype,c)}const uz={kernelName:vu,backendName:"webgl",kernelFunc:cz};const hz=`
  int r = int(a.r) & int(b.r);
  int g = int(a.g) & int(b.g);
  int rb = int(a.b) & int(b.b);
  int ra = int(a.a) & int(b.a);
  return vec4(r, g, rb, ra);
`,dz=`
  return float(int(a.r) & int(b.r));
`;function pz(n){const{inputs:t,backend:e}=n,{a:s,b:o}=t,r=L().getBool("WEBGL_PACK_BINARY_OPERATIONS"),i=L().getNumber("WEBGL_VERSION");if(e.shouldExecuteOnCPU([s,o])||i===1){const l=e.texData.get(s.dataId).values,c=e.texData.get(o.dataId).values,[u,h]=CM(s.shape,o.shape,l,c,s.dtype),d=e.makeTensorInfo(h,s.dtype),p=e.texData.get(d.dataId);return p.values=u,d}let a;return r?a=new Xo(hz,s.shape,o.shape,!1):a=new no(dz,s.shape,o.shape),e.runWebGLProgram(a,[s,o],s.dtype)}const fz={kernelName:Su,backendName:"webgl",kernelFunc:pz};function mz(n){const{inputs:t,backend:e}=n,{s0:s,s1:o}=t,r=e.readSync(s.dataId),i=e.readSync(o.dataId),a=mt(Array.from(r),Array.from(i));return e.makeTensorInfo([a.length],"int32",Int32Array.from(a))}const gz={kernelName:Vf,backendName:"webgl",kernelFunc:mz};const xz="return float(a != b);",K0=we({opSnippet:xz,cpuKernelImpl:WM,dtype:"bool"}),bz={kernelName:ml,backendName:"webgl",kernelFunc:K0};function Vi(n){const{inputs:t,backend:e}=n,{input:s}=t,o=e.texData.get(s.dataId);return He({inputs:{x:o.complexTensorInfos.real},backend:e})}const yz={kernelName:Zu,backendName:"webgl",kernelFunc:Vi};const wz="return float(int(x));";function Cz(n,t){const e=new En(n.shape,wz),s=t.runWebGLProgram(e,[n],"int32");return{dataId:s.dataId,shape:s.shape,dtype:s.dtype}}function hu(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{dtype:r}=s;if(r==="complex64"){if(o.dtype==="complex64")return He({inputs:{x:o},backend:e});const i=de(o.shape),a=hu({inputs:{x:o},backend:e,attrs:{dtype:"float32"}}),l=Es({inputs:{real:a,imag:i},backend:e});return i.dispose(),e.disposeIntermediateTensorInfo(a),l}if(o.dtype==="complex64"){const i=Vi({inputs:{input:o},backend:e}),a=hu({inputs:{x:i},backend:e,attrs:{dtype:r}});return e.disposeIntermediateTensorInfo(i),a}if(!Lf(o.dtype,r)){const i=He({inputs:{x:o},backend:e});return{dataId:i.dataId,shape:i.shape,dtype:r}}if(e.shouldExecuteOnCPU([o])){const i=e.texData.get(o.dataId).values,[a,l,c]=$M(i,o.shape,o.dtype,r);return e.makeTensorInfo(a,l,c)}if(r==="int32")return Cz(o,e);if(r==="bool"){const i=e.makeTensorInfo([],"bool",Ce("bool",1)),l=K0({inputs:{a:o,b:i},backend:e});return e.disposeIntermediateTensorInfo(i),l}throw new Error(`Error in Cast: failed to cast ${o.dtype} to ${r}`)}const $z={kernelName:Fr,backendName:"webgl",kernelFunc:hu};const Cf="return ceil(x);",Iz=vt({opSnippet:Cf,packedOpSnippet:Cf,cpuKernelImpl:IM}),kz={kernelName:Or,backendName:"webgl",kernelFunc:Iz};class vz{constructor(t){this.variableNames=["A"],this.customUniforms=[{name:"minVal",type:"float"},{name:"maxVal",type:"float"}],this.outputShape=t,this.userCode=`

      void main() {
        float value = getAAtOutCoords();
        if (isnan(value)) {
          setOutput(value);
          return;
        }

        setOutput(clamp(value, minVal, maxVal));
      }
    `}}class Sz{constructor(t){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"minVal",type:"float"},{name:"maxVal",type:"float"}],this.outputShape=t,this.userCode=`
      void main() {
        vec4 value = getAAtOutCoords();

        if (any(isnan(value))) {
          setOutput(value);
          return;
        }

        setOutput(clamp(value, vec4(minVal), vec4(maxVal)));
      }
    `}}function Nz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{clipValueMin:r,clipValueMax:i}=s;let a;L().getBool("WEBGL_PACK_CLIP")?a=new Sz(o.shape):a=new vz(o.shape);const l=[[r],[i]];return e.runWebGLProgram(a,[o],o.dtype,l)}const Tz={kernelName:_r,backendName:"webgl",kernelFunc:Nz};class Ez{constructor(t){this.variableNames=["real","imag"],this.outputShape=t,this.userCode=`
      void main() {
        float re = abs(getRealAtOutCoords());
        float im = abs(getImagAtOutCoords());
        float mx = max(re, im);

        // sadly the length function in glsl is not underflow-safe
        // (at least not on Intel GPUs). So the safe solution is
        // to ensure underflow-safety in all cases.
        setOutput(
          mx == 0.0 ? 0.0 : mx * length(vec2(1, min(re, im)/mx))
        );
      }
    `}}function $f(n,t){return{dataId:t.dataId,dtype:t.dtype,shape:n.shape}}function Rz(n){const{inputs:t,backend:e}=n,{x:s}=t,o=e.texData.get(s.dataId),r=new Ez(s.shape),i=[$f(s,o.complexTensorInfos.real),$f(s,o.complexTensorInfos.imag)];return e.runWebGLProgram(r,i,i[0].dtype)}const Dz={kernelName:Wa,backendName:"webgl",kernelFunc:Rz};class Az{constructor(t){this.outputShape=[],this.outputShape=An(t,1),this.variableNames=t.map((i,a)=>`T${a}`);const e=new Array(t.length-1);e[0]=t[0][1];for(let i=1;i<e.length;i++)e[i]=e[i-1]+t[i][1];const s=[`if (yC < ${e[0]}) setOutput(getT0(yR, yC));`];for(let i=1;i<e.length;i++){const a=e[i-1];s.push(`else if (yC < ${e[i]}) setOutput(getT${i}(yR, yC-${a}));`)}const o=e.length,r=e[e.length-1];s.push(`else setOutput(getT${o}(yR, yC-${r}));`),this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int yR = coords.x;
        int yC = coords.y;

        ${s.join(`
        `)}
      }
    `}}class Fz{constructor(t,e){this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[],this.outputShape=An(t,e);const s=this.outputShape,o=s.length,r=Ot(o),i=Ee("coords",o),a=["x","y","z","w","u","v"].slice(0,o);this.variableNames=t.map((m,g)=>`T${g}`);const l=new Array(t.length-1);l[0]=t[0][e];for(let m=1;m<l.length;m++)l[m]=l[m-1]+t[m][e];const c=a[e],u=a.slice(-2),h=a.join();let d=`if (${c} < ${l[0]}) {
        return getChannel(
            getT0(${h}), vec2(${u.join()}));
        }`;for(let m=1;m<l.length;m++){const g=l[m-1];d+=`
        if (${c} < ${l[m]}  && ${c} >= ${l[m-1]}) {
          return getChannel(
            getT${m}(${na(a,c,g)}),
            vec2(${na(u,c,g)}));
        }`}const p=l.length,f=l[l.length-1];d+=`
        return getChannel(
          getT${p}(${na(a,c,f)}),
          vec2(${na(u,c,f)}));`,this.userCode=`
      float getValue(${a.map(m=>"int "+m)}) {
        ${d}
      }

      void main() {
        ${r} coords = getOutputCoords();
        vec4 result = vec4(getValue(${i}), 0., 0., 0.);

        ${i[o-1]} = ${i[o-1]} + 1;
        if (${i[o-1]} < ${s[o-1]}) {
          result.g = getValue(${i});
        }

        ${i[o-2]} = ${i[o-2]} + 1;
        if (${i[o-2]} < ${s[o-2]}) {
          result.a = getValue(${i});
        }

        ${i[o-1]} = ${i[o-1]} - 1;
        if (${i[o-2]} < ${s[o-2]} &&
            ${i[o-1]} < ${s[o-1]}) {
          result.b = getValue(${i});
        }
        setOutput(result);
      }
    `}}function na(n,t,e){const s=n.indexOf(t);return n.map((r,i)=>i===s?`${r} - ${e}`:r).join()}function uc(n){const{inputs:t,backend:e}=n,{input:s}=t,o=e.texData.get(s.dataId);return He({inputs:{x:o.complexTensorInfos.imag},backend:e})}const Oz={kernelName:Uu,backendName:"webgl",kernelFunc:uc};function lr(n,t,e){const s=n[0].dtype;if(s==="complex64"){const p=n.map(b=>Vi({inputs:{input:b},backend:e})),f=n.map(b=>uc({inputs:{input:b},backend:e})),m=lr(p,t,e),g=lr(f,t,e),x=Es({inputs:{real:m,imag:g},backend:e});return p.forEach(b=>e.disposeIntermediateTensorInfo(b)),f.forEach(b=>e.disposeIntermediateTensorInfo(b)),e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(g),x}let o=e.shouldExecuteOnCPU(n);if(s==="string"&&(o=!0),o){const p=n.map(y=>{const I=[-1,W(y.shape.slice(t))];return tt({inputs:{x:y},backend:e,attrs:{shape:I}})}),f=p.map(y=>({vals:e.readSync(y.dataId),shape:y.shape})),m=An(p.map(y=>y.shape),1),g=p[0].shape[0]===1,x=kM(f,m,s,g),b=An(n.map(y=>y.shape),t),w=e.makeTensorInfo(b,s,x);return p.forEach(y=>e.disposeIntermediateTensorInfo(y)),w}const r=n.filter(p=>W(p.shape)>0),i=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")&&r[0].shape.length>1;if(r.length===1){const p=i?new En(n[0].shape,rs):new ls(n[0].shape,rs);return e.runWebGLProgram(p,n,s)}const a=L().getNumber("WEBGL_MAX_TEXTURES_IN_SHADER");if(r.length>a){const p=[];for(let m=0;m<r.length;m+=a){const g=r.slice(m,m+a);p.push(lr(g,t,e))}const f=lr(p,t,e);for(const m of p)e.disposeIntermediateTensorInfo(m);return f}if(i){const p=new Fz(r.map(f=>f.shape),t);return e.runWebGLProgram(p,r,s)}const{tensors2D:l,outShape:c}=_z(r,t,e),u=new Az(l.map(p=>p.shape)),h=e.runWebGLProgram(u,l,s);l.forEach(p=>e.disposeIntermediateTensorInfo(p));const d=tt({inputs:{x:h},attrs:{shape:c},backend:e});return e.disposeIntermediateTensorInfo(h),d}function _z(n,t,e){const s=An(n.map(r=>r.shape),t);return{tensors2D:n.map(r=>tt({inputs:{x:r},attrs:{shape:[-1,W(r.shape.slice(t))]},backend:e})),outShape:s}}function j0(n){const{inputs:t,backend:e,attrs:s}=n,{axis:o}=s,r=Ct(o,t[0].shape)[0],i=t.map(c=>c.shape);jh(i,r);const a=An(t.map(c=>c.shape),r);if(W(a)===0)return e.makeTensorInfo(a,t[0].dtype,[]);const l=t.filter(c=>W(c.shape)>0);return l.length===1?He({inputs:{x:l[0]},backend:e}):lr(l,r,e)}const Lz={kernelName:Ua,backendName:"webgl",kernelFunc:j0};class q0{constructor(t,e=!1,s=null,o=!1,r=!1){this.variableNames=["x","W"],this.outputShape=t.outShape;const i=t.padInfo.top,a=t.padInfo.left,l=t.strideHeight,c=t.strideWidth,u=t.dilationHeight,h=t.dilationWidth,d=t.filterHeight,p=t.filterWidth,f=Math.floor(t.inChannels/4)*4,m=t.inChannels%4,g=t.dataFormat==="channelsLast",x=g?1:2,b=g?2:3,w=g?3:1;let y="",C="";s&&(o?y=`float activation(float a) {
          float b = getPreluActivationWeightsAtOutCoords();
          ${s}
        }`:r?y=`float activation(float a) {
          float b = getLeakyreluAlphaAtOutCoords();
          ${s}
        }`:y=`
          float activation(float x) {
            ${s}
          }
        `,C="result = activation(result);");const I=e?"result += getBiasAtOutCoords();":"";e&&this.variableNames.push("bias"),o&&this.variableNames.push("preluActivationWeights"),r&&this.variableNames.push("leakyreluAlpha"),this.userCode=`
      ${y}

      const ivec2 strides = ivec2(${l}, ${c});
      const ivec2 pads = ivec2(${i}, ${a});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d2 = coords[${w}];

        ivec2 xRCCorner =
            ivec2(coords[${x}], coords[${b}]) * strides - pads;
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // Convolve x(?, ?, d1) with w(:, :, d1, d2) to get y(yR, yC, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${d}; wR++) {
          int xR = xRCorner + wR * ${u};

          if (xR < 0 || xR >= ${t.inHeight}) {
            continue;
          }

          for (int wC = 0; wC < ${p}; wC++) {
            int xC = xCCorner + wC * ${h};

            if (xC < 0 || xC >= ${t.inWidth}) {
              continue;
            }

            for (int d1 = 0; d1 < ${f}; d1 += 4) {
              vec4 wValues = vec4(
                getW(wR, wC, d1, d2),
                getW(wR, wC, d1 + 1, d2),
                getW(wR, wC, d1 + 2, d2),
                getW(wR, wC, d1 + 3, d2)
              );

              if (${g}) {
                vec4 xValues = vec4(
                  getX(batch, xR, xC, d1),
                  getX(batch, xR, xC, d1 + 1),
                  getX(batch, xR, xC, d1 + 2),
                  getX(batch, xR, xC, d1 + 3)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec4 xValues = vec4(
                  getX(batch, d1, xR, xC),
                  getX(batch, d1 + 1, xR, xC),
                  getX(batch, d1 + 2, xR, xC),
                  getX(batch, d1 + 3, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }
            }

            if (${m===1}) {

              if (${g}) {
                dotProd +=
                    getX(batch, xR, xC, ${f}) *
                    getW(wR, wC, ${f}, d2);
              } else {
                dotProd +=
                    getX(batch, ${f}, xR, xC) *
                    getW(wR, wC, ${f}, d2);
              }

            } else if (${m===2}) {
              vec2 wValues = vec2(
                getW(wR, wC, ${f}, d2),
                getW(wR, wC, ${f} + 1, d2)
              );

              if (${g}) {
                vec2 xValues = vec2(
                  getX(batch, xR, xC, ${f}),
                  getX(batch, xR, xC, ${f} + 1)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec2 xValues = vec2(
                  getX(batch, ${f}, xR, xC),
                  getX(batch, ${f} + 1, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }

            } else if (${m===3}) {
              vec3 wValues = vec3(
                getW(wR, wC, ${f}, d2),
                getW(wR, wC, ${f} + 1, d2),
                getW(wR, wC, ${f} + 2, d2)
              );

              if (${g}) {
                vec3 xValues = vec3(
                  getX(batch, xR, xC, ${f}),
                  getX(batch, xR, xC, ${f} + 1),
                  getX(batch, xR, xC, ${f} + 2)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec3 xValues = vec3(
                  getX(batch, ${f}, xR, xC),
                  getX(batch, ${f} + 1, xR, xC),
                  getX(batch, ${f} + 2, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }

            }
          }
        }

        float result = dotProd;
        ${I}
        ${C}
        setOutput(result);
      }
    `}}class Mz{constructor(t){this.variableNames=["x","W"],this.outputShape=t.outShape;const e=t.padInfo.front,s=t.padInfo.top,o=t.padInfo.left,r=t.strideDepth,i=t.strideHeight,a=t.strideWidth,l=t.dilationDepth,c=t.dilationHeight,u=t.dilationWidth,h=t.filterDepth,d=t.filterHeight,p=t.filterWidth,f=Math.floor(t.inChannels/4)*4,m=t.inChannels%4;this.userCode=`
      const ivec3 strides = ivec3(${r}, ${i}, ${a});
      const ivec3 pads = ivec3(${e}, ${s}, ${o});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int d2 = coords.u;

        ivec3 xFRCCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
        int xFCorner = xFRCCorner.x;
        int xRCorner = xFRCCorner.y;
        int xCCorner = xFRCCorner.z;

        // Convolve x(?, ?, ?, d1) with w(:, :, :, d1, d2) to get
        // y(yF, yR, yC, d2). ? = to be determined. : = across all
        // values in that axis.
        float dotProd = 0.0;
        for (int wF = 0; wF < ${h}; wF++) {
          int xF = xFCorner + wF * ${l};

          if (xF < 0 || xF >= ${t.inDepth}) {
            continue;
          }

          for (int wR = 0; wR < ${d}; wR++) {
            int xR = xRCorner + wR * ${c};

            if (xR < 0 || xR >= ${t.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${p}; wC++) {
              int xC = xCCorner + wC * ${u};

              if (xC < 0 || xC >= ${t.inWidth}) {
                continue;
              }

              for (int d1 = 0; d1 < ${f}; d1 += 4) {
                vec4 xValues = vec4(
                  getX(batch, xF, xR, xC, d1),
                  getX(batch, xF, xR, xC, d1 + 1),
                  getX(batch, xF, xR, xC, d1 + 2),
                  getX(batch, xF, xR, xC, d1 + 3)
                );
                vec4 wValues = vec4(
                  getW(wF, wR, wC, d1, d2),
                  getW(wF, wR, wC, d1 + 1, d2),
                  getW(wF, wR, wC, d1 + 2, d2),
                  getW(wF, wR, wC, d1 + 3, d2)
                );

                dotProd += dot(xValues, wValues);
              }

              if (${m===1}) {
                dotProd +=
                  getX(batch, xF, xR, xC, ${f}) *
                  getW(wF, wR, wC, ${f}, d2);
              } else if (${m===2}) {
                vec2 xValues = vec2(
                  getX(batch, xF, xR, xC, ${f}),
                  getX(batch, xF, xR, xC, ${f} + 1)
                );
                vec2 wValues = vec2(
                  getW(wF, wR, wC, ${f}, d2),
                  getW(wF, wR, wC, ${f} + 1, d2)
                );
                dotProd += dot(xValues, wValues);
              } else if (${m===3}) {
                vec3 xValues = vec3(
                  getX(batch, xF, xR, xC, ${f}),
                  getX(batch, xF, xR, xC, ${f} + 1),
                  getX(batch, xF, xR, xC, ${f} + 2)
                );
                vec3 wValues = vec3(
                  getW(wF, wR, wC, ${f}, d2),
                  getW(wF, wR, wC, ${f} + 1, d2),
                  getW(wF, wR, wC, ${f} + 2, d2)
                );
                dotProd += dot(xValues, wValues);
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}}class X0{constructor(t,e=!1,s=null,o=!1,r=!1){this.variableNames=["x","W"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"pads",type:"ivec2"},{name:"strides",type:"ivec2"},{name:"dilations",type:"ivec2"},{name:"inDims",type:"ivec2"}],this.outputShape=t.outShape,this.enableShapeUniforms=Se(this.outputShape.length);const i=t.padInfo.left,a=t.strideWidth,l=t.dilationWidth,c=t.filterHeight,u=t.filterWidth,h=u;let d=`
       int xR; int xC; int xCOffset;
       vec4 wTexel; vec4 previous; vec4 final;`;for(let g=0;g<u;g++)d+=`
           vec4 xTexelC${g*2};
           int xTexelC${g*2}Ready;
           vec4 xTexelC${g*2+1};
           int xTexelC${g*2+1}Ready;
           vec4 xC${g};`;d+=`
     for (int r = 0; r < ${c}; r++) {
      for (int d1 = 0; d1 < ${t.inChannels}; d1 += 2) {
       `;for(let g=0;g<u;g++)d+=`
           xTexelC${g*2} = vec4(0.0);
           xTexelC${g*2}Ready = 0;
           xTexelC${g*2+1} = vec4(0.0);
           xTexelC${g*2+1}Ready = 0;
           xC${g} = vec4(0.0);`;d+=`
         xR = xRCorner + r * dilations[0];
         if (xR >=0 && xR < inDims[0]) {
       `;for(let g=0;g<(h+1)/2;g++){const x=g*2;if(d+=`
           xC = xCCorner + ${x*l};
           `,a===1){if(x<u&&(i%2===1?(d+=`
                 xCOffset = xC + 1;
                 if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${x}Ready == 0) {
                   xTexelC${x} = getX(batch, xR, xCOffset, d1);

                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${x}.zw = vec2(0.0);
                   }
                   xTexelC${x}Ready = 1;
                 }
               `,l===1&&x>0?d+=`
                 xC${x} = vec4(xTexelC${x-2}.zw, xTexelC${x}.xy);
                 `:d+=`
                   xCOffset = xC + 1 - 2;

                   if (xCOffset >= 0 && xCOffset < inDims[1]) {
                     previous = getX(batch, xR, xCOffset, d1);

                     // Need to manually clear unused channels in case
                     // we're reading from recycled texture.
                     if (xCOffset + 1 >= inDims[1]) {
                       previous.zw = vec2(0.0);
                     }

                     xC${x} = vec4(previous.zw, xTexelC${x}.xy);
                   } else {
                     xC${x} = vec4(0.0, 0.0, xTexelC${x}.xy);
                   }
                   `):d+=`
                 if (xC >= 0 && xC < inDims[1] && xTexelC${x}Ready == 0) {
                   xTexelC${x} = getX(batch, xR, xC, d1);
                   if (xC + 1 >= inDims[1]) {
                     xTexelC${x}.zw = vec2(0.0);
                   }
                   xTexelC${x}Ready = 1;
                 }

                 xC${x} = xTexelC${x};
                 `,x+1<u)){const b=i%2===0?mu(l):l;l%2===0&&i%2===1||l%2!==0&&i%2!==1?(d+=`
                   xCOffset = xC + imod(pads[1], 2) + ${b};

                   if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${x+1}Ready == 0) {
                     xTexelC${x+1} = getX(batch, xR, xCOffset, d1);

                     // Need to manually clear unused channels in case
                     // we're reading from recycled texture.
                     if (xCOffset + 1 >= inDims[1]) {
                       xTexelC${x+1}.zw = vec2(0.0);
                     }
                     xTexelC${x+1}Ready = 1;
                   }
                   `,l>1?d+=`
                     xCOffset -= 2;
                     if (xCOffset >= 0 && xCOffset < inDims[1]) {
                      previous = getX(batch, xR, xCOffset, d1);
                      xC${x+1} = vec4(previous.zw, xTexelC${x+1}.xy);
                     } else {
                      xC${x+1} = vec4(0.0, 0.0, xTexelC${x+1}.xy);
                     }
                     `:d+=`
                     xC${x+1} = vec4(xTexelC${x}.zw, xTexelC${x+1}.xy);
                     `):b===1?d+=`
                     xC${x+1} = xTexelC${x};
                     `:d+=`
                     xCOffset = xC + ${b};

                     if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${x+1}Ready == 0) {
                       xTexelC${x+1} = getX(batch, xR, xCOffset, d1);
                       if (xCOffset + 1 >= inDims[1]) {
                         xTexelC${x+1}.zw = vec2(0.0);
                       }
                       xTexelC${x+1}Ready = 1;
                     }

                     xC${x+1} = xTexelC${x+1};
                     `}}else x<u&&(i%2===1?(d+=`
                 xCOffset = xC + 1 - strides[1];
                 if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${x}Ready == 0) {
                   xTexelC${x} = getX(batch, xR, xCOffset, d1);
                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${x}.zw = vec2(0.0);
                   }
                   xTexelC${x}Ready = 1;
                 }

                 if(xC + 1 >= 0 && xC + 1 < inDims[1] && xTexelC${x+1}Ready == 0) {
                   xTexelC${x+1} = getX(batch, xR, xC + 1, d1);
                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xC + 2 >= inDims[1]) {
                     xTexelC${x+1}.zw = vec2(0.0);
                   }
                   xTexelC${x+1}Ready = 1;
                 }

                 xC${x} = vec4(xTexelC${x}.zw, xTexelC${x+1}.zw);
               `,x+1<u&&(d+=`
                   final = vec4(0.0);
                   xCOffset = xC + 1 + strides[1];
                   if(xCOffset >= 0 && xCOffset < inDims[1]) {
                     final = getX(batch, xR, xCOffset, d1);
                   }
                   xC${x+1} = vec4(xTexelC${x+1}.xy, final.xy);
                 `)):(d+=`
                 if(xC >= 0 && xC < inDims[1] && xTexelC${x}Ready == 0) {
                   xTexelC${x} = getX(batch, xR, xC, d1);
                   if (xC + 1 >= inDims[1]) {
                     xTexelC${x}.zw = vec2(0.0);
                   }
                   xTexelC${x}Ready = 1;
                 }

                 xCOffset = xC + strides[1];
                 if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${x+1}Ready == 0) {
                   xTexelC${x+1} = getX(batch, xR, xCOffset, d1);
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${x+1}.zw = vec2(0.);
                   }
                   xTexelC${x+1}Ready = 1;
                 }

                 xC${x} = vec4(
                   xTexelC${x}.xy, xTexelC${x+1}.xy);
               `,x+1<u&&(d+=`
                   xC${x+1} = vec4(xTexelC${x}.zw, xTexelC${x+1}.zw);
                 `)));x<u&&(d+=`
             wTexel = getW(r, ${x}, d1, d2);
             dotProd += xC${x}.xxzz * vec4(wTexel.xy, wTexel.xy);
             if(d1 + 1 < ${t.inChannels}) {
               dotProd += xC${x}.yyww * vec4(wTexel.zw, wTexel.zw);
             }
           `,x+1<u&&(d+=`
               wTexel = getW(r, ${x+1}, d1, d2);
               dotProd += xC${x+1}.xxzz * vec4(wTexel.xy, wTexel.xy);
               if(d1 + 1 < ${t.inChannels}) {
                 dotProd += xC${x+1}.yyww * vec4(wTexel.zw, wTexel.zw);
               }
             `))}d+=`
     }
   `,d+=`
     }
   `,d+=`
     }
   `;let p="",f="";s&&(o?p=`vec4 activation(vec4 a) {
           vec4 b = getPreluActivationWeightsAtOutCoords();
           ${s}
         }`:r?p=`vec4 activation(vec4 a) {
           vec4 b = getLeakyreluAlphaAtOutCoords();
           ${s}
         }`:p=`vec4 activation(vec4 x) {
           ${s}
         }`,f="result = activation(result);");const m=e?"result += getBiasAtOutCoords();":"";e&&this.variableNames.push("bias"),o&&this.variableNames.push("preluActivationWeights"),r&&this.variableNames.push("leakyreluAlpha"),this.userCode=`
       ${p}

       void main() {
         ivec4 coords = getOutputCoords();
         int batch = coords.x;
         ivec2 xRCCorner = coords.yz * strides - pads;
         int d2 = coords.w;
         int xRCorner = xRCCorner.x;
         int xCCorner = xRCCorner.y;

         //intialize dotProd with a small epsilon seems to reduce GPU accuracy loss.
         vec4 dotProd = vec4(0.000000000000001);

         ${d}

         vec4 result = dotProd - vec4(0.000000000000001);
         ${m}
         ${f}
         setOutput(result);
       }
     `}}class Pz{constructor(t,e){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"inputShape",type:"ivec4"},{name:"pad",type:"ivec2"},{name:"stride",type:"ivec2"},{name:"dilation",type:"ivec2"},{name:"inChannels",type:"int"},{name:"itemsPerBlockRow",type:"int"},{name:"outWidth",type:"int"}],this.outputShape=t,this.enableShapeUniforms=Se(this.outputShape.length);const{dataFormat:s}=e,o=Ae(),r=s==="channelsLast",i=r?1:2,a=r?2:3,l=this.enableShapeUniforms?"if(blockIndex < outShape[2] && pos < outShape[1]) {":`if(blockIndex < ${t[2]} && pos < ${t[1]}) {`;let c="";for(let u=0;u<=1;u++)for(let h=0;h<=1;h++)c+=`
          blockIndex = rc.z + ${h};
          pos = rc.y + ${u};

          ${l}
            offsetY = int(blockIndex / outWidth) * stride[0] - pad[0];
            d0 = offsetY + dilation[0] * (pos / itemsPerBlockRow);

            if(d0 < inputShape[${i}] && d0 >= 0) {
              // Use custom imod instead mod. On Intel GPU, mod may generate
              // unexpected value.
              // https://github.com/tensorflow/tfjs/issues/5447
              offsetX = imod(blockIndex, outWidth) * stride[1] - pad[1];
              d1 = offsetX + dilation[1] * (imod(pos, itemsPerBlockRow) /
                  inChannels);

              if(d1 < inputShape[${a}] && d1 >= 0) {

                ch = imod(pos, inChannels);

                if (${r}) {
                  innerDims = vec2(d1, ch);
                  result[${u*2+h}] = getChannel(
                    getA(rc.x, d0, int(innerDims.x),
                    int(innerDims.y)), innerDims);
                } else {
                  innerDims = vec2(d0, d1);
                  result[${u*2+h}] = getChannel(
                    getA(rc.x, ch, int(innerDims.x),
                    int(innerDims.y)), innerDims);
                }
              }
            }
          }
        `;this.userCode=`
      void main() {
        ivec3 rc = getOutputCoords();

        vec4 result = vec4(0);

        int blockIndex, pos, offsetY, d0, offsetX, d1, ch;
        vec2 innerDims;

        ${c}

        ${o.output} = result;
      }
    `}}function Fa(n,t){const e=n.length;return e>=3?t?[...n.slice(0,-3),n[e-3]*n[e-2],n[e-1]]:[...n.slice(0,-3),n[e-3],n[e-2]*n[e-1]]:!t&&e===1&&n[0]>1?[n[0],1]:null}function Y0({x:n,filter:t,convInfo:e,backend:s,bias:o=null,preluActivationWeights:r=null,leakyreluAlpha:i=0,activation:a=null}){const l=n.shape,c=s.texData.get(n.dataId),u=e.inChannels,h=l[0]*l[1]*l[2],d=e.outChannels,p=e.dataFormat==="channelsLast",f=!1,m=!1;let g;const x=[];if(r!=null){const y=Fa(r.shape,p);y!=null&&(r=tt({inputs:{x:r},backend:s,attrs:{shape:y}}),x.push(r))}if(o!=null){const y=Fa(o.shape,p);y!=null&&(o=tt({inputs:{x:o},backend:s,attrs:{shape:y}}),x.push(o))}if(!((h===1||d===1)&&u>W0)&&c.isPacked&&p&&c.texture!=null&&l[2]%2!==0&&Et(c.shape.slice(-3),l.slice(-3))){const y=l[0]*l[1]*(l[2]+1),C={dataId:n.dataId,shape:[1,y,e.inChannels],dtype:n.dtype},I=c.shape;c.shape=c.shape.slice(),c.shape[c.shape.length-2]++,$(Da(c.shape,C.shape),()=>`packed reshape ${c.shape} to ${C.shape} isn't free`);const k=tt({inputs:{x:t},backend:s,attrs:{shape:[1,e.inChannels,e.outChannels]}});x.push(k);const v=Aa({a:C,b:k,backend:s,transposeA:f,transposeB:m,bias:o,activation:a,preluActivationWeights:r,leakyreluAlpha:i}),N=s.texData.get(v.dataId);$(N.isPacked,()=>"batchMatMul result is expected to be packed"),c.shape=I,N.shape=e.outShape,g=He({inputs:{x:v},backend:s}),g.shape=e.outShape,x.push(v)}else{const y=e.outHeight*e.outWidth,C=tt({inputs:{x:n},backend:s,attrs:{shape:p?[e.batchSize,y,e.inChannels]:[e.batchSize,e.inChannels,y]}}),I=tt({inputs:{x:t},backend:s,attrs:{shape:[1,e.inChannels,e.outChannels]}}),k=Aa({a:p?C:I,b:p?I:C,transposeA:!p,transposeB:m,backend:s,bias:o,activation:a,preluActivationWeights:r,leakyreluAlpha:i});g=tt({inputs:{x:k},backend:s,attrs:{shape:e.outShape}}),x.push(C),x.push(I),x.push(k)}for(const y of x)s.disposeIntermediateTensorInfo(y);return g}function J0({x:n,filter:t,convInfo:e,backend:s,bias:o=null,preluActivationWeights:r=null,leakyreluAlpha:i=0,activation:a=null}){const{filterWidth:l,filterHeight:c,inChannels:u,outWidth:h,outHeight:d,dataFormat:p}=e,f=p==="channelsLast",m=l*c*u,g=d*h,x=[e.batchSize,m,g],b=!0,w=!1,y=[];if(r!=null){const U=Fa(r.shape,f);U!=null&&(r=tt({inputs:{x:r},backend:s,attrs:{shape:U}}),y.push(r))}if(o!=null){const U=Fa(o.shape,f);U!=null&&(o=tt({inputs:{x:o},backend:s,attrs:{shape:U}}),y.push(o))}const C=tt({inputs:{x:t},backend:s,attrs:{shape:[1,m,W(t.shape)/m]}});y.push(C);const I=new Pz(x,e),k=[n.shape,[e.padInfo.top,e.padInfo.left],[e.strideHeight,e.strideWidth],[e.dilationHeight,e.dilationWidth],[e.inChannels],[e.filterWidth*e.inChannels],[e.outWidth]],v=s.runWebGLProgram(I,[n],"float32",k),N=tt({inputs:{x:v},backend:s,attrs:{shape:x}});y.push(v),y.push(N);const T=o!=null,O=r!=null,P=a==="leakyrelu",z=a?$r(a,!0):null,B=new V0(f?N.shape:C.shape,f?C.shape:N.shape,f?[e.batchSize,g,e.outChannels]:[e.batchSize,e.outChannels,g],b,w,T,z,O,P),M=f?[N,C]:[C,N];if(o&&M.push(o),O&&M.push(r),P){const U=s.makeTensorInfo([],"float32",ws(i,"float32"));M.push(U),y.push(U)}const G=s.runWebGLProgram(B,M,"float32"),H=tt({inputs:{x:G},backend:s,attrs:{shape:e.outShape}});y.push(G);for(const U of y)s.disposeIntermediateTensorInfo(U);return H}function zz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dataFormat:l,dilations:c,dimRoundingMode:u}=s,h=Qn(l),d=be(o.shape,r.shape,i,c,a,u,!1,h);let p;if(d.filterHeight===1&&d.filterWidth===1&&d.dilationHeight===1&&d.dilationWidth===1&&d.strideHeight===1&&d.strideWidth===1&&(d.padInfo.type==="SAME"||d.padInfo.type==="VALID"))p=Y0({x:o,filter:r,convInfo:d,backend:e});else if(d.strideWidth<=2&&h==="channelsLast"&&L().getBool("WEBGL_EXP_CONV")){const m=new X0(d),g=[[d.padInfo.top,d.padInfo.left],[d.strideHeight,d.strideWidth],[d.dilationHeight,d.dilationWidth],[d.inHeight,d.inWidth]];p=e.runWebGLProgram(m,[o,r],"float32",g)}else if(L().getBool("WEBGL_CONV_IM2COL"))p=J0({x:o,filter:r,convInfo:d,backend:e});else{const m=new q0(d);p=e.runWebGLProgram(m,[o,r],"float32")}const f=tt({inputs:{x:p},backend:e,attrs:{shape:d.outShape}});return e.disposeIntermediateTensorInfo(p),f}const Bz={kernelName:Ga,backendName:"webgl",kernelFunc:zz};class Vz{constructor(t){this.variableNames=["x","dy"],this.outputShape=t.filterShape;const e=t.strideHeight,s=t.strideWidth,o=t.padInfo.top,r=t.padInfo.left,i=t.dataFormat==="channelsLast";this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int wR = coords.x;
        int wC = coords.y;
        int d1 = coords.z;
        int d2 = coords.w;

        // Convolve x(?, ?, d1) with dy(:, :, d2) to get dw(wR, wC, d1, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int b = 0; b < ${t.batchSize}; b++) {
          for (int yR = 0; yR < ${t.outHeight}; yR++) {
            int xR = wR + yR * ${e} - ${o};

            if (xR < 0 || xR >= ${t.inHeight}) {
              continue;
            }

            for (int yC = 0; yC < ${t.outWidth}; yC++) {
              int xC = wC + yC * ${s} - ${r};

              if (xC < 0 || xC >= ${t.inWidth}) {
                continue;
              }

              ${i?`float dyValue = getDy(b, yR, yC, d2);
              float xValue = getX(b, xR, xC, d1);
              dotProd += (xValue * dyValue);`:`float dyValue = getDy(b, d2, yR, yC);
              float xValue = getX(b, d1, xR, xC);
              dotProd += (xValue * dyValue);`}
            }
          }
        }
        setOutput(dotProd);
      }
    `}}class Wz{constructor(t){this.variableNames=["dy","W"],this.outputShape=t.inShape;const e=t.filterHeight,s=t.filterWidth,o=t.strideHeight,r=t.strideWidth,i=t.dataFormat==="channelsLast",a=e-1-t.padInfo.top,l=s-1-t.padInfo.left,c=i?1:2,u=i?2:3,h=i?3:1;this.userCode=`
      const ivec2 pads = ivec2(${a}, ${l});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[${h}];

        ivec2 dyCorner = ivec2(coords[${c}], coords[${u}]) - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${e}; wR++) {
          float dyR = float(dyRCorner + wR) / ${o}.0;

          if (dyR < 0.0 || dyR >= ${t.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          int wRPerm = ${e} - 1 - wR;

          for (int wC = 0; wC < ${s}; wC++) {
            float dyC = float(dyCCorner + wC) / ${r}.0;

            if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            int wCPerm = ${s} - 1 - wC;

            for (int d2 = 0; d2 < ${t.outChannels}; d2++) {

              if (${i}) {
                float xValue = getDy(batch, idyR, idyC, d2);
                float wValue = getW(wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              } else {
                float xValue = getDy(batch, d2, idyR, idyC);
                float wValue = getW(wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              }

            }
          }
        }
        setOutput(dotProd);
      }
    `}}class Uz{constructor(t){this.variableNames=["x","dy"],this.outputShape=t.filterShape;const e=t.strideDepth,s=t.strideHeight,o=t.strideWidth,r=t.padInfo.front,i=t.padInfo.top,a=t.padInfo.left;this.userCode=`
      void main() {
        ivec5 coords = getOutputCoords();
        int wF = coords.x;
        int wR = coords.y;
        int wC = coords.z;
        int d1 = coords.w;
        int d2 = coords.u;

        float dotProd = 0.0;

        for (int b = 0; b < ${t.batchSize}; b++) {
          for (int yF = 0; yF < ${t.outDepth}; yF++) {
            int xF = wF + yF * ${e} - ${r};

            if (xF < 0 || xF >= ${t.inDepth}) {
              continue;
            }

            for (int yR = 0; yR < ${t.outHeight}; yR++) {
              int xR = wR + yR * ${s} - ${i};

              if (xR < 0 || xR >= ${t.inHeight}) {
                continue;
              }

              for (int yC = 0; yC < ${t.outWidth}; yC++) {
                int xC = wC + yC * ${o} - ${a};

                if (xC < 0 || xC >= ${t.inWidth}) {
                  continue;
                }

                float dyValue = getDy(b, yF, yR, yC, d2);
                float xValue = getX(b, xF, xR, xC, d1);
                dotProd += (xValue * dyValue);
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}}class Gz{constructor(t){this.variableNames=["dy","W"],this.outputShape=t.inShape;const e=t.filterDepth,s=t.filterHeight,o=t.filterWidth,r=t.strideDepth,i=t.strideHeight,a=t.strideWidth,l=e-1-t.padInfo.front,c=s-1-t.padInfo.top,u=o-1-t.padInfo.left;this.userCode=`
      const ivec3 pads = ivec3(${l}, ${c}, ${u});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int d1 = coords.u;


        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyFCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        float dotProd = 0.0;
        for (int wF = 0; wF < ${e}; wF++) {
          float dyF = float(dyFCorner + wF) / ${r}.0;

          if (dyF < 0.0 || dyF >= ${t.outDepth}.0 || fract(dyF) > 0.0) {
            continue;
          }
          int idyF = int(dyF);

          int wFPerm = ${e} - 1 - wF;

          for (int wR = 0; wR < ${s}; wR++) {
            float dyR = float(dyRCorner + wR) / ${i}.0;

            if (dyR < 0.0 || dyR >= ${t.outHeight}.0 ||
              fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            int wRPerm = ${s} - 1 - wR;

            for (int wC = 0; wC < ${o}; wC++) {
              float dyC = float(dyCCorner + wC) / ${a}.0;

              if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              int wCPerm = ${o} - 1 - wC;

              for (int d2 = 0; d2 < ${t.outChannels}; d2++) {
                float xValue = getDy(batch, idyF, idyR, idyC, d2);
                float wValue = getW(wFPerm, wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}}function Hz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,pad:a,dataFormat:l,dimRoundingMode:c,filterShape:u}=s,h=Qn(l),d=be(o.shape,u,i,1,a,c,!1,h),p=new Vz(d);return e.runWebGLProgram(p,[o,r],"float32")}const Kz={kernelName:Tu,backendName:"webgl",kernelFunc:Hz};class jz{constructor(t){this.variableNames=["dy","W"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"strides",type:"vec2"}],this.outputShape=t.inShape,this.enableShapeUniforms=Se(this.outputShape.length);const e=t.filterHeight,s=t.filterWidth,o=e-1-t.padInfo.top,r=s-1-t.padInfo.left;this.userCode=`
      const ivec2 pads = ivec2(${o}, ${r});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[3];

        ivec2 dyCorner = ivec2(coords[1], coords[2]) - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        vec4 result = vec4(0.);
        for (int wR = 0; wR < ${e}; wR++) {
          float dyR = float(dyRCorner + wR) / strides[0];
          if (dyR < 0.0 || dyR >= ${t.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);
          int wRPerm = ${e} - 1 - wR;

          for (int wC = 0; wC < ${s}; wC++) {
            int wCPerm = ${s} - 1 - wC;

            float dyC = float(dyCCorner + wC) / strides[1];
            bool idyCVal = (dyC >= 0.0) && (dyC < ${t.outWidth}.0)
              && (fract(dyC) == 0.0);
            int idyC = int(dyC);

            float dyC2 = float(dyCCorner + wC + 1) / strides[1];
            bool idyCVal2 = (dyC2 >= 0.0) && (dyC2 < ${t.outWidth}.0)
              && (fract(dyC2) == 0.0);
            int idyC2 = int(dyC2);

            if (idyCVal && idyCVal2) {
              for (int d2 = 0; d2 < ${t.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC, d2);
                vec4 dySample2 = (idyC / 2 == idyC2 / 2) ?
                  dySample : getDy(batch, idyR, idyC2, d2);

                vec2 dyValue = mod(float(idyC), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.xy += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));

                dyValue = mod(float(idyC2), 2.) == 0. ?
                  dySample2.xy : dySample2.zw;
                result.zw += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            } else if (idyCVal) {
              for (int d2 = 0; d2 < ${t.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC, d2);
                vec2 dyValue = mod(float(idyC), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.xy += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            } else if (idyCVal2) {
              for (int d2 = 0; d2 < ${t.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC2, d2);
                vec2 dyValue = mod(float(idyC2), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.zw += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            }
          }
        }
        setOutput(result);
      }
    `}}function qz(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{inputShape:i,strides:a,pad:l,dataFormat:c,dimRoundingMode:u}=s,h=Qn(c),d=be(i,r.shape,a,1,l,u,!1,h);if(L().getBool("WEBGL_PACK_CONV2DTRANSPOSE")&&h==="channelsLast"){const p=[[d.strideHeight,d.strideWidth]],f=new jz(d);return e.runWebGLProgram(f,[o,r],"float32",p)}else{const p=new Wz(d);return e.runWebGLProgram(p,[o,r],"float32")}}const Xz={kernelName:Ha,backendName:"webgl",kernelFunc:qz};function Yz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dilations:l}=s,c=$s(o.shape,r.shape,i,l,a),u=new Mz(c);return e.runWebGLProgram(u,[o,r],"float32")}const Jz={kernelName:Ka,backendName:"webgl",kernelFunc:Yz};function Zz(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,pad:a,filterShape:l}=s,c=$s(o.shape,l,i,1,a),u=new Uz(c);return e.runWebGLProgram(u,[o,r],"float32")}const Qz={kernelName:Eu,backendName:"webgl",kernelFunc:Zz};function tB(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{pad:i,strides:a,inputShape:l}=s,c=$s(l,r.shape,a,1,i),u=new Gz(c);return e.runWebGLProgram(u,[o,r],"float32")}const eB={kernelName:Ru,backendName:"webgl",kernelFunc:tB};const nB=Yo+`
  return cos(x);
`,sB=`
  vec4 result = cos(x);
  bvec4 isNaN = isnan(x);
  ${ho}
  return result;
`,oB=vt({opSnippet:nB,packedOpSnippet:sB}),rB={kernelName:Lr,backendName:"webgl",kernelFunc:oB};const iB=`
  float e2x = exp(-x);
  return (e2x + 1.0 / e2x) / 2.0;
`,aB=vt({opSnippet:iB}),lB={kernelName:Mr,backendName:"webgl",kernelFunc:aB};class cB{constructor(t,e,s,o,r){this.variableNames=["Image","Boxes","BoxInd"],this.outputShape=[];const[i,a,l,c]=t,[u]=e,[h,d]=s;this.outputShape=[u,h,d,c];const p=o==="bilinear"?1:0,[f,m]=[`${a-1}.0`,`${l-1}.0`],[g,x,b]=h>1?[`${(a-1)/(h-1)}`,"(y2-y1) * height_ratio",`y1*${f} + float(y)*(height_scale)`]:["0.0","0.0",`0.5 * (y1+y2) * ${f}`],[w,y,C]=d>1?[`${(l-1)/(d-1)}`,"(x2-x1) * width_ratio",`x1*${m} + float(x)*(width_scale)`]:["0.0","0.0",`0.5 * (x1+x2) * ${m}`];this.userCode=`
      const float height_ratio = float(${g});
      const float width_ratio = float(${w});
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int y = coords[1];
        int x = coords[2];
        int d = coords[3];

        // get box vals
        float y1 = getBoxes(b,0);
        float x1 = getBoxes(b,1);
        float y2 = getBoxes(b,2);
        float x2 = getBoxes(b,3);

        // get image in batch index
        int bInd = round(getBoxInd(b));
        if(bInd < 0 || bInd >= ${i}) {
          return;
        }

        float height_scale = ${x};
        float width_scale = ${y};

        float in_y = ${b};
        if( in_y < 0.0 || in_y > ${f} ) {
          setOutput(float(${r}));
          return;
        }
        float in_x = ${C};
        if( in_x < 0.0 || in_x > ${m} ) {
          setOutput(float(${r}));
          return;
        }

        vec2 sourceFracIndexCR = vec2(in_x,in_y);
        if(${p} == 1) {
          // Compute the four integer indices.
          ivec2 sourceFloorCR = ivec2(sourceFracIndexCR);
          ivec2 sourceCeilCR = ivec2(ceil(sourceFracIndexCR));

          float topLeft = getImage(b, sourceFloorCR.y, sourceFloorCR.x, d);
          float bottomLeft = getImage(b, sourceCeilCR.y, sourceFloorCR.x, d);
          float topRight = getImage(b, sourceFloorCR.y, sourceCeilCR.x, d);
          float bottomRight = getImage(b, sourceCeilCR.y, sourceCeilCR.x, d);

          vec2 fracCR = sourceFracIndexCR - vec2(sourceFloorCR);

          float top = topLeft + (topRight - topLeft) * fracCR.x;
          float bottom = bottomLeft + (bottomRight - bottomLeft) * fracCR.x;
          float newValue = top + (bottom - top) * fracCR.y;
          setOutput(newValue);
        } else {
          // Compute the coordinators of nearest neighbor point.
          ivec2 sourceNearestCR = ivec2(floor(
            sourceFracIndexCR + vec2(0.5,0.5)));
          float newValue = getImage(b, sourceNearestCR.y, sourceNearestCR.x, d);
          setOutput(newValue);
        }
      }
    `}}const uB=n=>{const{inputs:t,backend:e,attrs:s}=n,{image:o,boxes:r,boxInd:i}=t,{cropSize:a,method:l,extrapolationValue:c}=s,u=new cB(o.shape,r.shape,a,l,c);return e.runWebGLProgram(u,[o,r,i],"float32")},hB={kernelName:Au,backendName:"webgl",kernelFunc:uB};var kr;(function(n){n.Prod="*",n.Sum="+"})(kr||(kr={}));class If{constructor(t,e,s,o){this.op=t,this.outputShape=e,this.variableNames=["x"],this.customUniforms=[{name:"index",type:"float"}];const r=this.outputShape.length,i=this.op===kr.Prod?"1.0":"0.0",a=s?i:`getX(${kf(r,"coords",this.op)})`,l=this.outputShape[this.outputShape.length-1];let c="",u="";s?(c=o?`end != ${l-1}`:"end != 0",u=o?"end + 1":"end - 1"):(c=o?`end + pow2 < ${l}`:"end >= pow2",u=o?"end + pow2":"end - pow2"),this.userCode=`
      void main() {
        ${Ot(r)} coords = getOutputCoords();
        int end = ${vf(r,"coords",this.op)};
        float val = ${a};
        int pow2 = int(pow(2.0, index));
        if (${c}) {
          int idx = ${u};
          ${vf(r,"coords",this.op)} = idx;
          val ${this.op}= getX(${kf(r,"coords",this.op)});
        }
        setOutput(val);
      }
    `}}function kf(n,t,e){if(n===1)return`${t}`;if(n===2)return`${t}.x, ${t}.y`;if(n===3)return`${t}.x, ${t}.y, ${t}.z`;if(n===4)return`${t}.x, ${t}.y, ${t}.z, ${t}.w`;throw new Error(`Cumulative ${e} for rank ${n} is not yet supported`)}function vf(n,t,e){if(n===1)return`${t}`;if(n===2)return`${t}.y`;if(n===3)return`${t}.z`;if(n===4)return`${t}.w`;throw new Error(`Cumulative ${e} for rank ${n} is not yet supported`)}function Z0(n,t,e,s,o,r){const i=t.shape.length,a=jt([s],i);let l=t;a!=null&&(l=De({inputs:{x:t},backend:e,attrs:{perm:a}}));const c=Zt(1,i)[0];if(c!==i-1)throw new Error(`WebGL cumprod shader expects an inner-most axis=${t.shape.length-1} but got axis=${s}`);const u=l.shape[c];let h=He({inputs:{x:l},backend:e});for(let d=0;d<=Math.ceil(Math.log2(u))-1;d++){const p=new If(n,l.shape,!1,r),f=[[d]],m=h;h=e.runWebGLProgram(p,[h],h.dtype,f),e.disposeIntermediateTensorInfo(m)}if(o){const d=new If(n,l.shape,o,r),p=h;h=e.runWebGLProgram(d,[h],h.dtype),e.disposeIntermediateTensorInfo(p)}if(a!=null){const d=Is(a),p=De({inputs:{x:h},backend:e,attrs:{perm:d}});return e.disposeIntermediateTensorInfo(h),e.disposeIntermediateTensorInfo(l),p}return h}function dB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,exclusive:i,reverse:a}=s;return Z0(kr.Prod,o,e,r,i,a)}const pB={kernelName:Du,backendName:"webgl",kernelFunc:dB};function fB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,exclusive:i,reverse:a}=s;return Z0(kr.Sum,o,e,r,i,a)}const mB={kernelName:ja,backendName:"webgl",kernelFunc:fB};function gB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,weights:r}=t,{size:i,binaryOutput:a}=s;if(o.shape.length===1){const l=e.readSync(o.dataId),c=e.readSync(r.dataId),u=A0(l,c,r.dtype,r.shape,i);return e.makeTensorInfo([i],r.dtype,u)}else if(o.shape.length===2){const l=e.bufferSync(o),c=e.bufferSync(r),u=wM(l,c,i,a);return e.makeTensorInfo(u.shape,r.dtype,u.values)}throw new Error(`Error in denseBincount: input must be at most rank 2, but got rank${o.shape.length}.`)}const xB={kernelName:Fu,backendName:"webgl",kernelFunc:gB};class bB{constructor(t,e,s){this.variableNames=["x"],this.outputShape=[],this.outputShape=t,this.blockSize=e,this.dataFormat=s,this.userCode=`
    void main() {
      ivec4 coords = getOutputCoords();
      int b = coords[0];
      int h = ${this.getHeightCoordString()};
      int w = ${this.getWidthCoordString()};
      int d = ${this.getDepthCoordString()};

      int in_h = h / ${e};
      int offset_h = imod(h, ${e});
      int in_w = w / ${e};
      int offset_w = imod(w, ${e});
      int offset_d = (offset_h * ${e} + offset_w) *
        ${this.getOutputDepthSize()};
      int in_d = d + offset_d;

      float result = ${this.getInputSamplingString()};
      setOutput(result);
    }
  `}getHeightCoordString(){return this.dataFormat==="NHWC"?"coords[1]":"coords[2]"}getWidthCoordString(){return this.dataFormat==="NHWC"?"coords[2]":"coords[3]"}getDepthCoordString(){return this.dataFormat==="NHWC"?"coords[3]":"coords[1]"}getOutputDepthSize(){return this.dataFormat==="NHWC"?this.outputShape[3]:this.outputShape[1]}getInputSamplingString(){return this.dataFormat==="NHWC"?"getX(b, in_h, in_w, in_d)":"getX(b, in_d, in_h, in_w)"}}function yB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockSize:r,dataFormat:i}=s,a=o.shape[0],l=i==="NHWC"?o.shape[1]:o.shape[2],c=i==="NHWC"?o.shape[2]:o.shape[3],u=i==="NHWC"?o.shape[3]:o.shape[1],h=l*r,d=c*r,p=u/(r*r),f=i==="NHWC"?[a,h,d,p]:[a,p,h,d],m=new bB(f,r,i);return e.runWebGLProgram(m,[o],o.dtype)}const wB={kernelName:Ou,backendName:"webgl",kernelFunc:yB};class Q0{constructor(t,e=!1,s=null,o=!1,r=!1){this.variableNames=["x","W"],this.customUniforms=[{name:"pads",type:"ivec2"},{name:"strides",type:"ivec2"},{name:"dilations",type:"ivec2"},{name:"inDims",type:"ivec2"}],this.outputShape=t.outShape,this.enableShapeUniforms=Se(this.outputShape.length);const i=t.filterHeight,a=t.filterWidth,l=t.outChannels/t.inChannels;let c="",u="";s&&(o?c=`float activation(float a) {
          float b = getPreluActivationWeightsAtOutCoords();
          ${s}
        }`:r?c=`float activation(float a) {
          float b = getLeakyreluAlphaAtOutCoords();
          ${s}
        }`:c=`
          float activation(float x) {
            ${s}
          }
        `,u="result = activation(result);");const h=e?"result += getBiasAtOutCoords();":"";e&&this.variableNames.push("bias"),o&&this.variableNames.push("preluActivationWeights"),r&&this.variableNames.push("leakyreluAlpha"),this.userCode=`
      ${c}

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        ivec2 xRCCorner = coords.yz * strides - pads;
        int d2 = coords.w;
        int d1 = d2 / ${l};
        int q = d2 - d1 * ${l};

        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // Convolve x(?, ?, d1) with w(:, :, d1, q) to get y(yR, yC, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        // TO DO(dsmilkov): Flatten the two for loops and vec4 the operations.
        for (int wR = 0; wR < ${i}; wR++) {
          int xR = xRCorner + wR * dilations[0];

          if (xR < 0 || xR >= inDims[0]) {
            continue;
          }

          for (int wC = 0; wC < ${a}; wC++) {
            int xC = xCCorner + wC * dilations[1];

            if (xC < 0 || xC >= inDims[1]) {
              continue;
            }

            float xVal = getX(batch, xR, xC, d1);
            float wVal = getW(wR, wC, d1, q);
            dotProd += xVal * wVal;
          }
        }

        float result = dotProd;
        ${h}
        ${u}
        setOutput(result);
      }
    `}}class t1{constructor(t,e=!1,s=null,o=!1,r=!1){this.variableNames=["x","W"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"pads",type:"ivec2"},{name:"strides",type:"ivec2"},{name:"dilations",type:"ivec2"},{name:"inDims",type:"ivec2"}],this.outputShape=t.outShape,this.enableShapeUniforms=Se(this.outputShape.length);const i=t.outChannels/t.inChannels,a=t.padInfo.left,l=t.strideWidth,c=t.dilationWidth,u=t.filterHeight,h=t.filterWidth,d=h;let p=`
      int xR; int xC; int xCOffset;
      vec4 wTexel; vec4 previous; vec4 final;`;for(let x=0;x<h;x++)p+=`
          vec4 xTexelC${x*2};
          int xTexelC${x*2}Ready;
          vec4 xTexelC${x*2+1};
          int xTexelC${x*2+1}Ready;
          vec4 xC${x};`;p+=`
    for (int r = 0; r < ${u}; r++) {
      `;for(let x=0;x<h;x++)p+=`
          xTexelC${x*2} = vec4(0.0);
          xTexelC${x*2}Ready = 0;
          xTexelC${x*2+1} = vec4(0.0);
          xTexelC${x*2+1}Ready = 0;
          xC${x} = vec4(0.0);`;p+=`
        xR = xRCorner + r * dilations[0];
        if (xR >=0 && xR < inDims[0]) {
      `;for(let x=0;x<(d+1)/2;x++){const b=x*2;if(p+=`
          xC = xCCorner + ${b*c};
          `,l===1){if(b<h&&(a%2===1?(p+=`
                xCOffset = xC + 1;
                if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${b}Ready == 0) {
                  xTexelC${b} = getX(batch, xR, xCOffset, d1);

                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${b}.zw = vec2(0.0);
                  }
                  xTexelC${b}Ready = 1;
                }
              `,c===1&&b>0?p+=`
                xC${b} = vec4(xTexelC${b-2}.zw, xTexelC${b}.xy);
                `:p+=`
                  xCOffset = xC + 1 - 2;

                  if (xCOffset >= 0 && xCOffset < inDims[1]) {
                    previous = getX(batch, xR, xCOffset, d1);

                    // Need to manually clear unused channels in case
                    // we're reading from recycled texture.
                    if (xCOffset + 1 >= inDims[1]) {
                      previous.zw = vec2(0.0);
                    }

                    xC${b} = vec4(previous.zw, xTexelC${b}.xy);
                  } else {
                    xC${b} = vec4(0.0, 0.0, xTexelC${b}.xy);
                  }
                  `):p+=`
                if (xC >= 0 && xC < inDims[1] && xTexelC${b}Ready == 0) {
                  xTexelC${b} = getX(batch, xR, xC, d1);
                  if (xC + 1 >= inDims[1]) {
                    xTexelC${b}.zw = vec2(0.0);
                  }
                  xTexelC${b}Ready = 1;
                }

                xC${b} = xTexelC${b};
                `,b+1<h)){const w=a%2===0?mu(c):c;c%2===0&&a%2===1||c%2!==0&&a%2!==1?(p+=`
                  xCOffset = xC + imod(pads[1], 2) + ${w};

                  if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${b+1}Ready == 0) {
                    xTexelC${b+1} = getX(batch, xR, xCOffset, d1);

                    // Need to manually clear unused channels in case
                    // we're reading from recycled texture.
                    if (xCOffset + 1 >= inDims[1]) {
                      xTexelC${b+1}.zw = vec2(0.0);
                    }
                    xTexelC${b+1}Ready = 1;
                  }
                  `,c>1?p+=`
                    xCOffset -= 2;
                    if (xCOffset >= 0 && xCOffset < inDims[1]) {
                     previous = getX(batch, xR, xCOffset, d1);
                     xC${b+1} = vec4(previous.zw, xTexelC${b+1}.xy);
                    } else {
                     xC${b+1} = vec4(0.0, 0.0, xTexelC${b+1}.xy);
                    }
                    `:p+=`
                    xC${b+1} = vec4(xTexelC${b}.zw, xTexelC${b+1}.xy);
                    `):w===1?p+=`
                    xC${b+1} = xTexelC${b};
                    `:p+=`
                    xCOffset = xC + ${w};

                    if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${b+1}Ready == 0) {
                      xTexelC${b+1} = getX(batch, xR, xCOffset, d1);
                      if (xCOffset + 1 >= inDims[1]) {
                        xTexelC${b+1}.zw = vec2(0.0);
                      }
                      xTexelC${b+1}Ready = 1;
                    }

                    xC${b+1} = xTexelC${b+1};
                    `}}else b<h&&(a%2===1?(p+=`
                xCOffset = xC + 1 - strides[1];
                if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${b}Ready == 0) {
                  xTexelC${b} = getX(batch, xR, xCOffset, d1);
                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${b}.zw = vec2(0.0);
                  }
                  xTexelC${b}Ready = 1;
                }

                if(xC + 1 >= 0 && xC + 1 < inDims[1] && xTexelC${b+1}Ready == 0) {
                  xTexelC${b+1} = getX(batch, xR, xC + 1, d1);
                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xC + 2 >= inDims[1]) {
                    xTexelC${b+1}.zw = vec2(0.0);
                  }
                  xTexelC${b+1}Ready = 1;
                }

                xC${b} = vec4(xTexelC${b}.zw, xTexelC${b+1}.zw);
              `,b+1<h&&(p+=`
                  final = vec4(0.0);
                  xCOffset = xC + 1 + strides[1];
                  if(xCOffset >= 0 && xCOffset < inDims[1]) {
                    final = getX(batch, xR, xCOffset, d1);
                  }
                  xC${b+1} = vec4(xTexelC${b+1}.xy, final.xy);
                `)):(p+=`
                if(xC >= 0 && xC < inDims[1] && xTexelC${b}Ready == 0) {
                  xTexelC${b} = getX(batch, xR, xC, d1);
                  if (xC + 1 >= inDims[1]) {
                    xTexelC${b}.zw = vec2(0.0);
                  }
                  xTexelC${b}Ready = 1;
                }

                xCOffset = xC + strides[1];
                if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${b+1}Ready == 0) {
                  xTexelC${b+1} = getX(batch, xR, xCOffset, d1);
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${b+1}.zw = vec2(0.);
                  }
                  xTexelC${b+1}Ready = 1;
                }

                xC${b} = vec4(
                  xTexelC${b}.xy, xTexelC${b+1}.xy);
              `,b+1<h&&(p+=`
                  xC${b+1} = vec4(xTexelC${b}.zw, xTexelC${b+1}.zw);
                `)));b<h&&(p+=`
            wTexel = getW(r, ${b}, d1, q);
            dotProd += xC${b} * vec4(wTexel.xz, wTexel.xz);
          `,b+1<h&&(p+=`
              wTexel = getW(r, ${b+1}, d1, q);
              dotProd += xC${b+1} * vec4(wTexel.xz, wTexel.xz);
            `))}p+=`
    }
  `,p+=`
      }
    `;let f="",m="";s&&(o?f=`vec4 activation(vec4 a) {
          vec4 b = getPreluActivationWeightsAtOutCoords();
          ${s}
        }`:r?f=`vec4 activation(vec4 a) {
          vec4 b = getLeakyreluAlphaAtOutCoords();
          ${s}
        }`:f=`vec4 activation(vec4 x) {
          ${s}
        }`,m="result = activation(result);");const g=e?"result += getBiasAtOutCoords();":"";e&&this.variableNames.push("bias"),o&&this.variableNames.push("preluActivationWeights"),r&&this.variableNames.push("leakyreluAlpha"),this.userCode=`
      ${f}

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        ivec2 xRCCorner = coords.yz * strides - pads;
        int d2 = coords.w;
        int d1 = d2 / ${i};
        int q = d2 - d1 * ${i};
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        //intialize dotProd with a small epsilon seems to reduce GPU accuracy loss.
        vec4 dotProd = vec4(0.000000000000001);

        ${p}

        vec4 result = dotProd - vec4(0.000000000000001);
        ${g}
        ${m}
        setOutput(result);
      }
    `}}function CB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dilations:l,dimRoundingMode:c}=s;let u=l;u==null&&(u=[1,1]),$(ke(i,u),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${i} and dilations '${u}'`);const h=be(o.shape,r.shape,i,u,a,c,!0);let d;L().getBool("WEBGL_PACK_DEPTHWISECONV")&&h.strideWidth<=2&&h.outChannels/h.inChannels===1?d=new t1(h):d=new Q0(h);const p=[[h.padInfo.top,h.padInfo.left],[h.strideHeight,h.strideWidth],[h.dilationHeight,h.dilationWidth],[h.inHeight,h.inWidth]];return e.runWebGLProgram(d,[o,r],"float32",p)}const $B={kernelName:qa,backendName:"webgl",kernelFunc:CB};class IB{constructor(t){this.variableNames=["x","dy"],this.outputShape=t.filterShape;const e=t.strideHeight,s=t.strideWidth,o=t.padInfo.top,r=t.padInfo.left,i=t.outChannels/t.inChannels;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int wR = coords.x;
        int wC = coords.y;
        int d1 = coords.z;
        int dm = coords.w;
        int d2 = d1 * ${i} + dm;

        float dotProd = 0.0;

        // TO DO: Vec4 over the batch size
        for (int b = 0; b < ${t.batchSize}; b++) {
          for (int yR = 0; yR < ${t.outHeight}; yR++) {
            int xR = wR + yR * ${e} - ${o};

            if (xR < 0 || xR >= ${t.inHeight}) {
              continue;
            }

            for (int yC = 0; yC < ${t.outWidth}; yC++) {
              int xC = wC + yC * ${s} - ${r};

              if (xC < 0 || xC >= ${t.inWidth}) {
                continue;
              }

              float dyValue = getDy(b, yR, yC, d2);
              float xValue = getX(b, xR, xC, d1);
              dotProd += (xValue * dyValue);
            }
          }
        }
        setOutput(dotProd);
      }
    `}}class kB{constructor(t){this.variableNames=["dy","W"],this.outputShape=t.inShape;const e=t.filterHeight,s=t.filterWidth,o=t.strideHeight,r=t.strideWidth,i=e-1-t.padInfo.top,a=s-1-t.padInfo.left,l=t.outChannels/t.inChannels;this.userCode=`
      const ivec2 pads = ivec2(${i}, ${a});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[3];
        ivec2 dyCorner = coords.yz - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        float dotProd = 0.0;

        for (int wR = 0; wR < ${e}; wR++) {
          float dyR = float(dyRCorner + wR) / ${o}.0;

          if (dyR < 0.0 || dyR >= ${t.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          int wRPerm = ${e} - 1 - wR;

          for (int wC = 0; wC < ${s}; wC++) {
            float dyC = float(dyCCorner + wC) / ${r}.0;

            if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            int wCPerm = ${s} - 1 - wC;

            // TO DO: Vec4 over the channelMul
            for (int dm = 0; dm < ${l}; dm++) {
              int d2 = d1 * ${l} + dm;
              float xValue = getDy(batch, idyR, idyC, d2);
              float wValue = getW(wRPerm, wCPerm, d1, dm);
              dotProd += xValue * wValue;
            }
          }
        }
        setOutput(dotProd);
      }
    `}}function vB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,dy:r}=t,{strides:i,dilations:a,pad:l,dimRoundingMode:c,filterShape:u}=s,h=be(o.shape,u,i,a,l,c,!0),d=new IB(h);return e.runWebGLProgram(d,[o,r],"float32")}const SB={kernelName:_u,backendName:"webgl",kernelFunc:vB};function NB(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,filter:r}=t,{strides:i,dilations:a,pad:l,dimRoundingMode:c,inputShape:u}=s,h=be(u,r.shape,i,a,l,c,!0),d=new kB(h);return e.runWebGLProgram(d,[o,r],"float32")}const TB={kernelName:Lu,backendName:"webgl",kernelFunc:NB};class EB{constructor(t){this.variableNames=["X"],this.outputShape=[t,t],this.userCode=`
      void main() {
          ivec2 coords = getOutputCoords();
          float val = coords[0] == coords[1] ? getX(coords[0]) : 0.0;
          setOutput(val);
      }
    `}}function RB(n){const{inputs:t,backend:e}=n,{x:s}=t,o=[...s.shape,...s.shape],r=W(s.shape),i=tt({inputs:{x:s},backend:e,attrs:{shape:[r]}}),a=new EB(r),l=e.runWebGLProgram(a,[i],i.dtype),c=tt({inputs:{x:l},backend:e,attrs:{shape:o}});return e.disposeIntermediateTensorInfo(i),e.disposeIntermediateTensorInfo(l),c}const DB={kernelName:Wf,backendName:"webgl",kernelFunc:RB};class AB{constructor(t){this.variableNames=["x","W"],this.outputShape=t.outShape;const{inHeight:e,inWidth:s,padInfo:o,strideHeight:r,strideWidth:i,filterHeight:a,filterWidth:l,dilationHeight:c,dilationWidth:u}=t,{top:h,left:d}=o;this.userCode=`
      const ivec2 strides = ivec2(${r}, ${i});
      const ivec2 pads = ivec2(${h}, ${d});
      const float neg_infinity = -3.4e38;

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        int d1 = coords.w;
        ivec2 outTopLeftCorner =
            coords.yz * strides - pads;
        int hBeg = outTopLeftCorner.x;
        int wBeg = outTopLeftCorner.y;

        float curVal = neg_infinity;
        for (int h = 0; h < ${a}; h++) {
          int hIn = hBeg + h * ${c};

          if (hIn >= 0 && hIn < ${e}) {
            for (int w = 0; w < ${l}; w++) {
              int wIn = wBeg + w * ${u};

              if (wIn >= 0 && wIn < ${s}) {
                float xVal = getX(batch, hIn, wIn, d1);
                float wVal = getW(h, w, d1);

                float val = xVal + wVal;
                if (val > curVal) {
                  curVal = val;
                }
              }
            }
          }
        }

        float result = curVal;
        setOutput(result);
      }
    `}}function FB(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r}=t,{strides:i,pad:a,dilations:l}=s,c=Ci(o.shape,r.shape,i,a,"NHWC",l);let u;const h=new AB(c);u=e.runWebGLProgram(h,[o,r],"float32");const d=tt({inputs:{x:u},backend:e,attrs:{shape:c.outShape}});return e.disposeIntermediateTensorInfo(u),d}const OB={kernelName:Xa,backendName:"webgl",kernelFunc:FB};function _B(n){const{inputs:t,backend:e,attrs:s}=n,{equation:o}=s,r=t,{allDims:i,summedDims:a,idDims:l}=rd(o,r.length);ad(i.length,l,r);const{path:c,steps:u}=ld(a,l),h=u.length;let d=null,p=i.length;const f=[];for(let m=0;m<h;++m){for(const g of u[m]){const{permutationIndices:x,expandDims:b}=id(p,l[g]);let w;cd(x)?w=r[g]:(w=De({inputs:{x:r[g]},backend:e,attrs:{perm:x}}),f.push(w));const y=w.shape.slice();for(let C=0;C<b.length;++C)y.splice(b[C],0,1);Et(w.shape,y)||(w=tt({inputs:{x:w},backend:e,attrs:{shape:y}}),f.push(w)),d===null?d=w:(d=Xd({inputs:{a:w,b:d},backend:e}),f.push(d))}m<h-1&&(c[m]>=0&&(d=cc({inputs:{x:d},backend:e,attrs:{axis:c[m]-(i.length-p),keepDims:!1}}),f.push(d)),p--)}for(const m of f)m!==d&&e.disposeIntermediateTensorInfo(m);return d}const LB={kernelName:Mu,backendName:"webgl",kernelFunc:_B};const MB="return (x >= 0.0) ? x : (exp(x) - 1.0);",PB=`
  vec4 result;

  result.r = (x.r >= 0.0) ? x.r : (exp(x.r) - 1.0);
  result.g = (x.g >= 0.0) ? x.g : (exp(x.g) - 1.0);
  result.b = (x.b >= 0.0) ? x.b : (exp(x.b) - 1.0);
  result.a = (x.a >= 0.0) ? x.a : (exp(x.a) - 1.0);

  return result;
`,zB=vt({opSnippet:MB,packedOpSnippet:PB}),BB={kernelName:zr,backendName:"webgl",kernelFunc:zB};const VB="return (b >= 0.0) ? a : a * (b + 1.0);",WB=`
  vec4 bGTEZero = vec4(greaterThanEqual(b, vec4(0.)));
  return (bGTEZero * a) + ((vec4(1.0) - bGTEZero) * (a * (b + vec4(1.0))));
`,UB=n=>{const{inputs:t,backend:e}=n,{dy:s,y:o}=t,r=L().getBool("WEBGL_PACK_BINARY_OPERATIONS")?new Xo(WB,s.shape,o.shape):new no(VB,s.shape,o.shape);return e.runWebGLProgram(r,[s,o],s.dtype)},GB={kernelName:Pu,backendName:"webgl",kernelFunc:UB};const HB=`
  return vec4(equal(a, b));
`,KB="return float(a == b);",jB=we({opSnippet:KB,packedOpSnippet:HB,dtype:"bool",cpuKernelImpl:vM}),qB={kernelName:Ya,backendName:"webgl",kernelFunc:jB};const XB=`
  // Error function is calculated approximately with elementary function.
  // See "Handbook of Mathematical Functions with Formulas,
  // Graphs, and Mathematical Tables", Abramowitz and Stegun.
  float p = ${Zh};
  float a1 = ${Qh};
  float a2 = ${td};
  float a3 = ${ed};
  float a4 = ${nd};
  float a5 = ${sd};

  float sign = sign(x);
  x = abs(x);
  float t = 1.0 / (1.0 + p * x);
  return sign * (1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1)*t*exp(-x*x));
`,YB=vt({opSnippet:XB}),JB={kernelName:Br,backendName:"webgl",kernelFunc:YB};const ZB=Yo+`
  return exp(x);
`,QB=`
  vec4 result = exp(x);
  bvec4 isNaN = isnan(x);
  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,e1=vt({opSnippet:ZB,packedOpSnippet:QB,cpuKernelImpl:SM,dtype:"float32"}),tV={kernelName:Vr,backendName:"webgl",kernelFunc:e1};function du(n){const{inputs:t,attrs:e,backend:s}=n,{dim:o}=e,{input:r}=t,i=r.shape.length,a=r.shape.slice();let l=o;return o<0&&($(-(i+1)<=o,()=>`Axis must be in the interval [${-(i+1)}, ${i}]`),l=i+o+1),a.splice(l,0,1),tt({inputs:{x:r},backend:s,attrs:{shape:a}})}const eV={kernelName:Ja,backendName:"webgl",kernelFunc:du};const Sf="return exp(x) - 1.0;",nV=vt({opSnippet:Sf,packedOpSnippet:Sf,cpuKernelImpl:NM}),sV={kernelName:Wr,backendName:"webgl",kernelFunc:nV};class Nf{constructor(t,e,s){this.variableNames=["real","imag"];const o=e[1];this.outputShape=e;const r=s?`2.0 * ${Math.PI}`:`-2.0 * ${Math.PI}`,i=s?`${o}.0`:"1.0";let a;if(t==="real")a="return real * expR - imag * expI;";else if(t==="imag")a="return real * expI + imag * expR;";else throw new Error(`FFT component must be either "real" or "imag", got ${t}.`);this.userCode=`
      const float exponentMultiplier = ${r};

      float unaryOpComplex(float real, float expR, float imag, float expI) {
        ${a}
      }

      float mulMatDFT(int batch, int index) {
        float indexRatio = float(index) / float(${o});
        float exponentMultiplierTimesIndexRatio =
            exponentMultiplier * indexRatio;

        float result = 0.0;

        for (int i = 0; i < ${o}; i++) {
          // x = (-2|2 * PI / N) * index * i;
          float x = exponentMultiplierTimesIndexRatio * float(i);
          float expR = cos(x);
          float expI = sin(x);
          float real = getReal(batch, i);
          float imag = getImag(batch, i);

          result +=
              unaryOpComplex(real, expR, imag, expI) / ${i};
        }

        return result;
      }

      void main() {
        ivec2 coords = getOutputCoords();
        setOutput(mulMatDFT(coords[0], coords[1]));
      }
    `}}function n1(n,t,e){const s=e.texData.get(n.dataId),o=W(n.shape),r=n.shape[n.shape.length-1],i=o/r,a=tt({inputs:{x:n},backend:e,attrs:{shape:[i,r]}}),l=a.shape,c=new Nf("real",l,t),u=new Nf("imag",l,t),h=[{dataId:s.complexTensorInfos.real.dataId,dtype:s.complexTensorInfos.real.dtype,shape:l},{dataId:s.complexTensorInfos.imag.dataId,dtype:s.complexTensorInfos.imag.dtype,shape:l}],d=e.runWebGLProgram(c,h,"float32"),p=e.runWebGLProgram(u,h,"float32"),f=Es({inputs:{real:d,imag:p},backend:e});e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p);const m=tt({inputs:{x:f},backend:e,attrs:{shape:n.shape}});return e.disposeIntermediateTensorInfo(a),e.disposeIntermediateTensorInfo(f),m}function oV(n){const{inputs:t,backend:e}=n,{input:s}=t;return n1(s,!1,e)}const rV={kernelName:zu,backendName:"webgl",kernelFunc:oV};class iV{constructor(t,e){this.outputShape=[],this.customUniforms=[{name:"value",type:"float"}],this.variableNames=["x"],this.outputShape=t,this.userCode=`
      void main() {
        // Input can be obtained from uniform value.
        setOutput(value);
      }
    `}}function Wi(n){const{backend:t,attrs:e}=n,{shape:s,value:o}=e;let{dtype:r}=e;if(r=r||Lo(o),r==="string"){const i=Xt(r,W(s));return i.fill(o),t.makeTensorInfo(s,r,i)}else{const i=new iV(s,o),a=[[o]];return t.runWebGLProgram(i,[],r,a)}}const aV={kernelName:Bu,backendName:"webgl",kernelFunc:Wi};class lV{constructor(t){this.variableNames=["Image"],this.outputShape=[];const e=t[2];this.outputShape=t,this.userCode=`
        void main() {
          ivec4 coords = getOutputCoords();
          int x = coords[2];

          int coordX = ${e} - x - 1;
          float outputValue;
          if(coordX >= 0 && coordX < ${e}) {
            outputValue = getImage(coords[0], coords[1], coordX, coords[3]);
          } else {
            outputValue = getImage(coords[0], coords[1], coords[2], coords[3]);
          }
          setOutput(outputValue);
        }
    `}}const cV={kernelName:Vu,backendName:"webgl",kernelFunc:({inputs:n,backend:t})=>{const{image:e}=n,s=t,o=new lV(e.shape);return s.runWebGLProgram(o,[e],e.dtype)}};const Tf="return floor(x);",uV=vt({opSnippet:Tf,packedOpSnippet:Tf,cpuKernelImpl:TM}),hV={kernelName:Ur,backendName:"webgl",kernelFunc:uV};const dV=`
  float s = sign(a) * sign(b);
  int ia = round(a);
  int ib = round(b);
  if (ib != 0) {
    // Windows (D3D) wants guaranteed non-zero int division at compile-time.
    return float(idiv(ia, ib, s));
  } else {
    return NAN;
  }
`,pV=`
  ivec4 ia = round(a);
  ivec4 ib = round(b);
  bvec4 cond = notEqual(ib, ivec4(0));
  ivec4 result = ivec4(0);
  vec4 s = sign(a) * sign(b);

  // Windows (D3D) wants guaranteed non-zero int division at compile-time.
  if (cond[0]) {
    result[0] = idiv(ia[0], ib[0], s[0]);
  }
  if (cond[1]) {
    result[1] = idiv(ia[1], ib[1], s[1]);
  }
  if (cond[2]) {
    result[2] = idiv(ia[2], ib[2], s[2]);
  }
  if (cond[3]) {
    result[3] = idiv(ia[3], ib[3], s[3]);
  }
  return vec4(result);
`,fV=we({opSnippet:dV,packedOpSnippet:pV,dtype:"int32"}),mV={kernelName:Gr,backendName:"webgl",kernelFunc:fV};class gV{constructor(t){this.variableNames=["A"];const e=Ae(),[s,o]=t;this.outputShape=t,this.userCode=`
      void main() {
        ivec3 coords = getOutputCoords();
        int texR = coords[0];
        int texC = coords[1];
        int depth = coords[2];
        vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${o}.0, ${s}.0);

        vec4 values = ${e.texture2D}(A, uv);
        float value;
        if (depth == 0) {
          value = values.r;
        } else if (depth == 1) {
          value = values.g;
        } else if (depth == 2) {
          value = values.b;
        } else if (depth == 3) {
          value = values.a;
        }

        setOutput(floor(value * 255.0 + 0.5));
      }
    `}}class xV{constructor(t){this.variableNames=["A"],this.packedInputs=!1,this.packedOutput=!0;const e=Ae(),[s,o]=t;this.outputShape=t,this.userCode=`
      void main() {
        ivec3 coords = getOutputCoords();
        int texR = coords[0];
        int texC = coords[1];
        int depth = coords[2];

        vec4 result = vec4(0.);

        for(int row=0; row<=1; row++) {
          for(int col=0; col<=1; col++) {
            texC = coords[1] + row;
            depth = coords[2] + col;

            vec2 uv = (vec2(texC, texR) + halfCR) /
                       vec2(${o}.0, ${s}.0);
            vec4 values = ${e.texture2D}(A, uv);
            float value;
            if (depth == 0) {
              value = values.r;
            } else if (depth == 1) {
              value = values.g;
            } else if (depth == 2) {
              value = values.b;
            } else if (depth == 3) {
              value = values.a;
            }

            result[row * 2 + col] = floor(value * 255.0 + 0.5);
          }
        }

        ${e.output} = result;
      }
    `}}const bV={kernelName:_1,backendName:"webgl",kernelFunc:yV};let go,Rc=L().getBool("CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU");function yV(n){const{inputs:t,backend:e,attrs:s}=n;let{pixels:o}=t;const{numChannels:r}=s,i=typeof HTMLVideoElement<"u"&&o instanceof HTMLVideoElement,a=typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement,[l,c]=i?[o.videoWidth,o.videoHeight]:[o.width,o.height],u=[c,l],h=[c,l,r];if(a||i){const m=L().getBool("CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU");(go==null||m!==Rc)&&(Rc=m,go=document.createElement("canvas").getContext("2d",{willReadFrequently:Rc})),go.canvas.width=l,go.canvas.height=c,go.drawImage(o,0,0,l,c),o=go.canvas}const d=e.makeTensorInfo(u,"int32");e.texData.get(d.dataId).usage=qe.PIXELS,e.gpgpu.uploadPixelDataToTexture(e.getTexture(d.dataId),o);const p=L().getBool("WEBGL_PACK")?new xV(h):new gV(h),f=e.runWebGLProgram(p,[d],"int32");return e.disposeData(d.dataId),f}function wV(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r,bias:i,preluActivationWeights:a}=t,{strides:l,pad:c,dataFormat:u,dilations:h,dimRoundingMode:d,activation:p,leakyreluAlpha:f}=s,m=Qn(u),g=be(o.shape,r.shape,l,h,c,d,!1,m);let x;const b=[],w=i!=null,y=a!=null,C=p==="leakyrelu",I=()=>{const v=[o,r],N=(T,O)=>{if(O==="NCHW"&&T.shape.length===1&&T.shape[0]!==1){const P=tt({inputs:{x:T},backend:e,attrs:{shape:[T.shape[0],1,1]}});return b.push(P),P}return T};if(w&&v.push(N(i,u)),y&&v.push(N(a,u)),C){const T=e.makeTensorInfo([],"float32",ws(f,"float32"));v.push(T),b.push(T)}return v};if(g.filterHeight===1&&g.filterWidth===1&&g.dilationHeight===1&&g.dilationWidth===1&&g.strideHeight===1&&g.strideWidth===1&&(g.padInfo.type==="SAME"||g.padInfo.type==="VALID"))x=Y0({x:o,filter:r,convInfo:g,backend:e,bias:i,activation:p,preluActivationWeights:a,leakyreluAlpha:f});else if(g.strideWidth<=2&&m==="channelsLast"&&L().getBool("WEBGL_EXP_CONV")){const v=p?$r(p,!0):null,N=new X0(g,w,v,y,C),T=[[g.padInfo.top,g.padInfo.left],[g.strideHeight,g.strideWidth],[g.dilationHeight,g.dilationWidth],[g.inHeight,g.inWidth]],O=I();x=e.runWebGLProgram(N,O,"float32",T)}else if(L().getBool("WEBGL_CONV_IM2COL"))x=J0({x:o,filter:r,convInfo:g,backend:e,bias:i,activation:p,preluActivationWeights:a,leakyreluAlpha:f});else{const v=p?$r(p,!1):null,N=new q0(g,w,v,y,C),T=I();x=e.runWebGLProgram(N,T,"float32")}const k=tt({inputs:{x},backend:e,attrs:{shape:g.outShape}});return b.push(x),b.forEach(v=>e.disposeIntermediateTensorInfo(v)),k}const CV={kernelName:aa,backendName:"webgl",kernelFunc:wV};function $V(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,filter:r,bias:i,preluActivationWeights:a}=t,{strides:l,pad:c,dilations:u,dimRoundingMode:h,activation:d,leakyreluAlpha:p}=s,f=[];let m=u;m==null&&(m=[1,1]),$(ke(l,m),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${l} and dilations '${m}'`);const g=be(o.shape,r.shape,l,m,c,h,!0),x=L().getBool("WEBGL_PACK_DEPTHWISECONV")&&g.strideWidth<=2&&g.outChannels/g.inChannels===1,b=d?$r(d,x):null,w=[o,r],y=i!=null,C=a!=null,I=d==="leakyrelu";if(y&&w.push(i),C&&w.push(a),I){const T=e.makeTensorInfo([],"float32",ws(p,"float32"));w.push(T),f.push(T)}let k;x?k=new t1(g,y,b,C,I):k=new Q0(g,y,b,C,I);const v=[[g.padInfo.top,g.padInfo.left],[g.strideHeight,g.strideWidth],[g.dilationHeight,g.dilationWidth],[g.inHeight,g.inWidth]],N=e.runWebGLProgram(k,w,"float32",v);return f.forEach(T=>e.disposeIntermediateTensorInfo(T)),N}const IV={kernelName:im,backendName:"webgl",kernelFunc:$V};class kV{constructor(t,e,s,o){this.sliceDim=t,this.strides=e,this.paramsShape=o,this.variableNames=["x","indices"],this.outputShape=s;const r=Ot(s.length);let i=`
    int index;`;for(let a=0;a<this.sliceDim;a++)i+=`
          index = round(getIndices(coords[0], ${a}));
          out_of_bounds = out_of_bounds || index < 0;
          out_of_bounds = out_of_bounds || index >= ${this.paramsShape[a]};
          flattenIndex += index * ${this.strides[a]};`;this.userCode=`
         void main() {
          ${r} coords = getOutputCoords();
          int flattenIndex = 0;
          bool out_of_bounds = false;

          ${i}

          setOutput(out_of_bounds ? 0.0 : getX(flattenIndex, coords[1]));
        }
      `}}function vV(n){const{inputs:t,backend:e}=n,{params:s,indices:o}=t,r=o.shape,i=r[r.length-1],a=W(s.shape),[l,c,u,h]=Vh(s,o),d=tt({inputs:{x:o},backend:e,attrs:{shape:[c,i]}}),p=tt({inputs:{x:s},backend:e,attrs:{shape:[W(s.shape)/u,u]}});if(e.shouldExecuteOnCPU([s,o])||s.dtype==="string"){const x=e.readSync(o.dataId),b=e.bufferSync(s),w=EM(x,b,s.dtype,c,i,u,h,s.shape,a);return e.makeTensorInfo(l,s.dtype,w.values)}const f=new kV(i,h,[c,u],s.shape),m=e.runWebGLProgram(f,[p,d],p.dtype),g=tt({inputs:{x:m},backend:e,attrs:{shape:l}});return e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(m),g}const SV={kernelName:Uf,backendName:"webgl",kernelFunc:vV};class NV{constructor(t,e){this.variableNames=["A","indices"],this.outputShape=e,this.rank=e.length;const s=Ot(this.rank),o=TV(t);this.userCode=`
      void main() {
        ${s} resRC = getOutputCoords();
        int index = int(getIndices(resRC.x, resRC.z));
        float inBounds = (index >= 0) && (index < ${t[2]}) ? 1.0 : 0.0;
        setOutput(inBounds * getA(${o}));
      }
    `}}function TV(n,t){const e=["resRC.x","resRC.y","resRC.z","resRC.w"],s=[];for(let o=0;o<n.length;o++)o===2?s.push("index"):s.push(`${e[o]}`);return s.join()}function s1(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,indices:r}=t,{axis:i,batchDims:a}=s,l=Ct(i,o.shape)[0];if(L().get("DEBUG")){const b=e.readSync(r.dataId),w=o.shape[l];for(let y=0;y<b.length;++y){const C=b[y];$(C<=w-1&&C>=0,()=>`GatherV2: the index value ${C} is not in [0, ${w-1}]`)}}const c=hd(o,r,l,a),u=W(r.shape),h=[],d=tt({inputs:{x:o},backend:e,attrs:{shape:[c.batchSize,c.outerSize,c.dimSize,c.sliceSize]}}),p=tt({inputs:{x:r},backend:e,attrs:{shape:[c.batchSize,u/c.batchSize]}});h.push(d),h.push(p);const f=[c.batchSize,c.outerSize,u/c.batchSize,c.sliceSize];if(e.shouldExecuteOnCPU([o,r])||o.dtype==="string"){const b=e.bufferSync(p),w=e.bufferSync(d),y=RM(w,b,f);return h.forEach(C=>e.disposeIntermediateTensorInfo(C)),e.makeTensorInfo(c.outputShape,y.dtype,y.values)}const m=new NV(d.shape,f),g=e.runWebGLProgram(m,[d,p],d.dtype);h.push(g);const x=tt({inputs:{x:g},backend:e,attrs:{shape:c.outputShape}});return h.forEach(b=>e.disposeIntermediateTensorInfo(b)),x}const EV={kernelName:Qa,backendName:"webgl",kernelFunc:s1};const RV="return float(a > b);",DV=`
  return vec4(greaterThan(a, b));
`,AV=we({opSnippet:RV,packedOpSnippet:DV,cpuKernelImpl:DM,dtype:"bool"}),FV={kernelName:tl,backendName:"webgl",kernelFunc:AV};const OV="return float(a >= b);",_V=`
  return vec4(greaterThanEqual(a, b));
`,LV=we({opSnippet:OV,packedOpSnippet:_V,dtype:"bool",cpuKernelImpl:AM}),MV={kernelName:Hr,backendName:"webgl",kernelFunc:LV};function PV(n){const{inputs:t,backend:e}=n,{input:s}=t;return n1(s,!0,e)}const zV={kernelName:Wu,backendName:"webgl",kernelFunc:PV};const BV="return float(!isnan(x) && !isinf(x));",VV=vt({opSnippet:BV,dtype:"bool"}),WV={kernelName:jr,backendName:"webgl",kernelFunc:VV};const UV="return float(isinf(x));",GV=vt({opSnippet:UV,dtype:"bool"}),HV={kernelName:qr,backendName:"webgl",kernelFunc:GV};const KV="return float(isnan(x));",jV=vt({opSnippet:KV,dtype:"bool"}),qV={kernelName:Xr,backendName:"webgl",kernelFunc:jV};const XV="return float(a < b);",YV=`
  return vec4(lessThan(a, b));
`,JV=we({opSnippet:XV,packedOpSnippet:YV,cpuKernelImpl:FM,dtype:"bool"}),ZV={kernelName:nl,backendName:"webgl",kernelFunc:JV};const QV="return float(a <= b);",tW=`
  return vec4(lessThanEqual(a, b));
`,eW=we({opSnippet:QV,packedOpSnippet:tW,cpuKernelImpl:OM,dtype:"bool"}),nW={kernelName:sl,backendName:"webgl",kernelFunc:eW};function sW(n){const{backend:t,attrs:e}=n,{start:s,stop:o,num:r}=e,i=_M(s,o,r);return t.makeTensorInfo([i.length],"float32",i)}const oW={kernelName:Gu,backendName:"webgl",kernelFunc:sW};const rW=Yo+`
  return x < 0.0 ? 0./0. : log(x);
`,iW=`
  vec4 result = log(x);
  bvec4 isNaN = isnan(x);
  result.r = isNaN.r ? x.r : (x.r < 0.0 ? 0./0. : result.r);
  result.g = isNaN.g ? x.g : (x.g < 0.0 ? 0./0. : result.g);
  result.b = isNaN.b ? x.b : (x.b < 0.0 ? 0./0. : result.b);
  result.a = isNaN.a ? x.a : (x.a < 0.0 ? 0./0. : result.a);
  return result;
`,aW=vt({opSnippet:rW,packedOpSnippet:iW,cpuKernelImpl:LM}),lW={kernelName:Yr,backendName:"webgl",kernelFunc:aW};const cW=Yo+`
  return log(1.0 + x);
`,uW=vt({opSnippet:cW}),hW={kernelName:Jr,backendName:"webgl",kernelFunc:uW};const dW="return float(a >= 1.0 && b >= 1.0);",pW=`
  return vec4(
    vec4(greaterThanEqual(a, vec4(1.0))) *
    vec4(greaterThanEqual(b, vec4(1.0))));
`,fW=we({opSnippet:dW,packedOpSnippet:pW,dtype:"bool"}),mW={kernelName:ol,backendName:"webgl",kernelFunc:fW};const gW="return float(!(x >= 1.0));",xW=vt({opSnippet:gW}),bW={kernelName:rl,backendName:"webgl",kernelFunc:xW};const yW="return float(a >= 1.0 || b >= 1.0);",wW=`
  return min(
    vec4(greaterThanEqual(a, vec4(1.0))) +
    vec4(greaterThanEqual(b, vec4(1.0))),
    vec4(1.0));
`,CW=we({opSnippet:yW,packedOpSnippet:wW,dtype:"bool"}),$W={kernelName:il,backendName:"webgl",kernelFunc:CW};class IW{constructor(t,e,s,o,r){this.variableNames=["x"],this.outputShape=[];const i=e,a=t[3]-1;this.outputShape=t;let l;const c=`float(${s}) + float(${o}) * sum`;r===.5?l=`inversesqrt(${c})`:r===1?l=`1.0/(${c})`:l=`exp(log(${c}) * float(-${r}));`,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int r = coords[1];
        int c = coords[2];
        int d = coords[3];
        float x = getX(b, r, c, d);
        float sum = 0.0;
        for (int j = -${i}; j <= ${i}; j++) {
          int idx = d + j;
          if (idx >= 0 && idx <=  ${a}) {
            float z = getX(b, r, c, idx);
            sum += z * z;
          }
        }
        float val = x * ${l};
        setOutput(val);
      }
    `}}class kW{constructor(t,e,s,o,r){this.variableNames=["x"],this.outputShape=[],this.packedInputs=!0,this.packedOutput=!0;const i=e,a=t[3]-1;this.outputShape=t;let l;const c=`float(${s}) + float(${o}) * sum`;r===.5?l=`inversesqrt(${c})`:r===1?l=`1.0/(${c})`:l=`exp(log(${c}) * float(-${r}));`,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords.x;
        int r = coords.y;
        int c = coords.z;
        int d = coords.w;

        bool hasNextCol = d < ${this.outputShape[3]};
        bool hasNextRow = c < ${this.outputShape[2]};

        vec4 sum = vec4(0.);
        vec4 xFragAtOutputCoords = getX(b, r, c, d);

        vec4 xAtOutputCoords = vec4(
          getChannel(xFragAtOutputCoords, vec2(c, d)),
          hasNextCol ?
            getChannel(xFragAtOutputCoords, vec2(c, d + 1)) : 0.0,
          hasNextRow ?
            getChannel(xFragAtOutputCoords , vec2(c + 1, d)) : 0.0,
          (hasNextRow && hasNextCol) ?
            getChannel(xFragAtOutputCoords, vec2(c + 1, d + 1)) : 0.0
        );

        int firstChannel = d - ${i};
        vec2 cache = vec2(0.);
        if(firstChannel >= 0){
          vec4 firstChannelFrag = getX(b, r, c, firstChannel);
          cache.x = getChannel(firstChannelFrag, vec2(c, firstChannel));
            if(hasNextRow){
              cache.y = getChannel(firstChannelFrag, vec2(c + 1, firstChannel));
            }
        }

        ivec2 depth = ivec2(d, d + 1);
        for (int j = - ${i}; j <= ${i}; j++) {
          ivec2 idx = depth + j;
          bvec2 aboveLowerBound = greaterThanEqual(idx, ivec2(0));
          bvec2 belowUpperBound = lessThanEqual(idx, ivec2(${a}));

          bool depthInRange = aboveLowerBound.x && belowUpperBound.x;
          bool depthPlusOneInRange = aboveLowerBound.y && belowUpperBound.y;

          if(depthInRange || depthPlusOneInRange){
            vec4 z = vec4(0.);
            vec4 xFragAtCurrentDepth;
            z.xz = cache.xy;
            if(depthPlusOneInRange && hasNextCol){
              xFragAtCurrentDepth = idx.y != d ?
                getX(b, r, c, idx.y) : xFragAtOutputCoords;
              z.y = getChannel(xFragAtCurrentDepth, vec2(c, idx.y));
              if(hasNextRow){
                z.w = getChannel(xFragAtCurrentDepth, vec2(c + 1, idx.y));
              }
            }
            cache.xy = z.yw;
            sum += z * z;
          }
        }
        vec4 result = xAtOutputCoords * ${l};
        setOutput(result);
      }
    `}}const vW=n=>{const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{depthRadius:r,bias:i,alpha:a,beta:l}=s,c=L().getBool("WEBGL_PACK_NORMALIZATION")?new kW(o.shape,r,i,a,l):new IW(o.shape,r,i,a,l);return e.runWebGLProgram(c,[o],o.dtype)},SW={kernelName:al,backendName:"webgl",kernelFunc:vW};class NW{constructor(t,e,s,o,r){this.variableNames=["inputImage","outputImage","dy"],this.outputShape=[],this.outputShape=t,this.depth=t[3],this.depthRadius=e,this.bias=s,this.alpha=o,this.beta=r,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int r = coords[1];
        int c = coords[2];

        float result = 0.0;
        for (int d = 0; d < ${this.depth}; ++d) {
          int depthBegin = int(max(0.0, float(d - ${e})));
          int depthEnd = int(min(float(${this.depth}),
              float(d + ${e} + 1)));

          const int MIN_DEPTH_BEGIN = 0;
          const int MAX_DEPTH_END = ${this.depth};

          float norm = 0.0;
          for (int k = MIN_DEPTH_BEGIN; k < MAX_DEPTH_END; ++k) {
            if (k < depthBegin){
              continue;
            }
            else if (k >= depthBegin && k < depthEnd) {
              norm += getInputImage(b, r, c, k) * getInputImage(b, r, c, k);
            }
            else {
              break;
            }
          }

          norm = float(${o}) * norm + float(${s});

          for(int k = MIN_DEPTH_BEGIN; k < MAX_DEPTH_END; ++k){
            if (k < depthBegin){
              continue;
            }
            else if (k >= depthBegin && k < depthEnd){
              float dyi = -2.0 * float(${o})
                * float(${r})
                * getInputImage(b, r, c, k) * getOutputImage(b, r, c, d)
                / norm;
              if (k == d) {
                dyi += pow(norm, -1.0 * ${r});
              }
              if (k == coords[3]) {
                dyi *= getDy(b, r, c, d);
                result += dyi;
              }
            }
            else {
              break;
            }
          }
      }
      setOutput(result);
      }
    `}}const TW=n=>{const{inputs:t,backend:e,attrs:s}=n,{x:o,y:r,dy:i}=t,{depthRadius:a,bias:l,alpha:c,beta:u}=s,h=new NW(o.shape,a,l,c,u);return e.runWebGLProgram(h,[o,r,i],o.dtype)},EW={kernelName:Hu,backendName:"webgl",kernelFunc:TW};function RW(n,t,e,s){const o=W(t),i=W(n.shape)/o,a=tt({inputs:{x:n},attrs:{shape:[i,o]},backend:s}),l=po(a,n.dtype,"max",s),c=tt({inputs:{x:l},attrs:{shape:e},backend:s});return s.disposeIntermediateTensorInfo(a),s.disposeIntermediateTensorInfo(l),c}function o1(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{reductionIndices:r,keepDims:i}=s,a=o.shape.length,l=Ct(r,o.shape);let c=l;const u=jt(c,a),h=u!=null,d=e.shouldExecuteOnCPU([o]);let p=o;if(h){if(d){const w=e.texData.get(p.dataId).values,y=new Array(a);for(let k=0;k<y.length;k++)y[k]=o.shape[u[k]];const C=jd(w,o.shape,o.dtype,u,y);p=e.makeTensorInfo(y,o.dtype);const I=e.texData.get(p.dataId);I.values=C}else p=lc(o,u,e);c=Zt(c.length,a)}ye("max",c,a);const[f,m]=fe(p.shape,c);let g=f;i&&(g=ne(f,l));let x;if(d){const w=e.texData.get(p.dataId).values,y=MM(w,W(m),g,o.dtype);x=e.makeTensorInfo(g,o.dtype);const C=e.texData.get(x.dataId);C.values=y}else x=RW(p,m,g,e);return h&&e.disposeIntermediateTensorInfo(p),x}const DW={kernelName:ll,backendName:"webgl",kernelFunc:o1};const AW=qd+`
  return max(a, b);
`,FW=`
  vec4 result = vec4(max(a, b));
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+ho+`
  return result;
`,OW=we({opSnippet:AW,packedOpSnippet:FW,cpuKernelImpl:PM}),_W={kernelName:Zr,backendName:"webgl",kernelFunc:OW};function LW(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t;zi(o,"maxPool");const{filterSize:r,strides:i,pad:a,dimRoundingMode:l}=s,c=1;$(ke(i,c),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${i} and dilations '${c}'`);const u=ln(o.shape,r,i,c,a,l);if(u.filterWidth===1&&u.filterHeight===1&&Et(u.inShape,u.outShape))return He({inputs:{x:o},backend:e});const h=new Ir(u,"max",!1);return e.runWebGLProgram(h,[o],o.dtype)}const MW={kernelName:cl,backendName:"webgl",kernelFunc:LW};function PW(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{filterSize:r,strides:i,pad:a,dataFormat:l,dimRoundingMode:c}=s,u=[1,1,1],h=Zn(o.shape,r,i,u,a,c,l),d=new Yd(h,"max",!1);return e.runWebGLProgram(d,[o],o.dtype)}const zW={kernelName:ul,backendName:"webgl",kernelFunc:PW};class BW{constructor(t){this.variableNames=["dy","maxPos"],this.outputShape=t.inShape;const e=t.strideHeight,s=t.strideWidth,o=t.dilationHeight,r=t.effectiveFilterHeight,i=t.effectiveFilterWidth,a=r-1-t.padInfo.top,l=i-1-t.padInfo.left,c=r*i-1;this.userCode=`
      const ivec2 pads = ivec2(${a}, ${l});

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];

        ivec2 dyRCCorner = coords.yz - pads;
        int dyRCorner = dyRCCorner.x;
        int dyCCorner = dyRCCorner.y;

        // Convolve dy(?, ?, d) with pos mask(:, :, d) to get dx(xR, xC, d).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${r};
          wR += ${o}) {
          float dyR = float(dyRCorner + wR) / ${e}.0;

          if (dyR < 0.0 || dyR >= ${t.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          for (int wC = 0; wC < ${i}; wC++) {
            float dyC = float(dyCCorner + wC) / ${s}.0;

            if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            float dyValue = getDy(b, idyR, idyC, d);
            int maxPosValue = ${c} - int(getMaxPos(b, idyR, idyC, d));

            // Get the current value, check it against the value from the
            // position matrix.
            int curPosValue = wR * ${i} + wC;
            float mask = float(maxPosValue == curPosValue ? 1.0 : 0.0);

            dotProd += dyValue * mask;
          }
        }
        setOutput(dotProd);
      }
    `}}class VW{constructor(t){this.variableNames=["dy","maxPos"],this.outputShape=t.inShape;const e=t.strideDepth,s=t.strideHeight,o=t.strideWidth,r=t.dilationDepth,i=t.dilationHeight,a=t.dilationWidth,l=t.effectiveFilterDepth,c=t.effectiveFilterHeight,u=t.effectiveFilterWidth,h=l-1-t.padInfo.front,d=c-1-t.padInfo.top,p=u-1-t.padInfo.left,f=l*c*u-1;this.userCode=`
      const ivec3 pads = ivec3(${h}, ${d}, ${p});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyDCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        // Convolve dy(?, ?, ?, ch) with pos mask(:, :, :, d) to get
        // dx(xD, xR, xC, ch).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int wD = 0; wD < ${l};
           wD += ${r}) {
          float dyD = float(dyDCorner + wD) / ${e}.0;

          if (dyD < 0.0 || dyD >= ${t.outDepth}.0 || fract(dyD) > 0.0) {
            continue;
          }
          int idyD = int(dyD);

          for (int wR = 0; wR < ${c};
              wR += ${i}) {
            float dyR = float(dyRCorner + wR) / ${s}.0;

            if (dyR < 0.0 || dyR >= ${t.outHeight}.0 ||
                fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            for (int wC = 0; wC < ${u};
                wC += ${a}) {
              float dyC = float(dyCCorner + wC) / ${o}.0;

              if (dyC < 0.0 || dyC >= ${t.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              float dyValue = getDy(batch, idyD, idyR, idyC, ch);
              int maxPosValue = ${f} -
                  int(getMaxPos(batch, idyD, idyR, idyC, ch));

              // Get the current value, check it against the value from the
              // position matrix.
              int curPosValue =
                  wD * ${c} * ${u} +
                  wR * ${u} + wC;
              float mask = float(maxPosValue == curPosValue ? 1.0 : 0.0);

              dotProd += dyValue * mask;
            }
          }
        }
        setOutput(dotProd);
      }
    `}}function WW(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r}=t,i=r,{filterSize:a,strides:l,pad:c,dimRoundingMode:u}=s,h=[1,1,1],d=Zn(i.shape,a,l,h,c,u),p=new Yd(d,"max",!0),f=e.runWebGLProgram(p,[i],i.dtype),m=new VW(d),g=e.runWebGLProgram(m,[o,f],i.dtype);return e.disposeIntermediateTensorInfo(f),g}const UW={kernelName:ju,backendName:"webgl",kernelFunc:WW};function GW(n){const{inputs:t,backend:e,attrs:s}=n,{dy:o,input:r,output:i}=t,a=r;zi([r,i],"maxPoolGrad");const{filterSize:l,strides:c,pad:u,dimRoundingMode:h}=s,d=ln(a.shape,l,c,1,u,h),p=!0,f=new Ir(d,"max",p),m=e.runWebGLProgram(f,[a],a.dtype),g=new BW(d),x=e.runWebGLProgram(g,[o,m],a.dtype);return e.disposeIntermediateTensorInfo(m),x}const HW={kernelName:Ku,backendName:"webgl",kernelFunc:GW};function KW(n,t,e,s){let o=new Ir(e,"max",!1);const r=s.runWebGLProgram(o,[n],"float32");o=new Ir(e,"max",!0,!0,t);const i=s.runWebGLProgram(o,[n],"float32");return[r,i]}const jW={kernelName:Gf,backendName:"webgl",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{x:s}=n,{filterSize:o,strides:r,pad:i,includeBatchInIndex:a}=t,l=e;$(s.shape.length===4,()=>`Error in maxPool: input must be rank 4 but got rank ${s.shape.length}.`);const c=[1,1];$(ke(r,c),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${r} and dilations '${c}'`);const u=ln(s.shape,o,r,c,i),[h,d]=KW(s,a,u,l);return[h,d]}};function qW(n,t,e,s){const o=W(t),i=W(n.shape)/o,a=tt({inputs:{x:n},attrs:{shape:[i,o]},backend:s}),l=po(a,"float32","mean",s),c=tt({inputs:{x:l},attrs:{shape:e},backend:s});return s.disposeIntermediateTensorInfo(a),s.disposeIntermediateTensorInfo(l),c}const XW={kernelName:hl,backendName:"webgl",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{x:s}=n,{keepDims:o,axis:r}=t,i=e,a=s.shape.length,l=Ct(r,s.shape);let c=l;const u=jt(c,a),h=u!=null,d=i.shouldExecuteOnCPU([s]),p=[];let f=s;if(h){if(d){const y=i.texData.get(f.dataId).values,C=new Array(a);for(let v=0;v<C.length;v++)C[v]=s.shape[u[v]];const I=jd(y,s.shape,s.dtype,u,C);f=i.makeTensorInfo(C,s.dtype);const k=i.texData.get(f.dataId);k.values=I}else f=lc(s,u,i);p.push(f),c=Zt(c.length,a)}ye("sum",c,a);const[m,g]=fe(f.shape,c);let x=m;o&&(x=ne(m,l));const b=qW(f,g,x,i);for(const w of p)i.disposeIntermediateTensorInfo(w);return b}};function YW(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s,a=o.shape.length,l=Ct(r,o.shape);let c=l;const u=jt(c,a);let h=o;u!=null&&(h=De({inputs:{x:o},backend:e,attrs:{perm:u}}),c=Zt(c.length,o.shape.length)),ye("min",c,a);const[d,p]=fe(h.shape,c),f=W(p),m=tt({inputs:{x:h},backend:e,attrs:{shape:[-1,f]}}),g=po(m,m.dtype,"min",e);let x;if(i){const b=ne(d,l);x=tt({inputs:{x:g},backend:e,attrs:{shape:b}})}else x=tt({inputs:{x:g},backend:e,attrs:{shape:d}});return e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(g),u!=null&&e.disposeIntermediateTensorInfo(h),x}const JW={kernelName:dl,backendName:"webgl",kernelFunc:YW};const ZW=qd+`
  return min(a, b);
`,QW=`
  vec4 result = vec4(min(a, b));
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+ho+`
  return result;
`,t4=we({opSnippet:ZW,packedOpSnippet:QW,cpuKernelImpl:zM}),e4={kernelName:Qr,backendName:"webgl",kernelFunc:t4};class n4{constructor(t,e,s){this.variableNames=["x"],this.outputShape=e.map((u,h)=>u[0]+t[h]+u[1]);const o=t.length,r=Ot(o),i=e.map(u=>u[0]).join(","),a=e.map((u,h)=>u[0]+t[h]).join(","),l=["coords[0]","coords[1]","coords[2]","coords[3]"].slice(0,o),c=s==="reflect"?0:1;if(o===1){this.userCode=`
        int start = ${i};
        int end = ${a};

        void main() {
          int outC = getOutputCoords();
          if (outC < start) {
            outC = start * 2 - outC - ${c};
          } else if(outC >= end) {
            outC = (end - 1) * 2 - outC + ${c};
          }
          setOutput(getX(outC - start));
        }
      `;return}this.userCode=`
      ${r} start = ${r}(${i});
      ${r} end = ${r}(${a});

      void main() {
        ${r} outC = getOutputCoords();
        for (int i = 0; i < ${o}; i++) {
          if (outC[i] < start[i]) {
            outC[i] = start[i] * 2 - outC[i] - ${c};
          } else if(outC[i] >= end[i]) {
            outC[i] = (end[i] - 1) * 2 - outC[i] + ${c};
          }
        }
        ${r} coords = outC - start;
        setOutput(getX(${l}));
      }
    `}}class s4{constructor(t,e,s){this.variableNames=["x"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=e.map((f,m)=>f[0]+t[m]+f[1]);const o=t.length,r=Ot(o),i=e.map(f=>f[0]).join(","),a=e.map((f,m)=>f[0]+t[m]).join(","),l=Ee("rc",o),c=Ee("source",o),u=`${l[o-1]} < ${this.outputShape[o-1]}`,h=o===1?"source":`vec2(${c.slice(-2).join()})`,d=s==="reflect"?0:1;let p="";if(o===1){const f=`
        ${r} source = rc;
        if (source < start) {
          source = start * 2 - source - ${d};
        } else if (source >= end) {
          source = (end - 1) * 2 - source + ${d};
        }
        source -= start;
      `;p=`
        ${r} rc = outputLoc;
        ${f}
        result[0] = getChannel(getX(${c.join()}), ${h});
        ${l[o-1]} += 1;
        if(${u}) {
          ${f}
          result[1] = getChannel(getX(${c.join()}), ${h});
        }
      `}else{const f=`
        ${r} source = rc;
        ${r} lt = ${r}(lessThan(source, start));
        ${r} gte = ${r}(greaterThanEqual(source, end));
        ${r} orig = 1 - (lt + gte);
        source = orig * source +
                lt * (start * 2 - source - ${d}) +
                gte * ((end - 1) * 2 - source + ${d});
        source -= start;
      `;p=`
        ${r} rc = outputLoc;
        ${f}
        result[0] = getChannel(getX(${c.join()}), ${h});
        ${l[o-1]} += 1;
        if(${u}) {
          ${f}
          result[1] = getChannel(getX(${c.join()}), ${h});
        }
        rc = outputLoc;
        ${l[o-2]} += 1;
        if(${l[o-2]} < ${this.outputShape[o-2]}) {
          ${f}
          result[2] = getChannel(getX(${c.join()}), ${h});
          ${l[o-1]} += 1;
          if(${u}) {
            ${f}
            result[3] = getChannel(getX(${c.join()}), ${h});
          }
        }
      `}this.userCode=`
      const ${r} start = ${r}(${i});
      const ${r} end = ${r}(${a});

      void main() {
        ${r} outputLoc = getOutputCoords();
        vec4 result = vec4(0.);
        ${p}
        setOutput(result);
      }
    `}}const o4=({inputs:n,backend:t,attrs:e})=>{const{x:s}=n,{paddings:o,mode:r}=e,i=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")?new s4(s.shape,o,r):new n4(s.shape,o,r);return t.runWebGLProgram(i,[s],s.dtype)},r4={kernelName:pl,backendName:"webgl",kernelFunc:o4};const i4=`if (b == 0.0) return NAN;
  return mod(a, b);`,a4=`
  vec4 result = mod(a, b);
  bvec4 isNaN = equal(b, vec4(0.0));
  `+ho+`
  return result;
`,l4=we({opSnippet:i4,packedOpSnippet:a4}),c4={kernelName:ti,backendName:"webgl",kernelFunc:l4};class u4{constructor(t,e,s){this.variableNames=["probs"],this.customUniforms=[{name:"seed",type:"float"}],this.outputShape=[t,s],this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];

        float r = random(seed);
        float cdf = 0.0;

        for (int i = 0; i < ${e-1}; i++) {
          cdf += getProbs(batch, i);

          if (r < cdf) {
            setOutput(float(i));
            return;
          }
        }

        // If no other event happened, last event happened.
        setOutput(float(${e-1}));
      }
    `}}const h4=`
if (a == b) {
  return 1.0;
};
return a / b;`,d4=`
  // vec4 one = vec4(equal(a, b));
  // return one + (vec4(1.0) - one) * a / b;
  vec4 result = a / b;
  if(a.x == b.x) {
    result.x = 1.;
  }
  if(a.y == b.y) {
    result.y = 1.;
  }
  if(a.z == b.z) {
    result.z = 1.;
  }
  if(a.w == b.w) {
    result.w = 1.;
  }

  return result;
`,r1=we({opSnippet:h4,packedOpSnippet:d4,checkOutOfBounds:!0}),p4={kernelName:Pr,backendName:"webgl",kernelFunc:r1};const Ef="return a - b;",i1=we({opSnippet:Ef,packedOpSnippet:Ef,supportsComplex:!0,cpuKernelImpl:iP}),f4={kernelName:gi,backendName:"webgl",kernelFunc:i1};function a1(n){const{inputs:t,backend:e,attrs:s}=n,{logits:o}=t,{dim:r}=s,i=Ct([r],o.shape),a=o1({inputs:{x:o},backend:e,attrs:{reductionIndices:i,keepDims:!1}}),l=ne(a.shape,i),c=tt({inputs:{x:a},backend:e,attrs:{shape:l}}),u=i1({inputs:{a:o,b:c},backend:e}),h=e1({inputs:{x:u},backend:e}),d=cc({inputs:{x:h},backend:e,attrs:{axis:i,keepDims:!1}}),p=tt({inputs:{x:d},backend:e,attrs:{shape:l}}),f=r1({inputs:{a:h,b:p},backend:e});return e.disposeIntermediateTensorInfo(a),e.disposeIntermediateTensorInfo(c),e.disposeIntermediateTensorInfo(u),e.disposeIntermediateTensorInfo(h),e.disposeIntermediateTensorInfo(d),e.disposeIntermediateTensorInfo(p),f}const m4={kernelName:Dl,backendName:"webgl",kernelFunc:a1};function g4(n){const{inputs:t,backend:e,attrs:s}=n,{logits:o}=t,{numSamples:r,seed:i,normalized:a}=s,l=a?o:a1({inputs:{logits:o},backend:e,attrs:{dim:o.shape.length-1}}),c=l.shape[0],u=l.shape[1],h=new u4(c,u,r),d=[[i]],p=e.runWebGLProgram(h,[l],"int32",d);return a||e.disposeIntermediateTensorInfo(l),p}const x4={kernelName:Hf,backendName:"webgl",kernelFunc:g4};const b4=un+`
  return -x;
`,y4=`
  vec4 result = -x;
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`;function w4(n){const{inputs:t,backend:e}=n,{x:s}=t;if(e.shouldExecuteOnCPU([s])){const r=e.texData.get(s.dataId),[i,a]=VM(r.values,s.shape,s.dtype);return e.makeTensorInfo(a,s.dtype,i)}let o;return L().getBool("WEBGL_PACK_UNARY_OPERATIONS")?o=new ls(s.shape,y4):o=new En(s.shape,b4),e.runWebGLProgram(o,[s],s.dtype)}const C4={kernelName:fl,backendName:"webgl",kernelFunc:w4};const $4=_h;function I4(n){je("tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead");const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l}=s,c=e.readSync(o.dataId),u=e.readSync(r.dataId),{selectedIndices:h}=$4(c,u,i,a,l);return e.makeTensorInfo([h.length],"int32",new Int32Array(h))}const k4={kernelName:qu,backendName:"webgl",kernelFunc:I4};const v4=Lh;function S4(n){je("tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead");const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l,padToMaxOutputSize:c}=s,u=e.readSync(o.dataId),h=e.readSync(r.dataId),{selectedIndices:d,validOutputs:p}=v4(u,h,i,a,l,c);return[e.makeTensorInfo([d.length],"int32",new Int32Array(d)),e.makeTensorInfo([],"int32",new Int32Array([p]))]}const N4={kernelName:Xu,backendName:"webgl",kernelFunc:S4};const T4=Mh;function E4(n){je("tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead");const{inputs:t,backend:e,attrs:s}=n,{boxes:o,scores:r}=t,{maxOutputSize:i,iouThreshold:a,scoreThreshold:l,softNmsSigma:c}=s,u=e.readSync(o.dataId),h=e.readSync(r.dataId),d=i,p=a,f=l,m=c,{selectedIndices:g,selectedScores:x}=T4(u,h,d,p,f,m);return[e.makeTensorInfo([g.length],"int32",new Int32Array(g)),e.makeTensorInfo([x.length],"float32",new Float32Array(x))]}const R4={kernelName:Yu,backendName:"webgl",kernelFunc:E4};class D4{constructor(t,e,s,o){this.variableNames=["indices"],this.outputShape=[t,e],this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int index = round(getIndices(coords.x));
        setOutput(mix(float(${o}), float(${s}),
                      float(index == coords.y)));
      }
    `}}const A4=n=>{const{inputs:t,backend:e,attrs:s}=n,{indices:o}=t,{dtype:r,depth:i,onValue:a,offValue:l}=s,c=W(o.shape),u=new D4(c,i,a,l),h=tt({inputs:{x:o},backend:e,attrs:{shape:[c]}}),d=e.runWebGLProgram(u,[h],r);e.disposeIntermediateTensorInfo(h);const p=[...o.shape,i],f=tt({inputs:{x:d},backend:e,attrs:{shape:p}});return e.disposeIntermediateTensorInfo(d),f},F4={kernelName:xl,backendName:"webgl",kernelFunc:A4};function Oa(n){const{inputs:t,backend:e}=n,{x:s}=t;if(s.dtype==="complex64"){const o=Vi({inputs:{input:s},backend:e}),r=Oa({inputs:{x:o},backend:e}),i=uc({inputs:{input:s},backend:e}),a=Oa({inputs:{x:i},backend:e}),l=Es({inputs:{real:r,imag:a},backend:e});return e.disposeIntermediateTensorInfo(o),e.disposeIntermediateTensorInfo(r),e.disposeIntermediateTensorInfo(i),e.disposeIntermediateTensorInfo(a),l}else return Wi({attrs:{shape:s.shape,dtype:s.dtype,value:s.dtype==="string"?"":0},backend:e})}const O4={kernelName:Ol,backendName:"webgl",kernelFunc:Oa};function l1(n){const{inputs:t,backend:e}=n,{x:s}=t;if(s.dtype==="string")throw new Error("onesLike is not supported under string dtype");if(s.dtype==="complex64"){const o=Vi({inputs:{input:s},backend:e}),r=l1({inputs:{x:o},backend:e}),i=uc({inputs:{input:s},backend:e}),a=Oa({inputs:{x:i},backend:e}),l=Es({inputs:{real:r,imag:a},backend:e});return e.disposeIntermediateTensorInfo(o),e.disposeIntermediateTensorInfo(r),e.disposeIntermediateTensorInfo(i),e.disposeIntermediateTensorInfo(a),l}else return Wi({attrs:{shape:s.shape,dtype:s.dtype,value:1},backend:e})}const _4={kernelName:gl,backendName:"webgl",kernelFunc:l1};function L4(n){const{inputs:t,backend:e,attrs:s}=n,{axis:o}=s;if(t.length===1)return du({inputs:{input:t[0]},backend:e,attrs:{dim:o}});const r=t[0].shape,i=t[0].dtype;t.forEach(u=>{gu(r,u.shape,"All tensors passed to stack must have matching shapes"),$(i===u.dtype,()=>"All tensors passed to stack must have matching dtypes")});const a=[],l=t.map(u=>{const h=du({inputs:{input:u},backend:e,attrs:{dim:o}});return a.push(h),h}),c=j0({inputs:l,backend:e,attrs:{axis:o}});return a.forEach(u=>e.disposeIntermediateTensorInfo(u)),c}const M4={kernelName:bl,backendName:"webgl",kernelFunc:L4};class P4{constructor(t,e,s){this.variableNames=["x"],this.customUniforms=[{name:"value",type:"float"}],this.outputShape=e.map((c,u)=>c[0]+t[u]+c[1]);const o=t.length,r=Ot(o),i=e.map(c=>c[0]).join(","),a=e.map((c,u)=>c[0]+t[u]).join(","),l=["coords[0]","coords[1]","coords[2]","coords[3]"].slice(0,o);if(o===1){this.userCode=`
        int start = ${i};
        int end = ${a};

        void main() {
          int outC = getOutputCoords();
          if (outC < start || outC >= end) {
            setOutput(value);
          } else {
            setOutput(getX(outC - start));
          }
        }
      `;return}this.userCode=`
      ${r} start = ${r}(${i});
      ${r} end = ${r}(${a});

      void main() {
        ${r} outC = getOutputCoords();
        if (any(lessThan(outC, start)) || any(greaterThanEqual(outC, end))) {
          setOutput(value);
        } else {
          ${r} coords = outC - start;
          setOutput(getX(${l}));
        }
      }
    `}}class z4{constructor(t,e,s){this.variableNames=["x"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"value",type:"float"}],this.outputShape=e.map((m,g)=>m[0]+t[g]+m[1]);const o=t.length,r=Ot(o),i=e.map(m=>m[0]).join(","),a=e.map((m,g)=>m[0]+t[g]).join(","),l=Ee("rc",o),c=Ee("source",o),u=`${l[o-1]} < ${this.outputShape[o-1]}`,h=o===1?"source":`vec2(${c.slice(-2).join()})`,d=[`${r} rc = outputLoc;`,`${l[o-1]} += 1;
       if(${u}) {
      `,o===1?"":`}
       rc = outputLoc;
       ${l[o-2]} += 1;
       if(${l[o-2]} < ${this.outputShape[o-2]}) {`,o===1?"":`  ${l[o-1]} += 1;
         if(${u}) {`],p=o===1?"rc < start || rc >= end":"any(lessThan(rc, start)) || any(greaterThanEqual(rc, end))";let f="";for(let m=0,g=o===1?2:4;m<g;m++)f+=`
        ${d[m]}
        if (${p}) {
          result[${m}] = float(value);
        } else {
          ${r} source = rc - start;
          result[${m}] = getChannel(getX(${c.join()}), ${h});
        }
      `;f+=o===1?"} ":"}}",this.userCode=`
      const ${r} start = ${r}(${i});
      const ${r} end = ${r}(${a});

      void main() {
        ${r} outputLoc = getOutputCoords();
        vec4 result = vec4(0.);
        ${f}
        setOutput(result);
      }
    `}}const c1=n=>{const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{paddings:r,constantValue:i}=s;if(W(o.shape)===0){const c=r.map((u,h)=>u[0]+o.shape[h]+u[1]);return Wi({backend:e,attrs:{shape:c,value:i,dtype:o.dtype}})}const a=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")?new z4(o.shape,r,i):new P4(o.shape,r,i),l=[[i]];return e.runWebGLProgram(a,[o],o.dtype,l)},B4={kernelName:yl,backendName:"webgl",kernelFunc:c1};const V4=`
  if(a < 0.0 && floor(b) < b){
    return NAN;
  }
  if (b == 0.0) {
    return 1.0;
  }
  return (round(mod(b, 2.0)) != 1) ?
      pow(abs(a), b) : sign(a) * pow(abs(a), b);
`,W4=`
  // isModRound1 has 1 for components with round(mod(b, 2.0)) == 1, 0 otherwise.
  vec4 isModRound1 = vec4(equal(round(mod(b, 2.0)), ivec4(1)));
  vec4 multiplier = sign(a) * isModRound1 + (vec4(1.0) - isModRound1);
  vec4 result = multiplier * pow(abs(a), b);

  // Ensure that a^0 = 1, including 0^0 = 1 as this correspond to TF and JS
  bvec4 isExpZero = equal(b, vec4(0.0));
  result.r = isExpZero.r ? 1.0 : result.r;
  result.g = isExpZero.g ? 1.0 : result.g;
  result.b = isExpZero.b ? 1.0 : result.b;
  result.a = isExpZero.a ? 1.0 : result.a;

  bvec4 isNaN1 = lessThan(a, vec4(0.0));
  bvec4 isNaN2 = lessThan(floor(b), b);
  bvec4 isNaN = bvec4(isNaN1.x && isNaN2.x, isNaN1.y && isNaN2.y, isNaN1.z && isNaN2.z, isNaN1.w && isNaN2.w);
  `+ho+`
  return result;
`,U4=we({opSnippet:V4,packedOpSnippet:W4}),G4={kernelName:ni,backendName:"webgl",kernelFunc:U4};function H4(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{axis:r,keepDims:i}=s,a=o.shape.length,l=[],c=Ct(r,o.shape);let u=c;const h=jt(u,a);let d=o;h!=null&&(d=De({inputs:{x:o},backend:e,attrs:{perm:h}}),u=Zt(u.length,a),l.push(d)),ye("prod",u,a);let p;if(e.shouldExecuteOnCPU([d])){const f=e.texData.get(d.dataId).values,{outVals:m,outShape:g,outDtype:x}=UM(d.shape,d.dtype,f,u);p=e.makeTensorInfo(g,x,m)}else{const[f,m]=fe(d.shape,u),g=W(m),x=tt({inputs:{x:d},backend:e,attrs:{shape:[-1,g]}}),b=lh(o.dtype),w=po(x,b,"prod",e);p=tt({inputs:{x:w},backend:e,attrs:{shape:f}}),l.push(x),l.push(w)}if(i){l.push(p);const f=ne(p.shape,c);p=tt({inputs:{x:p},backend:e,attrs:{shape:f}})}return l.forEach(f=>e.disposeIntermediateTensorInfo(f)),p}const K4={kernelName:Cl,backendName:"webgl",kernelFunc:H4};function j4(n){const{inputs:t,backend:e,attrs:s}=n,{paramsNestedSplits:o,paramsDenseValues:r,indices:i}=t,{outputRaggedRank:a}=s,l=o.map(x=>e.readSync(x.dataId)),c=o.map(x=>x.shape),u=e.readSync(r.dataId),h=e.readSync(i.dataId),[d,p,f]=GM(l,c,u,r.shape,r.dtype,h,i.shape,a),m=d.map(x=>e.makeTensorInfo([x.length],"int32",x)),g=e.makeTensorInfo(f,r.dtype,p);return m.concat([g])}const q4={kernelName:Kf,backendName:"webgl",kernelFunc:j4};function X4(n){const{inputs:t,backend:e}=n,{starts:s,limits:o,deltas:r}=t,i=e.readSync(s.dataId),a=e.readSync(o.dataId),l=e.readSync(r.dataId),[c,u]=HM(i,s.shape,s.dtype,a,o.shape,l,r.shape),h=e.makeTensorInfo([c.length],"int32",c),d=e.makeTensorInfo([u.length],s.dtype,u);return[h,d]}const Y4={kernelName:jf,backendName:"webgl",kernelFunc:X4};function J4(n){const{inputs:t,backend:e,attrs:s}=n,{shape:o,values:r,defaultValue:i,rowPartitionTensors:a}=t,{rowPartitionTypes:l}=s,c=e.readSync(o.dataId),u=e.readSync(r.dataId),h=e.readSync(i.dataId),d=a.map(g=>e.readSync(g.dataId)),p=a.map(g=>g.shape),[f,m]=KM(c,o.shape,u,r.shape,r.dtype,h,i.shape,d,p,l);return e.makeTensorInfo(f,r.dtype,m)}const Z4={kernelName:qf,backendName:"webgl",kernelFunc:J4};const u1=n=>{const{backend:t,attrs:e}=n,{start:s,stop:o,step:r,dtype:i}=e,a=jM(s,o,r,i);return t.makeTensorInfo([a.length],i,a)},Q4={kernelName:Ju,backendName:"webgl",kernelFunc:u1};const tU="return 1.0 / x;",eU=vt({opSnippet:tU}),nU={kernelName:si,backendName:"webgl",kernelFunc:eU};const sU=un+`
  return (x < 0.0) ? 0.0 : x;
`,oU=`
  vec4 result = x * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,rU=vt({opSnippet:sU,packedOpSnippet:oU}),iU={kernelName:oi,backendName:"webgl",kernelFunc:rU};const aU=un+`
  return (x < 0.0) ? 0.0 : min(6.0, x);
`,lU=`
  vec4 result = min(x, vec4(6.)) * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,cU=vt({opSnippet:aU,packedOpSnippet:lU}),uU={kernelName:ri,backendName:"webgl",kernelFunc:cU};class hU{constructor(t,e,s,o,r){this.variableNames=["A"],this.outputShape=[];const[i,a,l,c]=t;this.outputShape=[i,e,s,c];const u=[o&&e>1?a-1:a,o&&s>1?l-1:l],h=[o&&e>1?e-1:e,o&&s>1?s-1:s];let d;r?d="(vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC - vec2(0.5)":d="vec2(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`
      const vec2 effectiveInputOverOutputRatioRC = vec2(
          ${u[0]/h[0]},
          ${u[1]/h[1]});
      const vec2 inputShapeRC = vec2(${a}.0, ${l}.0);

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        ivec2 yRC = coords.yz;

        // Fractional source index.
        vec2 sourceFracIndexRC = ${d};

        // Compute the four integer indices.
        ivec2 sourceFloorRC = ivec2(max(sourceFracIndexRC, vec2(0.0)));
        ivec2 sourceCeilRC = ivec2(
          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));

        float topLeft = getA(b, sourceFloorRC.x, sourceFloorRC.y, d);
        float bottomLeft = getA(b, sourceCeilRC.x, sourceFloorRC.y, d);
        float topRight = getA(b, sourceFloorRC.x, sourceCeilRC.y, d);
        float bottomRight = getA(b, sourceCeilRC.x, sourceCeilRC.y, d);

        vec2 fracRC = sourceFracIndexRC - vec2(sourceFloorRC);

        float top = topLeft + (topRight - topLeft) * fracRC.y;
        float bottom = bottomLeft + (bottomRight - bottomLeft) * fracRC.y;
        float newValue = top + (bottom - top) * fracRC.x;

        setOutput(newValue);
      }
    `}}class dU{constructor(t,e,s,o,r){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];const[i,a,l,c]=t;this.outputShape=[i,e,s,c];const u=[o&&e>1?a-1:a,o&&s>1?l-1:l],h=[o&&e>1?e-1:e,o&&s>1?s-1:s];let d;r?d="(vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC - vec3(0.5)":d="vec3(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`
      const vec3 effectiveInputOverOutputRatioRC = vec3(
          ${u[0]/h[0]},
          ${u[1]/h[1]},
          ${u[1]/h[1]});
      const vec3 inputShapeRC = vec3(${a}.0, ${l}.0,
                                     ${l}.0);

      float getAValue(int b, int r, int c, int d) {
        return getChannel(getA(b, r, c, d), vec2(c, d));
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        // Calculate values for next column in yRC.z.
        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);

        // Fractional source index.
        vec3 sourceFracIndexRC = ${d};

        // Compute the four integer indices.
        ivec3 sourceFloorRC = ivec3(max(sourceFracIndexRC, vec3(0.0)));
        ivec3 sourceCeilRC = ivec3(
          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));

        // Should we calculate next column and row elements in 2x2 packed cell.
        bool hasNextCol = d < ${c-1};
        bool hasNextRow = coords.z < ${s-1};

        // In parallel, construct four corners for all four components in
        // packed 2x2 cell.
        vec4 topLeft = vec4(
          getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d),
          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d + 1) : 0.0);

        vec4 bottomLeft = vec4(
          getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d),
          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d + 1) : 0.0);

        vec4 topRight = vec4(
          getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d),
          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d + 1) : 0.0);

        vec4 bottomRight = vec4(
          getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d),
          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d + 1) : 0.0);

        vec3 fracRC = sourceFracIndexRC - vec3(sourceFloorRC);

        vec4 top = mix(topLeft, topRight, fracRC.yyzz);
        vec4 bottom = mix(bottomLeft, bottomRight, fracRC.yyzz);
        vec4 newValue = mix(top, bottom, fracRC.x);

        setOutput(newValue);
      }
    `}}function pU(n){const{inputs:t,backend:e,attrs:s}=n,{images:o}=t,{alignCorners:r,halfPixelCenters:i,size:a}=s,[l,c]=a,u=L().getBool("WEBGL_PACK_IMAGE_OPERATIONS")?new dU(o.shape,l,c,r,i):new hU(o.shape,l,c,r,i);return e.runWebGLProgram(u,[o],"float32")}const fU={kernelName:kl,backendName:"webgl",kernelFunc:pU};class mU{constructor(t,e,s){this.variableNames=["dy"],this.outputShape=[],this.outputShape=e;const[,o,r]=e,[,i,a]=t,l=[s&&i>1?o-1:o,s&&a>1?r-1:r],c=[s&&i>1?i-1:i,s&&a>1?a-1:a],u=l[0]/c[0],h=l[1]/c[1],d=1/u,p=1/h,f=Math.ceil(d)*2+2,m=Math.ceil(p)*2+2;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        int r = coords[1];
        int c = coords[2];

        float accumulator = 0.0;

        const float heightScale = float(${u});
        const float widthScale = float(${h});

        const float invHeightScale = float(${d});
        const float invWidthScale = float(${p});

        const int winHeight = int(${f});
        const int winWidth = int(${m});

        // Compute bounds for where in dy we will look
        float startRLerp = floor(float(r) * invHeightScale);
        int startDyR = int(startRLerp - float(winHeight / 2));

        float startCLerp = floor(float(c) * invWidthScale);
        int startDyC = int(startCLerp - float(winWidth / 2));

        // Loop over dy
        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {
          int dyR = dyROffset + startDyR;

          // Guard against the window exceeding the bounds of dy
          if (dyR < 0 || dyR >= ${i}) {
            continue;
          }

          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {
            int dyC = dyCOffset + startDyC;

            // Guard against the window exceeding the bounds of dy
            if (dyC < 0 || dyC >= ${a}) {
              continue;
            }

            float dxR = float(dyR) * heightScale;
            int topDxRIndex = int(floor(dxR));
            int bottomDxRIndex = int(min(ceil(dxR), ${o-1}.0));
            float dxRLerp = dxR - float(topDxRIndex);
            float inverseDxRLerp = 1.0 - dxRLerp;

            float dxC = float(dyC) * widthScale;
            int leftDxCIndex = int(floor(dxC));
            int rightDxCIndex = int(min(ceil(dxC), ${r-1}.0));
            float dxCLerp = dxC - float(leftDxCIndex);
            float inverseDxCLerp = 1.0 - dxCLerp;

            if (r == topDxRIndex && c == leftDxCIndex) {
              // topLeft
              accumulator +=
                getDy(b, dyR, dyC, d) * inverseDxRLerp * inverseDxCLerp;
            }

            if (r == topDxRIndex && c == rightDxCIndex) {
              // topRight
              accumulator += getDy(b, dyR, dyC, d) * inverseDxRLerp * dxCLerp;
            }

            if (r == bottomDxRIndex && c == leftDxCIndex) {
              // bottomLeft
              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * inverseDxCLerp;
            }

            if (r == bottomDxRIndex && c == rightDxCIndex) {
              // bottomRight
              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * dxCLerp;
            }
          }
        }
        // End loop over dy

        setOutput(accumulator);
      }
    `}}function gU(n){const{inputs:t,backend:e,attrs:s}=n,{images:o,dy:r}=t,{alignCorners:i}=s,a=new mU(r.shape,o.shape,i);return e.runWebGLProgram(a,[r],r.dtype)}const xU={kernelName:th,backendName:"webgl",kernelFunc:gU};class bU{constructor(t,e,s,o,r){this.variableNames=["A"],this.outputShape=[];const[i,a,l,c]=t;this.outputShape=[i,e,s,c];const u=[o&&e>1?a-1:a,o&&s>1?l-1:l],h=[o&&e>1?e-1:e,o&&s>1?s-1:s],d=o?"0.5":"0.0";let p;r?p="max((vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC, vec2(0.0))":p="vec2(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`
      const vec2 effectiveInputOverOutputRatioRC = vec2(
          ${u[0]/h[0]},
          ${u[1]/h[1]});
      const vec2 inputShapeRC = vec2(${a}.0, ${l}.0);

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        ivec2 yRC = coords.yz;

        // Fractional source index.
        vec2 sourceFracIndexRC = ${p};

        // Compute the coordinators of nearest neighbor point.
        ivec2 sourceNearestRC = ivec2(
          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));
        float newValue = getA(b, sourceNearestRC.x, sourceNearestRC.y, d);

        setOutput(newValue);
      }
    `}}class yU{constructor(t,e,s,o,r){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];const[i,a,l,c]=t;this.outputShape=[i,e,s,c];const u=[o&&e>1?a-1:a,o&&s>1?l-1:l],h=[o&&e>1?e-1:e,o&&s>1?s-1:s],d=o?"0.5":"0.0";let p;r?p="max((vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC, vec3(0.0))":p="vec3(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`
      const vec3 effectiveInputOverOutputRatioRC = vec3(
          ${u[0]/h[0]},
          ${u[1]/h[1]},
          ${u[1]/h[1]});
      const vec3 inputShapeRC = vec3(${a}.0, ${l}.0,
                                     ${l}.0);

      float getAValue(int b, int r, int c, int d) {
        return getChannel(getA(b, r, c, d), vec2(c, d));
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        // Calculate values for next column in yRC.z.
        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);

        // Fractional source index.
        vec3 sourceFracIndexRC = ${p};

        // Compute the coordinators of nearest neighbor point.
        ivec3 sourceNearestRC = ivec3(
          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));

        // Should we calculate next column and row elements in 2x2 packed cell.
        bool hasNextCol = d < ${c-1};
        bool hasNextRow = coords.z < ${s-1};

        vec4 newValue = vec4(
          getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d),
          hasNextCol ? getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d + 1) : 0.0);

        setOutput(newValue);
      }
    `}}function wU(n){const{inputs:t,backend:e,attrs:s}=n,{images:o}=t,{alignCorners:r,halfPixelCenters:i,size:a}=s,[l,c]=a,u=L().getBool("WEBGL_PACK_IMAGE_OPERATIONS")?new yU(o.shape,l,c,r,i):new bU(o.shape,l,c,r,i);return e.runWebGLProgram(u,[o],o.dtype)}const CU={kernelName:Il,backendName:"webgl",kernelFunc:wU};class $U{constructor(t,e,s){this.variableNames=["dy"],this.outputShape=[],this.outputShape=e;const[,o,r]=e,[,i,a]=t,l=[s&&i>1?o-1:o,s&&a>1?r-1:r],c=[s&&i>1?i-1:i,s&&a>1?a-1:a],u=l[0]/c[0],h=l[1]/c[1],d=1/u,p=1/h,f=Math.ceil(d)*2+2,m=Math.ceil(p)*2+2;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        int r = coords[1];
        int c = coords[2];

        float accumulator = 0.0;

        const float heightScale = float(${u});
        const float widthScale = float(${h});

        const float invHeightScale = float(${d});
        const float invWidthScale = float(${p});

        const int winHeight = int(${f});
        const int winWidth = int(${m});

        // Compute bounds for where in dy we will look
        float startRLerp = floor(float(r) * invHeightScale);
        int startDyR = int(floor(startRLerp - float(winHeight / 2)));

        float startCLerp = floor(float(c) * invWidthScale);
        int startDyC = int(floor(startCLerp - float(winWidth / 2)));

        // Loop over dy
        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {
          int dyR = dyROffset + startDyR;

          // Guard against the window exceeding the bounds of dy
          if (dyR < 0 || dyR >= ${i}) {
            continue;
          }

          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {
            int dyC = dyCOffset + startDyC;

            // Guard against the window exceeding the bounds of dy
            if (dyC < 0 || dyC >= ${a}) {
              continue;
            }

            float sourceFracRow =
              float(${l[0]}) *
                (float(dyR) / float(${c[0]}));

            float sourceFracCol =
                float(${l[1]}) *
                  (float(dyC) / float(${c[1]}));

            int sourceNearestRow = int(min(
                float(int(${o}) - 1),
                ${s} ? float(round(sourceFracRow)) :
                                  float(floor(sourceFracRow))));

            int sourceNearestCol = int(min(
                float(int(${r}) - 1),
                ${s} ? float(round(sourceFracCol)) :
                                  float(floor(sourceFracCol))));

            if (r == sourceNearestRow && c == sourceNearestCol) {
              accumulator += getDy(b, dyR, dyC, d);
            }
          }
        }
        // End loop over dy

        setOutput(accumulator);
      }
    `}}function IU(n){const{inputs:t,backend:e,attrs:s}=n,{images:o,dy:r}=t,{alignCorners:i}=s,a=new $U(r.shape,o.shape,i);return e.runWebGLProgram(a,[r],r.dtype)}const kU={kernelName:Qu,backendName:"webgl",kernelFunc:IU};class vU{constructor(t,e){this.variableNames=["x"];const s=t.length;if(s>4)throw new Error(`WebGL backend: Reverse of rank-${s} tensor is not yet supported`);if(this.outputShape=t,s===1){this.userCode=`
        void main() {
          int coord = getOutputCoords();
          setOutput(getX(${t[0]} - coord - 1));
        }
      `;return}const o=a=>e.indexOf(a)!==-1&&t[a]!==1?`${t[a]} - coords[${a}] - 1`:`coords[${a}]`,r=t.map((a,l)=>o(l)).join(","),i=Ot(s);this.userCode=`
      void main() {
        ${i} coords = getOutputCoords();
        setOutput(getX(${r}));
      }
    `}}class SU{constructor(t,e){this.variableNames=["x"],this.packedInputs=!0,this.packedOutput=!0;const s=t.length;if(s>4)throw new Error(`WebGL backend: Reverse of rank-${s} tensor is not yet supported`);this.outputShape=t;const o=Ee("rc",s),r=`${o[s-1]} + 1 < ${this.outputShape[s-1]}`,i=`${o[s-2]} + 1 < ${this.outputShape[s-2]}`,a=Ot(s);s===1?this.userCode=`
        void main(){
          int rc = getOutputCoords();
          vec4 result = vec4(0.);
          result.r = getChannel(getX(${t[0]} - rc - 1),
            ${t[0]} - rc - 1);
          if(${r}){
              result.g = getChannel(getX(${t[0]} - (rc  + 1) - 1),
                ${t[0]} - (rc  + 1) - 1);
          }
          setOutput(result);
        }
      `:this.userCode=`
        void main() {
          ${a} rc = getOutputCoords();
          vec4 result = vec4(0.);
          result.r = ${l(o.slice())};
          if(${r}){
            result.g = ${c(o.slice())};
          }
          if(${i}) {
            result.b = ${u(o.slice())};
            if(${r}) {
              result.a = ${h(o.slice())};
            }
          }
          setOutput(result);
        }
    `;function l(f){return d(f)}function c(f){return f[s-1]="("+f[s-1]+" + 1)",d(f)}function u(f){return f[s-2]="("+f[s-2]+" + 1)",d(f)}function h(f){return f[s-1]="("+f[s-1]+" + 1)",f[s-2]="("+f[s-2]+" + 1)",d(f)}function d(f){const m=t.map((b,w)=>p(w,f)),g=m.join(","),x=m.slice(-2).join(",");return`getChannel(getX(${g}), vec2(${x}))`}function p(f,m){return e.indexOf(f)!==-1&&t[f]!==1?`${t[f]} - ${m[f]} - 1`:`${m[f]}`}}}function NU(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{dims:r}=s,i=o.shape.length,a=Ct(r,o.shape);if(i===0)return He({inputs:{x:o},backend:e});const l=L().getBool("WEBGL_PACK_ARRAY_OPERATIONS")?new SU(o.shape,a):new vU(o.shape,a);return e.runWebGLProgram(l,[o],o.dtype)}const TU={kernelName:vl,backendName:"webgl",kernelFunc:NU};class EU{constructor(t,e){this.variableNames=["Image"],this.outputShape=[],this.customUniforms=[{name:"params",type:"vec4"}];const s=t[1],o=t[2];this.outputShape=t;let r="";typeof e=="number"?r=`float outputValue = ${e.toFixed(2)};`:r=`
        vec3 fill = vec3(${e.join(",")});
        float outputValue = fill[coords[3]];`,this.userCode=`
        void main() {
          ivec4 coords = getOutputCoords();
          int x = coords[2];
          int y = coords[1];
          float coordXFloat = (float(x) - params[0]) * params[3] -
            (float(y) - params[1]) * params[2];
          float coordYFloat = (float(x) - params[0]) * params[2] +
            (float(y) - params[1]) * params[3];
          int coordX = int(round(coordXFloat + params[0]));
          int coordY = int(round(coordYFloat + params[1]));
          ${r}
          if(coordX >= 0 && coordX < ${o} && coordY >= 0 && coordY < ${s}) {
            outputValue = getImage(coords[0], coordY, coordX, coords[3]);
          }
          setOutput(outputValue);
        }
    `}}const RU={kernelName:ah,backendName:"webgl",kernelFunc:({inputs:n,attrs:t,backend:e})=>{const{image:s}=n,{radians:o,fillValue:r,center:i}=t,a=e,l=new EU(s.shape,r),[c,u]=Xh(i,s.shape[1],s.shape[2]),h=[[c,u,Math.sin(o),Math.cos(o)]];return a.runWebGLProgram(l,[s],s.dtype,h)}};const DU=`
  // OpenGL ES does not support round function.
  // The algorithm is based on banker's rounding.
  float base = floor(x);
  if ((x - base) < 0.5) {
    return floor(x);
  } else if ((x - base) > 0.5) {
    return ceil(x);
  } else {
    if (mod(base, 2.0) == 0.0) {
      return base;
    } else {
      return base + 1.0;
    }
  }
`,AU=vt({opSnippet:DU}),FU={kernelName:ii,backendName:"webgl",kernelFunc:AU};const OU="return inversesqrt(x);",_U=vt({opSnippet:OU,cpuKernelImpl:qM}),LU={kernelName:ai,backendName:"webgl",kernelFunc:_U};class Jd{constructor(t,e,s,o,r,i,a=!0,l=!1){this.variableNames=["updates","indices","defaultValue"],this.outputShape=i;const c=Ot(r.length),u=Ot(i.length);let h="";s===1?h="i":s===2&&(h="i, j");const d=`getIndices(${h})`;let p="";o===1?p="i":o===2&&(p="i, coords[1]");const f=`getUpdates(${p})`;let m="";l&&(m="coords[0], coords[1]");const g=`getDefaultValue(${m})`,x=e>1?"strides[j]":"strides";this.userCode=`
        ${c} strides = ${c}(${r});

        void main() {
          ${u} coords = getOutputCoords();
          float sum = 0.0;
          bool found = false;
          for (int i = 0; i < ${t}; i++) {
            int flattenedIndex = 0;
            for (int j = 0; j < ${e}; j++) {
              int index = round(${d});
              flattenedIndex += index * ${x};
            }
            if (flattenedIndex == coords[0]) {
              sum += ${f};
              found = true;
            }
          }
          setOutput(mix(${g}, sum, float(found)));
        }
      `}}class MU{constructor(t,e,s,o,r,i,a=!0,l=!1){this.variableNames=["updates","indices","defaultValue"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=i;const c=Ot(r.length),u=Ot(i.length);let h="";s===1?h="i":s===2&&(h="i, j");const d=`getIndices(${h})`;let p="";o===1?p="i":o===2&&(p="i, coords[1]");const f=`getUpdates(${p})`;let m="";l&&(m="coords[0], coords[1]");const g=`getDefaultValue(${m})`,x=e>1?"strides[j]":"strides",b=e>1?"strides[j + 1]":"strides";this.userCode=`
        ${c} strides = ${c}(${r});

        void main() {
          ${u} coords = getOutputCoords();
          vec4 sum = vec4(0.);
          vec4 found = vec4(0.);
          for (int i = 0; i < ${t}; i+=2) {
            ivec2 flattenedIndex = ivec2(0);
            for (int j = 0; j < ${e}; j+=2) {
              ivec4 index = round(${d});
              flattenedIndex += index.xz * ${x};
              if (j + 1 < ${e}) {
                flattenedIndex += index.yw * ${b};
              }
            }
            if (flattenedIndex[0] == coords[0] || flattenedIndex[1] == coords[0] ||
                flattenedIndex[0] == coords[0] + 1 || flattenedIndex[1] == coords[0] + 1) {
              vec4 updVals = ${f};
              if (flattenedIndex[0] == coords[0]) {
                sum.xy += updVals.xy;
                found.xy = vec2(1.);
              } else if (flattenedIndex[0] == coords[0] + 1) {
                sum.zw += updVals.xy;
                found.zw = vec2(1.);
              }
              if (flattenedIndex[1] == coords[0]) {
                sum.xy += updVals.zw;
                found.xy = vec2(1.);
              } else if (flattenedIndex[1] == coords[0] + 1) {
                sum.zw += updVals.zw;
                found.zw = vec2(1.);
              }
            }
          }
          setOutput(mix(${g}, sum, found));
        }
      `}}function PU(n){const{inputs:t,backend:e,attrs:s}=n,{indices:o,updates:r}=t,{shape:i}=s,{sliceRank:a,numUpdates:l,sliceSize:c,strides:u,outputSize:h}=io(r,o,i),d=[h/c,c];if(h===0)return e.makeTensorInfo(i,o.dtype);const p=tt({inputs:{x:o},backend:e,attrs:{shape:[l,a]}}),f=tt({inputs:{x:r},backend:e,attrs:{shape:[l,c]}}),m=e.makeTensorInfo([],"float32",new Float32Array([0]));let g;L().getBool("WEBGL_PACK")?g=new MU(l,a,p.shape.length,f.shape.length,u,d):g=new Jd(l,a,p.shape.length,f.shape.length,u,d);const x=e.runWebGLProgram(g,[f,p,m],f.dtype),b=tt({inputs:{x},backend:e,attrs:{shape:i}});return e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),e.disposeIntermediateTensorInfo(x),e.disposeIntermediateTensorInfo(m),b}const zU={kernelName:Xf,backendName:"webgl",kernelFunc:PU};class BU{constructor(t,e,s,o){this.variableNames=["sortedSequence","values"],this.customUniforms=[{name:"numInputs",type:"int"}],this.outputShape=[t,s];const r="while (left < right) {",i=`for (int i = 0; i < ${Math.ceil(Math.log2(e+1))}; ++i) { if (left >= right) break;`,a=L().getNumber("WEBGL_VERSION")===2?r:i,l=o==="left"?"<":"<=";this.userCode=`
       int findBound(int batch, float value) {
         int left = 0;
         int right = numInputs;
         int mid;
         ${a}
           mid = (left + right) / 2;
           if (getSortedSequence(batch, mid) ${l} value) {
             left = mid + 1;
           } else {
             right = mid;
           }
         }
         return right;
       }

       void main() {
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int valueIndex = coords[1];

         float value = getValues(batch, valueIndex);

         setOutput(float(findBound(batch, value)));
       }
     `}}function VU(n){const{inputs:t,backend:e,attrs:s}=n,{sortedSequence:o,values:r}=t,{side:i}=s,a=new BU(o.shape[0],o.shape[1],r.shape[1],i),l=[[o.shape[1]]];return e.runWebGLProgram(a,[o,r],"int32",l)}const WU={kernelName:Jf,backendName:"webgl",kernelFunc:VU};class UU{constructor(t,e,s){this.variableNames=["c","a","b"],this.outputShape=e;let o,r;if(s>4)throw Error(`Where for rank ${s} is not yet supported`);if(s===1)r="resRC",o="resRC";else{const a=["resRC.x","resRC.y","resRC.z","resRC.w"],l=[],c=[];for(let u=0;u<e.length;u++)c.push(`${a[u]}`),u<t&&l.push(`${a[u]}`);o=l.join(),r=c.join()}const i=Ot(s);this.userCode=`
      void main() {
        ${i} resRC = getOutputCoords();
        float cVal = getC(${o});
        if (cVal >= 1.0) {
          setOutput(getA(${r}));
        } else {
          setOutput(getB(${r}));
        }
      }
    `}}function GU(n){const{inputs:t,backend:e}=n,{condition:s,t:o,e:r}=t,i=new UU(s.shape.length,o.shape,o.shape.length);return e.runWebGLProgram(i,[s,o,r],Ue(o.dtype,r.dtype))}const HU={kernelName:Sl,backendName:"webgl",kernelFunc:GU};const KU=`
  // Stable and Attracting Fixed Point (0, 1) for Normalized Weights.
  // see: https://arxiv.org/abs/1706.02515
  float scaleAlpha = ${Kl};
  float scale = ${jl};
  return (x >= 0.0) ? scale * x : scaleAlpha * (exp(x) - 1.0);
`,jU=vt({opSnippet:KU}),qU={kernelName:li,backendName:"webgl",kernelFunc:jU};const XU=Yo+`
  return 1.0 / (1.0 + exp(-1.0 * x));
`,YU=`
  vec4 result = 1.0 / (1.0 + exp(-1.0 * x));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,JU=vt({opSnippet:XU,packedOpSnippet:YU,cpuKernelImpl:YM}),ZU={kernelName:di,backendName:"webgl",kernelFunc:JU};const QU=`
  if (isnan(x)) { return 0.0; }
  return sign(x);
`,tG=vt({opSnippet:QU}),eG={kernelName:hi,backendName:"webgl",kernelFunc:tG};const nG=Yo+`
  return sin(x);
`,sG=`
  vec4 result = sin(x);
  bvec4 isNaN = isnan(x);
  ${ho}
  return result;
`,oG=vt({opSnippet:nG,packedOpSnippet:sG}),rG={kernelName:ci,backendName:"webgl",kernelFunc:oG};const iG=`
  float e2x = exp(x);
  return (e2x - 1.0 / e2x) / 2.0;
`,aG=vt({opSnippet:iG}),lG={kernelName:ui,backendName:"webgl",kernelFunc:aG};const cG=`
  float epsilon = 1.1920928955078125e-7;
  float threshold = log(epsilon) + 2.0;

  bool too_large = x > -threshold;
  bool too_small = x < threshold;

  float result;
  float exp_x = exp(x);

  if (too_large){
    result = x;
  }
  else if (too_small){
    result = exp_x;
  }
  else{
    result = log(exp_x + 1.0);
  }
  return result;
`,uG=vt({opSnippet:cG}),hG={kernelName:pi,backendName:"webgl",kernelFunc:uG};const dG=n=>{const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{blockShape:r,paddings:i}=s;$(o.shape.length<=4,()=>"spaceToBatchND for rank > 4 with a WebGL backend not implemented yet");const a=r.reduce((x,b)=>x*b),l=[[0,0]];l.push(...i);for(let x=1+r.length;x<o.shape.length;++x)l.push([0,0]);const c=[],u=c1({inputs:{x:o},backend:e,attrs:{paddings:l,constantValue:0}}),h=Si(u.shape,r,a,!1),d=Ni(h.length,r.length,!1),p=Ti(u.shape,r,a,!1),f=tt({inputs:{x:u},backend:e,attrs:{shape:h}}),m=De({inputs:{x:f},backend:e,attrs:{perm:d}}),g=tt({inputs:{x:m},backend:e,attrs:{shape:p}});return c.push(u),c.push(f),c.push(m),c.forEach(x=>e.disposeIntermediateTensorInfo(x)),g},pG={kernelName:El,backendName:"webgl",kernelFunc:dG};function fG(n){const{inputs:t,backend:e}=n,{indices:s,values:o,denseShape:r,defaultValue:i}=t;if(r.shape.length!==1)throw new Error(`Dense shape must be a vector, saw:
         ${r.shape}`);if(s.shape.length!==2)throw new Error(`Indices must be a matrix, saw:
         ${s.shape}`);if(o.shape.length!==1)throw new Error(`Values must be a vector, saw:
         ${o.shape}`);if(i.shape.length!==0)throw new Error(`Default value must be a scalar, saw:
        ${i.shape}`);const a=e.readSync(s.dataId),l=e.readSync(o.dataId),c=e.readSync(r.dataId),u=e.readSync(i.dataId)[0],[h,d,p,f,m]=ZM(a,s.shape,s.dtype,l,o.dtype,c,u);return[e.makeTensorInfo(d,s.dtype,h),e.makeTensorInfo([d[0]],o.dtype,p),e.makeTensorInfo([f.length],"bool",new Uint8Array(f.map(g=>Number(g)))),e.makeTensorInfo([m.length],s.dtype,new Int32Array(m))]}const mG={kernelName:Zf,backendName:"webgl",kernelFunc:fG};function gG(n){const{inputs:t,backend:e}=n,{inputIndices:s,inputShape:o,newShape:r}=t;if(s.shape.length!==2)throw new Error(`Input indices should be a matrix but received shape ${s.shape}`);if(o.shape.length!==1)throw new Error(`Input shape should be a vector but received shape ${o.shape}`);if(r.shape.length!==1)throw new Error(`Target shape should be a vector but received shape ${r.shape}`);const i=Array.from(e.readSync(o.dataId)),a=e.readSync(s.dataId),l=Array.from(e.readSync(r.dataId)),[c,u,h]=QM(a,s.shape,s.dtype,i,l);return[e.makeTensorInfo(u,s.dtype,c),e.makeTensorInfo([h.length],r.dtype,new Int32Array(h))]}const xG={kernelName:Qf,backendName:"webgl",kernelFunc:gG};function bG(n){const{inputs:t,backend:e}=n,{data:s,indices:o,segmentIds:r}=t;if(s.shape.length<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(o.shape.length!==1)throw new Error(`Indices should be a vector but received shape
              ${o.shape}`);if(r.shape.length!==1)throw new Error(`Segment ids should be a vector but received shape
              ${r.shape}`);const i=e.readSync(s.dataId),a=e.readSync(o.dataId),l=e.readSync(r.dataId),[c,u]=O0(i,s.shape,s.dtype,a,l,!0);return e.makeTensorInfo(u,s.dtype,c)}const yG={kernelName:tm,backendName:"webgl",kernelFunc:bG};function wG(n){const{inputs:t,backend:e}=n,{data:s,indices:o,segmentIds:r}=t;if(s.shape.length<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(o.shape.length!==1)throw new Error(`Indices should be a vector but received shape
             ${o.shape}`);if(r.shape.length!==1)throw new Error(`Segment ids should be a vector but received shape
             ${r.shape}`);const i=e.readSync(s.dataId),a=e.readSync(o.dataId),l=e.readSync(r.dataId),[c,u]=O0(i,s.shape,s.dtype,a,l);return e.makeTensorInfo(u,s.dtype,c)}const CG={kernelName:em,backendName:"webgl",kernelFunc:wG};function $G(n){const{inputs:t,backend:e,attrs:s}=n,{sparseIndices:o,sparseValues:r,defaultValue:i}=t,{outputShape:a}=s,{sliceRank:l,numUpdates:c,sliceSize:u,strides:h,outputSize:d}=io(r,o,a),p=!1;if(r.dtype==="string"){const x=e.bufferSync(o),b=e.bufferSync(r),w=ps(e.readSync(i.dataId)[0]),y=XM(x,b,a,d,u,c,l,h,w,p);return e.makeTensorInfo(a,y.dtype,y.values)}const f=new Jd(c,l,o.shape.length,r.shape.length,h,[d,1],p),m=e.runWebGLProgram(f,[r,o,i],r.dtype),g=tt({inputs:{x:m},backend:e,attrs:{shape:a}});return e.disposeIntermediateTensorInfo(m),g}const IG={kernelName:nm,backendName:"webgl",kernelFunc:$G};function kG(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{numOrSizeSplits:r,axis:i}=s,a=Ct(i,o.shape)[0],l=ud(o,r,a),c=o.shape.length,u=new Array(c).fill(0),h=o.shape.slice();return l.map(d=>{const p=[...h];p[a]=d;const f=Jo({inputs:{x:o},backend:e,attrs:{begin:u,size:p}});return u[a]+=d,f})}const vG={kernelName:Rl,backendName:"webgl",kernelFunc:kG};const Rf="return sqrt(x);",SG=vt({opSnippet:Rf,packedOpSnippet:Rf,cpuKernelImpl:tP}),NG={kernelName:fi,backendName:"webgl",kernelFunc:SG};const TG="return x * x;",EG=vt({opSnippet:TG}),RG={kernelName:eh,backendName:"webgl",kernelFunc:EG};const Df="return (a - b) * (a - b);",DG=we({opSnippet:Df,packedOpSnippet:Df}),AG={kernelName:mi,backendName:"webgl",kernelFunc:DG};function FG(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t;if(o.dtype!=="string")throw new Error("Input must be of datatype string");const r=e.readSync(o.dataId),i=Yn(r),a=eP(i,"string",s);return e.makeTensorInfo(o.shape,"string",a)}const OG={kernelName:nh,backendName:"webgl",kernelFunc:FG};function _G({inputs:n,attrs:t,backend:e}){const{x:s}=n,o=un+`
    return x > 0.0 ? 1.0 : float(${t.alpha});
  `,r=new En(s.shape,o);return e.runWebGLProgram(r,[s],s.dtype)}const LG={kernelName:wi,backendName:"webgl",kernelFunc:_G};class MG{constructor(t,e,s){this.variableNames=["x"],this.outputShape=s;const o=s.length,r=Ot(s.length),i=Ot(s.length);let a="";if(o===1)a="coords * strides + begin";else{let l=0;a=s.map((c,u)=>(l++,s.length===1?`coords * strides[${u}] + begin[${u}]`:`coords[${l-1}] * strides[${u}] + begin[${u}]`)).join(",")}this.userCode=`
      ${r} begin = ${r}(${t});
      ${r} strides = ${r}(${e});

      void main() {
        ${i} coords = getOutputCoords();
        setOutput(getX(${a}));
      }
    `}}function PG(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{begin:r,end:i,strides:a,beginMask:l,endMask:c,ellipsisMask:u,newAxisMask:h,shrinkAxisMask:d}=s,{finalShapeSparse:p,finalShape:f,isIdentity:m,sliceDim0:g,isSimpleSlice:x,begin:b,end:w,strides:y}=Kh(o.shape,r,i,a,l,c,u,h,d);let C;if(m)C=tt({inputs:{x:o},backend:e,attrs:{shape:f}});else if(g||x){$(o.shape.length>=1,()=>`Input must have rank at least 1, got: ${o.shape.length}`);const k=Uh(b,w,y),v=Jo({inputs:{x:o},backend:e,attrs:{begin:b,size:k}});C=tt({inputs:{x:v},backend:e,attrs:{shape:f}}),e.disposeIntermediateTensorInfo(v)}else if(e.shouldExecuteOnCPU([o])){const v=e.readSync(o.dataId),N=wt(o.shape,o.dtype,v),T=nP(p,N,y,b);C=e.makeTensorInfo(f,o.dtype,T.values)}else{const v=new MG(b,y,p);C=e.runWebGLProgram(v,[o],o.dtype)}const I=tt({inputs:{x:C},backend:e,attrs:{shape:f}});return e.disposeIntermediateTensorInfo(C),I}const zG={kernelName:sh,backendName:"webgl",kernelFunc:PG};function BG(n){const{inputs:t,backend:e,attrs:s}=n,{separator:o,nGramWidths:r,leftPad:i,rightPad:a,padWidth:l,preserveShortSequences:c}=s,{data:u,dataSplits:h}=t,d=e.readSync(u.dataId),p=e.readSync(h.dataId),[f,m]=sP(d,p,o,r,i,a,l,c);return[e.makeTensorInfo([f.length],"string",f),e.makeTensorInfo(h.shape,"int32",m)]}const VG={kernelName:sm,backendName:"webgl",kernelFunc:BG};function WG(n){const{inputs:t,backend:e,attrs:s}=n,{skipEmpty:o}=s,{input:r,delimiter:i}=t;if(r.dtype!=="string")throw new Error("Input must be of datatype string");if(r.shape.length!==1)throw new Error(`Input must be a vector, got shape: ${r.shape}`);if(i.shape.length!==0)throw new Error(`Delimiter must be a scalar, got shape: ${i.shape}`);const a=e.readSync(r.dataId),l=e.readSync(i.dataId)[0],[c,u,h]=oP(a,l,o),d=u.length;return[e.makeTensorInfo([d,2],"int32",c),e.makeTensorInfo([d],"string",u),e.makeTensorInfo([2],"int32",new Int32Array(h))]}const UG={kernelName:om,backendName:"webgl",kernelFunc:WG};function GG(n){const{inputs:t,backend:e,attrs:s}=n,{numBuckets:o}=s,{input:r}=t;if(r.dtype!=="string")throw new Error("Input must be of datatype string");if(o<=0)throw new Error("Number of buckets must be at least 1");const i=e.readSync(r.dataId),a=rP(i,o);return e.makeTensorInfo(r.shape,"int32",a)}const HG={kernelName:rm,backendName:"webgl",kernelFunc:GG};const KG="return tan(x);",jG=vt({opSnippet:KG}),qG={kernelName:xi,backendName:"webgl",kernelFunc:jG};const XG=`
  float e2x = exp(-2.0 * abs(x));
  return sign(x) * (1.0 - e2x) / (1.0 + e2x);
`,YG=vt({opSnippet:XG}),JG={kernelName:bi,backendName:"webgl",kernelFunc:YG};function ZG(n){const{inputs:t,backend:e,attrs:s}=n,{tensor:o,indices:r,updates:i}=t,{sliceRank:a,numUpdates:l,sliceSize:c,strides:u,outputSize:h}=io(i,r,o.shape),d=[h/c,c];if(h===0)return e.makeTensorInfo(o.shape,r.dtype);const p=tt({inputs:{x:r},backend:e,attrs:{shape:[l,a]}}),f=tt({inputs:{x:i},backend:e,attrs:{shape:[l,c]}}),m=tt({inputs:{x:o},backend:e,attrs:{shape:d}}),g=new Jd(l,a,p.shape.length,f.shape.length,u,d,!1,!0),x=e.runWebGLProgram(g,[f,p,m],m.dtype),b=tt({inputs:{x},backend:e,attrs:{shape:o.shape}});return e.disposeIntermediateTensorInfo(p),e.disposeIntermediateTensorInfo(f),e.disposeIntermediateTensorInfo(m),e.disposeIntermediateTensorInfo(x),b}const QG={kernelName:Yf,backendName:"webgl",kernelFunc:ZG};class tH{constructor(t,e){this.variableNames=["A"];const s=new Array(t.length);for(let i=0;i<s.length;i++)s[i]=t[i]*e[i];this.outputShape=s,this.rank=s.length;const o=Ot(this.rank),r=eH(t);this.userCode=`
      void main() {
        ${o} resRC = getOutputCoords();
        setOutput(getA(${r}));
      }
    `}}function eH(n){const t=n.length;if(t>5)throw Error(`Tile for rank ${t} is not yet supported`);if(t===1)return`imod(resRC, ${n[0]})`;const e=["resRC.x","resRC.y","resRC.z","resRC.w","resRC.u"],s=[];for(let o=0;o<n.length;o++)s.push(`imod(${e[o]}, ${n[o]})`);return s.join()}function h1(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{reps:r}=s;if(o.dtype==="string"||o.shape.length>5){const l=e.readSync(o.dataId),c=o.dtype==="string"?l.map(d=>ps(d)):l,u=wt(o.shape,o.dtype,c),h=aP(u,r);return e.makeTensorInfo(h.shape,h.dtype,h.values)}const i=new tH(o.shape,r);return e.runWebGLProgram(i,[o],o.dtype)}const nH={kernelName:yi,backendName:"webgl",kernelFunc:h1};class sH{constructor(t){this.variableNames=["x","indices"],this.customUniforms=[{name:"n",type:"int"},{name:"firstPass",type:"int"},{name:"negativeInf",type:"float"},{name:"dir",type:"int"},{name:"inc",type:"int"}],this.outputShape=t,this.userCode=`
       void main() {
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int elemIdx = coords[1];

         // We compare elements pair-wise within a group of size 2 * inc.
         // The comparing rule for each group alternates between ascending
         // and descending. Within each group, we compare each pair at
         // positions i and i+inc. To decide whether an element at position i
         // is x0 or x1, we mod it by 2 * inc, if the result is smaller than
         // inc, it is in the first half of the group, we denote it as x0,
         // otherwise we denote it as x1.
         // For example, as shown in the Bitonic top K paper referenced above,
         // Figure5(a) shows that element[1] is in the
         // second half of the group when group size is 2, but it is in the
         // first half of the group when group size is 4.

         bool isFirstInPair = imod(elemIdx, 2 * inc) < inc;
         int i = isFirstInPair ? elemIdx : elemIdx - inc;

         int i0 = firstPass == 1 ? i : int(getIndices(batch, i));
         int i1 = firstPass == 1 ? i + inc : int(getIndices(batch, i + inc));
         float x0 = i0 < n ? getX(batch, i0) : negativeInf;
         float x1 = i1 < n ? getX(batch, i1) : negativeInf;

         // Denotes which direction indices are in (ascending or descending).
         bool reverse = imod(elemIdx, 2 * dir) >= dir;
         bool isGreater = x0 > x1 || (x0 == x1 && i1 > i0);
         if (reverse == isGreater) { // Elements in opposite order of direction
           int iTemp = i0;
           i0 = i1;
           i1 = iTemp;
         }
         if (isFirstInPair) {
            setOutput(float(i0));
         } else {
            setOutput(float(i1));
         }
       }
     `}}class oH{constructor(t){this.variableNames=["x","indices"],this.customUniforms=[{name:"n",type:"int"},{name:"firstPass",type:"int"},{name:"k",type:"int"}],this.outputShape=t,this.userCode=`
    void main() {
         // Takes max of indices (0, k), (1, k + 1), (2, k + 2) ...
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int elemIdx = coords[1];

         // The output size is half of the previous size.
         // If the previous sequence is | | | | _ _ _ _  | | | |  _ _ _ _ (k=4),
         // we only need to output the indices at positions |, the indices at
         // positions _ can be thrown away, see Figure5(b) After Phase 2
         // (Merge phase) in the Bitonic Top K paper referenced above.
         // For example, the paper shows we only need to output the orange bars.
         // The output sequence should look like this | | | | | | | |.
         // Because the sequence is halved, to map the output index back
         // to the previous sequence to find the corresponding value,
         // we need to double the index. When we double the index,
         // we basically interpolate a position, so 2i looks like
         // | _ | _ | _ | _ | _ | _ | _. We move the | to the first k position
         // of each 2k positions by - elemIdx % k. E.g. for output at
         // index 4,5,6,7, we want to get the corresponding element at
         // original index 8,9,10,11, for output at index 8,9,10,11,
         // we want to get the corresponding element at original index
         // 16,17,18,19, so on and so forth.

         int i = elemIdx < k ? elemIdx : (elemIdx * 2 - imod(elemIdx, k));
         int i0 = firstPass == 1 ? i : int(getIndices(batch, i));
         int i1 = firstPass == 1 ? i + k : int(getIndices(batch, i + k));

         float x0 = getX(batch, i0);
         float x1 = i1 < n ? getX(batch, i1) : x0;

         setOutput(x0 >= x1 ? float(i0) : float(i1));
       }
     `}}function As(n,t){t!==null&&n.disposeIntermediateTensorInfo(t)}function Af(n){let t=1;for(;t<n;)t*=2;return t}function rH(n){const{inputs:t,backend:e,attrs:s}=n,{x:o}=t,{k:r,sorted:i}=s,a=L().getNumber("TOPK_LAST_DIM_CPU_HANDOFF_SIZE_THRESHOLD"),l=L().getNumber("TOPK_K_CPU_HANDOFF_THRESHOLD"),c=o.shape,u=c[c.length-1];if(e.shouldExecuteOnCPU([o])||u<a||r>l){const T=e.readSync(o.dataId),[O,P]=lP(T,c,o.dtype,r,i);return[e.makeTensorInfo(O.shape,O.dtype,O.values),e.makeTensorInfo(P.shape,P.dtype,P.values)]}if(r===0)return c[c.length-1]=0,[e.makeTensorInfo(c,o.dtype,[]),e.makeTensorInfo(c,"int32",[])];if(u===1)return[o,Wi({attrs:{shape:c,dtype:"int32",value:0},backend:e})];const h=e.texData.get(o.dataId),d=h!==null&&h.isPacked,p=d?e.unpackTensor(o):o,m=W(c)/u,g=tt({inputs:{x:p},attrs:{shape:[m,u]},backend:e});d&&As(e,p);const x=Af(r),b=Af(u);let w=null;const y=()=>w===null?[g,g]:[g,w],C=(T,O,P)=>{const z=y(),B=new sH(P),G=[[u],[w===null?1:0],[Number.NEGATIVE_INFINITY],[T],[O]],H=w;w=e.runWebGLProgram(B,z,"int32",G),As(e,H)};for(let T=1;T<x;T*=2){const O=T*2;for(let P=T;P>=1;P/=2)C(O,P,[m,b])}for(let T=b;T>x;T/=2){const O=y(),P=new oH([m,T/2]),B=[[u],[w===null?1:0],[x]],M=w;w=e.runWebGLProgram(P,O,"int32",B),As(e,M);const G=x/2,H=G*2;for(let U=G;U>=1;U/=2)C(H,U,w.shape)}let I=w;w=Jo({inputs:{x:w},backend:e,attrs:{begin:0,size:[m,r]}}),As(e,I);let k=s1({inputs:{x:g,indices:w},backend:e,attrs:{axis:1,batchDims:1}});As(e,g);const v=c.slice(0,-1);v.push(r),I=w,w=tt({inputs:{x:w},attrs:{shape:v},backend:e}),As(e,I);const N=k;return k=tt({inputs:{x:k},attrs:{shape:v},backend:e}),As(e,N),[k,w]}const iH={kernelName:oh,backendName:"webgl",kernelFunc:rH};class aH{constructor(t,e,s,o,r,i){this.variableNames=["Image","Transforms"],this.outputShape=i;const a=s==="nearest"?1:2;let l;switch(o){case"constant":l=1;break;case"reflect":l=2;break;case"wrap":l=3;break;case"nearest":l=4;break;default:l=1;break}this.userCode=`
            float mapCoord(float outCoord, float len) {
              float inCoord = outCoord;
              if(${l} == 2) {
                if (inCoord < 0.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz2 = 2.0 * len;
                    if (inCoord < sz2) {
                      inCoord = sz2 * float(int(float(-inCoord / sz2))) +
                      inCoord;
                    }
                    inCoord = inCoord < -len ? inCoord + sz2 : -inCoord - 1.0;
                  }
                } else if (inCoord > len - 1.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz2 = 2.0 * len;
                    inCoord -= sz2 * float(int(float(inCoord / sz2)));
                    if (inCoord >= len) {
                      inCoord = sz2 - inCoord - 1.0;
                    }
                  }
                }
                return clamp(inCoord, 0.0, len - 1.0);
              } else if (${l} == 3) {
                if (inCoord < 0.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz = len - 1.0;
                    inCoord += len * (float(int(float(-inCoord / sz))) + 1.0);
                  }
                } else if (inCoord > len - 1.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz = len - 1.0;
                    inCoord -= len * float(int(float(inCoord / sz)));
                  }
                }
                return clamp(inCoord, 0.0, len - 1.0);
              } else if (${l} == 4) {
                return clamp(outCoord, 0.0, len - 1.0);
              } else {
                return outCoord;
              }
            }

            float readWithFillValue(int batch, int coordY, int coordX,
              int channel) {
              float outputValue;
              if (0 <= coordY && coordY < ${t} && 0 <= coordX && coordX < ${e}) {
                  outputValue = getImage(batch, coordY, coordX, channel);
              } else {
                outputValue = float(${r});
              }
              return outputValue;
            }

            void main() {
              ivec4 coords = getOutputCoords();
              float outputValue;
              int batch = coords[0];
              int x = coords[2];
              int y = coords[1];
              int channel = coords[3];
              float xf = float(x);
              float yf = float(y);
              float a1 = getTransforms(batch, 0);
              float a2 = getTransforms(batch, 1);
              float a3 = getTransforms(batch, 2);
              float b1 = getTransforms(batch, 3);
              float b2 = getTransforms(batch, 4);
              float b3 = getTransforms(batch, 5);
              float c1 = getTransforms(batch, 6);
              float c2 = getTransforms(batch, 7);
              float projection = c1 * xf + c2 * yf + 1.0;
              if (projection == 0.0) {
                outputValue = float(${r});
              } else {
                float inX = (a1 * xf + a2 * yf + a3) / projection;
                float inY = (b1 * xf + b2 * yf + b3) / projection;
                float mapX = mapCoord(inX, float(${e}));
                float mapY = mapCoord(inY, float(${t}));

                if (${a} == 1) {
                  int coordY = int(round(mapY));
                  int coordX = int(round(mapX));
                  outputValue = readWithFillValue(batch, coordY, coordX,
                    channel);
                } else {
                  float yFloor = floor(mapY);
                  float xFloor = floor(mapX);
                  float yCeil = yFloor + 1.0;
                  float xCeil = xFloor + 1.0;
                  float valueYFloor = (xCeil - mapX) *
                  readWithFillValue(batch, int(yFloor), int(xFloor), channel) +
                  (mapX - xFloor) *
                  readWithFillValue(batch, int(yFloor), int(xCeil), channel);
                  float valueYCeil = (xCeil - mapX) *
                  readWithFillValue(batch, int(yCeil), int(xFloor), channel) +
                  (mapX - xFloor) *
                  readWithFillValue(batch, int(yCeil), int(xCeil), channel);
                  outputValue = (yCeil - mapY) * valueYFloor +
                  (mapY - yFloor) * valueYCeil;
                }
              }
              setOutput(outputValue);
            }
        `}}function lH(n){const{inputs:t,backend:e,attrs:s}=n,{image:o,transforms:r}=t,{interpolation:i,fillMode:a,fillValue:l,outputShape:c}=s,[u,h,d,p]=o.shape,[f,m]=c??[h,d],g=[u,f,m,p],x=new aH(h,d,i,a,l,g);return e.runWebGLProgram(x,[o,r],"float32")}const cH={kernelName:rh,backendName:"webgl",kernelFunc:lH};function uH(n){const{inputs:t,attrs:e,backend:s}=n,{axis:o}=e,{x:r}=t;zi(r,"unique"),console.warn("WARNING: ","UI might be locked temporarily as data is being downloaded");const i=s.readSync(r.dataId),{outputValues:a,outputShape:l,indices:c}=cP(i,o,r.shape,r.dtype);return[s.makeTensorInfo(l,r.dtype,a),s.makeTensorInfo([c.length],"int32",c)]}const hH={kernelName:ih,backendName:"webgl",kernelFunc:uH};function dH(n){const{inputs:t,backend:e,attrs:s}=n,{value:o}=t;let{axis:r}=s;r<0&&(r+=o.shape.length);const i=o,a=i.shape.length,l=o.shape[r],c=new Array(a-1);let u=0;for(let m=0;m<a;m++)m!==r&&(c[u++]=i.shape[m]);const h=[],d=new Array(a).fill(0),p=i.shape.slice();p[r]=1;const f=new Array(l);for(let m=0;m<f.length;m++){d[r]=m;const g=Jo({inputs:{x:i},backend:e,attrs:{begin:d,size:p}}),x=tt({inputs:{x:g},backend:e,attrs:{shape:c}});f[m]=x,h.push(g)}return h.forEach(m=>e.disposeIntermediateTensorInfo(m)),f}const pH={kernelName:Al,backendName:"webgl",kernelFunc:dH};class fH{constructor(t,e){this.variableNames=["x","segmentIds"];const s=t.windowSize,o=t.batchSize,r=t.inSize,i=t.numSegments,a=i*Math.ceil(r/s);this.outputShape=[o,a];const l="0.0",c="sumValue",u=Math.floor(s/4)*4,h=s%4,d=`
        sumValue += dot(values, segFilter);
    `;let p="";r%s>0&&(p=`
        if (inIdx < 0 || inIdx >= ${r}) {
          return initializationValue;
        }
      `);let f="";r%s>0&&(f=`
        if (inIdx < 0 || inIdx >= ${r}) {
          return -1.0;
        }
      `),this.userCode=`
      const float initializationValue = ${l};

      float getValue(int batch, int inIdx) {
        ${p}
        return getX(batch, inIdx);
      }

      float getSegmentIdAtIndex(int inIdx) {
        ${f}
        return getSegmentIds(inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = int(floor(float(outIdx) / float(
          ${i})) * float(${s}));
        int currentSeg = int(mod(float(outIdx), float(${i})));

        float sumValue = 0.0;

        for (int i = 0; i < ${u}; i += 4) {
          int inIdx = inOffset + i;
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 2)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 3)) == currentSeg ? 1 : 0
          );

          ${d}
        }

        int inIdx = inOffset + ${u};
        if (${h===1}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            initializationValue,
            initializationValue,
            initializationValue
          );

          int inIdxSeg = int(getSegmentIdAtIndex(inIdx));

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            0,
            0,
            0
          );

          ${d}
        } else if (${h===2}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            initializationValue,
            initializationValue
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
              0,
              0
          );

          ${d}
        } else if (${h===3}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            initializationValue
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 2)) == currentSeg ? 1 : 0,
            0
          );

          ${d}
        }
        setOutput(${c});
      }
    `}}function mH(n){const{inputs:t,backend:e,attrs:s}=n,{x:o,segmentIds:r}=t,{numSegments:i}=s,a=o.shape.length,l=[];let c=0;const u=jt([c],a);let h=o;u!=null&&(h=De({inputs:{x:o},backend:e,attrs:{perm:u}}),l.push(h),c=Zt(1,a)[0]);const d=Kg(h.shape,c,i),p=W([h.shape[c]]),f=tt({inputs:{x:h},backend:e,attrs:{shape:[-1,p]}});l.push(f);const m=lh(o.dtype),g=(y,C,I,k,v)=>{const N=y.shape[0],T=y.shape[1],O=Hg(T,v),P={windowSize:O,inSize:T,batchSize:N,numSegments:v},z=new fH(P,C),B=e.compileAndRun(z,[y,I],k);if(l.push(B),B.shape[1]===v)return B;const M=u1({backend:e,attrs:{start:0,stop:v,step:1,dtype:"float32"}}),G=h1({inputs:{x:M},backend:e,attrs:{reps:[T/O]}});return l.push(M),l.push(G),g(B,C,G,k,v)},x=g(f,"unsortedSegmentSum",r,m,i),b=tt({inputs:{x},backend:e,attrs:{shape:d}});let w=b;if(u!=null){l.push(b);const y=Is(u);w=De({inputs:{x:w},backend:e,attrs:{perm:y}})}return l.forEach(y=>e.disposeIntermediateTensorInfo(y)),w}const gH={kernelName:Fl,backendName:"webgl",kernelFunc:mH};const xH=[t3,n3,r3,l3,u3,p3,m3,x3,C3,I3,S3,E3,A3,L3,z3,V3,U3,j3,X3,J3,ez,lz,uz,fz,gz,$z,kz,Tz,MP,Dz,Lz,Bz,Kz,Xz,Jz,Qz,eB,rB,lB,hB,pB,mB,xB,wB,$B,SB,TB,DB,OB,LB,BB,GB,qB,JB,tV,eV,sV,rV,aV,cV,hV,mV,bV,CV,IV,SV,EV,FV,MV,LP,zV,Oz,WV,HV,qV,zP,ZV,nW,oW,lW,hW,mW,bW,$W,SW,EW,DW,_W,MW,zW,UW,HW,jW,XW,JW,e4,r4,c4,x4,WP,C4,k4,N4,R4,bz,F4,_4,M4,B4,G4,VP,K4,q4,Y4,Z4,Q4,yz,p4,nU,iU,uU,GP,fU,xU,CU,kU,TU,RU,FU,LU,zU,WU,HU,qU,ZU,eG,rG,lG,iz,m4,hG,pG,mG,xG,yG,CG,IG,vG,NG,RG,AG,OG,LG,zG,VG,UG,HG,f4,JP,qG,JG,QG,nH,iH,cH,ZP,hH,pH,gH,O4];for(const n of xH)am(n);export{We as a,Tt as b,R as c,ut as d,yH as e,Y as f,CH as g,$H as l,ee as m,Wl as n,wH as r,pt as s,_ as t};
