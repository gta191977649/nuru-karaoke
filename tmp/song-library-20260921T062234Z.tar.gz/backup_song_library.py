import os
import sqlite3
import tarfile
from pathlib import Path

backup_dir = Path(os.environ["SONG_SYNC_BACKUP_DIR"])
backup_dir.mkdir(parents=True, exist_ok=False)

source = sqlite3.connect("/data/db.sqlite3")
destination = sqlite3.connect(str(backup_dir / "db.sqlite3"))
try:
    source.backup(destination)
finally:
    destination.close()
    source.close()

media_root = Path("/data/media")
with tarfile.open(backup_dir / "media.tar.gz", "w:gz") as archive:
    if media_root.exists():
        archive.add(media_root, arcname="media")

print(backup_dir)
