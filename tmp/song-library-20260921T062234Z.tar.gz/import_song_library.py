import json
from django.db import transaction
from songs.models import ArtistIndex, Song, Tag

MANIFEST_PATH = "/tmp/song-library-manifest.json"

with open(MANIFEST_PATH, "r", encoding="utf-8") as handle:
    manifest = json.load(handle)

if manifest.get("format") != 2:
    raise RuntimeError("Unsupported song-library manifest format")

created = 0
updated = 0

with transaction.atomic():
    # Artist IDs are part of song codes, so silently remapping them is unsafe.
    for source in manifest["artists"]:
        by_id = ArtistIndex.objects.filter(pk=source["id"]).first()
        by_name = ArtistIndex.objects.filter(name=source["name"]).first()
        if by_id and by_id.name != source["name"]:
            raise RuntimeError(
                f"Artist ID conflict: local {source['id']}={source['name']!r}, "
                f"server={by_id.name!r}"
            )
        if by_name and by_name.pk != source["id"]:
            raise RuntimeError(
                f"Artist name conflict: {source['name']!r} has local ID "
                f"{source['id']} but server ID {by_name.pk}"
            )
        artist = by_id or ArtistIndex(id=source["id"], name=source["name"])
        artist.name = source["name"]
        artist.next_song_no = max(artist.next_song_no, source["next_song_no"])
        artist.save(force_insert=artist._state.adding)

    tags = {}
    for name in manifest["tags"]:
        tags[name], _ = Tag.objects.get_or_create(name=name)

    scalar_fields = (
        "title", "artist", "artist_no", "song_no", "language",
        "duration_seconds", "bpm", "key", "lrc_offset", "is_published",
    )
    file_fields = ("midi_file", "lrc_file", "cover_image")

    for source in manifest["songs"]:
        song = Song.objects.select_for_update().filter(code=source["code"]).first()
        if song is None:
            song = Song(code=source["code"])
            created += 1
        else:
            updated += 1
        for field in scalar_fields:
            setattr(song, field, source[field])
        for field in file_fields:
            getattr(song, field).name = source[field]
        song.save()
        song.tags.set([tags[name] for name in source["tags"]])

print(json.dumps({
    "created": created,
    "updated": updated,
    "server_song_count": Song.objects.count(),
}, ensure_ascii=False))
