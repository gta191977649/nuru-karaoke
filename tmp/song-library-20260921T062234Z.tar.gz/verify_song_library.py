import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath

MANIFEST_PATH = os.environ.get("SONG_SYNC_MANIFEST", "/tmp/song-library-manifest.json")
MEDIA_ROOT = Path(os.environ.get("SONG_SYNC_MEDIA_ROOT", "/data/media")).resolve()
strict = "--strict" in sys.argv

with open(MANIFEST_PATH, "r", encoding="utf-8") as handle:
    manifest = json.load(handle)

if manifest.get("format") != 2 or not isinstance(manifest.get("media"), dict):
    raise RuntimeError("Manifest does not contain checksummed media metadata")

results = {"matching": [], "changed": [], "missing": []}
for name, expected in sorted(manifest["media"].items()):
    relative = PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise RuntimeError(f"Unsafe media path: {name!r}")
    path = MEDIA_ROOT.joinpath(*relative.parts).resolve()
    if MEDIA_ROOT not in path.parents:
        raise RuntimeError(f"Media path escapes MEDIA_ROOT: {name!r}")
    if not path.is_file():
        results["missing"].append(name)
        continue
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    actual_hash = digest.hexdigest()
    actual_size = path.stat().st_size
    if actual_hash == expected["sha256"] and actual_size == expected["size"]:
        results["matching"].append(name)
    else:
        results["changed"].append(name)

print(json.dumps({key: len(value) for key, value in results.items()}, ensure_ascii=False))
for category in ("changed", "missing"):
    for name in results[category]:
        print(f"{category.upper()} {name}")

if strict and (results["changed"] or results["missing"]):
    raise RuntimeError("Server media checksum verification failed")
